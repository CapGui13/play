# Table d'enchères — Bridge à distance

Application web statique permettant de 2 à 4 joueurs, chacun sur son propre écran, de
s'entraîner aux enchères en temps réel sur des donnes importées (fichier `.pbn` ou `.lin`
exporté depuis le générateur de donnes).

Aucun serveur : la connexion entre les navigateurs se fait directement en pair-à-pair
(WebRTC, via le service public gratuit PeerJS pour la mise en relation initiale, et deux
relais TURN gratuits et indépendants en secours si la connexion directe échoue — voir
`ICE_CONFIG` dans `peer-connection.js`). Le site peut donc être hébergé gratuitement sur
GitHub Pages.

## Composition libre de la table

Il n'y a pas de "modes" figés : l'hôte crée une partie, atterrit dans un **salon
d'attente**, et voit apparaître chaque participant au fil de leur connexion (avec un
pseudo par défaut du style "Guest #2", que chacun peut changer — le changement se
répercute immédiatement chez tout le monde).

Dans ce salon, l'hôte assigne librement chacun des 4 sièges (Nord/Est/Sud/Ouest) à
n'importe quel participant présent — y compris **la même personne sur deux sièges**, et y
compris lui-même. Un siège non assigné est automatiquement joué par un robot qui passe
systématiquement. Cette seule mécanique permet de reproduire toutes les configurations :

- **2 joueurs, binôme** : un invité et l'hôte sur Nord et Sud, Est-Ouest laissés vides (robot).
- **2 joueurs, diagonale** : l'hôte sur Sud+Ouest, l'invité sur Nord+Est (ou l'inverse).
- **3 joueurs, "maître du jeu"** : l'hôte sur Est **et** Ouest, deux invités sur Nord et Sud.
- **4 joueurs** : chacun un seul siège.
- Toute autre combinaison qui a du sens pour vous.

Une fois la table composée, l'hôte charge le fichier de donnes et lance la partie ; chaque
participant reçoit alors uniquement la ou les mains qu'on lui a assignées.

## Déploiement sur GitHub Pages

1. Crée un nouveau dépôt GitHub (ou utilise un dépôt existant).
2. Place-y les fichiers de ce dossier (`index.html`, `styles.css`, `app.js`,
   `bidding-rules.js`, `deal-parser.js`, `peer-connection.js`, `manifest.json`, `sw.js`,
   le dossier `icons/`, le dossier `donnes/`) à la racine.
3. Pousse-les :
   ```
   git init
   git add .
   git commit -m "Table d'enchères"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/<ton-depot>.git
   git push -u origin main
   ```
4. Sur GitHub : **Settings → Pages → Source : Deploy from a branch**, choisis la branche
   `main` et le dossier `/ (root)`, puis **Save**.
5. Après une minute ou deux, le site est accessible à
   `https://<ton-compte>.github.io/<ton-depot>/`.

PLAY lui-même est statique sur GitHub Pages, mais les fonctions réseau actuelles s'appuient sur l'API-GEN déjà déployée (Vercel/Upstash/Pusher). Pour un nouveau déploiement indépendant, ces services doivent être configurés côté API.

## Utilisation

**L'hôte (celui qui crée la partie)** :
1. Ouvre le site, clique sur **"Créer une partie"** → atterrit dans le salon.
2. Un code à 4 lettres apparaît (et un lien à partager, qui contient déjà le code, et
   rejoint automatiquement la partie une fois ouvert).
3. Partage ce code ou ce lien aux autres joueurs.
4. Au fil de leur connexion, chacun apparaît dans la liste des participants du salon.
5. L'hôte assigne chacun à un ou plusieurs sièges via les menus déroulants Nord/Est/Sud/Ouest
   (un siège laissé sur "— (robot)" sera joué automatiquement — voir "Enchères automatiques
   des robots" plus bas).
6. L'hôte choisit le fichier `.pbn` ou `.lin` à charger, puis clique sur
   **"Commencer la partie"**.

**Les invités** :
1. Ouvrent le lien partagé (rejoint automatiquement), ou saisissent le code manuellement
   sur l'écran d'accueil puis cliquent sur **"Rejoindre"**.
2. Arrivent dans le même salon, où ils peuvent changer leur pseudo (visible par tous en
   temps réel) et voir la composition de la table se dessiner au fur et à mesure.
3. Une fois que l'hôte lance la partie, la table de jeu apparaît automatiquement, avec
   le(s) siège(s) qui leur a/ont été attribué(s).

**Pendant la partie** :
- Chaque joueur ne voit que les mains qu'il contrôle (une ou deux). Sans siège assigné, on
  suit la partie en **kibbitz** : les 4 mains sont visibles dès le début de la donne.
  Quand on contrôle plusieurs sièges (mode "maître du jeu" ou diagonale), celle dont c'est
  le tour est mise en valeur (halo doré, léger balayage lumineux) et les autres grisées,
  pour repérer d'un coup d'œil laquelle demande une action.
- La boîte d'enchères n'autorise que les annonces légales, et seulement quand c'est
  votre tour.
- Une fois l'enchère terminée (3 passes après une annonce, ou 4 passes d'entrée), le
  contrat final s'affiche, avec un bouton pour passer à la donne suivante.
- Le bouton **"Recommencer l'enchère"** relance l'enchère de la donne en cours. Seuls les
  joueurs actifs (assignés à au moins un siège) peuvent recommencer l'enchère ou changer
  de donne ; un kibbitz ne peut que regarder.
- Le bouton **"Demander un undo"** propose d'annuler la dernière annonce (utile en cas de
  mauvais clic). Si l'équipe adverse compte un humain, elle doit accepter ou refuser ; si
  elle n'est faite que de robots (ou si vous jouez les deux camps), l'annulation est
  immédiate.
- Les flèches **◀ ▶** à côté du numéro de donne permettent à l'hôte de sauter à la donne
  précédente ou suivante à tout moment (même en pleine enchère), sans attendre la fin de
  l'enchère en cours. Seul l'hôte les voit ; les autres joueurs continuent d'utiliser le
  bouton "Donne suivante →" qui n'apparaît qu'une fois l'enchère terminée.

## Corrections diverses (voir échange avec Guillaume)

- **Avertissement contraintes obsolètes** : modifier un champ de contraintes après avoir
  généré affiche un rappel ("cliquez de nouveau sur Générer") plutôt que de laisser croire
  que les donnes déjà générées reflètent les derniers réglages — rien ne se régénère
  automatiquement, comme pour les deux autres sources (fichier, bibliothèque).
- **Wizz sur iPhone** : le tremblement anime maintenant `.app-container` plutôt que
  `<body>` directement — iOS Safari n'applique pas de façon fiable une animation
  `transform` posée sur `<body>` (lié à sa gestion du scroll/de la barre d'URL).
- **Rôles d'undo inversés** : un ancien cas spécial pour l'hôte annulait toujours la toute
  dernière case du tableau d'enchères, quel qu'en soit l'auteur — si un robot passait
  automatiquement juste après l'annonce de l'hôte (avant qu'il clique "undo"), l'hôte
  annulait ce passe robot au lieu de sa propre annonce, ce qui faussait le calcul de qui
  doit valider (parfois personne, parfois la mauvaise personne). Retiré ce cas spécial :
  hôte et invités suivent maintenant exactement la même logique (retrouver la dernière
  annonce parmi les sièges qu'on contrôle soi-même, pas juste la dernière case du tableau).

## Contraintes optionnelles pour les donnes aléatoires

Le bouton "⚙️ Contraintes avancées" (repliable, sous le générateur de donnes aléatoires)
permet de régler, pour chacun des 4 sièges indépendamment (voir échange avec Guillaume) :
- une fourchette de points H (min et/ou max) ;
- une longueur minimale dans une couleur choisie (ex. "Sud a 5+ cartes à Pique").

Et pour chaque ligne (Nord-Sud, Est-Ouest) :
- une fourchette de points H combinés (ex. "NS a 24+ à eux deux").

Toutes ces contraintes sont optionnelles et cumulables (un champ vide = pas de contrainte
sur ce point) ; elles s'ajoutent à la contrainte fixe déjà existante (12H+ dans toute
ligne occupée par 2 humains). Si des fourchettes trop serrées empêchent de satisfaire
toutes les contraintes simultanément après 500 tentatives, la donne est générée quand même
(mieux vaut ça qu'un blocage) et un avertissement s'affiche précisant combien de donnes
n'ont pas pu toutes les respecter.

## Navigation entre les donnes

Chaque donne garde sa propre enchère (`deals[i].auctionHistory`) au lieu d'une seule
variable de travail écrasée à chaque changement de donne : revenir sur une donne déjà
jouée réaffiche son enchère et son contrat tels quels, plutôt que de repartir de zéro.

**Export de session** (voir échange avec Guillaume) : le bouton "📦 Exporter la session"
(en-tête de l'écran de jeu, à côté d'Undo/Recommencer) télécharge un fichier PBN
regroupant toutes les donnes dont l'enchère est terminée — mains, enchère réellement
menée, vulnérabilité — pour donner un retour précis sur une session ("donne 2, Sud a
contré mais..."). Un fichier PBN standard accepte nativement plusieurs donnes à la suite,
donc réutilise directement `buildPlayedDealPBN` (déjà utilisé par l'export d'une seule
donne) pour chacune. Contrairement à l'export d'une seule donne, aucun serveur n'est
impliqué ici : téléchargement direct dans le navigateur, disponible à l'hôte comme à tout
joueur assis (à la différence de l'export unitaire, réservé à l'hôte puisque lui seul
écrit sur le repo GitHub).

## Enchères automatiques des robots

### Moteur sélectionnable : PONS ou BRL

Le salon de l'hôte propose désormais trois moteurs lorsque **Robots actifs** est coché :

- **PONS v2.61** : moteur historique de PLAY, avec les conventions/ajustements SEF du projet et l'option **1SA faible (12-14H)**.
- **BRL-SL** : réseau neuronal BRL supervisé, entraîné par imitation des enchères WBridge5. C'est le mode BRL recommandé dans PLAY pour des enchères lisibles par un humain.
- **BRL-RL-FSP** : modèle BRL renforcé par Fictitious Self Play. Il reste embarqué à titre expérimental/documentaire mais est **désactivé dans le menu PLAY** ; une ancienne préférence RL-FSP est automatiquement migrée vers BRL-SL.

BRL s'exécute directement dans le navigateur : PLAY encode la main, la vulnérabilité et l'historique dans l'observation PGX de 480 valeurs, calcule les 38 logits du réseau, puis applique deux filtres avant l'argmax : la légalité `isCallLegal()` et un garde-fou de cohérence bridge. Ce dernier élimine les violations grossières (par exemple une ouverture naturelle au palier de 1 avec 2 HCP, un contre/surcontre pratiquement sans jeu ou une ouverture incompatible avec la longueur promise) tout en restant volontairement permissif en cours d'enchères pour ne pas casser Stayman, Texas, cue-bids ou autres conventions artificielles. Il n'y a aucun repli silencieux vers PONS si le chargement BRL échoue.

Les poids BRL (~14 Mo par modèle) sont chargés à la première utilisation depuis une révision GitHub immuable, leur taille et leur Git blob SHA-1 sont contrôlés, puis ils sont conservés dans le cache runtime du Service Worker. Le code et les modèles BRL d'origine sont sous licence Apache-2.0 ; l'attribution et la licence sont dans `brl/`.

**Limite actuelle du mode différé :** le relais serveur déployé sait décider les tours robots avec PONS, mais n'embarque pas encore BRL. PLAY refuse donc proprement de démarrer une session différée contenant des robots si BRL est sélectionné. Les sessions live peuvent utiliser BRL normalement. L'option 1SA faible reste PONS-only.

**Outil de diagnostic** : chaque annonce jouée par un robot est tapable dans le relevé
d'enchères (petit point discret sur la case) et affiche pourquoi elle a été choisie
(points H/HL calculés, branche de décision, contexte) — pratique pour repérer directement
un seuil à corriger plutôt que de décortiquer une capture d'écran.

Un siège laissé sur "— (robot)" n'ouvre plus systématiquement passe : il applique un moteur
d'enchères volontairement simplifié plutôt qu'un vrai simulateur (hors de portée
raisonnable pour ce projet — même les logiciels commerciaux s'y cassent régulièrement les
dents), avec des seuils repris du **SEF** (Système d'Enchères Français), la référence
utilisée en club — voir [le dictionnaire des enchères de bridge-chailley.fr](https://www.bridge-chailley.fr/dictionnaire-des-encheres/),
notamment sa fiche "Ouvertures", plutôt qu'une généralisation approximative :

- **Comptage en points H+L** (honneurs + longueur : +1 par carte au-delà de la 4e dans une
  couleur de 5+ cartes) pour la plupart des décisions, à l'exception explicite d'1SA
  (compté en H purs, comme le veut le SEF).
- **Ouverture** : 1SA avec 15-17H et une main équilibrée (4333, 4432 ou 5332) ; 2SA avec
  20-21HL équilibrée ; barrages faibles 8-12HL (2 à une majeure 6ème, 3 à 7 cartes, 4 à 8
  cartes) ; sinon la couleur la plus longue à partir de 12HL (règle "majeure 5ème,
  meilleure mineure" : une majeure de 4 cartes n'ouvre jamais, exception SEF du 3-3 aux
  mineures sans majeure 5e qui ouvre toujours du ♣). Passe en dessous de 12HL.
- **Réponse à l'ouverture du partenaire** : après une ouverture à la mineure, une majeure
  4+ cartes franche est montrée avant de soutenir la mineure (principe de base : chercher
  un fit à la majeure d'abord). **Soutien à une majeure** : échelle complète des soutiens
  directs, reprise du document SEF "L'expression des soutiens majeurs" (Christian Maury,
  FFB) que Guillaume a fourni :
  - 6-10HLD, fit 3 ou 4 cartes → soutien simple au palier 2
  - 11-12HLD, fit exactement 3 cartes → 2SA conventionnel (ne promet pas une main
    régulière)
  - 11-12HLD, fit 4+ cartes → soutien au palier 3, non-forcing
  - 13-15HLD, sans aucun singleton → 3SA fitté
  - 13-15HLD avec une courte (singleton/chicane) et 4+ atouts → splinter (saut double
    dans la couleur courte)
  - Barrage (5+ atouts, une courte, main faible en H) → saut direct à la manche,
    indépendamment du seuil habituel de points (loi des levées totales)

  **Soutien à une mineure** : logique plus simple (3+ cartes, un fit c'est 8 cartes à eux
  deux) — 6H si le partenaire a promis 5+ cartes (via une intervention, jamais via une
  ouverture à la mineure elle-même), sinon 6HL. Au-delà, une nouvelle couleur à partir de
  11HL (seuil SEF), sinon un repli à SA à partir de 6HL. Réponse à 1SA/2SA : manche
  directe à la majeure si 5+ cartes franches (repérage simple du fit, pas un vrai
  Stayman/Texas), sinon 3SA (jamais 4SA — bug corrigé à l'audit) dès 10HL après 1SA, ou
  seulement 4HL après 2SA (l'ouverture promet déjà beaucoup plus de points).
- **Rebid de l'ouvreur** (voir échange avec Guillaume) : une main d'ouverture nettement
  excédentaire (18HL+) peut reparler UNE FOIS après la réponse du partenaire, pour éviter
  les partiels absurdes (22H qui passent sur une réponse minimale). Volontairement très
  borné pour ne jamais compromettre la terminaison de l'enchère : un seul rebid par
  donne, jamais de contrôle ni de Blackwood — juste une visée directe de la manche si un
  fit est confirmé, ou une montée dans la couleur du partenaire si elle lui convient.
  N'implémente pas les "vrais" soutiens différés du document (fit montré à un deuxième
  tour) ni les enchères d'essai/de contrôle — hors de portée de ce filet ciblé.
- **Intervention sur l'ouverture d'un adversaire** : **contre d'appel** si la main s'y
  prête (12HL+, courte dans la couleur adverse — 0-2 cartes —, support raisonnable dans
  les 3 autres), sinon une intervention naturelle (5+ cartes, HL ajusté par vulnérabilité —
  voir plus bas), au palier minimal légal — avec une barre plus haute (12H en H purs, 6+
  cartes) si ce palier minimal est 2 ou plus : un contre-appel forcé au-delà du palier 1
  exige davantage qu'un simple palier 1.
- **Réponse au contre du partenaire** : quasi obligatoire, dans la meilleure des 3 couleurs
  non contrées, au palier minimal légal (ou 2 avec 10HL+) — pas de main "punitive" (laisser
  le contre en place), hors périmètre.
- **Vulnérabilité** : barrages et interventions naturelles resserrés (seuil relevé de 8HL à
  10HL) quand le camp du robot est vulnérable, plus agressifs sinon — comme le vrai SEF.
- **Globalement un seul tour de dialogue, avec des exceptions forcing ciblées** : une fois
  qu'un robot a annoncé quelque chose dans une donne, il passe systématiquement ensuite —
  sauf l'ouvreur avec une main très forte (18HL+), qui dispose d'un unique rebid après la
  réponse du partenaire (voir ci-dessus), et sauf les situations explicitement forcing
  (renverse, 4ème couleur, réveil suivi d'un contre — voir "Corrections des sessions du
  23-24 juillet" plus bas), qui obligent à reparler quelle que soit la main. Pas de
  contre-annonce après une nouvelle enchère adverse en dehors de ces cas précis.
- **Contre d'appel (takeout) seulement** — jamais de surcontre, jamais de contre de
  pénalité, jamais de convention (Stayman, Blackwood, Roudi,
  Texas...), pas de 2♣ fort indéterminé ni de 2♦ forcing de manche (une main assez forte
  pour ça ouvre simplement au palier 1, faute d'implémenter tout un système de relais pour
  une main sur plusieurs centaines).

Chaque annonce calculée est vérifiée par les mêmes règles de légalité que celles d'un
joueur humain avant d'être jouée ; en cas de doute, le robot passe plutôt que de risquer
une annonce invalide. Testé sur 5000 enchères complètes à 4 robots (donnes aléatoires,
tout le cycle donneur/vulnérabilité) : zéro annonce illégale, zéro blocage — dont ~6,5%
avec un rebid de l'ouvreur effectivement déclenché.

**Bug important corrigé** (voir échange avec Guillaume, "les séquences s'arrêtent toujours
trop tôt") : un simple passe initial (faute de points pour ouvrir — très fréquent) comptait
à tort comme "avoir déjà parlé", rendant ce joueur muet pour le reste de la donne, incapable
de répondre normalement à son partenaire plus tard. Seule une vraie annonce (pas un passe)
épuise désormais le tour unique de dialogue.

**Corrections supplémentaires suite à un nouveau test de la donne 2** (voir échange avec
Guillaume) :
- **Routage en séquence compétitive** : quand un adversaire reparle après l'annonce du
  partenaire (typique en séquence compétitive à 4), le moteur cherchait auparavant
  uniquement la toute dernière annonce de l'enchère pour savoir "qui répond à qui" — donc
  un joueur pouvait se retrouver à tort à "intervenir" sur l'adversaire au lieu de
  répondre/soutenir son propre partenaire, ou l'ouvreur à tort privé de son rebid. Corrigé
  en recherchant l'annonce du partenaire en remontant l'historique plutôt qu'en ne
  regardant que la dernière.
- **Points de soutien** : quand la longueur de la couleur du partenaire est GARANTIE (5+
  via une majeure/intervention, 3+ par défaut à la mineure), les décisions de soutien
  comptent maintenant les points de soutien plutôt que HL — H bruts + 2 points si le 9ème
  atout du camp est atteint (ma longueur + le minimum garanti du partenaire) + la valeur
  des courtes dans les AUTRES couleurs (chicane +5, singleton +3, doubleton +1). Utilisé à
  la fois par le soutien mineur et l'échelle des soutiens majeurs.
- **Contre d'appel exclu avec une longue couleur** : 6+ cartes dans une même couleur se
  montrent directement plutôt que de se cacher derrière un contre, qui ne promet de
  longueur nulle part et gâcherait une belle couleur.

**Corrections supplémentaires suite aux donnes 5 et 7** (voir échange avec Guillaume) :
- **Réponse en changement de couleur toujours forcing** : généralisé au-delà du seul 2/1
  (palier 2 sur majeure) — une réponse en NOUVELLE couleur, palier 1 ou 2, n'est jamais
  limitée par nature, donc l'ouvreur reparle systématiquement, quels que soient ses
  points (donne 5 : l'ouvreur à 13HL montre bien sa 2e couleur maintenant). Reste borné à
  UN SEUL rebid de l'ouvreur — la suite complète du répondant (4ème couleur forcing,
  donne 5) reste hors périmètre : généraliser aussi cette suite produisait des sous-enchères
  incorrectes sur les mains fortes en test, signe que ça demande une vraie logique dédiée
  plutôt qu'une simple extension.
- **Palier de soutien manquant au-delà de 15 points** : l'échelle des soutiens directs à
  une majeure s'arrêtait à 15HLD (3SA), laissant une main de 16+ points de soutien
  retomber sur un repli générique invitant seulement (palier 3) — alors que la manche est
  déjà acquise. Ajout d'un palier "16+ HLD → manche directe" (donne 7).

**Suite du répondant en zone de manche connue** (voir échange avec Guillaume, retour sur
la donne 5) : ma première tentative (une heuristique de longueur de fit maison) ne
correspondait pas à ce qu'il avait demandé — remplacée par sa règle réelle, plus simple :
une ouverture à la couleur promet 12+, donc un répondant ayant lui-même 12+ sait que son
camp a 24+ à eux deux et doit continuer jusqu'à la manche. Priorité systématique à un fit
MAJEUR de 8+ cartes *connu* (la couleur d'ouverture promet 5+ si majeure, un rebid en
nouvelle couleur promet 4+) ; à défaut, manche à SA directement, sans explorer un fit
mineur. Ne considère que les couleurs déjà montrées par l'OUVREUR, pas une éventuelle
longue du répondant lui-même chez qui elle n'a pas été explicitement demandée — un
raffinement possible si besoin.

**Corrections supplémentaires suite aux donnes 5 et 6, encore affinées** (voir échange
avec Guillaume) :
- **Pas de rebid forcé si un adversaire est intervenu** : la règle "reparle toujours après
  une nouvelle couleur" ne s'applique que si personne d'autre n'a parlé depuis — une fois
  la concurrence entrée en jeu (adversaire intervenu entre la réponse du partenaire et mon
  tour), ce n'est plus vraiment forcing, l'ouvreur peut légitimement passer (donne 6 :
  Est n'a plus à reparler après l'intervention de Nord). La loi des atouts et le filet
  18HL+ restent inchangés, eux.
- **Reverse (bicolore cher)** : une 2e couleur qui EXIGE le palier 2 pour être annoncée
  ET qui rang plus haut que l'ouverture (donc le partenaire devrait monter d'un cran pour
  revenir à la 1ère couleur) promet 17HL+ — pas juste "une couleur plus chère" en
  général. Un bicolore économique montrable au palier 1 (donne 5 : 1♣ puis 1♠, le
  partenaire ayant répondu 1♥) n'est jamais un reverse, quel que soit le rang des
  couleurs — ma première version de cette règle comparait les rangs sans vérifier le
  palier réellement nécessaire, cassant à tort la donne 5 en la corrigeant.

**Correction critique sur la donne 7** (voir échange avec Guillaume) : j'avais mal compris
le sens d'un saut direct à la manche en soutien — ça ne montre PAS une main forte, mais
l'inverse (barrage, main faible et distribuée avec 5+ atouts, déjà couvert plus haut dans
l'échelle). Une main VRAIMENT forte (16+ points de soutien) doit au contraire **différer**
: annoncer une nouvelle couleur (la plus longue des 3 autres si 4+ cartes, sinon la plus
courte comme relais faute de mieux) pour forcer l'ouvreur à reparler, puis confirmer le
fit à la manche une fois la suite en zone de manche connue déclenchée (voir
decideResponderContinuationAfterNewSuit, corrigé au passage pour viser directement la
manche plutôt que le palier minimal légal, qui sous-vendait aussi la main).

**Correction sur la donne 8** (voir échange avec Guillaume) : une réponse en nouvelle
couleur sur un barrage du partenaire est déjà forcing un tour — pas besoin de sauter pour
montrer une main forte (le saut, lui, aurait un tout autre sens : splinter). Retiré le
saut que j'avais ajouté à tort, et déplacé la décision du bon côté : c'est l'OUVREUR du
barrage qui juge, à son rebid, s'il pousse à la manche — avec un fit (3+ cartes) et une
main en haut de sa fourchette (8-12HL, zone haute = 11HL+), il pousse directement à la
manche dans la couleur du partenaire ; sinon il répète sa propre couleur. Logique dédiée
aux ouvertures de barrage (palier 2+), distincte de la logique des ouvertures naturelles
au palier 1.

**Barrage en intervention** (voir échange avec Guillaume, précision sémantique importante
— c'est une intervention sur l'adversaire, pas une réponse au partenaire) : même forme
qu'un barrage d'ouverture (8-12HL, 6+ cartes dans une seule couleur, rien d'autre à
montrer) mais en intervention — saut direct au palier 2 plutôt qu'une intervention
naturelle au palier minimal, qui sous-décrit une main concentrée dans une longue sans
valeur défensive ailleurs.

## Nouvelle relecture de session (voir échange avec Guillaume)

Trois corrections supplémentaires, chacune trouvée en creusant au-delà du symptôme initial :

- **Longue avant majeure 4ème en zone de manche** : la priorité "majeure avant tout" ne
  vaut que pour une main limitée qui cherche un fit rapide en un seul tour. Avec 12+
  (zone de manche connue, plusieurs tours possibles) et une couleur de 5+ cartes plus
  longue que la majeure trouvée, on montre la longue d'abord — plus informatif qu'une
  majeure 4ème qui ne dit rien sur la vraie forme de la main.
- **Le fit prime sur une 2e couleur perso** : au rebid de l'ouvreur après une réponse en
  changement de couleur, indiquer qu'on est fitté (4+ cartes chez soi pour la couleur du
  partenaire — un simple 3 ne suffit pas, une réponse ne garantissant que 4+ chez le
  partenaire) passe avant de chercher à montrer sa propre 2e couleur. Mêmes zones que les
  ouvertures : 12-14H soutien simple, 15-17H invite, 18H+ manche directe.
- **Réponse au contre malgré une intervention adverse, et suite du contreur** : comme pour
  les enchères normales, répondre au contre d'appel du partenaire reste possible même si
  un adversaire a reparlé depuis (ça "libère" formellement l'obligation, sans l'empêcher).
  Ajout de la suite du CONTREUR lui-même : avec de la réserve au-delà du minimum du contre
  (15H+) et un fit pour la couleur choisie par le partenaire, il pousse directement à la
  manche plutôt que de laisser filer un partiel.

## Groupe D — Stayman et transferts (Jacoby/Texas) après SA (voir échange avec Guillaume)

Convention complète, implémentée à la suite des groupes A/B/C ci-dessous (même session) :

- **Stayman** (2♣ sur 1SA, 3♣ sur 2SA) : demande une majeure 4ème, avec assez de points
  pour vouloir explorer. L'ouvreur montre une majeure s'il en a une (cœur en priorité si
  les deux sont 4ème, laissant le répondant "corriger" à pique au même palier), sinon dénie
  en carreau. Le répondant, dont la 1ère annonce ne disait rien de sa main, l'évalue
  ensuite pour la première fois : fit trouvé + 25H à eux deux → manche ; sinon reste au
  palier atteint. Sans fit, repli à 3SA si assez de points, sinon reste sur le déni.
- **Transfert Jacoby** (2♦/2♥ sur 1SA, 3♦/3♥ sur 2SA) : 5 cartes à une majeure sans 6ème.
  L'ouvreur complète mécaniquement vers la majeure suivante (pas de sur-acceptation, hors
  périmètre) ; le répondant décide ensuite manche ou repos selon ses propres points combinés
  à la fourchette connue de l'ouvreur.
- **Transfert Texas** (4♦/4♥, toujours au palier 4 quel que soit le palier d'ouverture) :
  6+ cartes à une majeure, vise la manche directement — cache en plus la main forte de
  l'ouvreur comme déclarant, protégée de l'entame adverse. L'ouvreur complète sans
  condition ; pas de suite nécessaire pour le répondant, la manche est déjà atteinte.

## Corrections issues de la session du 22 juillet (voir échange avec Guillaume)

Six points corrigés, tous vérifiés sur les donnes exactes fournies, sans régression sur
l'historique complet (20 000 enchères de robustesse) :

- **Priorité à une belle couleur personnelle, généralisée (donnes 4 et 6)** : le correctif
  de la session précédente (montrer sa propre couleur de 6+ plutôt qu'un soutien marginal)
  ne s'appliquait qu'après une ouverture du partenaire à la MINEURE. Généralisé à toute
  situation (majeure ou mineure, ouverte ou montrée par intervention) — donne 6 : Nord
  soutenait 3 cartes à un cœur adverse-intervenu de 7 cartes plutôt que montrer ses 5
  trèfles. Seuil ajusté à 5+ cartes (pas 6+) avec un écart d'au moins 2 cartes par rapport
  au fit, pour ne préférer sa couleur que si elle est NETTEMENT meilleure.
- **Repli SA après intervention adverse, deux bugs distincts (donnes 2 et 8)** :
  - Le soutien à une mineure calculait un palier de soutien précis mais ne vérifiait
    jamais s'il était légal — une intervention adverse pouvait le rendre illégal, et le
    soutien pourtant justifié ne se faisait alors pas du tout (donne 8 : Est avec un fit de
    5 cartes garanti disait "2SA" au lieu de "3♦"). Cherche maintenant le palier légal le
    plus proche à partir du palier calculé.
  - Le repli SA lui-même ne vérifiait ni un vrai arrêt (2+ honneurs) dans la couleur
    adverse, ni la bonne fourchette de points pour le palier annoncé (donne 2 : "2SA"
    annoncé avec 8H et un seul valet dans la couleur adverse, alors que 2SA promet
    précisément 10-11H et un bon arrêt). Ajouté les deux vérifications.
- **Réponse "en montant" à bon marché (donne 3)** : répondre par une couleur plus chère que
  celle du partenaire (seul ♠ après ♥ est possible) utilisait le seuil du changement de
  couleur général (11HL) au lieu du seuil bas d'une réponse simple, bloquant Nord (10HL)
  de montrer sa majeure 5ème. Nouveau seuil bas (hl≥6, comme pour une mineure), placé après
  la vérification de fit pour ne jamais la court-circuiter.
- **Fit de l'ouvreur bloqué après un contre adverse (donne 5)** : bug trouvé — le drapeau
  `opponentIntervened` (censé seulement libérer l'ouvreur de l'obligation de TOUJOURS
  reparler) bloquait en réalité l'accès à TOUTE la fonction de rebid, y compris la
  vérification de fit elle-même. Un contre adverse suivi d'une relance empêchait donc
  totalement l'ouvreur de soutenir la réponse de son partenaire au contre, même avec un
  vrai fit de 4 cartes. Séparé : la vérification de fit s'applique désormais toujours, seul
  le filet final ("ne jamais passer") tient compte de l'intervention adverse.
- **Repli SA du répondant en zone basse (donne 1)** : avec 6-10H, une main plate et sans
  6+ cartes pour imposer sa propre couleur (le partenaire n'a rien promis en redemandant
  autre chose que SA), le répondant passait silencieusement faute d'atteindre le seuil de
  "zone de manche connue" (12H+). Nouvelle branche dédiée à cette zone basse, concluant à
  un repli SA plutôt qu'un passe qui n'exprime rien sur la main.

## Corrections issues de la session du 21 juillet, troisième relecture (voir échange avec Guillaume)

- **Priorité à une belle couleur personnelle sur un soutien mineur marginal (donne 4)** :
  bug trouvé — sans majeure 4ème ni 12H+, le garde-fou existant ("longerSuit") ne se
  déclenchait jamais (il en dépend entièrement), laissant une main avec un fit minimal
  (3 cartes) pour la mineure du partenaire "soutenir" cette mineure plutôt que de montrer
  sa propre couleur de 6+ cartes, bien plus descriptive. Nouveau garde-fou indépendant :
  avec 6+ cartes dans une couleur à soi (plus longue que le fit pour la mineure du
  partenaire), on la montre — question de longueur de couleur, pas de points.
- **Contre protecteur / de "quatrième main" (donne 1)** : nouveau mécanisme — quand le
  partenaire est intervenu et qu'un adversaire a ensuite renchéri sur SA propre couleur,
  avec 8H+ et 4+ cartes dans CHACUNE des deux couleurs pas encore montrées par quiconque,
  un contre (normes assouplies : 8H suffit, pas besoin de brièveté dans la couleur adverse)
  vaut mieux qu'un simple soutien ou passe.
- **4SA quantitatif (donne 2)** : nouveau mécanisme — quand l'ouvreur découvre une main
  énorme (22HL+) après une réponse simple du partenaire (pas de fit trouvé), "4SA" pose la
  question sans s'engager : le partenaire dit 6SA avec 9H+ (le haut de sa fourchette
  habituelle), reste à 4SA sinon. Pas une vraie enchère de contrôle (Blackwood, toujours
  hors périmètre) — juste une question bornée sur l'étendue des points, comme le chelem
  direct de la donne 6 d'une session précédente, mais posée plutôt qu'auto-décidée quand
  l'incertitude sur la main du partenaire est trop large pour trancher seul.

## Corrections issues de la session du 21 juillet, deuxième relecture (voir échange avec Guillaume)

**Révision majeure du système Stayman/transferts** : le système construit lors de la
première passe (Jacoby au palier 2 pour 5 cartes, "Texas" séparé sautant au palier 4 pour
6+ cartes) ne correspondait pas à ce que voulait Guillaume — chez lui, tout transfère
TOUJOURS au palier ouverture+1, quelle que soit la longueur (5 ou 6+) : "ça n'existe pas"
de sauter au palier 4. Cycle unifié sur toutes les couleurs : ♣=Stayman, ♦→♥, ♥→♠, ♠→♣
(mineure, 6+ cartes), SA=naturel, puis ♣ au palier suivant→♦ (l'autre mineure, faute de
place plus tôt).

**Transfert mineur avec annonce de la courte (donne 8)** : avec 6+ cartes à une mineure ET
une vraie courte (0-1 carte) ailleurs, on transfère systématiquement, même pour "juste" la
manche, afin d'indiquer où est la courte. Sans courte (main régulière, donc forcément
6322), seulement en zone de chelem — sinon conclusion directe à 3SA/la manche naturelle,
sans passer par le mécanisme. Après la complétion du transfert, la 3ème annonce du
répondant indique la courte : directement si son rang est SUPÉRIEUR à la mineure montrée,
sinon (seul cas possible : courte à ♣ quand ♦ est la mineure montrée, qui rang en dessous
et n'est plus nommable) via SA. Un bug d'inversion trèfle/carreau dans le déclenchement
initial (mais pas dans la réponse de l'ouvreur ni cette suite, qui étaient déjà correctes)
a été trouvé et corrigé avant livraison, en comparant directement à l'exemple donné.

**Avance d'une intervention du partenaire, pas une vraie ouverture (donne 4)** : le
"repli SA" (utilisé quand rien de mieux à dire) supposait à tort que le partenaire avait
toujours au moins 12H garantis — vrai pour une ouverture, pas pour une intervention
naturelle (aussi peu que 8-10H selon le contexte). Désormais désactivé entièrement quand
on avance l'intervention du partenaire plutôt que de répondre à sa propre ouverture : sans
fit ni jeu réel, il n'y a "aucune raison" de fabriquer un repli SA, passer est la seule
enchère honnête.

**Chelem par simple compte de points (donne 6)** : pas de véritable enchère de contrôle
(cue-bids, Blackwood — toujours hors périmètre), mais un déclenchement borné et sûr — si
mes points combinés au minimum garanti par l'ouverture du partenaire (12) atteignent 33+
(zone de petit chelem), saut direct à 6SA plutôt que de s'arrêter à la manche.

## Corrections issues de la session du 21 juillet (voir échange avec Guillaume)

Trois chantiers menés en parallèle, un quatrième (Stayman/Texas après SA) volontairement
laissé de côté pour l'instant — ampleur comparable au 2♣ fort, mérite sa propre passe
dédiée plutôt que d'être ajouté à la hâte ici.

**Groupe A — Seuil d'intervention forcée au palier 2 (donne 1)** : le "barrage en
intervention" (8-12HL, 6+ cartes) ne s'applique désormais qu'aux MAJEURES — "les barrages
n'existent qu'à partir de 2♥" (voir échange avec Guillaume). Une intervention à la mineure
forcée au palier 2+ (le palier 1 n'étant pas disponible) passe systématiquement par le
seuil plus exigeant déjà existant (12H+, 6 cartes), qui était jusque-là court-circuité par
le barrage.

**Groupe B — Contre "toute distribution" et silence de l'ouvreur de barrage (donne 2)** :
- À partir de 19HL+ (précision de Guillaume : "plus de 18" = 19+), on contre TOUJOURS
  d'abord en intervention, quelle que soit la distribution — même avec une belle couleur
  personnelle — puis on montre sa vraie couleur au tour suivant (voir
  decideDoublerFollowUp, désormais capable de distinguer ce cas d'un contre d'appel
  classique 12-18HL).
- Un ouvreur de barrage ne reparle plus jamais de son propre chef après son ouverture,
  même si le partenaire le soutient et même si la loi des atouts suggérerait de pousser
  encore — il a déjà tout dit à son premier tour.

**Groupe C — Redemande de l'ouvreur toujours forcing (donnes 3, 5, 7, 8)** : le principe
central (voir échange avec Guillaume) — une réponse en changement de couleur reste forcing
tant que la zone de manche (25H à eux deux) est encore atteignable, donc l'ouvreur DOIT
toujours produire une enchère, "la moins mauvaise" s'il n'en existe pas d'évidente. Mis en
œuvre par :
- Nouvel utilitaire `isBalanced` (4333/4432/5332 précisément — un bug de première version,
  trop permissif, laissait à tort passer un 5422, corrigé avant livraison) pour reconnaître
  une main régulière et lui faire dire 1SA (sous 15H) ou 2SA (18H+) plutôt que d'inventer un
  bicolore qu'elle n'a pas — ces deux fourchettes sont les seules possibles ici, puisqu'une
  main régulière de 15-17H aurait déjà ouvert 1SA directement.
- Un "bicolore cher" (renverse) exige désormais aussi 5+ cartes dans la couleur
  d'ouverture elle-même, pas seulement 17HL+ — une mineure ouverte à 3 cartes par défaut
  ne peut pas prétendre avoir un vrai bicolore 5-4.
- Le filet final ne passe plus jamais : à défaut de toute autre option, répéter sa couleur
  (même sans satisfaire pleinement le garde-fou "honnête" habituel) reste la moins mauvaise
  enchère plutôt qu'un passe sur une séquence forcing.

## Corrections issues de la session du 20 juillet, deuxième relecture (voir échange avec Guillaume)

- **Suite obligatoire de l'ouvreur après un soutien conventionnel** : "2SA" (11-12 points de
  soutien, fit exactement 3 cartes) et "3SA" (13-15, sans singleton) étaient déjà reconnus
  comme des enchères conventionnelles montrant un fit — mais seulement traités si l'ouvreur
  avait 18HL+ (seuil pensé pour "rien d'autre à ajouter"), ce qui laissait filer un
  partiel après "2SA" dans les mains normales. Corrigé : l'ouvreur reparle désormais
  TOUJOURS après ces deux enchères, indépendamment de ses points — 12-13H (mini) → accepte
  le fit au palier 3, 14H+ → manche directe (pour "3SA", toujours la manche, même avec une
  ouverture minimale : 12+13 dépasse déjà 25).
- **Passe de pénalité avec du jeu et un misfit** (deux formes du même principe) :
  - En réponse au PROPRE contre d'appel du joueur (`decideRobotResponseToDouble`) : à partir
    de 13H, passe plutôt que de forcer mécaniquement la plus longue couleur restante — une
    main de cette force vaut souvent mieux en défense.
  - En avance après qu'un ADVERSAIRE a contré l'ouverture du PARTENAIRE : même seuil (13H+)
    combiné à un misfit net (0-1 carte) avec la couleur du partenaire → passe. Recherche le
    contre n'importe où dans l'historique (pas seulement en dernière position), car un passe
    ne "consomme" pas de tour dans ce moteur — sans ça, un premier passe correct pouvait être
    annulé à un tour ultérieur une fois l'enchère développée.
- **Loi des atouts en réponse à un barrage majeur du partenaire** : l'échelle de soutien
  direct (2SA/3SA conventionnels, splinters...) est conçue pour une ouverture NORMALE au
  palier 1 — appliquée telle quelle à un barrage (palier 2+), elle produisait des non-sens
  comme "3SA fitté" avec un partenaire plafonné à 8-12HL. Sur un barrage, avec un fit (3+
  cartes, déjà 9+ cartes à eux deux), on prolonge simplement d'un palier plutôt que
  d'utiliser l'échelle de soutien normale.

## Corrections issues de la session du 20 juillet (voir échange avec Guillaume)

Trois retours après relecture d'une nouvelle session, chacun corrigé après une analyse
précise (donne 3 en particulier a d'abord été mal comprise — confusion entre intervention
et réponse au sein d'un même camp, corrigée après clarification) :

- **Contre d'appel exclu avec une majeure 5ème** : comme pour une couleur de 6+ cartes
  (correction précédente), une majeure de 5 cartes suffit à préférer une intervention
  naturelle à un contre d'appel — assez descriptive en elle-même pour ne pas se cacher
  derrière un contre.
- **Contre adverse = intervention pour la règle du rebid forcé** : un contre de la couleur
  du partenaire (pas seulement une vraie annonce) libère maintenant l'ouvreur de
  l'obligation de reparler après une réponse en changement de couleur — la situation est
  tout aussi compétitive qu'une nouvelle enchère adverse.
- **Répéter une mineure au palier 2+ doit rester honnête** : ça ne montre plus une simple
  main de 4 cartes minimum — seulement 6+ cartes, ou 5 cartes avec une chicane/singleton
  ailleurs (cas moins fréquent). Sans ces conditions, et sans autre option, l'ouvreur passe
  plutôt que de sur-décrire sa main. Ne s'applique pas à une majeure, qui promet déjà 5+
  dès l'ouverture.
- **2♣ fort artificiel (22-23HL équilibrée)** : un "super 2SA" annoncé en deux temps —
  2♣ (forcing), le répondant relaie systématiquement en 2♦ (pas de réponse positive par
  couleur, volontairement hors périmètre), puis l'ouvreur précise 22-23 en rebiddant 2SA.
  Le répondant, dont le relais initial ne disait rien de sa main, l'évalue alors pour la
  première fois (même logique de seuil qu'une réponse à une ouverture de 2SA normale) —
  avec une majeure 5+ franche, la manche s'y joue directement plutôt qu'à SA.
- **Seuil de réponse à un barrage relevé (donne 3)** : le seuil de 11HL pour montrer une
  nouvelle couleur était le même qu'après une ouverture normale (qui promet déjà 12+) —
  mais un barrage plafonne le partenaire à 8-12HL, donc 11HL n'offre "aucun espoir de
  manche" même dans le meilleur des cas. Relevé à 13HL (pour la nouvelle couleur ET le
  repli SA) spécifiquement en réponse à un barrage — pile de quoi espérer la manche même
  si le partenaire n'a que le minimum de sa fourchette. Le soutien direct du barrage
  lui-même (sans nouvelle couleur) n'est pas concerné : soutenir reste une action
  compétitive raisonnable même avec des points modestes.

## Corrections issues d'une relecture de session (voir échange avec Guillaume)

Après une session de test, Guillaume a exporté le fichier et relu chaque donne en détail
— plusieurs corrections concrètes en ont découlé :

- **Réponse "up the line"** : avec les deux majeures à 4 cartes en réponse à une ouverture
  à la mineure, Cœur est annoncé avant Pique (le moins cher d'abord, pour garder la main
  de montrer Pique ensuite sans se fermer d'options) — l'ordre était inversé.
- **"1SA poubelle"** : avec une main plate et un fit d'exactement 3 cartes à une mineure
  qui n'a jamais promis 5+ (donc via une ouverture, pas une intervention), 1SA naturel
  est préféré à un soutien direct qui engagerait sur un fit marginal.
- **2/1 forcing de manche** : une réponse en changement de couleur au palier 2 sur une
  ouverture d'1 majeure est désormais reconnue comme forcing de manche — l'ouvreur
  reparle TOUJOURS (pas seulement à 18HL+) : répète sa couleur ou montre un bicolore
  économique (4+ cartes) en zone 1 (12-14H), ou en zone 2+ irrégulière ; 2SA avec 15H+ et
  une répartition exactement 5332. Le répondant enchérit une deuxième fois lui aussi :
  fit avec l'ouverture (3+ cartes) ou le rebid (4+, seuil plus exigeant qu'une couleur
  déjà confirmée), sinon 3SA par défaut.
- **Loi des atouts** : avec 6+ cartes dans sa couleur d'ouverture et un soutien confirmé
  du partenaire (fit connu de 9+ cartes), l'ouvreur repousse d'un palier indépendamment
  de ses points d'honneur — la sécurité distributionnelle prime.
- **Réponse plus ferme face à un barrage** : avec une vraie main forte (13H+) en réponse
  à un "2 faible" du partenaire, un saut au-delà du palier naturel montre l'excédent
  plutôt qu'une simple couleur au minimum, qui ressemblerait à une main limitée.

**Corrections des sessions du 23-24 juillet** (voir échange avec Guillaume, retests
successifs sur fichiers PBN exportés depuis une vraie session) :
- **Correction vers un fit connu après SA du partenaire** : un répondant qui a montré une
  autre couleur mais dispose de 5+ cartes dans la couleur d'OUVERTURE du partenaire (ou
  3+ si c'est une majeure), avec une main trop faible pour forcer, corrige maintenant vers
  ce fit plutôt que de laisser jouer SA.
- **Renverse forcing** : un renverse de l'ouvreur (2e couleur de rang supérieur à la 1ère,
  au palier immédiatement au-dessus de ce qu'il faudrait pour revenir à la 1ère) oblige
  désormais le répondant à reparler — jamais de passe, même avec une main minimale.
  L'ouvreur lui-même, après son propre renverse, ne peut plus passer non plus sur la
  réponse la plus économique du partenaire ("auto-forcing") : il répète sa couleur si
  minimum, ou utilise la 4ème couleur forcing si sa main est nettement excédentaire.
- **4ème couleur forcing** : détectée (une couleur jamais annoncée par personne, après que
  chaque camp en a déjà montré une) et reconnue comme forcing — plus de passe dessus. La
  réponse cherche d'abord un arrêt (SA), sinon un fit connu dans une couleur déjà montrée
  par le partenaire.
- **Enchère d'essai à SA** : après un soutien SIMPLE d'une majeure (palier 2) avec 15-17
  points de soutien — ni un minimum qui compète juste, ni déjà sûr d'être en zone de
  manche —, l'ouvreur fait un essai à 2SA générique plutôt que de passer directement. Le
  répondant tranche mini (revient dans le fit au palier minimal, 6-7 points) ou maxi
  (manche, 9+).
- **Réveil** (voir "quatrième position" ci-dessus, la bonne terminologie) : quand passer
  clôturerait l'enchère sur la dernière annonce adverse, moins exigeant qu'une
  intervention directe — main plate sans couleur 5ème (8-12H) → 1SA, sans exigence
  d'arrêt ; couleur 5ème et 7-12H → nommée directement ; couleur 5ème et 13H+ → contre
  d'abord (même principe que le "contre toute distribution", généralisé à 13H — voir
  plus bas), la vraie couleur au tour suivant.
- **Préférence simple entre les deux couleurs de l'ouvreur** : avec une main minimale
  (jusqu'à 9H), le répondant reste par défaut sur la 1ère couleur de l'ouvreur (présumée
  plus longue) sauf avantage NET (2+ cartes) pour sa redemande — un simple écart d'une
  carte ne suffit pas à préférer la redemande, contrairement à ce qu'un premier correctif
  avait fait à tort.
- **Main énorme qui ne doit jamais passer** : un répondant avec 18H+, face à un partenaire
  qui n'a fait qu'ouvrir puis passer (typiquement après une intervention adverse), impose
  sa plus longue couleur en zone de chelem plutôt que de laisser filer un partiel — un
  éventuel destinataire de ce saut (le partenaire, recevant un contrat de manche/chelem
  nommé directement) sait s'arrêter net dessus, sauf surplus propre qui justifierait
  d'aller plus haut.
- **Framework HL/HLD unifié** (voir "Points HL/HLD" plus bas) : constantes de zone
  partagées (25H pour 3SA, 27HLD pour 4♥/4♠, 30HLD pour 5♣/5♦, 33 pour le petit chelem,
  37 pour le grand chelem) réutilisées à plusieurs endroits clés du moteur, remplaçant des
  calculs ad hoc jusque-là dispersés et parfois incohérents entre eux.

### Points HL/HLD

Une main s'évalue **toujours en HL** (honneurs + longueur dans sa propre main) tant
qu'aucun fit n'est trouvé avec le partenaire. Dès qu'un fit est **confirmé** (soutien
direct, ou couleur du partenaire à longueur garantie — majeure 5ème, intervention 5+...),
bascule sur **HLD** (`computeSupportPoints` — honneurs + DISTRIBUTION selon ce fit précis :
bonus du 9ème atout + valeur des courtes ailleurs) à la place des points de longueur —
jamais les deux additionnés sur la même main, la terminologie SEF "HLD" ne les cumule pas.

Zones, à l'échelle du camp (ses propres points + le minimum estimé du partenaire — 12
pour une ouverture, seulement 6 pour un simple soutien qui ne promet presque rien) :
25H pour 3SA, 27HLD pour la manche à la majeure, 30HLD à la mineure, 33 pour le petit
chelem, 37 pour le grand chelem — tant que ce seuil est atteignable, la séquence continue
d'une manière ou d'une autre plutôt que de s'arrêter prématurément. Implémenté pour
l'instant dans les deux fonctions les plus centrales (suite du répondant après une
nouvelle couleur, rebid de l'ouvreur après un soutien direct) ; le reste du moteur
(réponse au contre, soutiens directs, barrages...) n'a pas encore été repassé en revue
avec ce même cadre unifié.

**Mis de côté pour l'instant**, signalés explicitement plutôt qu'ignorés silencieusement :
4ème couleur forcing complet au-delà du cas 2/1 borné et du cas "après mon propre
renverse" (une généralisation totale exigerait plusieurs enchères par camp, avec un vrai
risque de casser la terminaison sans une refonte plus large), points Kaplan-Rubens (pas de
formule fournie), séquences compétitives détaillées après un contre (l'adversaire qui
reparle avant que le partenaire n'ait répondu, un contre de pénalité plus tard dans
l'enchère — trop pointu pour une première passe), repli 1SA en quatrième position (déjà
couvert en fait par le réveil ci-dessus, qui répond à la même question).

## Limites connues

- **Connexion directe (WebRTC)** : fonctionne dans l'immense majorité des cas grâce aux
  relais TURN de secours (deux fournisseurs indépendants), mais la mise en relation
  initiale peut occasionnellement prendre jusqu'à une trentaine de secondes sur certains
  réseaux.
- Tous les joueurs doivent être en ligne **en même temps** pour établir la connexion
  initiale, mais une coupure en cours de partie n'est plus fatale (voir "Reconnexion"
  ci-dessous).
- Seule la phase d'**enchères** est couverte (pas le jeu de la carte).
- Le fichier de donnes n'est chargé que par l'hôte ; les invités le reçoivent
  automatiquement via la connexion, ils n'ont rien à importer de leur côté.

## Fiabilité et confort en cours de partie (sessions du 23-24 juillet)

- **Réorganiser les sièges en cours de partie** : bouton dans la barre d'actions (à côté
  d'Undo/Recommencer/Rotation, réservé à l'hôte) ouvrant une grille en croix identique à
  celle du salon. Fonctionne en **brouillon** : les changements ne s'appliquent qu'au clic
  sur "Valider" — "Annuler" à côté abandonne sans rien changer, et il n'y a plus moyen de
  fermer la fenêtre en cliquant à côté (seuls ces deux boutons ferment). Permet notamment
  de réassigner à "Robot" le siège d'un joueur parti durablement, ce qui remet
  automatiquement ce siège en jeu automatique (recalcul à la volée des sièges "robot").
- **Notifications de présence** : un toast temporaire (même animation que le "wizz"), vert
  à la connexion, rouge à la déconnexion, pour chaque joueur assis — remplace l'ancienne
  bannière permanente et verbeuse. Compteur en direct pour sa PROPRE déconnexion en cours
  ("connexion perdue — reconnexion en cours... Xs"). La reconnexion P2P se fait en
  arrière-plan ; pendant une coupure, les actions autorisées peuvent passer par le relais
  cloud sans changer l'identité de l'hôte.
- **Chat permanent sur desktop** (≥600px) : ne peut plus être fermé, bouton et bandeau de
  fermeture masqués (redondants une fois le chat toujours visible). Reste fermable sur
  mobile. Hauteur fixe avec défilement interne (ne grandit plus avec la conversation).
  Historique des messages inclus dans la sauvegarde de reprise d'hôte (voir
  "Reconnexion"). Le renommage d'un participant par double-clic est réservé au "qui est
  là" en haut du panneau, plus disponible directement sur un message.
- **Nom de l'hôte affiché** à côté du code de salle en cours de partie.



Chaque invité porte un petit jeton généré dans son navigateur (conservé via
`localStorage` — survit à la fermeture de l'onglet et à un redémarrage du navigateur,
tant que c'est le même appareil). Si sa connexion tombe — Wi-Fi qui coupe, ordinateur qui
se met en veille, onglet qui plante — l'hôte garde sa place et son ou ses sièges
réservés. **Son siège n'est pas remplacé par un robot automatiquement** : l'enchère
patiente que ce joueur revienne, avec un toast qui signale la déconnexion (rouge) puis la
reconnexion (vert) de chaque participant. L'hôte peut, s'il le souhaite, réassigner
manuellement un siège resté vacant trop longtemps à "Robot" (voir "Réorganiser les
sièges" en cours de partie).

Pour revenir (invité) :
- **En rechargeant simplement la page** (ou en rouvrant le lien de partage, même dans un
  nouvel onglet) : la reconnexion et la reprise de la partie en cours (donne, enchère,
  sièges) sont automatiques.
- **Sans recharger** : un bouton **"🔌 Se reconnecter"** apparaît dans la barre du haut
  dès que la connexion est perdue ; un clic suffit pour reprendre exactement où on en
  était.

**Détection renforcée** : au-delà des événements PeerJS standards (fermeture de
connexion, coupure du serveur de signalisation), une connexion qui reste bloquée en état
ICE `disconnected`/`failed` plus de 6 secondes sans se rétablir toute seule est
considérée morte et fermée activement — un simple Wi-Fi qui vacille peut dégrader la
connexion sous-jacente sans jamais déclencher les événements PeerJS classiques, ce qui la
laissait auparavant dans les limbes sans que l'appli s'en aperçoive.

### Si c'est l'hôte qui part

Il n'existe plus d'élection automatique d'un nouvel hôte. L'identité d'autorité reste
stable, ce qui évite les doubles-hôtes et les inversions de rôle observées avec l'ancien
prototype.

- **Coupure réseau, onglet resté ouvert** : l'hôte tente de recréer sa connexion PeerJS
  sous le même code. L'état de jeu reste en mémoire et continue aussi d'être persisté côté
  cloud.
- **Hôte réellement absent** : les participants authentifiés peuvent continuer les actions
  qui leur appartiennent via le relais serveur. Les tours de robots en relais sont décidés
  par PONS côté serveur, pas par le navigateur du participant.
- **Retour du créateur** : la reprise à froid recharge d'abord l'état autoritaire du cloud,
  puis le créateur recrée le Peer hôte. Les autres participants se resynchronisent et
  conservent leurs sièges.
- **Reprise différée par un autre participant** : elle reste possible pour jouer son propre
  siège sans devenir l'autorité persistante de la salle ; cette reprise utilise le relais
  cloud jusqu'au retour du créateur.

La sauvegarde locale reste un filet de confort sur le même appareil/navigateur, mais le
cloud est la source à privilégier dès qu'une session serveur existe. Deux onglets du même
navigateur partagent toujours les mêmes données locales : pour les tests multi-joueurs,
utiliser des profils/navigateurs distincts.

## Transfert d'hôte

Dans le salon d'attente, **avant de charger les donnes**, l'hôte peut céder son rôle à
n'importe quel autre participant connecté : un bouton **"👑 Transférer l'hôte"** apparaît à
côté de son nom dans la liste des participants. Cas d'usage typique : la création de la
partie échoue sur votre propre appareil (réseau capricieux), mais fonctionne très bien
depuis le téléphone d'un ami — il crée la partie, vous le rejoignez, puis vous vous faites
transférer le rôle d'hôte pour reprendre la main (charger les donnes, composer la table).

Techniquement, un nouveau code de partie est généré pour l'occasion (PeerJS ne permet pas
de reprendre fiablement l'ancien identifiant tout de suite) : tout le monde, y compris
l'ancien hôte, rejoint automatiquement cette nouvelle salle en arrière-plan, sans rien à
resaisir — pseudos et sièges déjà assignés sont conservés.

Limites connues :
- Uniquement possible **dans le salon**, avant que la partie ait démarré.
- Le participant visé doit être connecté au moment du transfert (pas dans le cas d'une
  place réservée en attente de reconnexion).
- Sur iPhone, comme pour la création de partie (voir l'avertissement affiché dans le
  salon), ne changez pas d'application pendant les quelques secondes que prend le
  transfert — iOS pourrait couper la connexion en plein milieu.

## Fichiers

| Fichier | Rôle |
|---|---|
| `index.html` | Structure de la page (accueil / salon / jeu) |
| `styles.css` | Habillage visuel |
| `bidding-rules.js` | Logique pure des enchères (légalité des annonces, calcul du contrat) |
| `deal-parser.js` | Lecture des fichiers `.pbn` et `.lin` |
| `peer-connection.js` | Connexion WebRTC entre les joueurs (via PeerJS), topologie en étoile pour 3+ joueurs |
| `app.js` | État de l'application, salon (pseudos, assignation des sièges), et rendu de l'interface |
| `manifest.json` | Manifeste PWA (nom, icônes, couleurs, mode plein écran) |
| `sw.js` | Service worker : cache hors-ligne des fichiers ci-dessus, gère les mises à jour |
| `icons/` | Icônes PWA (180/192/512px) référencées par `manifest.json` et `index.html` |
| `donnes/` | Bibliothèque de donnes du club, piochable depuis le salon d'attente (voir `donnes/README.md`) |

## PWA — installation sur mobile

Le site est installable ("Ajouter à l'écran d'accueil") sur iOS et Android, et fonctionne
hors-ligne pour tout ce qui ne dépend pas du réseau (interface, règles d'enchères).
Aucune configuration : le navigateur détecte `manifest.json` et propose l'installation
automatiquement (Android), ou l'utilisateur passe par Partager → Sur l'écran d'accueil
(iOS — l'appli affiche une invite dédiée la première fois).

**Mise à jour du cache : versionnée par release.** `sw.js` gère l'invalidation via la
constante `CACHE_NAME` en tête de fichier. Le paquet distribué ici utilise un identifiant de
release propre ; à chaque future release, cette valeur doit être changée avant publication.
Le nouveau Service Worker peut alors installer un cache frais, puis l'application attend
qu'aucune salle ne soit active avant d'appliquer automatiquement la mise à jour. Les fichiers
`donnes/catalogue.json` et `donnes/` restent mis en cache à leur premier chargement même s'ils
ne figurent pas dans `CORE_ASSETS`.

Le mode de déploiement documenté plus haut reste **GitHub Pages → Deploy from a branch** ;
aucun workflow GitHub Actions n'est requis par ce paquet.


## Sécurité : capacités, CSP et rotation
> Compatibilité iOS 15.x : la CSP autorise aussi `unsafe-eval` en plus de `wasm-unsafe-eval`, car les anciens WebKit refusent sinon l’instanciation WebAssembly de PONS. Le code PLAY reste sans `eval`/`Function` et les handlers inline restent interdits.


- Le code court de salle est un identifiant humain, **pas** un secret cloud. La lecture et
  le relais utilisent une `accessKey`; l'écriture complète utilise une `hostWriteKey`
  distincte, conservée par l'hôte.
- La fonction de rotation/révocation des capacités est conservée dans le code, mais son bouton a été volontairement retiré de l'interface. Elle peut être réexposée plus tard dans un menu d'administration si nécessaire.
  Les anciennes deviennent immédiatement inutilisables ; seuls les joueurs encore
  connectés et assis reçoivent la nouvelle `accessKey`.
- `index.html` applique une Content Security Policy : aucun handler JavaScript inline,
  scripts limités aux fichiers de l'application et aux CDN explicitement autorisés,
  objets/frames interdits. Les événements UI passent par `ui-events.js`.
- Le zoom navigateur n'est plus désactivé : le viewport laisse l'utilisateur agrandir
  l'interface selon ses besoins.

## Mode robot 1SA faible (12–14H)

Dans le salon, l’hôte peut activer **🤖 1SA faible (12–14H)**. Dans ce mode, les robots actifs ouvrent de 1SA avec une main régulière de 12 à 14H au lieu de 15 à 17H. Les seuils de points du camp de l’ouvreur dans la branche issue de cette ouverture sont décalés de 3 points vers le bas ; les interventions adverses et toutes les enchères hors de cette branche restent inchangées. Le réglage est mémorisé localement et est sans effet lorsque **Robots inactifs** est activé.

