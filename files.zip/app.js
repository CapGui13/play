// app.js — État de l'application et rendu de l'interface.
// S'appuie sur bidding-rules.js (logique pure), deal-parser.js (lecture PBN/LIN)
// et peer-connection.js (connexion WebRTC) chargés avant ce fichier.
//
// PRINCIPE : plus de "modes" prédéfinis. L'hôte crée une partie, atterrit dans un salon
// où apparaissent au fil de l'eau les participants (chacun choisit son pseudo), et
// assigne librement chaque siège (Nord/Est/Sud/Ouest) à qui il veut — y compris la même
// personne sur 2 sièges. Un siège non assigné est joué par un robot qui passe
// systématiquement. Ce mécanisme unique permet de reproduire tous les cas de figure :
// binôme (2 sièges assignés, 2 en robot), diagonale, "maître du jeu" (une personne sur
// 2 sièges, deux autres sur les 2 restants), 4 joueurs (chacun un siège), etc.
//
// TOPOLOGIE : à partir de 2 invités, les invités ne sont jamais connectés entre eux —
// l'hôte relaie tout message reçu d'un invité vers les autres (voir relayIfHost).

const SUIT_SYMBOLS = { S: '♠', H: '♥', D: '♦', C: '♣' };
const SUIT_CLASSES = { S: 'spades', H: 'hearts', D: 'diamonds', C: 'clubs' };

// Caractères Unicode ♠♥♦♣, forcés en police Arial (voir règle .suit-icon dans
// styles.css) pour un rendu stable en glyphes texte plutôt qu'en émojis colorés selon
// la plateforme. La couleur (palette quatre couleurs) est appliquée en CSS via la classe
// de couleur (SUIT_CLASSES), pas cuite dans le caractère.
function suitIconHtml(suit, extraClass) {
    return `<span class="suit-icon ${SUIT_CLASSES[suit]}${extraClass ? ' ' + extraClass : ''}">${SUIT_SYMBOLS[suit]}</span>`;
}

// Libellé HTML d'une couleur d'enchère : "SA" en texte pour sans-atout, sinon l'icône de
// couleur (suitIconHtml). Centralise un motif répété à plusieurs endroits (boîte
// d'enchères, relevé, contrat final, table du double mort). Accepte les deux conventions
// utilisées dans ce fichier pour désigner le sans-atout : 'NT' (calls d'enchères, voir
// bidding-rules.js/STRAINS) et 'N' (clés de la table du double mort, voir STRAIN_ORDER —
// où N signifie sans-atout et non Nord). Aucune des deux ne désigne autre chose ailleurs,
// donc pas d'ambiguïté à les traiter ensemble ici.
function formatStrainLabel(strain) {
    return (strain === 'NT' || strain === 'N') ? 'SA' : suitIconHtml(strain);
}
const SEAT_FULL_NAME = { N: 'Nord', E: 'Est', S: 'Sud', W: 'Ouest' };
// Abréviation d'un seul caractère à afficher (convention française : O, pas W) — les
// clés internes restent N/E/S/W partout ailleurs (PBN, protocole réseau, etc.).
const SEAT_ABBR_FR = { N: 'N', E: 'E', S: 'S', W: 'O' };
const VULN_LABEL = { None: 'Non vulnérable', NS: 'NS vulnérable', EW: 'EO vulnérable', Both: 'Tous vulnérables' };

let peerConn = null;
let myRole = null;          // 'host' | 'guest'
let myParticipantId = null; // 'host', ou le jeton de reconnexion de l'invité (stable entre reconnexions)
let participants = [];      // [{ id, name, disconnected }, ...] — état du salon, maintenu par l'hôte
let seatAssignment = { N: null, E: null, S: null, W: null }; // id de participant, ou null (robot)
// Pas de statut "spectateur" séparé : quiconque n'occupe aucun siège est kibbitz (voir
// SEATS.every / mySeats.length === 0 un peu partout dans ce fichier) et voit donc les 4
// mains dès le début de la donne — inutile de l'assigner manuellement, ça découle
// directement de seatAssignment.

// Dernier instantané de seatAssignment vu au rendu précédent, pour détecter les
// affectations qui viennent tout juste d'arriver et leur appliquer un flash (voir
// renderSeatAssignmentGrid). `null` signifie "pas encore de repère" (première mesure
// après un (re)chargement du salon) : dans ce cas on se contente de capturer l'état sans
// rien flasher, pour ne pas allumer d'un coup toutes les places déjà occupées quand on
// rejoint un salon en cours de remplissage.
let prevSeatAssignmentSnapshot = null;

// Même principe, pour détecter côté invité les transitions déconnecté -> reconnecté d'un
// AUTRE participant (voir le cas 'lobby-state' dans handlePeerData) et déclencher un
// message de bienvenue transitoire. Côté hôte, cette détection se fait directement dans
// onGuestConnected (l'événement est déjà connu avec certitude, pas besoin de comparer),
// donc ce snapshot n'y est pas utilisé pour cette partie-là.
let prevParticipantsDisconnectedSnapshot = null;

// Nom affiché dans la bannière "de retour" (voir flashWelcomeBack/renderReconnectionBanner)
// pendant les quelques secondes où elle est visible ; null sinon.
let welcomeBackName = null;
let welcomeBackTimeoutId = null;

let currentRoomCode = null; // pour uiReconnect() : on doit se souvenir du code utilisé pour rejoindre

// (Hôte uniquement) jeton de reconnexion -> numéro de connexion PeerJS actif. Un invité
// garde le même jeton (localStorage) à travers ses reconnexions, mais son guestIndex
// change à chaque fois (nouvelle connexion PeerJS) : cette table fait le pont entre les
// deux, pour que seatAssignment (qui référence le jeton, stable) reste valide.
let guestIndexByToken = {};

// ===== Transfert d'hôte (salon uniquement, avant le lancement de la partie) =====
//
// Voir échange avec Guillaume : permet à l'hôte de céder son rôle à un autre participant
// connecté, dans le salon, avant de charger les donnes. Utile notamment quand la création
// de la partie échoue sur son propre appareil (réseau) : un ami crée la partie, puis
// Guillaume se la fait transférer une fois dans le salon.
//
// hostTransferInProgress : vrai entre l'envoi de 'prepare-become-host' et la réception de
// 'become-host-ready'/'become-host-failed' — évite de lancer un second transfert pendant
// qu'un premier est encore en cours.
let hostTransferInProgress = false;
// Jeton du participant visé par le transfert en cours (pour retrouver sa connexion au
// moment de la réponse) — uniquement pertinent côté ancien hôte, le temps du transfert.
let pendingHostTransferTarget = null;
// Jeton de reconnexion que l'hôte actuel s'apprête à utiliser une fois redevenu invité
// (généré au moment de lancer le transfert, voir uiTransferHost) — transmis au nouvel
// hôte dans 'prepare-become-host' pour qu'il puisse déjà lui réserver sa place/son siège
// sous ce jeton, avant même qu'il ne se reconnecte.
let pendingHostTransferOldToken = null;

// Jeton de reconnexion propre à ce navigateur, généré une fois puis conservé dans
// localStorage — survit à un rechargement ET à la fermeture/réouverture de l'onglet
// (contrairement à sessionStorage, qui est isolé par onglet et aurait généré un nouveau
// jeton à chaque réouverture, empêchant toute reconnexion réelle). Revers : deux onglets
// ouverts sur la même partie, dans le même navigateur, partageront le même jeton — sans
// conséquence pour un usage normal (un onglet par joueur), seulement pour un test solo
// avec plusieurs onglets qui simuleraient plusieurs joueurs différents.
function getReconnectToken() {
    try {
        let t = localStorage.getItem('bridgeBidReconnectToken');
        if (!t) {
            t = 'p' + Math.random().toString(36).slice(2) + Date.now().toString(36);
            localStorage.setItem('bridgeBidReconnectToken', t);
        }
        return t;
    } catch (e) {
        // localStorage indisponible (navigation privée stricte, etc.) : le jeton ne
        // survivra pas à un rechargement, mais au moins l'app ne plante pas.
        if (!window._fallbackReconnectToken) {
            window._fallbackReconnectToken = 'p' + Math.random().toString(36).slice(2) + Date.now().toString(36);
        }
        return window._fallbackReconnectToken;
    }
}

let mySeats = null;         // sièges contrôlés par ce joueur pendant la partie
let autoPassSeats = [];     // sièges non assignés (robot "passe") — décidé par l'hôte au lancement

// Plus de statut kibbitz suivi séparément (source de bug : oublié pour un joueur qui
// rejoint après le lancement de la partie, resté "spectateur" sans les mains) — un
// kibbitz, c'est simplement quiconque n'occupe aucun siège, dérivé à la demande plutôt
// que traqué en parallèle de mySeats.
function isKibbitz() {
    return !mySeats || mySeats.length === 0;
}

// ===== Préférences d'affichage des mains (locales, persistées, indépendantes du réseau) =====
//
// Purement cosmétique et propre à chaque appareil (comme le jeton de reconnexion) : pas
// besoin de les synchroniser entre joueurs, chacun choisit sa propre présentation.

function loadBoolPref(key, fallback) {
    try {
        const v = localStorage.getItem(key);
        return v === null ? fallback : v === 'true';
    } catch (e) {
        return fallback;
    }
}

function saveBoolPref(key, value) {
    try { localStorage.setItem(key, value ? 'true' : 'false'); } catch (e) { /* navigation privée stricte, tant pis */ }
}

// Même principe que loadBoolPref/saveBoolPref, pour une valeur texte (le pseudo — voir
// savedNickname plus bas) plutôt qu'un booléen.
function loadStringPref(key, fallback) {
    try {
        const v = localStorage.getItem(key);
        return v === null || v === '' ? fallback : v;
    } catch (e) {
        return fallback;
    }
}

function saveStringPref(key, value) {
    try {
        if (value) localStorage.setItem(key, value);
        else localStorage.removeItem(key);
    } catch (e) { /* navigation privée stricte, tant pis */ }
}

// Pseudo choisi par l'utilisateur, mémorisé sur cet appareil comme les autres préférences
// d'affichage — propre à l'appareil, pas au jeton de reconnexion (qui identifie la place
// dans UNE partie précise, alors que le pseudo doit survivre d'une partie à l'autre).
// null si jamais personnalisé : on retombe alors sur defaultParticipantName comme avant.
let savedNickname = loadStringPref('bridgeBidNickname', null);

let useFrenchRanks = loadBoolPref('bridgeBidFrenchRanks', false); // R/D/V/X au lieu de K/Q/J/T
let showHcp = loadBoolPref('bridgeBidShowHcp', false);            // affiche le compte de points d'honneur par main
let showKr = loadBoolPref('bridgeBidShowKr', false);              // affiche l'évaluation Kaplan-Rubens par main
let showLedgerNames = loadBoolPref('bridgeBidShowLedgerNames', false); // noms des joueurs au lieu de N/E/S/O dans le tableau d'enchères
// (Hôte uniquement) Voir les 4 mains à tout moment pendant la partie, même en pleine
// enchère — voir uiToggleHostSeeAllHands. Jamais envoyé aux autres joueurs.
let hostSeeAllHands = loadBoolPref('bridgeBidHostSeeAllHands', false);

const FRENCH_RANK_LETTER = { K: 'R', Q: 'D', J: 'V', T: 'X' };

// Convertit une chaîne de rangs (ex: "AKQT98") selon la préférence de notation en cours.
function formatRanksForDisplay(ranks) {
    if (!ranks) return '';
    if (!useFrenchRanks) return ranks;
    return ranks.split('').map(c => FRENCH_RANK_LETTER[c] || c).join('');
}

const HCP_VALUE = { A: 4, K: 3, Q: 2, J: 1 };

// Compte de points d'honneur (High Card Points) d'une main : As=4, Roi=3, Dame=2, Valet=1.
function computeHandHcp(hand) {
    let total = 0;
    ['S', 'H', 'D', 'C'].forEach(suit => {
        const ranks = hand[suit] || '';
        for (const c of ranks) total += HCP_VALUE[c] || 0;
    });
    return total;
}

// ===== Évaluateur Kaplan-Rubens (CCCC — "Complex Computer Count") =====
//
// Port fidèle de la fonction cccc() du code de référence de Jeff Goldsmith
// (https://www.jeff-goldsmith.com/knrsource.c), qui implémente l'algorithme d'Edgar
// Kaplan et Jeff Rubens tel que publié dans Bridge World, octobre 1982, pp. 21-23.
// N'implémente QUE le calcul Kaplan-Rubens d'origine ("cccc"), pas la variante de Danny
// Kleinman ("dkcccc") qui figure dans les mêmes fichiers.
//
// Une seule divergence connue entre les sources de référence elles-mêmes (voir plus bas,
// couleurs de 7 cartes) : on suit alors knrsource.c, la source d'origine désignée.

const KR_SUITS = ['S', 'H', 'D', 'C'];

function krHas(hand, suit, rank) {
    return hand[suit].includes(rank);
}

function krCountHeld(hand, suit, ranks) {
    let n = 0;
    for (const r of ranks) if (krHas(hand, suit, r)) n++;
    return n;
}

function computeKaplanRubens(hand) {
    const len = {};
    KR_SUITS.forEach(s => { len[s] = hand[s].length; });

    // 321 count pour les As, Rois, Dames (honneurs "protégés" au sens large)
    let pakq = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'A')) pakq += 3;
        if (krHas(hand, s, 'K')) pakq += 2;
        if (krHas(hand, s, 'Q')) pakq += 1;
    });

    // Points de longueur : 4321 count pondéré par la longueur de la couleur
    let p2 = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'A')) p2 += len[s] * 4;
        if (krHas(hand, s, 'K')) p2 += len[s] * 3;
        if (krHas(hand, s, 'Q')) p2 += len[s] * 2;
        if (krHas(hand, s, 'J')) p2 += len[s] * 1;
    });

    // Bonus pour longues couleurs sans les honneurs bas (Dame/Valet) qui y seraient
    // de toute façon peu utiles.
    KR_SUITS.forEach(s => {
        const l = len[s];
        const hasQ = krHas(hand, s, 'Q');
        const hasJ = krHas(hand, s, 'J');
        if (l === 7) {
            // Le texte original ("1 point si Dame ou Valet manquant") est ambigu, et les
            // DEUX sources de référence de Jeff Goldsmith (C et Perl) le traitent
            // différemment l'une de l'autre pour ce cas précis : knrsource.c déclenche le
            // bonus dès qu'IL MANQUE AU MOINS L'UN des deux honneurs, alors que sa version
            // Perl exige qu'ils manquent TOUS LES DEUX (avec une note de l'auteur disant
            // lui-même ne pas être sûr de l'intention d'origine). On suit ici knrsource.c,
            // la source désignée comme référence.
            if (!hasQ || !hasJ) p2 += 7;
        }
        if (l === 8) {
            if (!hasQ) p2 += 16;
            else if (!hasJ) p2 += 8;
        }
        if (l > 8) {
            if (!hasQ) p2 += 2 * l;
            if (!hasJ) p2 += l;
        }
    });

    // Honneurs bas selon la longueur de la couleur (Dix, Neuf)
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (krHas(hand, s, 'T')) {
            if (l > 6) {
                p2 += 0.5 * l;
            } else {
                const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
                if (higher >= 2 || krHas(hand, s, 'J')) p2 += l;
                else p2 += 0.5 * l;
            }
        }
        if (krHas(hand, s, '9') && l <= 6) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
            if (higher >= 2 || krHas(hand, s, 'T') || krHas(hand, s, '8')) p2 += 0.5 * l;
        }
    });

    // Points de brièveté (chicane/singleton/doubleton) — on ne compte pas le 1er doubleton
    let pdist = 0;
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (l === 0) pdist += 3;
        else if (l === 1) pdist += 2;
        else if (l === 2) pdist += 1;
    });
    if (pdist !== 0) pdist -= 1;

    // Rois secs, Dames courtes ou longues sans As/Roi d'appui
    let p = pakq;
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (krHas(hand, s, 'K') && l === 1) p -= 1.5;
        if (krHas(hand, s, 'Q') && l < 3) {
            p -= 1;
            if (krHas(hand, s, 'A') || krHas(hand, s, 'K')) p += 0.5;
            else if (l === 2) p += 0.25;
        }
        if (krHas(hand, s, 'Q') && l >= 3) {
            if (!krHas(hand, s, 'A') && !krHas(hand, s, 'K')) p -= 0.25;
        }
    });

    // Honneurs bas (Valet, Dix) soutenus par des honneurs supérieurs
    let p3 = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'J')) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
            if (higher === 2) p3 += 0.5;
            if (higher === 1) p3 += 0.25;
        }
        if (krHas(hand, s, 'T')) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q', 'J']);
            if (higher === 2) p3 += 0.25;
            if (higher === 1 && krHas(hand, s, '9')) p3 += 0.25;
        }
    });

    // Pénalité pour la répartition 4-3-3-3
    const sortedLens = KR_SUITS.map(s => len[s]).sort((a, b) => b - a);
    const d = sortedLens[3] === 3 ? 0.5 : 0;

    return p + p2 / 10 + p3 + pdist - d;
}

function uiToggleFrenchRanks() {
    useFrenchRanks = !useFrenchRanks;
    saveBoolPref('bridgeBidFrenchRanks', useFrenchRanks);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        if (isAuctionOver(auctionHistory)) renderAllHandsDiagram();
    }
}

function uiToggleShowHcp() {
    showHcp = !showHcp;
    saveBoolPref('bridgeBidShowHcp', showHcp);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        if (isAuctionOver(auctionHistory)) renderAllHandsDiagram();
    }
}

function uiToggleShowKr() {
    showKr = !showKr;
    saveBoolPref('bridgeBidShowKr', showKr);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        if (isAuctionOver(auctionHistory)) renderAllHandsDiagram();
    }
}

function uiToggleLedgerNames() {
    showLedgerNames = !showLedgerNames;
    saveBoolPref('bridgeBidShowLedgerNames', showLedgerNames);
    const btn = document.getElementById('ledgerNamesToggleBtn');
    if (btn) btn.classList.toggle('is-active', showLedgerNames);
    if (deals) renderAuctionLedger();
}

// Réservé à l'hôte : révèle les 4 mains à tout moment pendant la partie, même en pleine
// enchère (utile pour vérifier une donne, aider un débutant en direct, etc.). Purement
// local — jamais envoyé aux autres joueurs, qui ne voient toujours que ce qu'ils sont
// censés voir. Voir checkAuctionEnd, qui force l'affichage du diagramme des 4 mains tant
// que ce réglage est actif, indépendamment de l'état de l'enchère.
function uiToggleHostSeeAllHands() {
    if (myRole !== 'host') return;
    hostSeeAllHands = !hostSeeAllHands;
    saveBoolPref('bridgeBidHostSeeAllHands', hostSeeAllHands);
    renderHandDisplayOptionButtons();
    if (deals) checkAuctionEnd();
}

function renderHandDisplayOptionButtons() {
    const frBtn = document.getElementById('frenchRanksToggleBtn');
    if (frBtn) frBtn.classList.toggle('is-active', useFrenchRanks);

    const hcpBtn = document.getElementById('hcpToggleBtn');
    if (hcpBtn) hcpBtn.classList.toggle('is-active', showHcp);

    const krBtn = document.getElementById('krToggleBtn');
    if (krBtn) krBtn.classList.toggle('is-active', showKr);

    const hostSeeAllBtn = document.getElementById('hostSeeAllHandsBtn');
    if (hostSeeAllBtn) {
        hostSeeAllBtn.style.display = myRole === 'host' ? '' : 'none';
        hostSeeAllBtn.classList.toggle('is-active', hostSeeAllHands);
    }
}
let deals = null;           // tableau de donnes parsées
let boardIndex = 0;
let auctionHistory = [];    // historique de la donne en cours : [{seat, call}, ...]

// (Hôte) Résultat du fichier de donnes déjà lu et parsé au moment où il a été choisi (voir
// uiHandleDealFileChosen), pour afficher tout de suite une éventuelle erreur ou
// l'avertissement "PARs non disponibles" — pendant que l'hôte compose encore la table,
// PAS au moment de cliquer sur "Commencer la partie", puisqu'à cet instant l'écran du
// salon (et donc le message) disparaît immédiatement avec le passage à l'écran de jeu.
let pendingParsedDeals = null;
// Identifie la source dont pendingParsedDeals est le résultat, pour savoir si le cache
// est encore valable sans avoir à relire/re-fetch : soit l'objet File choisi via l'input
// upload, soit une chaîne 'library:nomDeFichier' pour une donne piochée dans la
// bibliothèque du club (voir uiHandleDealLibraryChosen) — comparée uniquement par
// égalité (===), jamais utilisée comme un vrai File au-delà de ce contrôle.
let pendingParsedSource = null;

// Ordre effectivement utilisé pour la partie : soit pendingParsedDeals tel quel (ordre du
// fichier), soit une copie mélangée, selon la case "Ordre aléatoire des donnes" (voir
// uiToggleRandomizeDeals). Calculé une seule fois par chargement de fichier / bascule de
// la case, et réutilisé à la fois par l'aperçu et par le lancement de la partie, pour que
// l'un corresponde toujours exactement à l'autre. Les numéros de donne d'origine (deal.board)
// sont conservés tels quels dans le fichier — seul l'ordre de passage est mélangé.
let pendingOrderedDeals = null;

// Mélange de Fisher-Yates (Math.random() suffit ici : besoin d'aléatoire simple pour
// varier l'ordre d'entraînement, pas de garanties cryptographiques).
function shuffleDealsArray(arr) {
    const shuffled = arr.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Recalcule pendingOrderedDeals à partir de pendingParsedDeals et de l'état actuel de la
// case à cocher. Appelé au chargement du fichier et à chaque bascule de la case.
function refreshPendingOrderedDeals() {
    if (!pendingParsedDeals) {
        pendingOrderedDeals = null;
        return;
    }
    const checkbox = document.getElementById('randomizeDealsToggle');
    pendingOrderedDeals = (checkbox && checkbox.checked)
        ? shuffleDealsArray(pendingParsedDeals)
        : pendingParsedDeals;
}

// Appelé par la case "Ordre aléatoire des donnes" du salon d'attente.
function uiToggleRandomizeDeals() {
    refreshPendingOrderedDeals();
}

// ===== Bibliothèque de donnes du club =====
//
// donnes/catalogue.json est un simple tableau de noms de fichiers (voir donnes/README.md
// pour la marche à suivre pour en ajouter) : ["exemple.pbn", "autre-exemple.lin"]. Pas de
// backend — ajouter une donne à la bibliothèque, c'est déposer le fichier dans donnes/ et
// ajouter son nom à ce tableau, puis pousser sur GitHub comme le reste du site.
//
// Chargé une fois au démarrage de l'appli plutôt qu'à l'entrée dans le salon : peu de
// risque que le catalogue change en cours de session, et ça évite un aller-retour réseau
// à chaque fois que l'hôte revient sur cet écran.
function initDealLibrary() {
    fetch('donnes/catalogue.json')
        .then(resp => {
            if (!resp.ok) throw new Error('catalogue absent ou illisible');
            return resp.json();
        })
        .then(filenames => {
            if (!Array.isArray(filenames) || filenames.length === 0) return; // bibliothèque vide : on laisse le groupe masqué

            const select = document.getElementById('dealLibrarySelect');
            const group = document.getElementById('dealLibraryGroup');
            if (!select || !group) return;

            filenames.forEach(filename => {
                const option = document.createElement('option');
                option.value = filename;
                option.textContent = filename;
                select.appendChild(option);
            });
            group.style.display = 'block';
        })
        .catch(() => {
            // Pas de bibliothèque déployée (ou catalogue.json absent/vide) : ce n'est pas
            // une erreur pour l'utilisateur, juste une fonctionnalité qui ne s'active pas.
            // Le groupe reste masqué (voir style initial dans index.html), pas de message.
        });
}

// --- Demande d'annulation (undo) ---
let undoRequestPending = false; // je suis le demandeur, en attente d'une réponse
let pendingUndoAsk = null;      // on me demande d'accepter/refuser une annulation
let hostPendingUndo = null;     // (hôte uniquement) demande en cours d'arbitrage
let undoRequestTimeoutId = null;

function currentDeal() {
    return deals[boardIndex];
}

// Un kibbitz (non assigné à un siège) ne peut pas naviguer entre les donnes ; tout
// joueur actif (hôte ou invité) le peut.
function canControlBoard() {
    return myRole === 'host' || (mySeats && mySeats.length > 0);
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
}

// Avatar rond (couleur + initiale) affiché devant un participant, dans la liste et dans
// les cases de sièges assignées — juste un repère visuel rapide pour distinguer les
// joueurs d'un coup d'œil, pas une vraie identité. La couleur est dérivée de l'id du
// participant (stable même s'il se renomme, change du coup si un autre participant
// prend sa place au même id ne se produit jamais — les id sont uniques par connexion).
// Palette de couleurs d'avatar : les 15 couleurs par défaut officielles de Twitch (celles
// proposées gratuitement dans son sélecteur "Chat Identity", sans abonnement Turbo/Prime)
// — même liste, mêmes valeurs hexadécimales exactes.
const AVATAR_COLOR_PALETTE = [
    '#FF0000', // Red
    '#0000FF', // Blue
    '#00FF00', // Green
    '#8A2BE2', // BlueViolet
    '#FF7F50', // Coral
    '#5F9EA0', // CadetBlue
    '#D2691E', // Chocolate
    '#1E90FF', // DodgerBlue
    '#B22222', // Firebrick
    '#DAA520', // GoldenRod
    '#FF69B4', // HotPink
    '#FF4500', // OrangeRed
    '#2E8B57', // SeaGreen
    '#00FF7F', // SpringGreen
    '#9ACD32', // YellowGreen
];

function avatarColorForId(id) {
    // Mélange le code de salon dans le hash (pas l'id seul) : une couleur différente à
    // chaque nouvelle partie plutôt qu'une "couleur de signature" fixe pour toujours sur
    // cet appareil — mais stable pendant toute la durée d'UNE partie, y compris après une
    // reconnexion (le code de salon ne change pas entre-temps, seul le jeton pourrait
    // changer de contexte). Sans code de salon connu (avant qu'une partie ait démarré),
    // repli sur l'id seul.
    let hash = 0;
    const str = (currentRoomCode || '') + '|' + String(id || '');
    for (let i = 0; i < str.length; i++) {
        hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
    }
    return AVATAR_COLOR_PALETTE[hash % AVATAR_COLOR_PALETTE.length];
}

// Certaines des 15 couleurs Twitch (Green, SpringGreen, HotPink...) sont trop claires
// pour rester lisibles avec le texte blanc fixe de l'initiale dans le rond d'avatar —
// Twitch, lui, ne les utilise qu'en texte sur fond sombre, jamais en aplat avec du blanc
// dessus. Calcule donc noir ou blanc selon la luminosité perçue de la couleur de fond
// (formule standard de luminance relative), plutôt qu'un blanc fixe qui échouerait sur
// les teintes claires de la palette.
function avatarTextColorFor(hexColor) {
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.55 ? '#17231d' : '#ffffff';
}



function avatarInitial(name) {
    const trimmed = (name || '').trim();
    return trimmed ? trimmed[0].toUpperCase() : '?';
}

// HTML de l'avatar pour un participant donné (par son id) ; chaîne vide si personne.
function avatarHtml(participantId) {
    const p = participants.find(x => x.id === participantId);
    if (!p) return '';
    const bg = avatarColorForId(p.id);
    return `<span class="mini-avatar" style="background:${bg};color:${avatarTextColorFor(bg)}">${escapeHtml(avatarInitial(p.name))}</span>`;
}

function defaultParticipantName(pid) {
    if (pid === 'host') return 'Hôte';
    // Nom par défaut d'un nouvel invité, basé sur son rang d'arrivée (pas sur son id, qui
    // est maintenant un jeton opaque et non plus un simple numéro de connexion).
    const guestCount = participants.filter(p => p.id !== 'host').length;
    return 'Guest #' + (guestCount + 1);
}

// ===== Navigation entre écrans =====

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(el => el.style.display = 'none');
    // '' (et non 'block' en dur) : un style inline a une priorité absolue sur n'importe
    // quelle règle de styles.css, y compris #screen-game { display: flex; ... } posé par
    // le layout plein écran mobile (voir @media max-width:768px) — le forcer à 'block'
    // ici l'écrasait silencieusement et faisait s'effondrer tout le système de répartition
    // des hauteurs (mains/enchères/boîte fixée en bas), avec un retour au scroll de page
    // classique. Laisser vide restaure le display défini par la feuille de style (block
    // par défaut pour un <section>, flex pour #screen-game sous 768px).
    document.getElementById(id).style.display = '';

    // Le chat n'a de sens qu'une fois dans un salon ou en partie (il faut des participants
    // à qui parler) : masqué sur l'écran d'accueil, affiché partout ailleurs. Point de
    // contrôle unique ici plutôt que dispersé à chaque appel de showScreen (voir échange
    // avec Guillaume — le bouton était visible dès le chargement, avant toute connexion,
    // alors que non fonctionnel).
    const chatBtn = document.getElementById('chatToggleBtn');
    if (chatBtn) {
        chatBtn.style.display = (id === 'screen-landing') ? 'none' : '';
        // Si on retombe sur l'écran d'accueil (ex. erreur de connexion) alors que le
        // panneau de chat était resté ouvert, on le referme avec : un panneau de chat
        // ouvert sur l'écran d'accueil serait tout aussi orphelin que le bouton qui
        // l'ouvre.
        if (id === 'screen-landing' && chatPanelOpen) uiToggleChat();
    }

    // Voir échange avec Guillaume : sur l'écran d'accueil, rien n'est encore connecté, le
    // trait de séparation sous la barre de statut n'a donc rien à séparer et fait juste
    // ligne parasite (voir la règle CSS body.on-landing-screen .connection-bar).
    document.body.classList.toggle('on-landing-screen', id === 'screen-landing');

    // Chaque changement d'écran est une occasion de retenter une mise à jour PWA restée en
    // attente (voir tryAutoApplyUpdate) — sans effet tant qu'une connexion de salle est
    // active, donc sans risque à appeler ici systématiquement, y compris pour screen-game.
    tryAutoApplyUpdate();
}

function setConnectionStatus(connected) {
    const bar = document.getElementById('connectionBar');
    const status = document.getElementById('connectionStatus');
    bar.style.display = 'flex';
    status.textContent = connected ? '🟢 Connecté' : '🔴 Déconnecté';
    status.className = 'connection-status ' + (connected ? 'connected' : 'disconnected');
}

function showLandingError(msg) {
    const el = document.getElementById('landingError');
    el.textContent = msg;
    el.style.display = 'block';
}

// ===== Panneau de diagnostic (visible à l'écran, utile sur mobile sans accès aux DevTools) =====

const debugLogLines = [];

function pushDebugLog(line) {
    const timestamp = new Date().toLocaleTimeString('fr-FR');
    debugLogLines.push(`[${timestamp}] ${line}`);
    const content = document.getElementById('debugLogContent');
    if (content) {
        content.textContent = debugLogLines.join('\n');
        content.scrollTop = content.scrollHeight;
    }
}

function uiToggleDebugPanel() {
    const panel = document.getElementById('debugPanel');
    panel.style.display = panel.style.display === 'none' ? 'flex' : 'none';
}

function uiCopyDebugLog() {
    const text = debugLogLines.join('\n');
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).catch(() => fallbackCopyDebugLog(text));
    } else {
        fallbackCopyDebugLog(text);
    }
}

function fallbackCopyDebugLog(text) {
    const content = document.getElementById('debugLogContent');
    const range = document.createRange();
    range.selectNodeContents(content);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('copy');
}

// ===== Écran d'accueil : créer / rejoindre =====

function tokenForGuestIndex(guestIndex) {
    return Object.keys(guestIndexByToken).find(t => guestIndexByToken[t] === guestIndex) || null;
}

function uiCreateRoom() {
    document.getElementById('landingError').style.display = 'none';
    if (peerConn) peerConn.destroy();

    myRole = 'host';
    myParticipantId = 'host';
    participants = [{ id: 'host', name: savedNickname || 'Hôte' }];
    seatAssignment = { N: null, E: null, S: null, W: null };
    guestIndexByToken = {};
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;
    chatMessages = [];
    chatUnreadCount = 0;
    updateChatUnreadBadge();
    lobbyChatAutoOpened = false;
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;

    peerConn = new BridgePeerConnection(buildHostHandlers());
    peerConn.createRoom();
}

// Handlers PeerJS côté hôte — partagés entre uiCreateRoom (nouvelle partie) et la prise de
// rôle après un transfert d'hôte (voir uiTransferHost/'prepare-become-host'), qui doivent
// tous deux traiter les connexions entrantes exactement de la même façon. Seul le
// comportement à l'ouverture du Peer diffère (onOpenExtra) : une toute nouvelle partie
// atterrit dans le salon normalement, une prise de rôle a besoin de faire autre chose
// d'abord (prévenir l'ancien hôte) avant de basculer l'écran.
function buildHostHandlers(onOpenExtra) {
    return {
        onOpen: (role, roomCode) => {
            currentRoomCode = roomCode;
            const url = new URL(window.location.href);
            url.searchParams.set('room', roomCode);
            document.getElementById('shareLinkInput').value = url.toString();
            document.getElementById('lobbyRoomCodeInline').textContent = `(code ${roomCode})`;
            if (onOpenExtra) onOpenExtra(roomCode);
            else enterLobbyScreen();
        },
        onGuestConnected: (guestIndex, metadata) => {
            setConnectionStatus(true);
            // Jeton fourni par l'invité (persistant côté lui, via localStorage) : s'il est
            // déjà connu, c'est un retour (reconnexion), pas un nouvel arrivant. Repli sur un
            // id à l'ancienne pour un client qui n'enverrait pas de jeton (compat).
            const token = (metadata && metadata.reconnectToken) || ('guest' + guestIndex);
            guestIndexByToken[token] = guestIndex;

            let p = participants.find(x => x.id === token);
            const isReturning = !!p;
            const wasDisconnected = isReturning && p.disconnected;
            if (!p) {
                // Un pseudo sauvegardé côté invité (voir savedNickname) prime sur le nom
                // générique "Guest #N" — transmis via les métadonnées de connexion, comme
                // le jeton de reconnexion.
                const nickname = metadata && metadata.nickname;
                p = { id: token, name: nickname || defaultParticipantName(token), disconnected: false, disconnectedAt: null };
                participants.push(p);
            } else {
                p.disconnected = false;
                p.disconnectedAt = null;
            }
            pushDebugLog(`Connexion #${guestIndex} : jeton ${token.slice(0, 10)}… → ${isReturning ? 'reconnexion reconnue (' + p.name + ')' : 'nouveau participant'}`);
            if (wasDisconnected) flashWelcomeBack(p.name);

            peerConn.send({ type: 'welcome', yourId: token }, guestIndex);

            if (deals) {
                // La partie est déjà lancée : on renvoie l'état complet (donnes, enchère en
                // cours, sièges) à ce joueur, qu'il soit nouveau ou de retour après coupure.
                // Les sièges "robot" restent ceux décidés au lancement (voir uiStartGameAsHost) :
                // un joueur déconnecté n'est PAS remplacé automatiquement, son siège attend
                // simplement qu'il revienne (voir le tour-indicateur pendant la partie).
                const seatsForThisGuest = SEATS.filter(seat => seatAssignment[seat] === token);
                peerConn.send({
                    type: 'resync',
                    deals, boardIndex, auctionHistory,
                    yourSeats: seatsForThisGuest,
                    botSeats: autoPassSeats
                }, guestIndex);
            }

            broadcastLobbyState();
            renderLobby();
            if (deals) renderBoard();
        },
        onPeerDisconnected: (guestIndex) => {
            setConnectionStatus(peerConn ? peerConn.isConnected() : false);
            const token = tokenForGuestIndex(guestIndex);
            if (token) {
                delete guestIndexByToken[token];
                // On NE supprime pas le participant ni son siège : ils restent réservés, en
                // attente qu'il se reconnecte. Son siège n'est PAS remplacé par un robot —
                // l'enchère patiente simplement (le tour-indicateur et la bannière de
                // reconnexion le signalent tous les deux, cf. renderReconnectionBanner).
                const p = participants.find(x => x.id === token);
                if (p) { p.disconnected = true; p.disconnectedAt = Date.now(); }
            }
            hostPendingUndo = null; // un invité qui part au milieu d'un arbitrage : on ne reste pas bloqué
            // Voir audit : si le participant qui vient de partir était justement la cible
            // d'un transfert d'hôte en cours, plus aucune réponse ('become-host-ready' ou
            // '-failed') n'arrivera jamais — sans ce filet, hostTransferInProgress resterait
            // bloqué à true pour toujours, empêchant tout nouveau transfert.
            if (hostTransferInProgress && token === pendingHostTransferTarget) {
                hostTransferInProgress = false;
                pendingHostTransferTarget = null;
                pendingHostTransferOldToken = null;
                showHostTransferStatus('Le participant visé par le transfert vient de se déconnecter. Transfert annulé, vous restez hôte.', true);
            }
            broadcastLobbyState();
            renderLobby();
            if (deals) renderBoard();
        },
        onSlowConnection: () => {},
        onTimeout: () => {},
        onData: handlePeerData,
        // Voir onSignalingDisconnected côté invité (buildGuestHandlers) : même lacune côté
        // hôte, avec une conséquence différente — les invités déjà connectés continuent
        // parfois de fonctionner un moment via leur canal WebRTC direct, mais personne de
        // nouveau ne peut plus rejoindre la partie tant que ce n'est pas rétabli. Ça
        // correspond très probablement au souci "Aucune partie trouvée" déjà diagnostiqué
        // (host qui change d'appli sur iPhone juste après avoir créé la salle) : au moins,
        // maintenant, le statut reflète ce problème au lieu de rester "🟢 Connecté".
        onSignalingDisconnected: () => {
            setConnectionStatus(false);
        },
        onError: (err) => {
            showLandingError('Erreur de connexion : ' + ((err && (err.message || err.type)) || err));
        }
    };
}

// Construit les handlers PeerJS côté invité — partagés entre uiJoinRoom (première
// connexion) et uiReconnect (après une coupure), pour ne pas dupliquer la logique.
function buildGuestHandlers() {
    return {
        onOpen: (role, roomCode) => {
            document.getElementById('lobbyRoomCodeInline').textContent = `(code ${roomCode})`;
        },
        onGuestConnected: () => {
            everConnectedAsGuest = true;
            setConnectionStatus(true);
            renderReconnectButton();
        },
        onPeerDisconnected: () => {
            setConnectionStatus(false);
            renderReconnectButton();
        },
        // Voir échange avec Guillaume ("le bouton Se reconnecter n'apparaît pas") : sans ce
        // handler, une coupure de la connexion au serveur de signalisation (WebSocket) qui
        // ne provoque pas de fermeture propre de la DataConnection passait complètement
        // inaperçue — ni le statut ni le bouton ne se mettaient à jour.
        onSignalingDisconnected: () => {
            setConnectionStatus(false);
            renderReconnectButton();
        },
        onSlowConnection: () => {
            showLandingError("⏳ Ça prend plus de temps que d'habitude... Vérifie que le code est correct.");
        },
        onTimeout: () => {
            if (deals) {
                // On était déjà en jeu : pas de retour à l'écran d'accueil, on laisse le
                // bouton "Se reconnecter" de la barre de connexion (renderReconnectButton).
                return;
            }
            showScreen('screen-landing');
            showLandingError(
                "⚠️ La connexion n'a pas abouti après 45 secondes. Vérifie le code, que l'hôte est " +
                "toujours connecté, et ouvre la console (F12) pour plus de détails avant de réessayer."
            );
        },
        onData: handlePeerData,
        onError: (err) => {
            if (!deals) showScreen('screen-landing');
            if (err && err.type === 'peer-unavailable') {
                showLandingError("Aucune partie trouvée avec ce code. Vérifiez le code ou demandez à l'hôte de le repartager.");
            } else {
                showLandingError('Erreur de connexion : ' + ((err && (err.message || err.type)) || err));
            }
        }
    };
}

// Voir échange avec Guillaume (double tap nécessaire sur "Rejoindre" au clavier mobile) :
// valider directement depuis le clavier virtuel (touche "Aller", voir enterkeyhint="go"
// dans index.html) contourne complètement le souci, plutôt que de devoir taper le bouton.
function uiJoinCodeInputKeydown(event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    uiJoinRoom();
}

function uiJoinRoom() {
    document.getElementById('landingError').style.display = 'none';
    const code = document.getElementById('joinCodeInput').value.trim().toUpperCase();
    if (code.length !== 4) {
        showLandingError('Entrez un code à 4 lettres.');
        return;
    }
    chatMessages = [];
    chatUnreadCount = 0;
    updateChatUnreadBadge();
    connectAsGuest(code, getReconnectToken(), savedNickname);
}

// Rejoint (ou re-rejoint) une salle en tant qu'invité, avec un jeton et un pseudo donnés.
// Partagé par uiJoinRoom (première connexion) et le transfert d'hôte (voir 'host-transferred'
// / 'become-host-ready' dans handlePeerData) : dans les deux cas, on repart d'un état de
// salon vierge, qui sera reconstitué dès réception du premier 'lobby-state' du nouvel hôte —
// exactement comme un rejoin normal.
function connectAsGuest(code, token, nickname) {
    if (peerConn) peerConn.destroy();

    myRole = 'guest';
    myParticipantId = null; // fixé à réception du message 'welcome'
    participants = [];
    seatAssignment = { N: null, E: null, S: null, W: null };
    currentRoomCode = code;
    everConnectedAsGuest = false;
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;
    lobbyChatAutoOpened = false;

    peerConn = new BridgePeerConnection(buildGuestHandlers());
    pushDebugLog(`Connexion au salon ${code} avec le jeton ${token.slice(0, 10)}…`);
    peerConn.joinRoom(code, { reconnectToken: token, nickname: nickname });
}

// Reconnexion après coupure : même code de salon, même jeton (localStorage) — l'hôte
// reconnaît le jeton et renvoie automatiquement les sièges et l'état de partie en cours.
function uiReconnect() {
    if (myRole !== 'guest' || !currentRoomCode) return;
    if (peerConn) peerConn.destroy();
    setConnectionStatus(false);
    peerConn = new BridgePeerConnection(buildGuestHandlers());
    const token = getReconnectToken();
    pushDebugLog(`Reconnexion au salon ${currentRoomCode} avec le jeton ${token.slice(0, 10)}…`);
    peerConn.joinRoom(currentRoomCode, { reconnectToken: token, nickname: savedNickname });
}

let everConnectedAsGuest = false;

function renderReconnectButton() {
    const btn = document.getElementById('reconnectBtn');
    if (!btn) return;
    const shouldShow = myRole === 'guest' && everConnectedAsGuest && peerConn && !peerConn.isConnected();
    btn.style.display = shouldShow ? '' : 'none';
}

let copyShareLinkTimeoutId = null;
function uiCopyShareLink() {
    const input = document.getElementById('shareLinkInput');
    input.select();
    input.setSelectionRange(0, 99999);
    if (!navigator.clipboard) return;

    navigator.clipboard.writeText(input.value).then(() => {
        // Confirmation temporaire directement sur le bouton (pas de toast à part à
        // gérer) : le libellé change le temps d'un instant, puis revient à la normale.
        const btn = document.getElementById('copyShareLinkBtn');
        if (!btn) return;
        clearTimeout(copyShareLinkTimeoutId);
        btn.textContent = '✅ Lien copié !';
        copyShareLinkTimeoutId = setTimeout(() => {
            btn.textContent = '🔗 Copier lien de connexion';
        }, 1800);
    }).catch(() => { /* échec silencieux (permission navigateur, etc.) : pas de fausse confirmation */ });
}

// ===== Salon d'attente =====

function enterLobbyScreen() {
    showScreen('screen-lobby');
    document.getElementById('lobbyRoomCodeBlock').style.display = myRole === 'host' ? 'block' : 'none';
    document.getElementById('hostSetupPanel').style.display = myRole === 'host' ? 'block' : 'none';
    document.getElementById('guestWaitingNote').style.display = myRole === 'host' ? 'none' : 'block';

    // Voir échange avec Guillaume (session ratée avec 2 amis sur iPhone, "Aucune partie
    // trouvée" côté invités) : contrairement à #iosLockScreenWarning (dismissible, montré
    // une fois sur l'écran d'accueil), ce rappel-ci reste affiché à chaque fois qu'on
    // devient hôte sur iOS, tant que les conséquences d'un oubli sont un échec de
    // connexion complet pour les invités plutôt qu'une simple gêne en cours de partie.
    const iosHostWarning = document.getElementById('iosHostShareWarning');
    if (iosHostWarning) {
        iosHostWarning.style.display = (myRole === 'host' && isIosDevice()) ? 'block' : 'none';
    }

    const nameInput = document.getElementById('myNameInput');
    // On ne touche jamais au champ pendant que l'utilisateur est en train d'y taper
    // (sinon un lobby-state reçu pile pendant l'effacement du nom réécrase ce qu'il
    // est en train de saisir).
    if (!nameInput.value && document.activeElement !== nameInput) {
        const me = participants.find(p => p.id === myParticipantId);
        nameInput.value = me ? me.name : '';
    }

    // Voir échange avec Guillaume : dans le salon, le chat s'ouvre automatiquement — pas
    // besoin d'aller cliquer sur 💬 pour voir qui est là et papoter en attendant que tout
    // le monde arrive. `lobbyChatAutoOpened` évite de le rouvrir de force à chaque nouveau
    // 'lobby-state' reçu (enterLobbyScreen est réappelée à chaque changement de
    // participant) : une seule fois par entrée fraîche dans le salon, sinon on écraserait
    // le choix de quelqu'un qui l'aurait refermé volontairement entre-temps.
    if (!deals && !lobbyChatAutoOpened) {
        lobbyChatAutoOpened = true;
        if (!chatPanelOpen) uiToggleChat();
    }

    renderLobby();
}

function renderLobby() {
    renderParticipantsList();
    renderSeatAssignmentGrid();
    renderHostTransferWidget();
}

// Vrai si ce participant occupe un siège à la table — utilisé pour la coloration de son
// nom dans la liste des participants (bleu si placé, rouge sinon). Il n'y a plus de
// "place de kibbitz" à assigner à part : quiconque n'a pas de siège devient
// automatiquement kibbitz une fois la partie lancée (voir isKibbitz), donc rien
// d'autre à cocher ici.
function participantHasAPlace(participantId) {
    return SEATS.some(seat => seatAssignment[seat] === participantId);
}

function renderParticipantsList() {
    const list = document.getElementById('participantsList');
    // Si l'hôte est en train de renommer quelqu'un, on ne reconstruit pas la liste
    // (un reflow ici lui ferait perdre le focus et le curseur en pleine frappe).
    if (document.activeElement && document.activeElement.classList.contains('participant-rename-input')) {
        return;
    }
    const isHost = myRole === 'host';
    list.innerHTML = participants.map(p => {
        const canRename = isHost && p.id !== myParticipantId;
        const nameHtml = canRename
            ? `<input type="text" class="participant-rename-input" maxlength="20" value="${escapeHtml(p.name)}"
                   oninput="uiRenameParticipant('${p.id}', this.value)"
                   onblur="uiRenameParticipantBlur('${p.id}', this)">`
            : escapeHtml(p.name);
        // Bleu si assis à un siège (voir participantHasAPlace), rouge sinon — sans siège,
        // devient kibbitz automatiquement, ce n'est pas un problème à corriger.
        const placementClass = participantHasAPlace(p.id) ? 'is-assigned' : 'is-unassigned';
        return `
        <li class="participant-item ${placementClass} ${p.id === myParticipantId ? 'is-me' : ''}">
            ${avatarHtml(p.id)}
            ${nameHtml}
            ${p.id === 'host' ? ' <span class="host-tag">(hôte)</span>' : ''}
            ${p.id === myParticipantId ? ' <span class="me-tag">(vous)</span>' : ''}
            ${p.disconnected ? ' <span class="disconnected-tag">🔌 déconnecté — place réservée</span>' : ''}
        </li>
    `;
    }).join('');
}

let participantRenameDebounceTimers = {};
// Renommage d'un participant par l'hôte. On met à jour et on diffuse, mais sans
// reconstruire la liste des participants pendant la frappe (voir garde ci-dessus) — la
// grille des sièges, elle, peut se rafraîchir sans risque puisqu'elle ne contient pas le
// champ en cours d'édition.
function uiRenameParticipant(participantId, value) {
    if (myRole !== 'host') return;
    clearTimeout(participantRenameDebounceTimers[participantId]);
    participantRenameDebounceTimers[participantId] = setTimeout(() => {
        const trimmed = value.trim();
        if (!trimmed) return; // idem que pour son propre nom : on attend le blur si le champ est vide
        const p = participants.find(x => x.id === participantId);
        if (!p) return;
        p.name = trimmed;
        broadcastLobbyState();
        renderSeatAssignmentGrid();
    }, 300);
}

// Si l'hôte quitte le champ en le laissant vide, on retombe sur le nom par défaut
// de ce participant plutôt que de laisser un pseudo vide.
function uiRenameParticipantBlur(participantId, inputEl) {
    if (myRole !== 'host') return;
    clearTimeout(participantRenameDebounceTimers[participantId]);
    const p = participants.find(x => x.id === participantId);
    if (!p) return;
    const trimmed = inputEl.value.trim();
    p.name = trimmed || defaultParticipantName(participantId);
    broadcastLobbyState();
    renderLobby();
}

function renderSeatAssignmentGrid() {
    const container = document.getElementById('seatAssignmentGrid');
    const isHost = myRole === 'host';

    // Un siège "vient d'être assigné" si son occupant est non vide ET différent de ce
    // qu'il était au rendu précédent (couvre à la fois une case vide qui se remplit et un
    // changement d'occupant) — voir prevSeatAssignmentSnapshot pour le cas particulier du
    // tout premier rendu.
    const justAssigned = seat => {
        if (prevSeatAssignmentSnapshot === null) return false;
        const assignedId = seatAssignment[seat];
        return !!assignedId && assignedId !== prevSeatAssignmentSnapshot[seat];
    };

    const seatBoxes = SEATS.map(seat => {
        const assignedId = seatAssignment[seat];
        const flashClass = justAssigned(seat) ? ' just-assigned' : '';
        if (isHost) {
            const options = ['<option value="">— (robot : passe)</option>']
                .concat(participants.map(p =>
                    `<option value="${p.id}" ${p.id === assignedId ? 'selected' : ''}>${escapeHtml(p.name)}</option>`
                ));
            return `
                <div class="seat-box seat-pos-${seat}${flashClass}">
                    <span class="seat-box-label">${SEAT_FULL_NAME[seat]}</span>
                    <div class="seat-select-row">
                        ${assignedId ? avatarHtml(assignedId) : '<span class="mini-avatar mini-avatar-robot">🤖</span>'}
                        <select class="seat-assign-select" onchange="uiAssignSeat('${seat}', this.value)">${options.join('')}</select>
                    </div>
                </div>
            `;
        }
        const p = participants.find(x => x.id === assignedId);
        const name = p ? escapeHtml(p.name) : '— (robot)';
        return `
            <div class="seat-box seat-pos-${seat}${flashClass}">
                <span class="seat-box-label">${SEAT_FULL_NAME[seat]}</span>
                <span class="seat-box-name-row">
                    ${assignedId ? avatarHtml(assignedId) : '<span class="mini-avatar mini-avatar-robot">🤖</span>'}
                    <span class="seat-box-name">${name}</span>
                </span>
            </div>
        `;
    }).join('');

    container.innerHTML = seatBoxes;
    prevSeatAssignmentSnapshot = { ...seatAssignment };
}

let nameUpdateDebounceTimer = null;
function uiUpdateMyName() {
    clearTimeout(nameUpdateDebounceTimer);
    nameUpdateDebounceTimer = setTimeout(() => {
        const input = document.getElementById('myNameInput');
        const trimmed = input.value.trim();
        // Champ momentanément vide (l'utilisateur efface pour retaper autre chose) :
        // on n'impose pas le nom par défaut ici, seulement au blur (voir uiMyNameBlur).
        // Sinon on écrase ce que la personne est en train de saisir.
        if (!trimmed) return;

        const me = participants.find(p => p.id === myParticipantId);
        if (me) me.name = trimmed;
        saveStringPref('bridgeBidNickname', trimmed);
        savedNickname = trimmed;

        if (myRole === 'host') {
            broadcastLobbyState();
            renderLobby();
        } else if (peerConn) {
            peerConn.send({ type: 'set-name', name: trimmed });
            renderLobby();
        }
    }, 300);
}

// Si l'utilisateur quitte le champ en le laissant vide, on retombe sur le nom par
// défaut (au lieu de laisser un pseudo vide affiché aux autres) — et on efface le pseudo
// sauvegardé : revenir explicitement au nom générique doit aussi valoir pour la
// prochaine fois, pas seulement pour la session en cours.
function uiMyNameBlur() {
    const input = document.getElementById('myNameInput');
    if (input.value.trim()) return;
    clearTimeout(nameUpdateDebounceTimer);
    const name = defaultParticipantName(myParticipantId);
    input.value = name;
    const me = participants.find(p => p.id === myParticipantId);
    if (me) me.name = name;
    saveStringPref('bridgeBidNickname', null);
    savedNickname = null;

    if (myRole === 'host') {
        broadcastLobbyState();
        renderLobby();
    } else if (peerConn) {
        peerConn.send({ type: 'set-name', name });
        renderLobby();
    }
}

function uiAssignSeat(seat, participantId) {
    if (myRole !== 'host') return;
    seatAssignment[seat] = participantId || null;
    broadcastLobbyState();
    renderLobby();
}

function broadcastLobbyState() {
    peerConn.send({ type: 'lobby-state', participants, seatAssignment });
}

// Affiche/masque le petit bandeau de statut du transfert d'hôte, dans le salon (distinct
// de #hostSetupError, réservé aux erreurs de chargement de fichier de donnes).
function showHostTransferStatus(message, isError) {
    const el = document.getElementById('hostTransferStatus');
    if (!el) return;
    if (!message) { el.style.display = 'none'; return; }
    el.textContent = message;
    el.className = 'error-banner' + (isError ? '' : ' is-warning');
    el.style.display = 'block';
}

// Bouton unique à côté du pseudo (voir échange avec Guillaume : un seul bouton, pas un par
// participant dans la liste), qui ouvre un menu déroulant listant qui peut recevoir le
// rôle d'hôte. Visible seulement pour l'hôte, dans le salon, tant qu'au moins un autre
// participant connecté existe — sinon rien à proposer.
function renderHostTransferWidget() {
    const widget = document.getElementById('hostTransferWidget');
    if (!widget) return;

    const isHost = myRole === 'host';
    const eligible = isHost && !deals
        ? participants.filter(p => p.id !== myParticipantId && !p.disconnected)
        : [];

    if (!isHost || deals) {
        widget.style.display = 'none';
        uiCloseTransferMenu();
        return;
    }
    widget.style.display = '';

    const menu = document.getElementById('transferMenu');
    if (!menu) return;
    menu.innerHTML = eligible.length > 0
        ? eligible.map(p => `<button type="button" class="transfer-menu-item" onclick="uiTransferHost('${p.id}')">${avatarHtml(p.id)}${escapeHtml(p.name)}</button>`).join('')
        : `<div class="transfer-menu-empty">Personne d'autre pour l'instant.</div>`;
}

function uiToggleTransferMenu() {
    const menu = document.getElementById('transferMenu');
    if (!menu) return;
    if (menu.style.display === 'block') {
        uiCloseTransferMenu();
    } else {
        menu.style.display = 'block';
        // Ferme au clic ailleurs sur la page — posé au tick suivant, sinon le clic sur le
        // bouton lui-même (qui vient de déclencher cette ouverture) le refermerait aussitôt.
        setTimeout(() => document.addEventListener('click', uiTransferMenuOutsideClick), 0);
    }
}

function uiCloseTransferMenu() {
    const menu = document.getElementById('transferMenu');
    if (menu) menu.style.display = 'none';
    document.removeEventListener('click', uiTransferMenuOutsideClick);
}

function uiTransferMenuOutsideClick(event) {
    const widget = document.getElementById('hostTransferWidget');
    if (widget && !widget.contains(event.target)) uiCloseTransferMenu();
}

// Lance le transfert du rôle d'hôte vers `targetId`, un participant actuellement connecté
// (voir le menu déroulant dans renderHostTransferWidget). Ne fait que la première moitié
// du travail : envoyer à ce participant tout ce qu'il faut pour qu'il devienne hôte à son
// tour (voir 'prepare-become-host' dans handlePeerData) ; la bascule effective de l'ancien
// hôte se fait plus tard, à la réception de 'become-host-ready'.
function uiTransferHost(targetId) {
    uiCloseTransferMenu();
    if (myRole !== 'host' || deals) return; // uniquement possible dans le salon, avant le lancement
    if (hostTransferInProgress) return;

    const guestIndex = guestIndexByToken[targetId];
    const target = participants.find(p => p.id === targetId);
    if (guestIndex === undefined || !target || target.disconnected) {
        showHostTransferStatus('Ce joueur doit être connecté pour devenir hôte.', true);
        return;
    }
    if (!confirm(`Transférer le rôle d'hôte à ${target.name} ? Vous redeviendrez un simple participant, sur une nouvelle salle.`)) {
        return;
    }

    hostTransferInProgress = true;
    pendingHostTransferTarget = targetId;
    // Généré maintenant (pas seulement au moment de rejoindre la nouvelle salle) : il faut
    // que le nouvel hôte connaisse déjà ce jeton pour préparer la liste des participants et
    // les sièges AVANT même que je ne m'y reconnecte.
    pendingHostTransferOldToken = getReconnectToken();
    showHostTransferStatus(`Transfert de l'hôte à ${target.name} en cours...`, false);

    // On recalcule dès maintenant participants/seatAssignment tels qu'ils doivent apparaître
    // une fois le transfert effectif : mon entrée 'host' devient mon jeton personnel, et
    // l'entrée du participant ciblé devient 'host'. Envoyer un état déjà cohérent évite au
    // nouvel hôte d'avoir à faire lui-même cette traduction (il ne connaît pas forcément mon
    // jeton avant que je ne le lui donne ici).
    const newParticipants = participants.map(p => {
        if (p.id === 'host') return { ...p, id: pendingHostTransferOldToken };
        if (p.id === targetId) return { ...p, id: 'host' };
        return p;
    });
    const newSeatAssignment = {};
    SEATS.forEach(seat => {
        const occupant = seatAssignment[seat];
        if (occupant === 'host') newSeatAssignment[seat] = pendingHostTransferOldToken;
        else if (occupant === targetId) newSeatAssignment[seat] = 'host';
        else newSeatAssignment[seat] = occupant;
    });

    peerConn.send({ type: 'prepare-become-host', participants: newParticipants, seatAssignment: newSeatAssignment }, guestIndex);

    // Filet de sécurité : au cas où ni 'become-host-ready' ni 'become-host-failed' ni même
    // onPeerDisconnected ne se déclenchent (silence radio complet — improbable mais pas
    // impossible), on ne reste jamais bloqué plus de 20s sur "transfert en cours".
    setTimeout(() => {
        if (hostTransferInProgress && pendingHostTransferTarget === targetId) {
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            showHostTransferStatus('Le transfert a expiré sans réponse. Vous restez hôte, réessayez si besoin.', true);
        }
    }, 20000);
}

// ===== Démarrage de la partie (hôte) =====

// Affiche un message dans la bannière du panneau de chargement des donnes.
// `isWarning` distingue visuellement (voir .error-banner.is-warning dans styles.css) un
// avertissement non bloquant — la partie peut démarrer quand même (PARs absents, format
// de fichier ambigu) — d'une vraie erreur qui empêche de continuer (fichier illisible,
// aucun fichier choisi).
function setHostSetupMessage(text, isWarning) {
    const errorEl = document.getElementById('hostSetupError');
    errorEl.textContent = (isWarning ? '⚠️ ' : '') + text;
    errorEl.classList.toggle('is-warning', !!isWarning);
    errorEl.style.display = 'block';
}

function clearHostSetupMessage() {
    document.getElementById('hostSetupError').style.display = 'none';
}

// Parse et valide un texte de donnes déjà en main (peu importe sa provenance — fichier
// local lu via FileReader, ou donne de la bibliothèque récupérée via fetch, voir
// readAndValidateDealFile / readAndValidateDealFromLibrary), affichant tout de suite
// l'erreur ou l'avertissement "PARs non disponibles" s'il y a lieu. `onDone` reçoit le
// tableau de donnes parsées, ou `null` si le parsing a échoué (l'erreur est alors déjà
// affichée).
function validateAndUseDealText(text, filename, onDone) {
    clearHostSetupMessage();
    const infoEl = document.getElementById('dealFileInfo');
    infoEl.style.display = 'none';

    let parsedDeals;
    try {
        parsedDeals = parseDealFile(text, filename);
    } catch (err) {
        setHostSetupMessage(err.message, false);
        onDone(null);
        return;
    }

    const n = parsedDeals.length;
    document.getElementById('dealFileInfoText').textContent =
        `✅ ${n} donne${n > 1 ? 's' : ''} chargée${n > 1 ? 's' : ''}`;
    infoEl.style.display = 'flex';

    // Avertissements non bloquants (la partie peut démarrer quand même) : format de
    // fichier ambigu (voir parseDealFile) et/ou absence de toute info de contrat optimal.
    // Deux sources indépendantes dans le PBN peuvent la fournir (voir deal-parser.js) :
    // [OptimumScore]/[OptimumContract] (résumé rapide "Par : 4♠ S (NS +420)" affiché dans
    // LA PRÉVISUALISATION uniquement — voir dealPreviewParText) et [OptimumResultTable]
    // (la table complète du double mort, affichée PENDANT LA PARTIE avec mise en évidence
    // du meilleur contrat — voir renderDDTable). Un fichier peut avoir l'un sans l'autre :
    // n'avertir que si aucun des deux n'est disponible, sinon le message serait faux pour
    // un fichier qui a la table complète mais pas le résumé rapide.
    const warnings = [];
    if (parsedDeals._formatWarning) warnings.push(parsedDeals._formatWarning);
    if (!parsedDeals.some(d => d.par || d.ddTable)) {
        warnings.push('PARs non disponibles dans ce fichier — les contrats optimaux ne seront pas affichés.');
    }
    if (warnings.length > 0) {
        setHostSetupMessage(warnings.join('\n⚠️ '), true);
    }

    onDone(parsedDeals);
}

// Lit un fichier local (upload) puis délègue à validateAndUseDealText.
function readAndValidateDealFile(file, onDone) {
    const reader = new FileReader();
    reader.onload = () => validateAndUseDealText(reader.result, file.name, onDone);
    reader.onerror = () => {
        clearHostSetupMessage();
        setHostSetupMessage('Impossible de lire ce fichier.', false);
        onDone(null);
    };
    reader.readAsText(file);
}

// Récupère une donne de la bibliothèque du club (voir donnes/catalogue.json) puis délègue
// à validateAndUseDealText — même circuit de validation que l'upload, seule la façon
// d'obtenir le texte change.
function readAndValidateDealFromLibrary(filename, onDone) {
    fetch(`donnes/${encodeURIComponent(filename)}`)
        .then(resp => {
            if (!resp.ok) throw new Error(`Fichier introuvable dans la bibliothèque (HTTP ${resp.status}).`);
            return resp.text();
        })
        .then(text => validateAndUseDealText(text, filename, onDone))
        .catch(err => {
            clearHostSetupMessage();
            setHostSetupMessage(err.message || 'Impossible de charger cette donne depuis la bibliothèque.', false);
            onDone(null);
        });
}

// Appelé dès que l'hôte choisit (ou change) le fichier de donnes, pour parser et valider
// tout de suite — voir readAndValidateDealFile. L'hôte voit ainsi l'éventuel message
// pendant qu'il compose encore la table, et uiStartGameAsHost n'a plus qu'à réutiliser ce
// résultat (pendingParsedDeals) sans relire le fichier une seconde fois.
function uiHandleDealFileChosen() {
    const fileInput = document.getElementById('dealFileInput');
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;

    if (!fileInput.files || fileInput.files.length === 0) {
        clearHostSetupMessage();
        document.getElementById('dealFileInfo').style.display = 'none';
        return;
    }

    // Un fichier local et une donne de bibliothèque sont mutuellement exclusifs (une
    // seule source à la fois, pour éviter toute ambiguïté sur celle qui sera utilisée) :
    // choisir l'un désélectionne l'autre.
    const librarySelect = document.getElementById('dealLibrarySelect');
    if (librarySelect) librarySelect.value = '';

    const file = fileInput.files[0];
    readAndValidateDealFile(file, (parsedDeals) => {
        pendingParsedSource = file;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
    });
}

// Symétrique de uiHandleDealFileChosen, pour une donne piochée dans la bibliothèque du
// club (voir donnes/catalogue.json et initDealLibrary) plutôt qu'un fichier local.
function uiHandleDealLibraryChosen() {
    const select = document.getElementById('dealLibrarySelect');
    const filename = select ? select.value : '';
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;

    if (!filename) {
        clearHostSetupMessage();
        document.getElementById('dealFileInfo').style.display = 'none';
        return;
    }

    // Réciproquement, choisir dans la bibliothèque désélectionne le fichier local.
    const fileInput = document.getElementById('dealFileInput');
    if (fileInput) fileInput.value = '';

    readAndValidateDealFromLibrary(filename, (parsedDeals) => {
        pendingParsedSource = `library:${filename}`;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
    });
}

// ===== Aperçu des donnes chargées (avant de lancer la partie) =====

function uiPreviewDeals() {
    if (!pendingOrderedDeals || pendingOrderedDeals.length === 0) return;
    renderDealPreview(pendingOrderedDeals);
    document.getElementById('dealPreviewModal').style.display = 'flex';
}

function uiCloseDealPreview() {
    document.getElementById('dealPreviewModal').style.display = 'none';
}

function uiCloseDealPreviewOnBackdrop(evt) {
    if (evt.target.id === 'dealPreviewModal') uiCloseDealPreview();
}

// Petite carte de main compacte pour l'aperçu (même principe que renderMyHands /
// renderAllHandsDiagram, mais toujours avec le HCP affiché, indépendamment de la
// préférence showHcp qui ne concerne que l'écran de jeu).
function dealPreviewHandCardHtml(seat, hand) {
    const lines = ['S', 'H', 'D', 'C'].map(suit => `
        <div class="card-line">
            <span class="suit-symbol">${suitIconHtml(suit)}</span>
            <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
        </div>
    `).join('');

    return `
        <div class="hand-card deal-preview-hand-card">
            <div class="hand-card-title">
                <span class="hand-card-title-name">${SEAT_FULL_NAME[seat]}</span>
                <span class="hand-card-badges"><span class="hand-hcp-badge">${computeHandHcp(hand)} HCP</span></span>
            </div>
            <div class="hand-cards">${lines}</div>
        </div>
    `;
}

function dealPreviewParText(par) {
    if (!par) return '';
    const contract = par.contract ? `${par.contract}${par.declarer ? ' ' + par.declarer : ''}` : '?';
    const scoreSign = par.score > 0 ? '+' : '';
    return ` · Par : ${contract} (${par.side} ${scoreSign}${par.score})`;
}

function renderDealPreview(dealsToPreview) {
    const n = dealsToPreview.length;
    document.getElementById('dealPreviewTitle').textContent = `Aperçu — ${n} donne${n > 1 ? 's' : ''}`;

    const content = document.getElementById('dealPreviewContent');
    content.innerHTML = dealsToPreview.map(deal => `
        <div class="deal-preview-board">
            <div class="deal-preview-board-header">
                <strong>Donne #${deal.board}</strong> — Donneur : ${SEAT_FULL_NAME[deal.dealer]} · ${VULN_LABEL[deal.vulnerable]}${dealPreviewParText(deal.par)}
            </div>
            <div class="deal-preview-hands">
                ${SEATS.map(seat => dealPreviewHandCardHtml(seat, deal.hands[seat])).join('')}
            </div>
        </div>
    `).join('');
}

function uiStartGameAsHost() {
    const fileInput = document.getElementById('dealFileInput');
    const librarySelect = document.getElementById('dealLibrarySelect');
    const file = (fileInput.files && fileInput.files[0]) || null;
    const libraryFilename = librarySelect ? librarySelect.value : '';

    if (!file && !libraryFilename) {
        setHostSetupMessage('Choisissez un fichier .pbn ou .lin, ou une donne dans la bibliothèque.', false);
        return;
    }

    // Reçoit les donnes déjà dans l'ordre à utiliser pour jouer (mélangé ou non, voir
    // pendingOrderedDeals / refreshPendingOrderedDeals) — jamais l'ordre brut du fichier.
    const proceedWithDeals = (orderedDeals) => {
        if (!orderedDeals) return; // l'erreur est déjà affichée par readAndValidateDealFile/readAndValidateDealFromLibrary

        deals = orderedDeals;
        boardIndex = 0;
        auctionHistory = [];
        hostPendingUndo = null;
        clearUndoUiState();

        const botSeats = SEATS.filter(seat => !seatAssignment[seat]);
        mySeats = SEATS.filter(seat => seatAssignment[seat] === 'host');
        autoPassSeats = botSeats;

        participants.filter(p => p.id !== 'host' && !p.disconnected).forEach(p => {
            const guestIndex = guestIndexForParticipant(p.id);
            if (guestIndex == null) return;
            const seatsForThisGuest = SEATS.filter(seat => seatAssignment[seat] === p.id);
            peerConn.send({ type: 'start-game', deals, yourSeats: seatsForThisGuest, botSeats }, guestIndex);
        });

        enterGameScreen();
    };

    // Source effectivement active : le fichier local prime si les deux sont, par un
    // hasard quelconque, renseignés à la fois (ne devrait pas arriver, voir
    // uiHandleDealFileChosen/uiHandleDealLibraryChosen qui désélectionnent l'autre à
    // chaque choix, mais on tranche explicitement plutôt que de laisser un cas ambigu).
    const activeSource = file || `library:${libraryFilename}`;

    // Cas normal : la source a déjà été lue et parsée au moment où elle a été choisie
    // (voir uiHandleDealFileChosen / uiHandleDealLibraryChosen) — pas besoin de la
    // relire, et le message éventuel (erreur ou avertissement PAR) est déjà affiché
    // depuis ce moment-là.
    if (pendingParsedSource === activeSource) {
        proceedWithDeals(pendingOrderedDeals);
        return;
    }

    // Filet de sécurité si, pour une raison quelconque, le cache ne correspond pas à la
    // source actuellement sélectionnée (ex. écouteur 'change' non déclenché) : on relit,
    // puis on applique l'ordre aléatoire éventuel avant de démarrer.
    const onReloaded = (parsedDeals) => {
        pendingParsedSource = activeSource;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
        proceedWithDeals(pendingOrderedDeals);
    };
    if (file) {
        readAndValidateDealFile(file, onReloaded);
    } else {
        readAndValidateDealFromLibrary(libraryFilename, onReloaded);
    }
}

// ===== Réception des messages des autres joueurs =====

function handlePeerData(msg, guestIndex) {
    if (!msg || !msg.type) return;

    switch (msg.type) {
        case 'welcome': {
            myParticipantId = msg.yourId;
            break;
        }

        // Reçu par le participant CIBLÉ par un transfert d'hôte (voir uiTransferHost) : il
        // doit créer sa propre salle (nouveau code, PeerJS ne permet pas de reprendre
        // fiablement l'ancien identifiant tout de suite) puis prévenir l'ancien hôte dès que
        // c'est prêt — c'est par CETTE connexion, celle qui reçoit ce message, qu'on le
        // préviendra, donc on ne la coupe qu'une fois le nouveau code obtenu et transmis.
        case 'prepare-become-host': {
            if (myRole !== 'guest') break;
            pushDebugLog('Transfert d\'hôte reçu, création de la nouvelle salle...');

            const inheritedParticipants = msg.participants;
            const inheritedSeatAssignment = msg.seatAssignment;

            const claimPeer = new BridgePeerConnection(buildHostHandlers((newRoomCode) => {
                // On a le nouveau code : prévenir l'ancien hôte AVANT de couper la connexion
                // vers lui (c'est la seule voie pour le lui dire). Un court délai laisse le
                // temps au message de partir sur le canal WebRTC avant qu'on ne le ferme.
                if (peerConn) peerConn.send({ type: 'become-host-ready', newRoomCode });
                setTimeout(() => {
                    if (peerConn) peerConn.destroy();
                    peerConn = claimPeer;
                    myRole = 'host';
                    myParticipantId = 'host';
                    participants = inheritedParticipants;
                    seatAssignment = inheritedSeatAssignment;
                    guestIndexByToken = {};
                    prevSeatAssignmentSnapshot = null;
                    prevParticipantsDisconnectedSnapshot = null;
                    lobbyChatAutoOpened = false;
                    enterLobbyScreen();
                    renderLobby();
                }, 300);
            }));
            // Repli propre si la création de la nouvelle salle échoue (réseau, etc.) :
            // prévenir l'ancien hôte plutôt que de le laisser attendre indéfiniment, sans
            // toucher à quoi que ce soit côté local (on reste un invité normal, connecté
            // comme avant à l'ancien hôte).
            claimPeer.handlers.onError = (err) => {
                pushDebugLog('Échec de la prise de rôle hôte : ' + ((err && (err.message || err.type)) || err));
                if (peerConn) peerConn.send({ type: 'become-host-failed', reason: (err && err.type) || 'erreur inconnue' });
            };
            claimPeer.createRoom();
            break;
        }

        // Reçu par l'ANCIEN hôte : le participant ciblé a bien créé sa nouvelle salle. On
        // prévient tous les autres invités connectés (pas lui, il le sait déjà), puis on
        // rejoint nous-mêmes cette nouvelle salle comme simple participant.
        case 'become-host-ready': {
            if (myRole !== 'host' || !hostTransferInProgress) break;
            const newRoomCode = msg.newRoomCode;
            const targetIndex = guestIndexByToken[pendingHostTransferTarget];
            peerConn.sendExcept({ type: 'host-transferred', newRoomCode }, targetIndex);

            const myOldToken = pendingHostTransferOldToken;
            const myName = savedNickname;
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            showHostTransferStatus(null);

            connectAsGuest(newRoomCode, myOldToken, myName);
            break;
        }

        // Reçu par l'ANCIEN hôte : le transfert a échoué chez le participant ciblé (voir
        // 'prepare-become-host' ci-dessus) — on reste hôte, rien d'autre à faire.
        case 'become-host-failed': {
            if (myRole !== 'host' || !hostTransferInProgress) break;
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            showHostTransferStatus("Le transfert a échoué (" + (msg.reason || 'raison inconnue') + "). Vous restez hôte.", true);
            break;
        }

        // Reçu par tout invité qui n'était NI la cible du transfert (déjà géré dans
        // 'prepare-become-host') NI l'ancien hôte (déjà géré dans 'become-host-ready') :
        // on rejoint simplement la nouvelle salle avec son propre jeton, comme un join normal.
        case 'host-transferred': {
            if (myRole !== 'guest') break;
            pushDebugLog('Hôte transféré, on rejoint la nouvelle salle ' + msg.newRoomCode);
            connectAsGuest(msg.newRoomCode, getReconnectToken(), savedNickname);
            break;
        }

        case 'set-name': {
            if (myRole !== 'host') return;
            const pid = tokenForGuestIndex(guestIndex);
            const p = participants.find(x => x.id === pid);
            if (p) p.name = msg.name || p.name;
            broadcastLobbyState();
            renderLobby();
            break;
        }

        case 'lobby-state': {
            const newParticipants = msg.participants;
            // Détecte les reconnexions (disconnected true -> false) pour la bannière de
            // bienvenue transitoire (voir flashWelcomeBack). Un diff est nécessaire ici,
            // contrairement au côté hôte qui connaît déjà l'événement précis au moment où
            // il se produit (voir onGuestConnected) : ce message ne porte qu'un instantané,
            // pas la nature du changement.
            if (deals && prevParticipantsDisconnectedSnapshot) {
                newParticipants.forEach(p => {
                    if (prevParticipantsDisconnectedSnapshot[p.id] && !p.disconnected) {
                        flashWelcomeBack(p.name);
                    }
                });
            }
            prevParticipantsDisconnectedSnapshot = {};
            newParticipants.forEach(p => { prevParticipantsDisconnectedSnapshot[p.id] = !!p.disconnected; });

            participants = newParticipants;
            seatAssignment = msg.seatAssignment;
            // Ce message est aussi renvoyé quand la connectivité change en pleine partie
            // (quelqu'un se (re)connecte) : on ne bascule à l'écran du salon que si la
            // partie n'a pas encore commencé, sinon ça arracherait un invité de sa table.
            // Dans le cas contraire (partie en cours), on doit quand même rafraîchir
            // l'écran de jeu — sans ça, la bannière de reconnexion et le tour-indicateur
            // resteraient figés jusqu'à la prochaine annonce.
            if (myRole === 'guest' && !deals) enterLobbyScreen();
            else if (deals) renderBoard();
            break;
        }

        case 'start-game': {
            deals = msg.deals;
            mySeats = msg.yourSeats;
            autoPassSeats = msg.botSeats || [];
            boardIndex = 0;
            auctionHistory = [];
            hostPendingUndo = null;
            clearUndoUiState();
            enterGameScreen();
            break;
        }

        // Reçu après une (re)connexion alors que la partie est déjà en cours : remet ce
        // joueur exactement là où en est la table (donne, enchère, sièges), qu'il soit
        // nouveau ou de retour après une coupure.
        case 'resync': {
            deals = msg.deals;
            mySeats = msg.yourSeats;
            autoPassSeats = msg.botSeats || [];
            boardIndex = msg.boardIndex;
            auctionHistory = msg.auctionHistory || [];
            hostPendingUndo = null;
            clearUndoUiState();
            enterGameScreen();
            break;
        }

        case 'call': {
            if (!deals || msg.boardIndex !== boardIndex) return;
            const deal = currentDeal();
            const expectedSeat = currentTurnSeat(deal.dealer, auctionHistory);
            if (msg.seat !== expectedSeat || !isCallLegal(auctionHistory, msg.call, msg.seat)) {
                console.warn('Annonce reçue invalide, ignorée :', msg);
                return;
            }
            applyCall(msg.seat, msg.call);
            relayIfHost(msg, guestIndex);
            break;
        }

        case 'chat': {
            addChatMessage(msg);
            relayIfHost(msg, guestIndex);
            break;
        }

        case 'reset-auction': {
            if (!deals || msg.boardIndex !== boardIndex) return;
            auctionHistory = [];
            hostPendingUndo = null;
            clearUndoUiState();
            renderAuctionLedger();
            renderBiddingBox();
            renderMyHands();
            checkAuctionEnd();
            relayIfHost(msg, guestIndex);
            maybeAutoPass(); // sans effet si on n'est pas l'hôte ; couvre le cas où c'est
                              // un invité qui a demandé le reset (l'hôte doit prendre le relais)
            break;
        }

        case 'goto-board': {
            if (!deals) return;
            boardIndex = msg.boardIndex;
            auctionHistory = [];
            hostPendingUndo = null;
            clearUndoUiState();
            renderBoard();
            relayIfHost(msg, guestIndex);
            break;
        }

        // --- Demande d'annulation (undo) ---
        // Voir la section "Demande d'annulation (undo)" plus bas pour le détail du protocole.
        // L'hôte est toujours l'arbitre : 'undo-request' et 'undo-answer' ne sont traités
        // que par lui ; 'undo-ask', 'undo-apply' et 'undo-rejected' sont ce qu'il diffuse.
        case 'undo-request': {
            if (myRole !== 'host') return;
            hostHandleUndoRequest(msg);
            break;
        }

        case 'undo-ask': {
            pendingUndoAsk = msg;
            renderUndoAskBanner();
            renderUndoControls();
            break;
        }

        case 'undo-answer': {
            if (myRole !== 'host') return;
            hostReceiveUndoAnswer(msg);
            break;
        }

        case 'undo-apply': {
            if (!deals || msg.boardIndex !== boardIndex) return;
            if (typeof msg.newLength === 'number') {
                auctionHistory.length = Math.max(0, Math.min(msg.newLength, auctionHistory.length));
            } else if (auctionHistory.length > 0) {
                auctionHistory.pop(); // compat, ne devrait plus arriver
            }
            renderAuctionLedger();
            renderBiddingBox();
            renderMyHands();
            checkAuctionEnd();
            clearUndoUiState();
            break;
        }

        case 'undo-rejected': {
            if (msg.requesterId !== myParticipantId) return;
            clearUndoUiState();
            setUndoStatus(undoRejectReasonText(msg.reason));
            break;
        }
    }
}

// Quand l'hôte reçoit un message d'un invité, il le relaie aux AUTRES invités (les invités
// ne sont jamais connectés entre eux). Ne fait rien de plus en configuration à 2 joueurs.
function relayIfHost(msg, fromGuestIndex) {
    if (myRole === 'host') {
        peerConn.sendExcept(msg, fromGuestIndex);
    }
}

// ===== Robot "passe automatique" (sièges non assignés) =====
//
// Seul l'hôte injecte les passes automatiques (pour ne jamais les déclencher en double),
// puis les diffuse comme n'importe quelle annonce.
function maybeAutoPass() {
    if (myRole !== 'host') return;
    if (!autoPassSeats || autoPassSeats.length === 0) return;
    if (!deals || isAuctionOver(auctionHistory)) return;

    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    if (!autoPassSeats.includes(turnSeat)) return;

    const boardAtSchedule = boardIndex;
    const historyLengthAtSchedule = auctionHistory.length;

    setTimeout(() => {
        if (boardIndex !== boardAtSchedule) return;
        if (auctionHistory.length !== historyLengthAtSchedule) return;
        if (isAuctionOver(auctionHistory)) return;
        const stillTurnSeat = currentTurnSeat(currentDeal().dealer, auctionHistory);
        if (stillTurnSeat !== turnSeat) return;

        applyCall(turnSeat, 'PASS');
        peerConn.send({ type: 'call', boardIndex, seat: turnSeat, call: 'PASS' });
    }, 300);
}

// ===== Écran de jeu =====

function enterGameScreen() {
    showScreen('screen-game');
    renderBoard();
}

function seatFullName(seat) {
    return SEAT_FULL_NAME[seat];
}

// ===== Bannière de reconnexion =====
//
// Signale, pendant toute la partie (pas seulement quand c'est son tour — voir aussi
// #turnIndicator/.disconnected-turn dans renderGameHeader pour ce cas précis), tout
// joueur assis à la table actuellement déconnecté, avec un décompte du temps écoulé. Un
// joueur déconnecté n'est PAS remplacé par un robot (voir onPeerDisconnected) : son siège
// attend simplement qu'il revienne, cette bannière rend cette attente visible même quand
// ce n'est pas encore à lui de parler.

// Affiche brièvement "X est de retour" à la place de la bannière d'attente, puis revient
// automatiquement à l'affichage normal après quelques secondes.
function flashWelcomeBack(name) {
    welcomeBackName = name;
    renderReconnectionBanner();
    clearTimeout(welcomeBackTimeoutId);
    welcomeBackTimeoutId = setTimeout(() => {
        welcomeBackName = null;
        renderReconnectionBanner();
    }, 4000);
}

function renderReconnectionBanner() {
    const banner = document.getElementById('reconnectionBanner');
    if (!banner) return;

    if (!deals) {
        banner.style.display = 'none';
        return;
    }

    if (welcomeBackName) {
        banner.className = 'reconnection-banner is-back';
        banner.textContent = `✅ ${welcomeBackName} est de retour !`;
        banner.style.display = 'block';
        return;
    }

    // Seuls les joueurs assis à la table intéressent cette bannière : un kibbitz
    // déconnecté ne bloque rien pour personne.
    const waiting = participants.filter(p =>
        p.disconnected && Object.values(seatAssignment).includes(p.id)
    );
    if (waiting.length === 0) {
        banner.style.display = 'none';
        return;
    }

    banner.textContent = waiting.map(p => {
        const seat = SEATS.find(s => seatAssignment[s] === p.id);
        const seatLabel = seat ? ` (${seatFullName(seat)})` : '';
        const elapsedS = p.disconnectedAt ? Math.max(0, Math.floor((Date.now() - p.disconnectedAt) / 1000)) : 0;
        return `🔌 ${p.name}${seatLabel} déconnecté depuis ${elapsedS}s — sa place est réservée`;
    }).join('\n');
    banner.className = 'reconnection-banner is-waiting';
    banner.style.display = 'block';
}

function renderBoard() {
    renderGameHeader();
    renderHandDisplayOptionButtons();
    renderMyHands();
    renderAuctionLedger();
    renderBiddingBox();
    checkAuctionEnd();
    updateBoardControlVisibility();
    renderUndoControls();
    renderUndoAskBanner();
    renderBoardSkipControls();
    renderReconnectionBanner();
    // Seulement si le panneau de chat est actuellement ouvert (il contient le bandeau
    // "qui est présent", voir uiToggleChat) : pas besoin de reconstruire son contenu tant
    // que personne ne le regarde.
    if (chatPanelOpen) renderRoomBoard();
    maybeAutoPass();
}

function updateBoardControlVisibility() {
    const resetBtn = document.getElementById('resetAuctionBtn');
    if (resetBtn) resetBtn.style.display = canControlBoard() ? '' : 'none';
}

function renderGameHeader() {
    const deal = currentDeal();
    document.getElementById('boardNumberLabel').textContent = `Donne #${deal.board} (${boardIndex + 1}/${deals.length})`;
    const mySeatsLabel = mySeats && mySeats.length > 0 ? mySeats.map(seatFullName).join(' + ') : 'kibbitz';
    document.getElementById('dealerVulnLabel').textContent =
        `Donneur : ${seatFullName(deal.dealer)} · ${VULN_LABEL[deal.vulnerable]} · Vous jouez : ${mySeatsLabel}`;
}

// ===== Chat =====
//
// Diffusion par le même mécanisme que les enchères (voir 'call' dans handlePeerData) :
// un invité envoie à l'hôte, qui relaie aux autres invités (relayIfHost) — les invités ne
// sont jamais connectés entre eux. L'hôte, lui, diffuse directement à tout le monde.
// Historique gardé en mémoire pour la session en cours seulement : pas inclus dans
// 'resync', un joueur qui se reconnecte ne revoit pas les messages d'avant sa coupure —
// acceptable pour une fonctionnalité de confort, pas une donnée de jeu à préserver à tout
// prix.
let chatMessages = [];
let chatPanelOpen = false;
// Voir enterLobbyScreen : vrai une fois le chat auto-ouvert pour l'entrée en cours dans le
// salon, remis à false à chaque nouvelle session (création, jointure, transfert d'hôte) —
// voir uiCreateRoom, connectAsGuest, et la prise de rôle dans 'prepare-become-host'.
let lobbyChatAutoOpened = false;
let chatUnreadCount = 0;

function uiToggleChat() {
    chatPanelOpen = !chatPanelOpen;
    const panel = document.getElementById('chatPanel');
    if (panel) panel.style.display = chatPanelOpen ? 'flex' : 'none';
    if (chatPanelOpen) {
        chatUnreadCount = 0;
        updateChatUnreadBadge();
        renderChat();
        renderRoomBoard(); // "qui est présent" fusionné dans le même panneau, voir échange avec Guillaume
        const input = document.getElementById('chatInput');
        if (input) input.focus();
    }
}

function updateChatUnreadBadge() {
    const badge = document.getElementById('chatUnreadBadge');
    if (!badge) return;
    if (chatUnreadCount > 0) {
        badge.textContent = chatUnreadCount > 9 ? '9+' : String(chatUnreadCount);
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
}

// Point d'entrée UNIQUE pour tout message de chat, qu'il vienne de moi (voir
// uiSendChatMessage) ou d'un autre participant (voir handlePeerData) : ajoute au journal,
// met à jour l'affichage, et incrémente le badge seulement si le panneau est fermé.
function addChatMessage(msg) {
    chatMessages.push(msg);
    renderChat();
    if (!chatPanelOpen) {
        chatUnreadCount++;
        updateChatUnreadBadge();
    }
}

function renderChat() {
    const el = document.getElementById('chatMessages');
    if (!el) return;
    el.innerHTML = chatMessages.map(m => {
        // Tous les messages partent de la gauche, y compris les siens (pas de bulle
        // alignée à droite façon messagerie) — le nom précède toujours le message, avec
        // sa couleur reprise de avatarColorForId (même couleur que la petite pastille
        // d'avatar de ce participant ailleurs dans l'appli, pour un repère cohérent).
        const senderColor = avatarColorForId(m.senderId);
        return `<div class="chat-message"><span class="chat-message-sender" style="color:${senderColor}">${escapeHtml(m.senderName)} :</span> <span class="chat-message-text">${escapeHtml(m.text)}</span></div>`;
    }).join('');
    el.scrollTop = el.scrollHeight; // toujours faire défiler vers le message le plus récent
}

function uiChatInputKeydown(event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    uiSendChatMessage();
}

function uiSendChatMessage() {
    const input = document.getElementById('chatInput');
    if (!input || !peerConn) return;
    const text = input.value.trim().slice(0, 500);
    if (!text) return;
    input.value = '';

    const me = participants.find(p => p.id === myParticipantId);
    const msg = { type: 'chat', senderId: myParticipantId, senderName: me ? me.name : '?', text };
    addChatMessage(msg);
    // Même appel pour l'hôte (diffuse directement à tous les invités) et pour un invité
    // (envoie à l'hôte, qui relaiera) : send() sans guestIndex explicite diffuse déjà à
    // toutes les connexions actives de ce peer, qui n'en a qu'une seule (l'hôte) côté
    // invité — voir peer-connection.js.
    peerConn.send(msg);
}

// ===== Panneau "Salle" (qui est présent pendant la partie) =====
//
// Le salon d'attente montre déjà qui est là et où (renderSeatAssignmentGrid), mais cet
// écran disparaît une fois la partie lancée — il n'y avait alors plus aucun moyen de voir
// qui est présent, seulement (voir renderReconnectionBanner) une alerte quand quelqu'un se
// déconnecte. Masqué par défaut (comme le panneau de diagnostic) pour ne pas prendre de
// place en continu ; l'utilisateur l'ouvre s'il en a besoin.
// Fusionné dans le panneau de chat (voir uiToggleChat) plutôt qu'un panneau séparé à
// part : un bandeau "qui est présent", toujours visible en haut du chat, complète
// naturellement les messages plutôt que de demander un clic de plus pour y accéder.
function renderRoomBoard() {
    const el = document.getElementById('roomBoard');
    if (!el) return;

    // Seuls les sièges réellement occupés par un participant apparaissent ici : les
    // robots ne sont pas des "personnes dans la salle", ça n'a pas sa place dans ce
    // panneau (contrairement au relevé d'enchères, où "Bot" reste utile pour savoir qui
    // a annoncé quoi — voir ledgerSeatLabel).
    //
    // Regroupement par participant plutôt qu'une ligne par siège : en mode diagonale ou
    // "maître du jeu", une même personne peut occuper 2 sièges — elle ne doit apparaître
    // qu'une fois, avec ses sièges listés ensemble (ex. "Nord + Sud"), pas deux fois.
    const seatsByParticipant = new Map(); // id -> [seat, seat, ...], dans l'ordre N/E/S/O
    SEATS.forEach(seat => {
        const pid = seatAssignment[seat];
        if (!pid) return;
        if (!seatsByParticipant.has(pid)) seatsByParticipant.set(pid, []);
        seatsByParticipant.get(pid).push(seat);
    });

    const seatRows = [...seatsByParticipant.keys()].map(pid => {
        const p = participants.find(x => x.id === pid);
        if (!p) return '';
        const seatsLabel = seatsByParticipant.get(pid).map(seatFullName).join(' + ');
        const disconnectedTag = p.disconnected ? ' <span class="disconnected-tag">🔌</span>' : '';
        const occupant = `${avatarHtml(p.id)}<span class="room-board-name">${escapeHtml(p.name)}</span>${disconnectedTag}`;
        return `<div class="room-board-seat"><span class="room-board-seat-label">${seatsLabel}</span>${occupant}</div>`;
    }).filter(Boolean).join('');

    // Quiconque n'occupe aucun siège est kibbitz (voir isKibbitz) : plus de liste à part à
    // maintenir, on liste simplement tous les participants absents de seatAssignment. Mais
    // seulement une fois la partie lancée (voir échange avec Guillaume) : dans le salon,
    // ne pas avoir de siège ne veut encore rien dire — l'hôte est peut-être justement en
    // train de composer la table — donc l'étiquette "Kibbitz" n'y a pas sa place.
    const kibbitzNames = deals ? participants.filter(p => !seatsByParticipant.has(p.id)) : [];
    const kibbitzHtml = kibbitzNames.length > 0
        ? `<div class="room-board-kibbitz">
               <span class="room-board-section-label">👁 Kibbitz :</span>
               ${kibbitzNames.map(p => `${avatarHtml(p.id)}<span class="room-board-name">${escapeHtml(p.name)}</span>`).join('')}
           </div>`
        : '';

    if (!seatRows && !kibbitzHtml) {
        // Rien à afficher (personne d'autre pour l'instant) : on laisse vide plutôt que
        // d'occuper de la place avec un message (voir échange avec Guillaume — superflu).
        // .room-board:empty se masque déjà tout seul (voir styles.css).
        el.innerHTML = '';
        return;
    }

    el.innerHTML = `<div class="room-board-seats">${seatRows}</div>${kibbitzHtml}`;
}

function renderMyHands() {
    const deal = currentDeal();
    const container = document.getElementById('myHandsContainer');

    if (!mySeats || mySeats.length === 0) {
        // Plus de statut "spectateur" séparé : quiconque n'a pas de siège est kibbitz et
        // voit les 4 mains dès le début (voir isKibbitz). Les mains elles-mêmes
        // s'affichent dans #allHandsDiagram (voir checkAuctionEnd/renderAllHandsDiagram) —
        // le même emplacement central, en grille N/E/S/O, que celui utilisé quand l'hôte
        // active "Voir les 4 mains". Les construire ici, dans le panneau latéral étroit
        // des mains, les aurait affichées à l'étroit et mal calibrées plutôt qu'au centre.
        container.innerHTML =
            '<div class="info-text kibbitz-note">👁 Vous suivez la partie en kibbitz : vous voyez les 4 mains ci-dessous.</div>';
        return;
    }

    // Distinction main active / inactive : seulement utile quand on contrôle plusieurs
    // sièges, et seulement pendant l'enchère (une fois terminée, plus de "tour" à signaler).
    const showActiveState = mySeats.length > 1 && !isAuctionOver(auctionHistory);
    const turnSeat = showActiveState ? currentTurnSeat(deal.dealer, auctionHistory) : null;

    container.innerHTML = mySeats.map(seat => {
        const hand = deal.hands[seat];
        const lines = ['S', 'H', 'D', 'C'].map(suit => `
            <div class="card-line">
                <span class="suit-symbol">${suitIconHtml(suit)}</span>
                <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
            </div>
        `).join('');

        const hcpBadge = showHcp ? `<span class="hand-hcp-badge">${computeHandHcp(hand)} HCP</span>` : '';
        const krBadge = showKr ? `<span class="hand-hcp-badge">K&R ${computeKaplanRubens(hand).toFixed(2)}</span>` : '';
        const stateClass = showActiveState ? (seat === turnSeat ? 'hand-card-active' : 'hand-card-inactive') : '';

        return `
            <div class="hand-card ${stateClass}">
                <div class="hand-card-title">
                    <span class="hand-card-title-name">${seatFullName(seat)}</span>
                    <span class="hand-card-badges">${hcpBadge}${krBadge}</span>
                </div>
                <div class="hand-cards">${lines}</div>
            </div>
        `;
    }).join('');
}

// Rendu coloré d'une annonce en dehors de la boîte d'enchères (relevé, contrat final) :
// même logique de classe de couleur que les boutons (SUIT_CLASSES), avec l'icône de
// couleur à la place du caractère Unicode brut (voir formatStrainLabel/suitIconHtml).
function formatCallCellHtml(call) {
    const b = parseBid(call);
    if (!b) return escapeHtml(formatCallForDisplay(call)); // Passe / X / XX : pas de couleur de suite
    const cls = SUIT_CLASSES[b.strain] || 'notrump';
    const label = formatStrainLabel(b.strain);
    return `<span class="call-suit ${cls}">${b.level}${label}</span>`;
}

// Libellé affiché dans l'en-tête du tableau d'enchères pour un siège donné : soit
// l'abréviation N/E/S/O, soit le nom du joueur qui l'occupe (préférence showLedgerNames).
// Un siège robot (non assigné) ou sans nom exploitable retombe sur l'abréviation.
function ledgerSeatLabel(seat) {
    if (!showLedgerNames) return SEAT_ABBR_FR[seat];
    const pid = typeof seatAssignment !== 'undefined' ? seatAssignment[seat] : null;
    if (!pid) return 'Bot'; // siège non assigné : joué par le robot "passe" (voir maybeAutoPass)
    const p = participants.find(x => x.id === pid);
    const name = p && p.name ? p.name.trim() : '';
    return name || SEAT_ABBR_FR[seat]; // quelqu'un est bien assigné ici, pas un bot : jamais "Bot" dans ce cas
}

function renderAuctionLedger() {
    const deal = currentDeal();
    const header = document.getElementById('auctionLedgerHeader');
    const toggleBtn = document.getElementById('ledgerNamesToggleBtn');
    if (toggleBtn) toggleBtn.classList.toggle('is-active', showLedgerNames);
    const turnSeat = isAuctionOver(auctionHistory) ? null : currentTurnSeat(deal.dealer, auctionHistory);
    header.innerHTML = SEATS.map(s => {
        const pair = partnershipOf(s);
        const isVulnerable = deal.vulnerable === 'Both' || deal.vulnerable === pair;
        const vulnClass = isVulnerable ? 'vuln-bar-danger' : 'vuln-bar-safe';
        const classes = [s === turnSeat ? 'turn-col' : ''].filter(Boolean).join(' ');
        return `<th class="${classes}">
            <span class="ledger-seat-label">${escapeHtml(ledgerSeatLabel(s))}</span>
            <span class="vuln-bar ${vulnClass}"></span>
        </th>`;
    }).join('');

    const dealerIdx = SEATS.indexOf(deal.dealer);
    const slots = new Array(dealerIdx).fill('');
    auctionHistory.forEach(entry => slots.push(formatCallCellHtml(entry.call)));
    // Index de la toute dernière enchère jouée (pas juste la dernière case du tableau,
    // qui peut être vide en fin de ligne) : sert à lui appliquer un bref flash visuel à
    // chaque nouvelle annonce, pour la repérer d'un coup d'œil sans avoir à la chercher
    // dans la grille (voir .is-latest-call plus bas / styles.css).
    const lastIndex = auctionHistory.length > 0 ? slots.length - 1 : -1;

    const rows = [];
    for (let i = 0; i < slots.length || rows.length === 0; i += 4) {
        rows.push(slots.slice(i, i + 4));
        if (i + 4 >= slots.length) break;
    }

    const body = document.getElementById('auctionLedgerBody');
    let flatIndex = 0;
    body.innerHTML = rows.map(row => {
        const cells = [0, 1, 2, 3].map(i => {
            const isLatest = flatIndex === lastIndex;
            flatIndex++;
            const cls = isLatest ? ' class="is-latest-call"' : '';
            return `<td${cls}>${row[i] != null ? row[i] : ''}</td>`;
        });
        return `<tr>${cells.join('')}</tr>`;
    }).join('');
}

function renderBiddingBox() {
    const box = document.getElementById('biddingBox');
    const turnPanel = document.getElementById('turnIndicator');
    const deal = currentDeal();

    if (isAuctionOver(auctionHistory)) {
        box.innerHTML = '';
        turnPanel.textContent = '';
        return;
    }

    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    const myTurn = mySeats && mySeats.includes(turnSeat);

    const turnOwnerId = seatAssignment[turnSeat];
    const turnOwner = turnOwnerId ? participants.find(p => p.id === turnOwnerId) : null;
    const ownerDisconnected = !!(turnOwner && turnOwner.disconnected);

    if (myTurn) {
        turnPanel.textContent = `À vous d'enchérir (${seatFullName(turnSeat)})`;
    } else if (ownerDisconnected) {
        turnPanel.textContent = `🔌 En attente que ${turnOwner.name} se reconnecte (${seatFullName(turnSeat)})...`;
    } else {
        turnPanel.textContent = `En attente de ${seatFullName(turnSeat)}...`;
    }
    turnPanel.className = 'turn-indicator ' + (myTurn ? 'my-turn' : (ownerDisconnected ? 'disconnected-turn' : 'their-turn'));

    const specialLabels = { PASS: 'Passe', X: 'X', XX: 'XX' };
    const specialRow = ['PASS', 'X', 'XX'].map(call => {
        const legal = myTurn && isCallLegal(auctionHistory, call, turnSeat);
        return `<button class="call-btn call-btn-special" ${legal ? '' : 'disabled'} onclick="uiMakeCall('${call}')">${specialLabels[call]}</button>`;
    }).join('');

    const bidRows = [];
    for (let level = 1; level <= 7; level++) {
        const cells = STRAINS.map(strain => {
            const call = `${level}${strain}`;
            const legal = myTurn && isCallLegal(auctionHistory, call, turnSeat);
            const label = formatStrainLabel(strain);
            const suitClass = SUIT_CLASSES[strain] || 'notrump';
            return `<button class="call-btn ${suitClass}" ${legal ? '' : 'disabled'} onclick="uiMakeCall('${call}')">${level}${label}</button>`;
        }).join('');
        bidRows.push(`<div class="bid-row">${cells}</div>`);
    }

    box.innerHTML = `
        <div class="special-calls-row">${specialRow}</div>
        <div class="bid-grid">${bidRows.join('')}</div>
    `;
}

function uiMakeCall(call) {
    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    if (!mySeats || !mySeats.includes(turnSeat)) return;
    if (!isCallLegal(auctionHistory, call, turnSeat)) return;

    applyCall(turnSeat, call);
    peerConn.send({ type: 'call', boardIndex, seat: turnSeat, call });
}

function applyCall(seat, call) {
    auctionHistory.push({ seat, call });
    renderAuctionLedger();
    renderBiddingBox();
    renderMyHands();
    checkAuctionEnd();
    renderUndoControls();
    maybeAutoPass();
}

// Construit le HTML des 4 mains, affiché dans #allHandsDiagram (voir
// renderAllHandsDiagram) — révélé à tout le monde une fois l'enchère terminée, à l'hôte
// seul s'il active "Voir les 4 mains" en cours d'enchère, et en continu à un kibbitz
// (voir checkAuctionEnd).
function buildAllHandsHtml(deal) {
    return SEATS.map(seat => {
        const hand = deal.hands[seat];
        const lines = ['S', 'H', 'D', 'C'].map(suit => `
            <div class="card-line">
                <span class="suit-symbol">${suitIconHtml(suit)}</span>
                <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
            </div>
        `).join('');

        const hcpBadge = showHcp ? `<span class="hand-hcp-badge">${computeHandHcp(hand)} HCP</span>` : '';
        const krBadge = showKr ? `<span class="hand-hcp-badge">K&R ${computeKaplanRubens(hand).toFixed(2)}</span>` : '';

        return `
            <div class="hand-card hand-${seat}">
                <div class="hand-card-title">
                    <span class="hand-card-title-name">${seatFullName(seat)}</span>
                    <span class="hand-card-badges">${hcpBadge}${krBadge}</span>
                </div>
                <div class="hand-cards">${lines}</div>
            </div>
        `;
    }).join('');
}

function renderAllHandsDiagram() {
    const container = document.getElementById('allHandsDiagram');
    container.innerHTML = buildAllHandsHtml(currentDeal());
}

const STRAIN_ORDER = ['N', 'S', 'H', 'D', 'C']; // N = sans-atout (SA), pas Nord
// Classe de couleur CSS par couleur d'enchère, pour la table du double mort — mêmes
// classes que SUIT_CLASSES, complétées de 'notrump' pour la ligne SA.
const STRAIN_CLASS = { N: 'notrump', S: 'spades', H: 'hearts', D: 'diamonds', C: 'clubs' };

// Convertit un nombre de levées (sur 13) en palier de contrat réalisable : il faut
// 6 levées de base + le palier, donc palier = levées - 6. En dessous de 7 levées, aucun
// contrat n'est réalisable (le palier serait nul ou négatif) : on affiche "―".
function tricksToContractLevel(tricks) {
    if (tricks == null) return '—';
    const level = tricks - 6;
    return level >= 1 ? String(level) : '―';
}

// ===== Mise en évidence du meilleur contrat (table du double mort) =====
//
// Portée depuis le générateur de donnes (dds-controller.js) — même algorithme exact, pour
// que les deux applis restent cohérentes visuellement. Principe : pour chaque case
// (couleur x déclarant), on suppose que le camp du déclarant enchérit tout juste au
// palier permis par le double mort (ni plus, ni moins), et on calcule le score de
// duplicate correspondant (barème SEF/FFB standard, non contré, selon la vulnérabilité
// réelle de la donne). Calcul INDÉPENDANT par camp (NS et EW n'enchérissent pas le même
// contrat) : chelem prime sur manche, qui prime sur partielle ; seules les cases du
// palier le plus haut atteint par ce camp sont mises en évidence — la ou les meilleures
// en vert vif, les autres du même palier en vert plus doux (sauf en partielle, qui n'a
// pas de prime notable : seule la meilleure y est marquée, pas de dégradé secondaire).

function trickPoints(strain, level) {
    if (strain === 'N') return 40 + (level - 1) * 30;
    if (strain === 'H' || strain === 'S') return level * 30;
    return level * 20; // C ou D
}

function contractScoreFromTrickPoints(trickPts, level, vulnerable) {
    let total = trickPts;
    total += trickPts >= 100 ? (vulnerable ? 500 : 300) : 50; // prime de manche ou de partielle
    if (level === 6) total += vulnerable ? 750 : 500;         // petit chelem
    else if (level === 7) total += vulnerable ? 1500 : 1000;  // grand chelem
    return total;
}

// `dealVulnerable` : la valeur normalisée habituelle ('None'/'NS'/'EW'/'Both', voir
// deal-parser.js) — contrairement au générateur, pas besoin de la recalculer depuis le
// numéro de donne, currentDeal().vulnerable la donne déjà directement.
function computeDDScores(ddTable, dealVulnerable) {
    const nsVuln = (dealVulnerable === 'NS' || dealVulnerable === 'Both');
    const ewVuln = (dealVulnerable === 'EW' || dealVulnerable === 'Both');

    const info = {};
    const bySide = { NS: [], EW: [] };

    for (const strain of STRAIN_ORDER) {
        info[strain] = {};
        for (const pos of DD_TABLE_SEAT_ORDER) {
            const side = (pos === 'N' || pos === 'S') ? 'NS' : 'EW';
            const tricks = ddTable[strain][pos];
            const level = tricks - 6;

            let score = null;
            let tier = null;
            if (level >= 1) {
                const trickPts = trickPoints(strain, level);
                score = contractScoreFromTrickPoints(trickPts, level, side === 'NS' ? nsVuln : ewVuln);
                tier = level >= 6 ? 'slam' : (trickPts >= 100 ? 'game' : 'partial');
            }

            info[strain][pos] = { score, tier, side };
            if (tier) bySide[side].push({ score, tier });
        }
    }

    const sideSummary = {};
    for (const side of ['NS', 'EW']) {
        const cells = bySide[side];
        let activeTier = null;
        if (cells.some(c => c.tier === 'slam')) activeTier = 'slam';
        else if (cells.some(c => c.tier === 'game')) activeTier = 'game';
        else if (cells.some(c => c.tier === 'partial')) activeTier = 'partial';

        let bestScore = null;
        if (activeTier) {
            bestScore = Math.max(...cells.filter(c => c.tier === activeTier).map(c => c.score));
        }

        sideSummary[side] = { activeTier, bestScore };
    }

    return { info, sideSummary };
}

// Ordre d'affichage des colonnes de la table du double mort : N S E O (les deux camps
// groupés côte à côte), plus pratique à lire que l'ordre de rotation des enchères N E S O
// utilisé partout ailleurs (SEATS, dans bidding-rules.js) — surtout ne pas réutiliser
// SEATS ici, sous peine de casser la logique de tour de parole.
const DD_TABLE_SEAT_ORDER = ['N', 'S', 'E', 'W'];

// Construit le tableau HTML du double mort (5 lignes SA/♠/♥/♦/♣ x 4 colonnes N/S/E/O),
// tel qu'éventuellement fourni dans le fichier PBN chargé (tag [OptimumResultTable]).
// Affiche le palier de contrat réalisable (et non le nombre brut de levées), avec le
// meilleur contrat de chaque camp mis en évidence (voir computeDDScores ci-dessus).
function renderDDTable(ddTable, dealVulnerable) {
    if (!ddTable) return '';
    const { info, sideSummary } = computeDDScores(ddTable, dealVulnerable);
    const rows = STRAIN_ORDER.map(strain => {
        const labelHtml = formatStrainLabel(strain);
        const cells = DD_TABLE_SEAT_ORDER.map(pos => {
            const cellInfo = info[strain][pos];
            const summary = sideSummary[cellInfo.side];
            let cls = '';
            if (summary.activeTier && cellInfo.tier === summary.activeTier) {
                if (cellInfo.score === summary.bestScore) {
                    cls = ' class="dd-best-contract"';
                } else if (summary.activeTier !== 'partial') {
                    cls = ' class="dd-secondary-contract"';
                }
            }
            return `<td${cls}>${tricksToContractLevel(ddTable[strain][pos])}</td>`;
        }).join('');
        return `<tr><th class="${STRAIN_CLASS[strain]}">${labelHtml}</th>${cells}</tr>`;
    }).join('');
    return `
        <div class="dd-table-title">Table du double mort (fournie dans le fichier)</div>
        <table class="dd-table">
            <thead><tr><th></th>${DD_TABLE_SEAT_ORDER.map(p => `<th>${SEAT_ABBR_FR[p]}</th>`).join('')}</tr></thead>
            <tbody>${rows}</tbody>
        </table>
    `;
}

function checkAuctionEnd() {
    const resultEl = document.getElementById('contractResult');
    const nextPanel = document.getElementById('nextBoardPanel');
    const diagramEl = document.getElementById('allHandsDiagram');

    const auctionOver = isAuctionOver(auctionHistory);
    // L'hôte peut choisir de voir les 4 mains à tout moment (voir uiToggleHostSeeAllHands),
    // même pendant l'enchère — un outil réservé à lui seul (vérifier une donne, aider un
    // débutant en direct...), jamais envoyé ni visible pour les autres joueurs. Un
    // kibbitz, lui, voit toujours les 4 mains dès le début (voir renderMyHands) — pas
    // besoin d'attendre la fin de l'enchère ni une action de l'hôte, puisqu'il n'est
    // assis à aucun siège et ne peut donc rien "tricher" en les voyant.
    const hostForcedReveal = myRole === 'host' && hostSeeAllHands;
    const showAllHandsEarly = hostForcedReveal || isKibbitz();

    if (!auctionOver) {
        resultEl.style.display = 'none';
        nextPanel.style.display = 'none';
        if (showAllHandsEarly) {
            renderAllHandsDiagram();
            diagramEl.style.display = 'grid';
        } else {
            diagramEl.style.display = 'none';
        }
        return;
    }

    const contract = determineContract(auctionHistory);
    // Ne joue l'animation de révélation (voir .contract-reveal dans styles.css) qu'au
    // moment précis où le contrat apparaît, pas à chaque re-rendu (renderBoard tourne
    // pour bien d'autres raisons — reconnexion d'un joueur, etc. — tant que la donne
    // reste sur cet écran) : on la déclenche seulement s'il était masqué juste avant.
    const wasHidden = resultEl.style.display === 'none' || resultEl.style.display === '';
    resultEl.style.display = 'block';
    if (!contract) {
        resultEl.innerHTML = "↩️ Donne passée — personne n'a annoncé.";
    } else {
        const strainCls = SUIT_CLASSES[contract.strain] || 'notrump';
        const strainLabel = formatStrainLabel(contract.strain);
        const contractHtml = `<span class="call-suit ${strainCls}">${contract.level}${strainLabel}${escapeHtml(contract.doubled)}</span>`;
        resultEl.innerHTML = `Contrat final : <strong>${contractHtml}</strong> par <strong>${seatFullName(contract.declarer)}</strong>`;
    }
    if (wasHidden) {
        // Retire puis relit offsetWidth avant de rajouter la classe : sans ce "force
        // reflow", le navigateur ne rejouerait pas l'animation si la classe était déjà
        // présente d'un affichage précédent (peu probable ici vu qu'on ne la retire
        // jamais ailleurs, mais le filet de sécurité ne coûte rien).
        resultEl.classList.remove('contract-reveal');
        void resultEl.offsetWidth;
        resultEl.classList.add('contract-reveal');
    }

    const ddTableHtml = renderDDTable(currentDeal().ddTable, currentDeal().vulnerable);
    if (ddTableHtml) {
        resultEl.innerHTML += ddTableHtml;
    }

    renderAllHandsDiagram();
    diagramEl.style.display = 'grid';

    const isLastBoard = boardIndex >= deals.length - 1;
    const iCanNavigate = canControlBoard();
    nextPanel.style.display = (isLastBoard || !iCanNavigate) ? 'none' : 'block';

    if (isLastBoard) {
        resultEl.innerHTML += '<div class="info-text">Dernière donne du fichier chargé.</div>';
    } else if (!iCanNavigate) {
        resultEl.innerHTML += '<div class="info-text">En attente qu\'un joueur actif passe à la donne suivante.</div>';
    }
}

// ===== Demande d'annulation (undo) =====
//
// Un joueur actif peut demander l'annulation de la dernière annonce (utile en cas de
// mauvais clic). Cette annonce a pu déjà donner une information au camp adverse : on ne
// l'annule donc jamais tout seul dans son coin, il faut l'accord d'un adversaire humain.
// S'il n'y a personne à convaincre en face (siège robot, ou la même personne joue les
// deux camps), l'annulation s'applique immédiatement.
//
// Protocole (voir aussi peer-connection.js) :
//   'undo-request' (→ hôte)      le demandeur sollicite une annulation
//   'undo-ask'     (hôte →)      l'hôte demande l'accord à un adversaire humain
//   'undo-answer'  (→ hôte)      la réponse de cet adversaire (accepté/refusé)
//   'undo-apply'   (hôte →)      l'annulation est actée, tout le monde retire la dernière annonce
//   'undo-rejected'(hôte →)      informe le demandeur que ça ne s'est pas fait, et pourquoi
//
// L'hôte est toujours l'arbitre (hostPendingUndo) : c'est le seul point de passage
// obligé entre deux invités (topologie en étoile). Quand l'hôte est lui-même demandeur ou
// répondeur, ces messages sont traités directement en local (voir deliverToParticipant),
// sans aller-retour réseau inutile.

function clearUndoUiState() {
    undoRequestPending = false;
    pendingUndoAsk = null;
    clearTimeout(undoRequestTimeoutId);
    undoRequestTimeoutId = null;
    renderUndoControls();
    renderUndoAskBanner();
}

function setUndoStatus(text) {
    const el = document.getElementById('undoStatusText');
    if (el) el.textContent = text || '';
}

function renderUndoControls() {
    const btn = document.getElementById('requestUndoBtn');
    if (!btn) return;
    const visible = canControlBoard();
    btn.style.display = visible ? '' : 'none';
    btn.disabled = !visible || !deals || auctionHistory.length === 0 || undoRequestPending || !!pendingUndoAsk;
    // Deux <span> (voir index.html) plutôt qu'un textContent direct : .btn-label-full/
    // .btn-label-short sont affichés en alternance en CSS selon la largeur d'écran
    // (bouton complet sur desktop, abrégé sur mobile où la place manque).
    const fullEl = btn.querySelector('.btn-label-full');
    const shortEl = btn.querySelector('.btn-label-short');
    if (fullEl) fullEl.textContent = undoRequestPending ? '⏳ Demande envoyée...' : '↩️ Demander un undo';
    if (shortEl) shortEl.textContent = undoRequestPending ? '⏳ Envoyée...' : '↩️ Undo';
}

function renderUndoAskBanner() {
    const banner = document.getElementById('undoAskBanner');
    if (!banner) return;
    if (!pendingUndoAsk) {
        banner.style.display = 'none';
        banner.innerHTML = '';
        return;
    }
    const name = escapeHtml(participantName(pendingUndoAsk.requesterId));
    banner.style.display = 'flex';
    banner.innerHTML = `
        <span>${name} demande à annuler la dernière annonce.</span>
        <button class="btn btn-success btn-small" onclick="uiAnswerUndo(true)">Accepter</button>
        <button class="btn btn-secondary btn-small" onclick="uiAnswerUndo(false)">Refuser</button>
    `;
}

function participantName(pid) {
    if (pid === 'host') return "L'hôte";
    const p = participants.find(x => x.id === pid);
    return p ? p.name : 'Un joueur';
}

function partnershipSeats(partnership) {
    return SEATS.filter(s => partnershipOf(s) === partnership);
}

function seatsOfParticipant(pid) {
    return SEATS.filter(seat => seatAssignment[seat] === pid);
}

// Détermine quelle entrée de l'historique une demande d'undo doit effectivement annuler.
// Pour un invité : la dernière annonce parmi celles produites par UN des sièges qu'il
// contrôle — pas forcément la toute dernière case du tableau, puisqu'un ou plusieurs
// robots ont pu passer automatiquement juste après (voir maybeAutoPass) si le joueur a
// mis un peu de temps à cliquer sur "undo". On renvoie alors l'index de SA dernière
// annonce ; applyUndoAsHost retirera cette annonce et tout ce qui a suivi (uniquement des
// passes robot, puisqu'aucun autre humain n'a pu jouer avant que ce ne soit à nouveau le
// tour de ce joueur).
// Renvoie -1 si ce participant n'a fait aucune annonce sur cette donne (rien à annuler).
//
// Exception : quand c'est L'HÔTE qui demande, on garde l'ancien comportement (annuler la
// toute dernière annonce du tableau, quel qu'en soit l'auteur) — l'hôte arbitre déjà toute
// la table (navigation libre entre donnes, etc.), et son bouton undo reste un simple
// "reculer d'un cran", sans distinction de siège.
function findUndoTargetIndex(requesterId, history) {
    if (requesterId === 'host') {
        return history.length - 1;
    }
    const seats = seatsOfParticipant(requesterId);
    for (let i = history.length - 1; i >= 0; i--) {
        if (seats.includes(history[i].seat)) return i;
    }
    return -1;
}

function guestIndexForParticipant(pid) {
    if (!pid || pid === 'host') return null;
    return Object.prototype.hasOwnProperty.call(guestIndexByToken, pid) ? guestIndexByToken[pid] : null;
}

// Participants humains "en face" du camp qui a fait l'annonce ciblée par l'undo, hors le
// demandeur — ce sont eux dont l'accord est requis pour annuler. `targetSeat` est le siège
// dont l'annonce va effectivement être retirée (voir findUndoTargetIndex), pas forcément
// le dernier siège de l'historique.
function humanOpponentsFor(requesterId, targetSeat) {
    const opposing = partnershipOf(targetSeat) === 'NS' ? partnershipSeats('EW') : partnershipSeats('NS');
    const ids = new Set();
    opposing.forEach(seat => {
        const pid = seatAssignment[seat];
        if (pid && pid !== requesterId) ids.add(pid);
    });
    return Array.from(ids);
}

function undoRejectReasonText(reason) {
    switch (reason) {
        case 'declined': return 'Annulation refusée.';
        case 'timeout': return "Personne n'a répondu à temps.";
        case 'busy': return 'Une autre demande est déjà en cours, réessayez.';
        case 'stale': return 'La situation a changé entre-temps, réessayez.';
        case 'nothing': return "Vous n'avez fait aucune annonce à annuler sur cette donne.";
        default: return "Impossible d'annuler pour le moment.";
    }
}

// Envoie `msg` à un participant donné — sans passer par le réseau si ce participant,
// c'est nous (l'hôte est toujours au centre de l'arbitrage, y compris pour lui-même).
function deliverToParticipant(pid, msg) {
    if (pid === myParticipantId) {
        if (msg.type === 'undo-ask') {
            pendingUndoAsk = msg;
            renderUndoAskBanner();
            renderUndoControls();
        } else if (msg.type === 'undo-rejected') {
            clearUndoUiState();
            setUndoStatus(undoRejectReasonText(msg.reason));
        }
        return;
    }
    const gi = guestIndexForParticipant(pid);
    if (gi != null) peerConn.send(msg, gi);
}

function uiRequestUndo() {
    if (!canControlBoard() || !deals || auctionHistory.length === 0) return;
    if (undoRequestPending || pendingUndoAsk) return;

    const msg = {
        type: 'undo-request',
        boardIndex,
        requesterId: myParticipantId,
        historyLengthAtRequest: auctionHistory.length
    };

    undoRequestPending = true;
    setUndoStatus('');
    renderUndoControls();

    clearTimeout(undoRequestTimeoutId);
    undoRequestTimeoutId = setTimeout(() => {
        if (undoRequestPending) {
            undoRequestPending = false;
            renderUndoControls();
            setUndoStatus("Personne n'a répondu à temps.");
        }
    }, 20000);

    if (myRole === 'host') {
        hostHandleUndoRequest(msg);
    } else {
        peerConn.send(msg);
    }
}

// (Hôte) Reçoit une demande d'annulation — la sienne, ou celle d'un invité relayée par
// handlePeerData — et décide si elle nécessite l'accord d'un adversaire humain.
function hostHandleUndoRequest(msg) {
    if (hostPendingUndo) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'busy' });
        return;
    }
    if (msg.boardIndex !== boardIndex || msg.historyLengthAtRequest !== auctionHistory.length) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'stale' });
        return;
    }

    const targetIndex = findUndoTargetIndex(msg.requesterId, auctionHistory);
    if (targetIndex < 0) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'nothing' });
        return;
    }
    const targetSeat = auctionHistory[targetIndex].seat;

    const opponents = humanOpponentsFor(msg.requesterId, targetSeat);
    if (opponents.length === 0) {
        applyUndoAsHost({ boardIndex: msg.boardIndex, requesterId: msg.requesterId, historyLengthAtRequest: msg.historyLengthAtRequest, targetIndex });
        return;
    }

    hostPendingUndo = { requesterId: msg.requesterId, boardIndex: msg.boardIndex, historyLengthAtRequest: msg.historyLengthAtRequest, targetIndex };

    const askMsg = {
        type: 'undo-ask',
        boardIndex: msg.boardIndex,
        requesterId: msg.requesterId,
        historyLengthAtRequest: msg.historyLengthAtRequest
    };
    opponents.forEach(pid => deliverToParticipant(pid, askMsg));

    setTimeout(() => {
        if (hostPendingUndo &&
            hostPendingUndo.requesterId === msg.requesterId &&
            hostPendingUndo.boardIndex === msg.boardIndex &&
            hostPendingUndo.historyLengthAtRequest === msg.historyLengthAtRequest) {
            hostPendingUndo = null;
            deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'timeout' });
        }
    }, 20000);
}

// (Hôte) Reçoit la réponse (accepté/refusé) d'un adversaire — la sienne, ou celle d'un
// invité relayée par handlePeerData. Seule la première réponse compte.
function hostReceiveUndoAnswer(msg) {
    if (!hostPendingUndo) return;
    if (msg.boardIndex !== hostPendingUndo.boardIndex || msg.historyLengthAtRequest !== hostPendingUndo.historyLengthAtRequest) return;

    const resolved = hostPendingUndo;
    hostPendingUndo = null;

    if (msg.approved) {
        applyUndoAsHost(resolved);
    } else {
        deliverToParticipant(resolved.requesterId, { type: 'undo-rejected', boardIndex: resolved.boardIndex, requesterId: resolved.requesterId, reason: 'declined' });
    }
}

// (Hôte) Applique effectivement l'annulation et la diffuse à tout le monde.
function applyUndoAsHost(pending) {
    if (pending.boardIndex !== boardIndex || pending.historyLengthAtRequest !== auctionHistory.length) {
        deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: pending.boardIndex, requesterId: pending.requesterId, reason: 'stale' });
        return;
    }
    // On retire l'annonce ciblée (la dernière de CE joueur — voir findUndoTargetIndex) et
    // tout ce qui l'a suivie (uniquement des passes robot dans ce cas, voir plus haut),
    // plutôt qu'un simple pop() de la toute dernière case du tableau.
    auctionHistory.length = pending.targetIndex;
    renderAuctionLedger();
    renderBiddingBox();
    renderMyHands();
    checkAuctionEnd();
    clearUndoUiState();
    peerConn.send({ type: 'undo-apply', boardIndex: pending.boardIndex, newLength: pending.targetIndex });
    maybeAutoPass(); // si l'annulation redonne la main à un siège robot, il doit rejouer
}

// Réponse de l'utilisateur au bandeau "on me demande d'annuler".
function uiAnswerUndo(approved) {
    const ask = pendingUndoAsk;
    if (!ask) return;
    pendingUndoAsk = null;
    renderUndoAskBanner();
    renderUndoControls();

    const answerMsg = {
        type: 'undo-answer',
        boardIndex: ask.boardIndex,
        requesterId: ask.requesterId,
        historyLengthAtRequest: ask.historyLengthAtRequest,
        approved
    };

    if (myRole === 'host') {
        hostReceiveUndoAnswer(answerMsg);
    } else {
        peerConn.send(answerMsg);
    }
}

function uiResetAuction() {
    if (!canControlBoard()) return;
    auctionHistory = [];
    hostPendingUndo = null;
    clearUndoUiState();
    renderAuctionLedger();
    renderBiddingBox();
    renderMyHands();
    checkAuctionEnd();
    peerConn.send({ type: 'reset-auction', boardIndex });
    maybeAutoPass(); // sans effet si on n'est pas l'hôte (voir maybeAutoPass) ; utile si le
                      // dealer (ou tout siège en tête d'enchère après reset) est un robot
}

// Change de donne : remet l'enchère à zéro, annule toute demande d'undo en cours, et
// diffuse le nouvel index à tout le monde. Partagé par le bouton "Donne suivante →"
// (accessible à tout joueur actif, uniquement une fois l'enchère terminée — voir
// checkAuctionEnd) et par les flèches ◀▶ de navigation libre, réservées à l'hôte.
function gotoBoard(newIndex) {
    boardIndex = newIndex;
    auctionHistory = [];
    hostPendingUndo = null;
    clearUndoUiState();
    renderBoard();
    peerConn.send({ type: 'goto-board', boardIndex });
}

function uiNextBoard() {
    if (!canControlBoard()) return;
    if (boardIndex >= deals.length - 1) return;
    gotoBoard(boardIndex + 1);
}

// Navigation libre entre les donnes (avancer ou reculer, y compris en pleine enchère) :
// réservée à l'hôte, pour pouvoir sauter une donne sans attendre que l'enchère en cours
// se termine.
function uiHostSkipNextBoard() {
    if (myRole !== 'host' || !deals) return;
    if (boardIndex >= deals.length - 1) return;
    gotoBoard(boardIndex + 1);
}

function uiHostSkipPrevBoard() {
    if (myRole !== 'host' || !deals) return;
    if (boardIndex <= 0) return;
    gotoBoard(boardIndex - 1);
}

function renderBoardSkipControls() {
    const prevBtn = document.getElementById('prevBoardBtn');
    const nextBtn = document.getElementById('skipNextBoardBtn');
    if (!prevBtn || !nextBtn) return;
    const isHost = myRole === 'host';
    prevBtn.style.display = isHost ? '' : 'none';
    nextBtn.style.display = isHost ? '' : 'none';
    if (!isHost || !deals) return;
    prevBtn.disabled = boardIndex <= 0;
    nextBtn.disabled = boardIndex >= deals.length - 1;
}

// ===== PWA : service worker, installation iOS, hors-ligne =====
//
// Voir manifest.json + sw.js pour le reste. Le versioning des fichiers mis en cache
// (anciennement un paramètre `?v=NN` sur chaque <script>/<link> de index.html) est
// désormais géré par CACHE_NAME dans sw.js — à incrémenter là-bas à chaque déploiement
// qui touche un fichier mis en cache.

let pendingSwRegistration = null;

function initServiceWorker() {
    if (!('serviceWorker' in navigator)) return;

    navigator.serviceWorker.register('sw.js').then((registration) => {
        // Un service worker déjà en attente (installé lors d'une visite précédente, jamais
        // activé faute de rechargement) : on tente de l'appliquer tout de suite, pas
        // seulement lors d'une future mise à jour détectée dans cette session.
        if (registration.waiting) {
            pendingSwRegistration = registration;
            tryAutoApplyUpdate();
        }

        registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (!newWorker) return;
            newWorker.addEventListener('statechange', () => {
                // 'installed' + un controller déjà actif = une mise à jour est prête et
                // attend ; sans controller actif, ce serait la toute première installation
                // du site, pas une mise à jour à appliquer.
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    pendingSwRegistration = registration;
                    tryAutoApplyUpdate();
                }
            });
        });
    }).catch((err) => {
        pushDebugLog('Service worker : échec d\'enregistrement — ' + (err && err.message));
    });

    // Une fois que le nouveau service worker prend effectivement le contrôle de la page
    // (après skipWaiting), recharger pour utiliser les nouveaux fichiers plutôt que ceux
    // encore en mémoire depuis avant la mise à jour. Protégé par un drapeau : cet
    // événement peut en théorie se déclencher plusieurs fois.
    let reloadedForUpdate = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (reloadedForUpdate) return;
        reloadedForUpdate = true;
        window.location.reload();
    });

    // Filet de sécurité : si une mise à jour est détectée pendant qu'une connexion de salle
    // est active (voir tryAutoApplyUpdate ci-dessous), elle reste en attente sans jamais
    // relancer d'elle-même — ce sondage périodique retente régulièrement, pour l'appliquer
    // dès qu'on revient à un moment sûr (plus aucune salle active) sans dépendre uniquement
    // d'un changement d'écran pour s'en rendre compte.
    setInterval(tryAutoApplyUpdate, 30000);
}

// Voir échange avec Guillaume : plus de bannière "Nouvelle version disponible" à cliquer,
// la mise à jour s'applique automatiquement — SAUF s'il y a une connexion de salle active
// (peerConn non nul), qu'on soit hôte ou invité, dans le salon ou en pleine donne. Ne pas
// se limiter à "pas en pleine donne" (deals) : un rechargement forcé pendant que l'hôte est
// encore dans le salon le laisserait bloqué, sans façon de s'y reconnecter (voir la
// limitation déjà documentée dans le README — l'identifiant de connexion de l'hôte change à
// chaque nouvelle partie). Dans ce cas, retenté plus tard (voir les appels dans showScreen
// et le sondage périodique) : au pire, elle s'appliquera à la prochaine ouverture de la
// page, exactement comme avant, juste sans bouton à cliquer.
function tryAutoApplyUpdate() {
    if (!pendingSwRegistration || !pendingSwRegistration.waiting) return;
    if (peerConn) return;
    pendingSwRegistration.waiting.postMessage('skipWaiting');
}

// iPadOS se fait passer pour un Mac (navigator.platform "MacIntel") depuis la version 13 :
// le distinguer d'un vrai Mac se fait via le support tactile, qu'aucun Mac n'a.
function isIosDevice() {
    return (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream)
        || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function isStandaloneDisplay() {
    return window.navigator.standalone === true
        || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
}

const IOS_INSTALL_HINT_DISMISSED_KEY = 'bridgeBidIosInstallHintDismissed';

// Safari iOS ne propose aucune invite d'installation automatique (contrairement à Chrome
// Android) : sans ce message, un joueur sur iPhone n'a aucun moyen de découvrir que
// l'appli peut être ajoutée à l'écran d'accueil.
function initIosInstallHint() {
    if (!isIosDevice() || isStandaloneDisplay()) return;
    let dismissed = false;
    try { dismissed = localStorage.getItem(IOS_INSTALL_HINT_DISMISSED_KEY) === 'true'; } catch (e) { /* tant pis */ }
    if (dismissed) return;
    const banner = document.getElementById('iosInstallBanner');
    if (banner) banner.style.display = 'flex';
}

function uiDismissIosInstallHint() {
    document.getElementById('iosInstallBanner').style.display = 'none';
    try { localStorage.setItem(IOS_INSTALL_HINT_DISMISSED_KEY, 'true'); } catch (e) { /* tant pis */ }
}

const IOS_LOCK_WARNING_DISMISSED_KEY = 'bridgeBidIosLockWarningDismissed';

// iOS suspend les connexions WebRTC quand Safari passe en arrière-plan ou que l'écran se
// verrouille — une vraie limitation de la plateforme, pas un bug de l'appli. Affiché une
// fois sur l'écran d'accueil, mémorisé pour ne pas le réafficher à chaque visite.
function initIosLockScreenWarning() {
    if (!isIosDevice()) return;
    let dismissed = false;
    try { dismissed = localStorage.getItem(IOS_LOCK_WARNING_DISMISSED_KEY) === 'true'; } catch (e) { /* tant pis */ }
    if (dismissed) return;
    const note = document.getElementById('iosLockScreenWarning');
    if (note) note.style.display = 'block';
}

function uiDismissIosLockScreenWarning() {
    document.getElementById('iosLockScreenWarning').style.display = 'none';
    try { localStorage.setItem(IOS_LOCK_WARNING_DISMISSED_KEY, 'true'); } catch (e) { /* tant pis */ }
}

// Hors-ligne : la partie de l'appli qui a un sens sans réseau est proche de zéro (tout
// repose sur la connexion pair-à-pair), donc on se contente de désactiver clairement les
// deux points d'entrée plutôt que de laisser l'utilisateur découvrir l'échec au clic.
function updateOfflineUI() {
    const offline = !navigator.onLine;
    const banner = document.getElementById('offlineBanner');
    if (banner) banner.style.display = offline ? 'block' : 'none';
    const createBtn = document.getElementById('createRoomBtn');
    const joinBtn = document.getElementById('joinRoomBtn');
    if (createBtn) createBtn.disabled = offline;
    if (joinBtn) joinBtn.disabled = offline;
}

function initOfflineHandling() {
    updateOfflineUI();
    window.addEventListener('online', updateOfflineUI);
    window.addEventListener('offline', updateOfflineUI);
}

// ===== Initialisation =====

window.addEventListener('DOMContentLoaded', () => {
    initServiceWorker();
    initIosInstallHint();
    initIosLockScreenWarning();
    initOfflineHandling();
    initDealLibrary();

    // Rafraîchit uniquement le texte du décompte ("déconnecté depuis Xs") de la bannière
    // de reconnexion — pas besoin d'un message réseau pour ça, chaque client calcule son
    // propre écoulé à partir de disconnectedAt. Sans effet (sortie immédiate) hors partie
    // ou si la bannière n'est pas affichée, voir renderReconnectionBanner.
    setInterval(renderReconnectionBanner, 1000);

    const params = new URLSearchParams(window.location.search);
    const room = params.get('room');
    if (room && navigator.onLine) {
        document.getElementById('joinCodeInput').value = room.toUpperCase();
        uiJoinRoom();
    } else if (room) {
        // Lien de partage ouvert hors-ligne : on préremplit le code, mais on ne tente pas
        // la connexion (updateOfflineUI, appelé juste au-dessus par initOfflineHandling,
        // a déjà désactivé le bouton "Rejoindre" — la personne devra réessayer une fois
        // reconnectée).
        document.getElementById('joinCodeInput').value = room.toUpperCase();
    }

    const dealFileInput = document.getElementById('dealFileInput');
    if (dealFileInput) {
        dealFileInput.addEventListener('change', uiHandleDealFileChosen);
    }
});
