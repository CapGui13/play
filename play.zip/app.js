// app.js — État de l'application et rendu de l'interface.
// S'appuie sur bidding-rules.js (logique pure), deal-parser.js (lecture PBN/LIN)
// et peer-connection.js (connexion WebRTC) chargés avant ce fichier.
//
// PRINCIPE : plus de "modes" prédéfinis. L'hôte crée une partie, atterrit dans un salon
// où apparaissent au fil de l'eau les participants (chacun choisit son pseudo), et
// assigne librement chaque siège (Nord/Est/Sud/Ouest) à qui il veut — y compris la même
// personne sur 2 sièges. Un siège non assigné est joué par un robot qui passe
// systématiquement. Ce mécanisme unique permet de reproduire tous les cas de figure :
// binôme (2 sièges assignés, 2 en robot), diagonale, "maître du jeu" (une personne sur
// 2 sièges, deux autres sur les 2 restants), 4 joueurs (chacun un siège), etc.
//
// TOPOLOGIE : à partir de 2 invités, les invités ne sont jamais connectés entre eux —
// l'hôte relaie tout message reçu d'un invité vers les autres (voir relayIfHost).

const SUIT_SYMBOLS = { S: '♠', H: '♥', D: '♦', C: '♣' };
const SUIT_CLASSES = { S: 'spades', H: 'hearts', D: 'diamonds', C: 'clubs' };

// Caractères Unicode ♠♥♦♣, forcés en police Arial (voir règle .suit-icon dans
// styles.css) pour un rendu stable en glyphes texte plutôt qu'en émojis colorés selon
// la plateforme. La couleur (palette quatre couleurs) est appliquée en CSS via la classe
// de couleur (SUIT_CLASSES), pas cuite dans le caractère.
function suitIconHtml(suit, extraClass) {
    return `<span class="suit-icon ${SUIT_CLASSES[suit]}${extraClass ? ' ' + extraClass : ''}">${SUIT_SYMBOLS[suit]}</span>`;
}

// Libellé HTML d'une couleur d'enchère : "SA" en texte pour sans-atout, sinon l'icône de
// couleur (suitIconHtml). Centralise un motif répété à plusieurs endroits (boîte
// d'enchères, relevé, contrat final, table du double mort). Accepte les deux conventions
// utilisées dans ce fichier pour désigner le sans-atout : 'NT' (calls d'enchères, voir
// bidding-rules.js/STRAINS) et 'N' (clés de la table du double mort, voir STRAIN_ORDER —
// où N signifie sans-atout et non Nord). Aucune des deux ne désigne autre chose ailleurs,
// donc pas d'ambiguïté à les traiter ensemble ici.
function formatStrainLabel(strain) {
    return (strain === 'NT' || strain === 'N') ? 'SA' : suitIconHtml(strain);
}
const SEAT_FULL_NAME = { N: 'Nord', E: 'Est', S: 'Sud', W: 'Ouest' };

// Voir échange avec Guillaume (session asynchrone à deux) : troisième état possible pour
// seatAssignment[seat], en plus de null (robot, auto-passe) et de l'id d'un participant
// déjà connecté. 'PENDING' désigne un siège réservé à un futur partenaire qui n'est pas
// encore venu — contrairement à un robot, ce siège N'auto-passe JAMAIS (voir
// `!seatAssignment[seat]` un peu partout dans ce fichier pour calculer autoPassSeats :
// une chaîne non vide comme 'PENDING' y est déjà exclue naturellement, aucun changement
// nécessaire à ces endroits-là). Une fois que ce partenaire ouvre le lien de la salle et
// revendique ce siège (voir claimPendingSeat), la valeur est remplacée par son propre
// jeton de reconnexion, comme pour n'importe quel invité classique.
const SEAT_PENDING = 'PENDING';
// Abréviation d'un seul caractère à afficher (convention française : O, pas W) — les
// clés internes restent N/E/S/W partout ailleurs (PBN, protocole réseau, etc.).
const SEAT_ABBR_FR = { N: 'N', E: 'E', S: 'S', W: 'O' };
const VULN_LABEL = { None: 'Non vulnérable', NS: 'NS vulnérable', EW: 'EO vulnérable', Both: 'Tous vulnérables' };

// ===== Diagnostic de performance léger =====
// Garde uniquement des timestamps/étapes, jamais de données de partie ni de secret.
// Accessible dans la console via getPlayPerfTrace() quand une lenteur intermittente doit
// être attribuée précisément (réservation Vercel/Redis, chargement PeerJS, signalisation...).
const playPerfTrace = [];
function recordPlayPerfMilestone(name, detail) {
    const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    const entry = { name: String(name), t: Math.round(now * 10) / 10 };
    if (detail !== undefined) entry.detail = detail;
    playPerfTrace.push(entry);
    if (playPerfTrace.length > 80) playPerfTrace.shift();
    if (typeof console !== 'undefined' && console.info) console.info('[PLAY perf]', entry.name, entry.t, entry.detail || '');
    return entry;
}
if (typeof window !== 'undefined') {
    window.recordPlayPerfMilestone = recordPlayPerfMilestone;
    window.getPlayPerfTrace = () => playPerfTrace.slice();
}
recordPlayPerfMilestone('app-script-ready');

// Le seul utilitaire de l'ancien bidding-engine.js encore utilisé par l'UI. Le moteur
// legacy complet (~519 ko brut) n'a donc plus besoin d'être parsé sur l'écran d'accueil.
const HCP_VALUE_LIGHT = { A: 4, K: 3, Q: 2, J: 1 };
function computeHandHcp(hand) {
    let total = 0;
    for (const suit of ['S', 'H', 'D', 'C']) {
        const ranks = hand && hand[suit] ? hand[suit] : '';
        for (const c of ranks) total += HCP_VALUE_LIGHT[c] || 0;
    }
    return total;
}


// ===== Chargement différé de PONS =====
//
// PONS représente de très loin la majorité du poids JavaScript de PLAY (~15,2 Mo brut).
// Sur mobile, l'ancienne optimisation lançait sept <link rel="preload"> en parallèle :
// cela pouvait saturer le réseau/mémoire et, surtout, un <script> ayant échoué restait dans
// le DOM ; une retentative s'abonnait alors à un événement "error" déjà passé et pouvait
// rester bloquée. Le chargement réel est maintenant strictement séquentiel, chaque fichier
// a une retentative réseau fraîche, et le préchargement spéculatif est désactivé sur mobile,
// Save-Data et réseaux lents.
const PONS_CANONICAL_RULES_URL = 'pons/canonical-rules-v1.json';
const PONS_RAW_WASM_URL = 'pons/pons_wasm_bg.wasm';
const PONS_CANONICAL_RULES_LEGACY_URL = 'pons/canonical-rules-v1.js?v=20260821-mobile-fallback';
const PONS_WASM_EMBEDDED_FALLBACK_URL = 'pons/pons-wasm-embedded.js?v=20260821-mobile-fallback';
const PONS_CLIENT_SCRIPT_URLS = [
    'pons/bridge-engine-v1-browser.js',
    'pons/fiches-engine-v1-app.js?v=20260825-shortnt',
    'pons/pons-semantic.js?v=20260812-semantic05-v216',
    'pons/pons-critic.js?v=20260815-v251-realworld-p0',
    'pons/pons-wasm-runtime.js?v=20260821-mobile-memory',
    'pons/pons-engine.js?v=20260825-shortnt'
];
let ponsClientLoadPromise = null;
let ponsCanonicalRulesPromise = null;
let ponsClientPreloadScheduled = false;
let ponsLoadStage = 'idle';
let ponsLastLoadError = null;

function setPonsLoadStage(stage) {
    ponsLoadStage = stage;
    recordPlayPerfMilestone('pons-stage', stage);
    if (typeof recordSyncTrace === 'function') recordSyncTrace('pons.stage', { stage });
}

if (typeof window !== 'undefined') {
    window.getPonsLoadDiagnostic = () => ({
        stage: ponsLoadStage,
        error: ponsLastLoadError ? String(ponsLastLoadError.message || ponsLastLoadError) : null,
        rulesLoaded: Array.isArray(window.BRIDGE_CANONICAL_RULES_V1) ? window.BRIDGE_CANONICAL_RULES_V1.length : 0,
        wasmReady: !!window.PonsWasmModule,
        wasmRuntimeError: window.PONS_WASM_RUNTIME_ERROR ? String(window.PONS_WASM_RUNTIME_ERROR.message || window.PONS_WASM_RUNTIME_ERROR) : null,
        engineReady: !!(window.PonsEngine && window.PonsEngine.loaded),
        engineError: window.PonsEngine && window.PonsEngine.error ? String(window.PonsEngine.error.message || window.PonsEngine.error) : null,
        mobile: isLikelyMobileDevice(),
        online: navigator.onLine,
        userAgent: navigator.userAgent,
        platform: navigator.platform || '',
        standalone: !!(window.matchMedia && window.matchMedia('(display-mode: standalone)').matches),
        serviceWorkerControlled: !!(navigator.serviceWorker && navigator.serviceWorker.controller)
    });
}

function setPonsClientLoadingStatus(text, kind = 'is-offline') {
    const el = document.getElementById('ponsEngineStatus');
    if (!el) return;
    el.className = `wbridge-status ${kind}`;
    el.textContent = text;
}

function isLikelyMobileDevice() {
    try {
        if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches && window.innerWidth <= 1366) return true;
    } catch (e) { /* fallback largeur */ }
    return typeof window !== 'undefined' && window.innerWidth <= 760;
}

function isConstrainedNetworkForPreload() {
    const conn = typeof navigator !== 'undefined' && (navigator.connection || navigator.mozConnection || navigator.webkitConnection);
    if (!conn) return false;
    if (conn.saveData) return true;
    return ['slow-2g', '2g'].includes(String(conn.effectiveType || '').toLowerCase());
}

function ponsNeededForCurrentSetup() {
    if (typeof robotBiddingMode !== 'undefined' && robotBiddingMode === 'passOnly') return false;
    if (typeof seatAssignment !== 'object' || !seatAssignment) return true;
    return SEATS.some(seat => !seatAssignment[seat]);
}

function prefetchPonsClientScripts() {
    if (!ponsNeededForCurrentSetup() || isLikelyMobileDevice() || isConstrainedNetworkForPreload()) return false;
    const assets = [
        { src: PONS_CANONICAL_RULES_URL, as: 'fetch' },
        ...PONS_CLIENT_SCRIPT_URLS.map(src => ({ src, as: 'script' })),
        { src: PONS_RAW_WASM_URL, as: 'fetch' }
    ];
    for (const { src, as } of assets) {
        if (Array.from(document.querySelectorAll('link[data-pons-prefetch]')).some(link => link.dataset.ponsPrefetch === src)) continue;
        const link = document.createElement('link');
        // prefetch = opportuniste/faible priorité ; contrairement à preload il ne concurrence
        // pas les requêtes interactives du salon et le navigateur peut choisir de l'ignorer.
        link.rel = 'prefetch';
        link.as = as;
        link.href = src;
        link.dataset.ponsPrefetch = src;
        document.head.appendChild(link);
    }
    return true;
}

function ponsTimeoutError(label, ms) {
    const seconds = Math.max(1, Math.round(ms / 1000));
    const err = new Error(`${label} n’a pas répondu après ${seconds} s`);
    err.name = 'PonsTimeoutError';
    return err;
}

async function fetchPonsWithTimeout(url, options = {}, timeoutMs = 25000, label = 'Ressource PONS') {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        return await fetch(url, { ...options, signal: controller.signal });
    } catch (err) {
        if (controller.signal.aborted) throw ponsTimeoutError(label, timeoutMs);
        throw err;
    } finally {
        clearTimeout(timer);
    }
}

function withPonsTimeout(promise, timeoutMs, label) {
    let timer = null;
    const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(ponsTimeoutError(label, timeoutMs)), timeoutMs);
    });
    return Promise.race([Promise.resolve(promise), timeout]).finally(() => {
        if (timer) clearTimeout(timer);
    });
}

async function loadPonsCanonicalRules() {
    if (Array.isArray(window.BRIDGE_CANONICAL_RULES_V1) && window.BRIDGE_CANONICAL_RULES_V1.length) {
        return window.BRIDGE_CANONICAL_RULES_V1;
    }
    if (ponsCanonicalRulesPromise) return ponsCanonicalRulesPromise;

    ponsCanonicalRulesPromise = (async () => {
        let lastError;
        for (let attempt = 0; attempt < 2; attempt++) {
            try {
                setPonsLoadStage(attempt ? 'canonical-rules-retry' : 'canonical-rules');
                const url = ponsAttemptUrl(PONS_CANONICAL_RULES_URL, attempt);
                const response = await fetchPonsWithTimeout(
                    url,
                    { cache: attempt ? 'reload' : 'default' },
                    attempt ? 20000 : 25000,
                    'Règles PONS'
                );
                if (!response.ok) throw new Error(`Règles PONS HTTP ${response.status}`);
                const rules = await response.json();
                if (!Array.isArray(rules) || rules.length < 1000) throw new Error('Règles PONS JSON invalides');
                window.BRIDGE_CANONICAL_RULES_V1 = rules;
                recordPlayPerfMilestone('pons-canonical-ready', rules.length);
                return rules;
            } catch (err) {
                lastError = err;
                if (attempt) break;
            }
        }
        // Dernier filet de sécurité mobile : si le chemin JSON optimisé échoue, reprendre
        // exactement l'ancien producteur JS qui fonctionnait avant PERF2. Il n'est chargé
        // qu'après deux échecs JSON, donc aucun coût sur le chemin normal rapide.
        try {
            setPonsLoadStage('canonical-rules-legacy-fallback');
            await loadPonsClientScript(PONS_CANONICAL_RULES_LEGACY_URL);
            if (!Array.isArray(window.BRIDGE_CANONICAL_RULES_V1) || window.BRIDGE_CANONICAL_RULES_V1.length < 1000) {
                throw new Error('Règles PONS legacy invalides');
            }
            recordPlayPerfMilestone('pons-canonical-legacy-ready', window.BRIDGE_CANONICAL_RULES_V1.length);
            return window.BRIDGE_CANONICAL_RULES_V1;
        } catch (fallbackErr) {
            const primary = lastError ? String(lastError.message || lastError) : 'inconnu';
            const fallback = String(fallbackErr.message || fallbackErr);
            throw new Error(`Règles PONS indisponibles (JSON: ${primary}; fallback JS: ${fallback})`);
        }
    })().catch(err => {
        ponsCanonicalRulesPromise = null;
        throw err;
    });
    return ponsCanonicalRulesPromise;
}

function ponsAttemptUrl(src, attempt) {
    if (!attempt) return src;
    const url = new URL(src, window.location.href);
    url.searchParams.set('__pons_fresh', `${Date.now()}-${attempt}`);
    return url.href;
}

function loadPonsClientScriptOnce(src, attempt) {
    return new Promise((resolve, reject) => {
        const stale = Array.from(document.scripts).find(script => script.dataset && script.dataset.ponsLazySrc === src);
        if (stale) {
            if (stale.dataset.ponsLoaded === '1') { resolve(); return; }
            // Un script en erreur ne doit JAMAIS rester comme faux "chargement en cours".
            // C'était une cause possible de retentative bloquée sur mobile.
            stale.remove();
        }
        const script = document.createElement('script');
        script.src = ponsAttemptUrl(src, attempt);
        script.async = false;
        script.dataset.ponsLazySrc = src;
        script.dataset.ponsAttempt = String(attempt);
        let settled = false;
        const scriptTimeoutMs = src.includes('pons-wasm-embedded.js') || src.includes('canonical-rules-v1.js') ? 45000 : 25000;
        const timer = setTimeout(() => finish(false, ponsTimeoutError(`Chargement de ${src.split('?')[0]}`, scriptTimeoutMs)), scriptTimeoutMs);
        const finish = (ok, err) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            if (ok) {
                script.dataset.ponsLoaded = '1';
                resolve();
            } else {
                script.dataset.ponsFailed = '1';
                script.remove();
                reject(err || new Error(`Chargement PONS impossible : ${src}`));
            }
        };
        script.addEventListener('load', () => finish(true), { once: true });
        script.addEventListener('error', () => finish(false, new Error(`Chargement PONS impossible : ${src}`)), { once: true });
        document.body.appendChild(script);
    });
}

async function loadPonsClientScript(src) {
    let lastError;
    for (let attempt = 0; attempt < 2; attempt++) {
        try {
            if (attempt) {
                setPonsClientLoadingStatus('🧠 PONS : nouvelle tentative de chargement…');
                recordPlayPerfMilestone('pons-script-retry', src);
            }
            setPonsLoadStage(`script:${src.split('?')[0]}`);
            await loadPonsClientScriptOnce(src, attempt);
            // Le nouveau loader WASM est volontairement minuscule : son événement load
            // signifie seulement que le glue JS est parsé. Il faut aussi attendre le vrai
            // .wasm, compilé en streaming, avant de charger pons-engine.js.
            if (src.includes('pons-wasm-runtime.js')) {
                if (!window.PONS_WASM_RUNTIME_READY) throw new Error('Promise WASM PONS absente');
                await withPonsTimeout(window.PONS_WASM_RUNTIME_READY, 22000, 'Initialisation WASM PONS');
                if (!window.PonsWasmModule) throw new Error('Module WASM PONS absent après initialisation');
                recordPlayPerfMilestone('pons-wasm-ready');
            }
            return;
        } catch (err) {
            lastError = err;
            // Un glue JS peut être chargé avec succès alors que son fetch WASM a échoué.
            // Dans ce cas, supprimer réellement le nœud et la promise rejetée afin que la
            // seconde tentative reparte du réseau, au lieu de recycler un faux succès.
            const stale = Array.from(document.scripts).find(script => script.dataset && script.dataset.ponsLazySrc === src);
            if (stale) stale.remove();
            if (src.includes('pons-wasm-runtime.js')) {
                try { delete window.PONS_WASM_RUNTIME_READY; } catch (_) { window.PONS_WASM_RUNTIME_READY = null; }
                try { delete window.PONS_WASM_RUNTIME_ERROR; } catch (_) { window.PONS_WASM_RUNTIME_ERROR = null; }
                try { delete window.PonsWasmModule; } catch (_) { window.PonsWasmModule = null; }
            }
        }
    }
    throw lastError || new Error(`Chargement PONS impossible : ${src}`);
}

async function ensurePonsClientReady() {
    if (window.PonsEngine) {
        const ready = await window.PonsEngine.ready;
        if (!ready || !window.PonsEngine.loaded) {
            throw window.PonsEngine.error || new Error('PONS v2.61 n’a pas pu être initialisé.');
        }
        return window.PonsEngine;
    }
    if (ponsClientLoadPromise) return ponsClientLoadPromise;

    ponsClientLoadPromise = (async () => {
        ponsLastLoadError = null;
        recordPlayPerfMilestone('pons-load-start', { mobile: isLikelyMobileDevice() });
        setPonsClientLoadingStatus('🧠 PONS : chargement du moteur…');
        // Les deux anciens monstres JS (règles ~9,5 Mo et WASM base64 ~4,8 Mo) ne sont plus
        // parsés comme JavaScript sur le client. Les règles sont un JSON chargé avant le
        // moteur canonique ; le WASM est un vrai binaire compilé en streaming. C'est le
        // chemin par défaut sur desktop ET mobile pour garder exactement le même moteur.
        await loadPonsCanonicalRules();
        for (const src of PONS_CLIENT_SCRIPT_URLS) {
            if (src.includes('pons-wasm-runtime.js')) {
                try {
                    await loadPonsClientScript(src);
                } catch (rawWasmErr) {
                    // Si le nouveau .wasm brut échoue (réseau/MIME/Safari), reprendre le
                    // bundle WASM embarqué historique. C'est plus lourd, mais uniquement
                    // comme secours et avec exactement les mêmes octets WASM.
                    setPonsLoadStage('wasm-embedded-fallback');
                    recordPlayPerfMilestone('pons-wasm-embedded-fallback', String(rawWasmErr.message || rawWasmErr));
                    try { delete window.PONS_WASM_RUNTIME_READY; } catch (_) { window.PONS_WASM_RUNTIME_READY = null; }
                    try { delete window.PONS_WASM_RUNTIME_ERROR; } catch (_) { window.PONS_WASM_RUNTIME_ERROR = null; }
                    try { delete window.PonsWasmModule; } catch (_) { window.PonsWasmModule = null; }
                    await loadPonsClientScript(PONS_WASM_EMBEDDED_FALLBACK_URL);
                    if (!window.PonsWasmModule) throw rawWasmErr;
                    recordPlayPerfMilestone('pons-wasm-embedded-ready');
                }
            } else {
                await loadPonsClientScript(src);
            }
        }
        if (!window.PonsEngine) throw new Error('PONS v2.61 chargé mais API navigateur absente.');
        setPonsLoadStage('engine-ready');
        const ready = await window.PonsEngine.ready;
        if (!ready || !window.PonsEngine.loaded) {
            throw window.PonsEngine.error || new Error('PONS v2.61 n’a pas pu être initialisé.');
        }
        setPonsLoadStage('ready');
        recordPlayPerfMilestone('pons-load-ready');
        return window.PonsEngine;
    })().catch(err => {
        ponsLastLoadError = err;
        recordPlayPerfMilestone('pons-load-failed', { stage: ponsLoadStage, message: err && err.message ? err.message : String(err) });
        setPonsClientLoadingStatus('❌ PONS v2.61 indisponible — robots bloqués');
        ponsClientLoadPromise = null;
        throw err;
    });

    return ponsClientLoadPromise;
}

async function ponsDiagnosticFetchProbe(url) {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 10000) : null;
    try {
        const response = await fetch(url, {
            method: 'HEAD',
            cache: 'reload',
            signal: controller ? controller.signal : undefined
        });
        return `${response.status} ${response.headers.get('content-type') || '(sans MIME)'}`;
    } catch (err) {
        return `ECHEC ${String(err && err.message ? err.message : err)}`;
    } finally {
        if (timer) clearTimeout(timer);
    }
}

async function ponsDiagnosticWasmProbe() {
    if (typeof WebAssembly === 'undefined') return 'ABSENT';
    try {
        // Module WASM minimal valide : magic + version uniquement. Ce test distingue un
        // blocage CSP/WebKit d'un problème de téléchargement de notre gros binaire.
        await WebAssembly.compile(new Uint8Array([0,97,115,109,1,0,0,0]));
        return 'OK';
    } catch (err) {
        return `ECHEC ${String(err && err.message ? err.message : err)}`;
    }
}

async function buildPonsFailureDiagnostic() {
    const base = window.getPonsLoadDiagnostic ? window.getPonsLoadDiagnostic() : {};
    const [rulesHttp, wasmHttp, wasmProbe] = await Promise.all([
        ponsDiagnosticFetchProbe(PONS_CANONICAL_RULES_URL),
        ponsDiagnosticFetchProbe(PONS_RAW_WASM_URL),
        ponsDiagnosticWasmProbe()
    ]);
    let cacheNames = [];
    try { if (window.caches && caches.keys) cacheNames = await caches.keys(); } catch (_) { /* non critique */ }
    return [
        'PLAY / PONS mobile diagnostic',
        `stage=${base.stage || 'inconnu'}`,
        `error=${base.error || '(aucune)'}`,
        `wasmRuntimeError=${base.wasmRuntimeError || '(aucune)'}`,
        `engineError=${base.engineError || '(aucune)'}`,
        `rulesLoaded=${base.rulesLoaded || 0}`,
        `wasmReady=${!!base.wasmReady}`,
        `engineReady=${!!base.engineReady}`,
        `wasmCompileProbe=${wasmProbe}`,
        `rulesHEAD=${rulesHttp}`,
        `wasmHEAD=${wasmHttp}`,
        `online=${base.online}`,
        `mobile=${base.mobile}`,
        `standalone=${base.standalone}`,
        `serviceWorkerControlled=${base.serviceWorkerControlled}`,
        `cacheNames=${cacheNames.join(',') || '(aucun)'}`,
        `platform=${base.platform || ''}`,
        `userAgent=${base.userAgent || navigator.userAgent || ''}`
    ].join('\n');
}

async function showPonsFailureDiagnostic() {
    const panel = document.getElementById('ponsFailureDiagnostic');
    const text = document.getElementById('ponsFailureDiagnosticText');
    if (!panel || !text) return;
    panel.style.display = 'block';
    text.value = 'Diagnostic PONS en cours…';
    try { text.value = await buildPonsFailureDiagnostic(); }
    catch (err) { text.value = `Diagnostic lui-même en échec : ${String(err && err.message ? err.message : err)}`; }
}

function hidePonsFailureDiagnostic() {
    const panel = document.getElementById('ponsFailureDiagnostic');
    if (panel) panel.style.display = 'none';
}

async function uiCopyPonsDiagnostic() {
    const text = document.getElementById('ponsFailureDiagnosticText');
    if (!text) return;
    const value = text.value || '';
    try {
        await navigator.clipboard.writeText(value);
        setHostSetupMessage('Diagnostic PONS copié. Colle-le dans ChatGPT.', 'warning');
    } catch (_) {
        text.focus();
        text.select();
        setHostSetupMessage('Diagnostic sélectionné : utilise Copier dans le menu du téléphone.', 'warning');
    }
}

function resetPonsEngineForRetry() {
    ponsClientLoadPromise = null;
    const engineSrc = PONS_CLIENT_SCRIPT_URLS.find(src => src.includes('pons-engine.js'));
    if (engineSrc) {
        Array.from(document.scripts)
            .filter(script => script.dataset && script.dataset.ponsLazySrc === engineSrc)
            .forEach(script => script.remove());
    }
    try { delete window.PonsEngine; } catch (_) { window.PonsEngine = null; }
}

async function uiRetryPonsFromDiagnostic() {
    setHostSetupMessage('Nouvelle tentative de chargement PONS…', 'warning');
    hidePonsFailureDiagnostic();
    resetPonsEngineForRetry();
    try {
        await ensurePonsClientReady();
        setHostSetupMessage('PONS est maintenant chargé. Tu peux relancer la partie.', 'success');
    } catch (err) {
        ponsLastLoadError = err;
        setHostSetupMessage('PONS bloque encore. Le diagnostic ci-dessous indique l’étape exacte.', false);
        await showPonsFailureDiagnostic();
    }
}

function schedulePonsClientPreload() {
    if (window.PonsEngine || ponsClientLoadPromise || ponsClientPreloadScheduled) return;
    if (!ponsNeededForCurrentSetup() || isLikelyMobileDevice() || isConstrainedNetworkForPreload()) return;
    ponsClientPreloadScheduled = true;
    const run = () => {
        ponsClientPreloadScheduled = false;
        prefetchPonsClientScripts();
    };
    if (window.requestIdleCallback) window.requestIdleCallback(run, { timeout: 1800 });
    else setTimeout(run, 900);
}

let peerConn = null;
let myRole = null;          // 'host' | 'guest'
let myParticipantId = null; // 'host', ou le jeton de reconnexion de l'invité (stable entre reconnexions)
let participants = [];      // [{ id, name, disconnected }, ...] — état du salon, maintenu par l'hôte
let seatAssignment = { N: null, E: null, S: null, W: null }; // id de participant, ou null (robot)
// Pas de statut "spectateur" séparé : quiconque n'occupe aucun siège est kibbitz (voir
// SEATS.every / mySeats.length === 0 un peu partout dans ce fichier) et voit donc les 4
// mains dès le début de la donne — inutile de l'assigner manuellement, ça découle
// directement de seatAssignment.

// Dernier instantané de seatAssignment vu au rendu précédent, pour détecter les
// affectations qui viennent tout juste d'arriver et leur appliquer un flash (voir
// renderSeatAssignmentGrid). `null` signifie "pas encore de repère" (première mesure
// après un (re)chargement du salon) : dans ce cas on se contente de capturer l'état sans
// rien flasher, pour ne pas allumer d'un coup toutes les places déjà occupées quand on
// rejoint un salon en cours de remplissage.
let prevSeatAssignmentSnapshot = null;

// Même principe, pour détecter côté invité les transitions déconnecté -> reconnecté d'un
// AUTRE participant (voir le cas 'lobby-state' dans handlePeerData) et déclencher un
// message de bienvenue transitoire. Côté hôte, cette détection se fait directement dans
// onGuestConnected (l'événement est déjà connu avec certitude, pas besoin de comparer),
// donc ce snapshot n'y est pas utilisé pour cette partie-là.
let prevParticipantsDisconnectedSnapshot = null;

let currentRoomCode = null; // pour uiReconnect() : on doit se souvenir du code utilisé pour rejoindre
// Voir échange avec Guillaume (session asynchrone à deux — "connexion en cours en
// boucle") : incrémenté à chaque connectAsGuest(), permet à un minuteur programmé par un
// essai précédent de se reconnaître périmé si un nouvel essai a pris le relais entre-temps.
let guestJoinAttemptToken = 0;
// Délai avant de tenter la reprise cloud EN PARALLÈLE de la tentative de connexion directe
// (voir connectAsGuest) — bien plus court que le délai d'abandon de 45s.
// Voir échange avec Guillaume ("je rejoins depuis mon PC et je me retrouve avec des
// privilèges d'hôte") : ancienne valeur (4000) beaucoup trop courte — une vraie connexion
// P2P live entre deux réseaux différents (ex. mobile en 4G qui héberge, PC en WiFi qui
// rejoint) peut légitimement prendre plusieurs secondes, surtout si un relais TURN est
// nécessaire (négociation ICE). Le minuteur se déclenchait alors AVANT que la connexion
// live n'aboutisse, et la reprise cloud prenait le relais à tort — passant l'invité en
// myRole='host' LOCALEMENT (voir uiResumeFromCloud : c'est voulu pour le jeu asynchrone,
// où n'importe qui doit pouvoir naviguer les donnes, mais ça donne exactement les mêmes
// privilèges d'affichage que le vrai hôte, dont la réorganisation des sièges — puisque
// toute l'interface se base uniquement sur myRole==='host'). 12s laisse une large marge à
// une connexion live normale, y compris avec relais TURN, tout en restant nettement plus
// rapide que 45s pour le cas légitime visé à l'origine (salle vraiment vide/expirée).
const EARLY_CLOUD_CHECK_DELAY_MS = 12000;
// Identité de l'autorité persistante de la SALLE COURANTE. À la création normale,
// elle désigne le créateur. Un transfert manuel crée volontairement une NOUVELLE salle :
// le participant promu devient donc le creator de cette nouvelle salle (voir
// 'prepare-become-host'), afin qu'une reprise à froid lui rende aussi l'autorité P2P.
let roomCreatorName = null;
// Jeton privé local du creator de la salle courante, utilisé par uiResumeFromCloud pour
// distinguer celui qui peut recréer le vrai Peer hôte d'un participant qui ne fait qu'une
// reprise différée locale. Il n'est jamais conservé lorsqu'on repasse en rôle invité.
let roomCreatorToken = null;

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4 — nettoyage) : la reprise automatique
// d'hôte automatique (ancien mécanisme d'élection P2P en cas de coupure prolongée,
// session du 23 juillet) a été retirée — superflue maintenant que chaque siège route
// individuellement vers le relais serveur en cas de coupure (voir étape 3), sans jamais
// changer qui est l'hôte. C'était aussi la source de la quasi-totalité des bugs de
// reconnexion rencontrés cette session (transfert d'hôte incohérent, double hôte,
// retour de l'hôte original non reconnu...).
//
// currentHostReconnectToken reste : le jeton de reconnexion de l'hôte ACTUEL (qui ne
// change plus jamais en cours de partie) — utile pour qu'un invité sache identifier
// correctement l'hôte dans ses propres échanges avec le serveur (voir
// buildCloudStatePayload), reçu via 'lobby-state'/'start-game'/'resync' comme avant.
let currentHostReconnectToken = null;
// Horodatage de NOTRE PROPRE déconnexion détectée. La bannière persistante ayant été
// retirée, ce repère sert encore à distinguer une vraie reconnexion et à afficher le toast
// de retour une seule fois (voir les gestionnaires de connexion plus bas).
let selfDisconnectedAt = null;

// Voir échange avec Guillaume ("je rouvre la fenêtre de l'hôte bien avant 20s, mais
// l'invité bascule en 'prise de relais' comme si rien n'avait changé") : la reconnexion
// d'un INVITÉ n'a jamais été qu'un clic manuel sur "Se reconnecter" (uiReconnect) — rouvrir
// la fenêtre de l'hôte, même immédiatement, ne change donc RIEN tout seul côté invité sans
// ce minuteur. Retente silencieusement une reconnexion en tâche de fond pendant qu'un
// invité reste déconnecté — annulé dès qu'onGuestConnected réussit (voir
// buildGuestHandlers), donc sans effet une fois reconnecté.
let guestAutoReconnectTimer = null;
const GUEST_AUTO_RECONNECT_INTERVAL_MS = 4000;

// (Hôte uniquement) jeton de reconnexion -> numéro de connexion PeerJS actif. Un invité
// garde le même jeton (localStorage) à travers ses reconnexions, mais son guestIndex
// change à chaque fois (nouvelle connexion PeerJS) : cette table fait le pont entre les
// deux, pour que seatAssignment (qui référence le jeton, stable) reste valide.
let guestIndexByToken = {};

// ===== Transfert d'hôte (salon uniquement, avant le lancement de la partie) =====
//
// Voir échange avec Guillaume : permet à l'hôte de céder son rôle à un autre participant
// connecté, dans le salon, avant de charger les donnes. Utile notamment quand la création
// de la partie échoue sur son propre appareil (réseau) : un ami crée la partie, puis
// Guillaume se la fait transférer une fois dans le salon.
//
// hostTransferInProgress : vrai entre l'envoi de 'prepare-become-host' et la réception de
// 'become-host-ready'/'become-host-failed' — évite de lancer un second transfert pendant
// qu'un premier est encore en cours.
let hostTransferInProgress = false;
// Jeton du participant visé par le transfert en cours (pour retrouver sa connexion au
// moment de la réponse) — uniquement pertinent côté ancien hôte, le temps du transfert.
let pendingHostTransferTarget = null;
// Jeton de reconnexion que l'hôte actuel s'apprête à utiliser une fois redevenu invité
// (généré au moment de lancer le transfert, voir uiTransferHost) — transmis au nouvel
// hôte dans 'prepare-become-host' pour qu'il puisse déjà lui réserver sa place/son siège
// sous ce jeton, avant même qu'il ne se reconnecte.
let pendingHostTransferOldToken = null;
let pendingHostTransferOldCredential = null;

// Jeton de reconnexion propre à ce navigateur, généré une fois puis conservé dans
// localStorage — survit à un rechargement ET à la fermeture/réouverture de l'onglet
// (contrairement à sessionStorage, qui est isolé par onglet et aurait généré un nouveau
// jeton à chaque réouverture, empêchant toute reconnexion réelle). Revers : deux onglets
// ouverts sur la même partie, dans le même navigateur, partageront le même jeton — sans
// conséquence pour un usage normal (un onglet par joueur), seulement pour un test solo
// avec plusieurs onglets qui simuleraient plusieurs joueurs différents.
function getReconnectToken() {
    try {
        let t = localStorage.getItem('bridgeBidReconnectToken');
        if (!t) {
            t = 'p' + Math.random().toString(36).slice(2) + Date.now().toString(36);
            localStorage.setItem('bridgeBidReconnectToken', t);
        }
        return t;
    } catch (e) {
        // localStorage indisponible (navigation privée stricte, etc.) : le jeton ne
        // survivra pas à un rechargement, mais au moins l'app ne plante pas.
        if (!window._fallbackReconnectToken) {
            window._fallbackReconnectToken = 'p' + Math.random().toString(36).slice(2) + Date.now().toString(36);
        }
        return window._fallbackReconnectToken;
    }
}

// ===== Identité P2P invitée durcie =====
//
// Le participantId est PUBLIC et peut être diffusé dans lobby-state. Le reconnectSecret
// est PRIVÉ : il n'est envoyé qu'en métadonnée de la connexion directe au host et n'est
// jamais inclus dans participants/lobby-state/start-game/resync ni dans le snapshot cloud.
// Le host conserve uniquement, sur son propre appareil, la table participantId -> secret
// nécessaire pour reconnaître une vraie reconnexion. Un id public observé par un autre
// peer ne constitue donc plus une preuve d'identité.
const GUEST_ROOM_IDENTITY_STORAGE_KEY = 'bridgeBidGuestRoomIdentityV2';
const HOST_GUEST_RECONNECT_STORAGE_KEY = 'bridgeBidHostGuestReconnectSecretsV2';
const GUEST_IDENTITY_MAX_AGE_MS = 70 * 24 * 60 * 60 * 1000;
const MODERN_GUEST_ID_RE = /^p_[A-Za-z0-9_-]{24,96}$/;
const SAFE_GUEST_ID_RE = /^(?:p_[A-Za-z0-9_-]{24,96}|p[A-Za-z0-9]{8,96}|guest\d{1,3})$/;
const RECONNECT_SECRET_RE = /^s_[A-Za-z0-9_-]{32,160}$/;
const identityRecoveryAttemptedRooms = new Set();

function secureRandomBase64Url(byteLength) {
    const bytes = new Uint8Array(byteLength);
    if (!window.crypto || typeof window.crypto.getRandomValues !== 'function') {
        throw new Error('Générateur cryptographique indisponible.');
    }
    window.crypto.getRandomValues(bytes);
    let raw = '';
    for (let i = 0; i < bytes.length; i++) raw += String.fromCharCode(bytes[i]);
    return btoa(raw).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function createGuestReconnectCredential() {
    return {
        participantId: 'p_' + secureRandomBase64Url(18),
        reconnectSecret: 's_' + secureRandomBase64Url(32)
    };
}

function isModernGuestParticipantId(id) {
    return typeof id === 'string' && MODERN_GUEST_ID_RE.test(id);
}

function isSafeParticipantId(id) {
    return id === 'host' || (typeof id === 'string' && SAFE_GUEST_ID_RE.test(id));
}

function isValidReconnectSecret(secret) {
    return typeof secret === 'string' && RECONNECT_SECRET_RE.test(secret);
}

function readGuestRoomIdentityMap() {
    let map = {};
    try { map = JSON.parse(localStorage.getItem(GUEST_ROOM_IDENTITY_STORAGE_KEY) || '{}'); }
    catch (e) { map = {}; }
    if (!map || typeof map !== 'object' || Array.isArray(map)) map = {};
    const now = Date.now();
    let changed = false;
    for (const code of Object.keys(map)) {
        const item = map[code];
        if (!item || !isModernGuestParticipantId(item.participantId)
                || !isValidReconnectSecret(item.reconnectSecret)
                || !Number.isFinite(item.savedAt)
                || now - item.savedAt > GUEST_IDENTITY_MAX_AGE_MS) {
            delete map[code];
            changed = true;
        }
    }
    if (changed) {
        try { localStorage.setItem(GUEST_ROOM_IDENTITY_STORAGE_KEY, JSON.stringify(map)); } catch (e) {}
    }
    return map;
}

function rememberGuestRoomCredential(roomCode, credential, displayName = null) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code) || !credential
            || !isModernGuestParticipantId(credential.participantId)
            || !isValidReconnectSecret(credential.reconnectSecret)) return false;
    const map = readGuestRoomIdentityMap();
    const previous = map[code] && map[code].participantId === credential.participantId ? map[code] : null;
    const cleanName = typeof displayName === 'string' ? displayName.trim().slice(0, 40) : '';
    const previousName = previous && typeof previous.name === 'string' ? previous.name.trim().slice(0, 40) : '';
    map[code] = {
        participantId: credential.participantId,
        reconnectSecret: credential.reconnectSecret,
        ...(cleanName || previousName ? { name: cleanName || previousName } : {}),
        savedAt: Date.now()
    };
    try { localStorage.setItem(GUEST_ROOM_IDENTITY_STORAGE_KEY, JSON.stringify(map)); }
    catch (e) { return false; }
    return true;
}

function guestRoomDisplayName(roomCode, participantId) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code) || !isModernGuestParticipantId(participantId)) return '';
    const item = readGuestRoomIdentityMap()[code];
    if (!item || item.participantId !== participantId || typeof item.name !== 'string') return '';
    return item.name.trim().slice(0, 40);
}

function rememberGuestRoomDisplayName(roomCode, participantId, name) {
    const code = String(roomCode || '').trim();
    const cleanName = typeof name === 'string' ? name.trim().slice(0, 40) : '';
    if (!/^\d{4}$/.test(code) || !isModernGuestParticipantId(participantId) || !cleanName) return false;
    const credential = getGuestRoomCredential(code, false);
    if (!credential || credential.participantId !== participantId) return false;
    return rememberGuestRoomCredential(code, credential, cleanName);
}

function getGuestRoomCredential(roomCode, createIfMissing = true) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code)) return null;
    const map = readGuestRoomIdentityMap();
    const existing = map[code];
    if (existing && isModernGuestParticipantId(existing.participantId)
            && isValidReconnectSecret(existing.reconnectSecret)) {
        return { participantId: existing.participantId, reconnectSecret: existing.reconnectSecret };
    }
    if (!createIfMissing) return null;
    const credential = createGuestReconnectCredential();
    rememberGuestRoomCredential(code, credential);
    return credential;
}

function forgetGuestRoomCredential(roomCode) {
    const code = String(roomCode || '').trim();
    const map = readGuestRoomIdentityMap();
    if (map[code]) {
        delete map[code];
        try { localStorage.setItem(GUEST_ROOM_IDENTITY_STORAGE_KEY, JSON.stringify(map)); } catch (e) {}
    }
}

// Identité différée pré-autorisée : contrairement à un invité live, le futur partenaire
// peut arriver alors que le créateur est complètement hors ligne. Dans le modèle actuel,
// cette identité est dérivable du code à 4 chiffres et pré-enregistrée côté serveur par
// l'hôte ; le code suffit donc à la reprise. La map ci-dessous reste seulement comme
// fallback de compatibilité avec un ancien session-storage.js.
const DEFERRED_INVITE_CREDENTIALS_KEY = 'bridgeBidDeferredInviteCredentialsV1';

function readDeferredInviteCredentialMap() {
    let map = {};
    try { map = JSON.parse(localStorage.getItem(DEFERRED_INVITE_CREDENTIALS_KEY) || '{}'); }
    catch (e) { map = {}; }
    if (!map || typeof map !== 'object' || Array.isArray(map)) map = {};
    return map;
}

function getOrCreateDeferredInviteCredential(roomCode) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code)) return null;

    // Nouveau modèle différé : l'identité du futur partenaire est volontairement
    // dérivable du code à 4 chiffres, afin que ce code suffise même si le créateur est
    // complètement hors ligne. Ancien fallback aléatoire conservé uniquement si le
    // helper de session-storage.js n'est pas disponible (compat déploiement partiel).
    if (typeof deferredCodeOnlyParticipantCredential === 'function') {
        const deterministic = deferredCodeOnlyParticipantCredential(code);
        if (deterministic && isModernGuestParticipantId(deterministic.participantId)
                && isValidReconnectSecret(deterministic.reconnectSecret)) {
            return deterministic;
        }
    }

    const map = readDeferredInviteCredentialMap();
    const existing = map[code];
    if (existing && isModernGuestParticipantId(existing.participantId) && isValidReconnectSecret(existing.reconnectSecret)) {
        return { participantId: existing.participantId, reconnectSecret: existing.reconnectSecret };
    }
    const credential = createGuestReconnectCredential();
    map[code] = { ...credential, savedAt: Date.now() };
    try { localStorage.setItem(DEFERRED_INVITE_CREDENTIALS_KEY, JSON.stringify(map)); }
    catch (e) { /* la session live continue ; seul le join différé à froid perdra ce filet */ }
    return credential;
}

async function ensureDeferredInviteCredentialRegistered(roomCode = currentRoomCode) {
    if (myRole !== 'host' || !roomCode) return null;
    if (!SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING) && !deferredRoomMode) return null;
    const credential = getOrCreateDeferredInviteCredential(roomCode);
    if (!credential) return null;

    // Le host doit connaître cette même identité si le partenaire arrive pendant qu'il
    // est encore en ligne en P2P.
    registerHostGuestReconnectSecret(credential.participantId, credential.reconnectSecret);

    // Nouveau mode produit : en différé, le code à 4 chiffres suffit. session-storage.js
    // pré-enregistre cette credential puis remplace seulement la capacité DE LECTURE par
    // une valeur dérivable du code ; la clé d'écriture complète de l'hôte reste aléatoire.
    if (typeof enableDeferredCodeOnlyRoomAccess === 'function') {
        try {
            const ok = await enableDeferredCodeOnlyRoomAccess(roomCode);
            if (!ok) pushDebugLog('Préparation du mode différé par code seul impossible pour le moment.');
            return ok ? credential : null;
        } catch (e) {
            pushDebugLog('Préparation du mode différé par code seul impossible : ' + ((e && e.message) || e));
            return null;
        }
    }

    // Compat avec une version de session-storage.js plus ancienne.
    if (typeof registerSessionParticipantCredential === 'function') {
        try {
            const ok = await registerSessionParticipantCredential(roomCode, credential.participantId, credential.reconnectSecret);
            if (!ok) return null;
        } catch (e) {
            pushDebugLog('Pré-autorisation du partenaire différé impossible : ' + ((e && e.message) || e));
            return null;
        }
    }
    return credential;
}

// Table privée du host courant. Elle n'est jamais placée dans les messages P2P généraux
// ni dans buildCloudStatePayload(). Elle survit à un reload du même host via localStorage.
let guestReconnectSecretsByParticipantId = {};

function readHostGuestReconnectSecrets(roomCode) {
    const code = String(roomCode || '').trim();
    let all = {};
    try { all = JSON.parse(localStorage.getItem(HOST_GUEST_RECONNECT_STORAGE_KEY) || '{}'); }
    catch (e) { all = {}; }
    if (!all || typeof all !== 'object' || Array.isArray(all)) all = {};
    const item = all[code];
    const src = item && item.secrets && typeof item.secrets === 'object' && !Array.isArray(item.secrets)
        ? item.secrets : {};
    const clean = {};
    for (const [id, secret] of Object.entries(src)) {
        if (isModernGuestParticipantId(id) && isValidReconnectSecret(secret)) clean[id] = secret;
    }
    return clean;
}

function persistHostGuestReconnectSecrets(roomCode = currentRoomCode) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code)) return;
    let all = {};
    try { all = JSON.parse(localStorage.getItem(HOST_GUEST_RECONNECT_STORAGE_KEY) || '{}'); }
    catch (e) { all = {}; }
    if (!all || typeof all !== 'object' || Array.isArray(all)) all = {};
    all[code] = { secrets: { ...guestReconnectSecretsByParticipantId }, savedAt: Date.now() };
    const entries = Object.entries(all)
        .filter(([, value]) => value && Number.isFinite(value.savedAt)
            && Date.now() - value.savedAt <= GUEST_IDENTITY_MAX_AGE_MS)
        .sort((a, b) => (b[1].savedAt || 0) - (a[1].savedAt || 0))
        .slice(0, 16);
    all = Object.fromEntries(entries);
    try { localStorage.setItem(HOST_GUEST_RECONNECT_STORAGE_KEY, JSON.stringify(all)); } catch (e) {}
}

function loadHostGuestReconnectSecrets(roomCode) {
    guestReconnectSecretsByParticipantId = readHostGuestReconnectSecrets(roomCode);
}

function registerHostGuestReconnectSecret(participantId, reconnectSecret) {
    if (!isModernGuestParticipantId(participantId) || !isValidReconnectSecret(reconnectSecret)) return false;
    guestReconnectSecretsByParticipantId[participantId] = reconnectSecret;
    persistHostGuestReconnectSecrets();
    return true;
}

function guestConnectionMetadata(roomCode, nickname, credentialOverride = null) {
    const credential = credentialOverride || getGuestRoomCredential(roomCode, true);
    if (!credential) throw new Error('Identité invitée indisponible.');
    if (credentialOverride) rememberGuestRoomCredential(roomCode, credentialOverride, nickname);
    else rememberGuestRoomCredential(roomCode, credential, nickname);
    return {
        participantId: credential.participantId,
        reconnectSecret: credential.reconnectSecret,
        nickname: nickname,
        avatarColor: isAllowedAvatarColor(savedAvatarColor) ? savedAvatarColor : null
    };
}

let mySeats = null;         // sièges contrôlés par ce joueur pendant la partie
let autoPassSeats = [];     // sièges non assignés (robot "passe") — décidé par l'hôte au lancement
// Marqueur sémantique du mode différé. Il est figé au lancement lorsqu'au moins un siège
// vaut SEAT_PENDING, puis persisté dans les snapshots/messages. Ne pas le déduire du type
// de connexion : depuis l'architecture P2P + relais serveur, le créateur d'une salle
// différée peut conserver une vraie BridgePeerConnection tout en restant en mode différé.
let deferredRoomMode = false;
// Mode d'enchère des robots (voir échange avec Guillaume) : 'smart' = système appris (le
// moteur habituel, decideRobotCall), 'passOnly' = passe en boucle sans réfléchir, quel que
// soit le jeu. Configurable UNIQUEMENT dans le salon, avant de lancer la session (voir
// index.html) — pas modifiable une fois la partie démarrée. Décision purement locale à
// l'hôte : seul lui déclenche les décisions des robots (voir maybeRobotBid, gardé par
// `myRole !== 'host'`), donc pas besoin de la diffuser aux invités, qui n'en ont jamais
// l'usage. Persisté (voir échange avec Guillaume) comme les autres préférences locales —
// voir loadBoolPref/saveBoolPref, la case du salon reprend cette valeur au chargement
// (voir enterLobbyScreen).
let robotBiddingMode = loadBoolPref('bridgeBidRobotPassOnly', false) ? 'passOnly' : 'smart';
// Variante système optionnelle : les robots actifs jouent une ouverture de 1SA faible
// (12-14H au lieu de 15-17H). Seule la branche issue d'une vraie ouverture de 1SA est
// adaptée ; toutes les autres enchères continuent d'être décidées par PONS inchangé.
let robotShortNtMode = loadBoolPref('bridgeBidRobotShortNT', false);

// Plus de statut kibbitz suivi séparément (source de bug : oublié pour un joueur qui
// rejoint après le lancement de la partie, resté "spectateur" sans les mains) — un
// kibbitz, c'est simplement quiconque n'occupe aucun siège, dérivé à la demande plutôt
// que traqué en parallèle de mySeats.
function isKibbitz() {
    return !mySeats || mySeats.length === 0;
}

// Privilèges d'hôte réels : ils appartiennent au détenteur ACTUEL du rôle d'hôte,
// jamais à un ancien hôte simplement parce que son jeton est encore roomCreatorToken.
// C'est particulièrement important après un transfert manuel : l'ancien créateur revient
// comme invité avec son jeton historique ; sans le test myRole==='host', il conservait
// localement les boutons All pass / Reset / Rotation / Réorganisation / Voir les 4 mains
// et pouvait faire diverger son écran de celui du nouvel hôte.
//
// Le second terme reste nécessaire pour le mode différé : le creator de la salle courante
// peut y être contrôleur technique avec son vrai jeton plutôt qu'avec l'identifiant
// littéral 'host'. Un autre participant ayant repris la salle en différé ne doit pas
// recevoir ces privilèges d'organisation.
function isTrueOriginalHost() {
    return myRole === 'host' && (myParticipantId === 'host' || myParticipantId === roomCreatorToken);
}

// ===== Préférences d'affichage des mains (locales, persistées, indépendantes du réseau) =====
//
// Purement cosmétique et propre à chaque appareil (comme le jeton de reconnexion) : pas
// besoin de les synchroniser entre joueurs, chacun choisit sa propre présentation.

function loadBoolPref(key, fallback) {
    try {
        const v = localStorage.getItem(key);
        return v === null ? fallback : v === 'true';
    } catch (e) {
        return fallback;
    }
}

function saveBoolPref(key, value) {
    try { localStorage.setItem(key, value ? 'true' : 'false'); } catch (e) { /* navigation privée stricte, tant pis */ }
}

// Même principe que loadBoolPref/saveBoolPref, pour une valeur texte (le pseudo — voir
// savedNickname plus bas) plutôt qu'un booléen.
function loadStringPref(key, fallback) {
    try {
        const v = localStorage.getItem(key);
        return v === null || v === '' ? fallback : v;
    } catch (e) {
        return fallback;
    }
}

function saveStringPref(key, value) {
    try {
        if (value) localStorage.setItem(key, value);
        else localStorage.removeItem(key);
    } catch (e) { /* navigation privée stricte, tant pis */ }
}

// Pseudo choisi par l'utilisateur, mémorisé sur cet appareil comme les autres préférences
// d'affichage — propre à l'appareil, pas au jeton de reconnexion (qui identifie la place
// dans UNE partie précise, alors que le pseudo doit survivre d'une partie à l'autre).
// null si jamais personnalisé : on retombe alors sur defaultParticipantName comme avant.
let savedNickname = loadStringPref('bridgeBidNickname', null);

// Voir échange avec Guillaume (session du 8 août — "je voudrais que sa couleur d'avatar
// [soit persistante]... qu'il récupère automatiquement la dernière couleur utilisée à
// chaque nouvelle connexion") : même principe exact que savedNickname ci-dessus — propre
// à l'appareil, survit d'une partie à l'autre. null si jamais choisie : on retombe alors
// sur la couleur dérivée par hachage (avatarColorForId) comme avant.
let savedAvatarColor = loadStringPref('bridgeBidAvatarColor', null);

let useFrenchRanks = loadBoolPref('bridgeBidFrenchRanks', false); // R/D/V/X au lieu de K/Q/J/T
let showHcp = loadBoolPref('bridgeBidShowHcp', false);            // affiche le compte de points d'honneur par main
let showKr = loadBoolPref('bridgeBidShowKr', false);              // affiche l'évaluation Kaplan-Rubens par main
let showHandStrip = loadBoolPref('bridgeBidShowHandStrip', false);      // main du joueur sur une seule ligne (♠… ♥… ♦… ♣…)
let showLedgerNames = loadBoolPref('bridgeBidShowLedgerNames', false); // noms des joueurs au lieu de N/E/S/O dans le tableau d'enchères
// (Hôte uniquement) Voir les 4 mains à tout moment pendant la partie, même en pleine
// enchère — voir uiToggleHostSeeAllHands. Jamais envoyé aux autres joueurs.
let hostSeeAllHands = loadBoolPref('bridgeBidHostSeeAllHands', false);
// Pendant une enchère avec les 4 mains visibles et un PAR disponible : false = enchères, true = PAR.
let showParDuringAuction = false;
let allPassInProgress = false;

const FRENCH_RANK_LETTER = { K: 'R', Q: 'D', J: 'V', T: 'X' };

// Convertit une chaîne de rangs (ex: "AKQT98") selon la préférence de notation en cours.
function formatRanksForDisplay(ranks) {
    if (!ranks) return '';
    if (!useFrenchRanks) return ranks;
    return ranks.split('').map(c => FRENCH_RANK_LETTER[c] || c).join('');
}

// ===== Évaluateur Kaplan-Rubens (CCCC — "Complex Computer Count") =====
//
// Port fidèle de la fonction cccc() du code de référence de Jeff Goldsmith
// (https://www.jeff-goldsmith.com/knrsource.c), qui implémente l'algorithme d'Edgar
// Kaplan et Jeff Rubens tel que publié dans Bridge World, octobre 1982, pp. 21-23.
// N'implémente QUE le calcul Kaplan-Rubens d'origine ("cccc"), pas la variante de Danny
// Kleinman ("dkcccc") qui figure dans les mêmes fichiers.
//
// Une seule divergence connue entre les sources de référence elles-mêmes (voir plus bas,
// couleurs de 7 cartes) : on suit alors knrsource.c, la source d'origine désignée.

const KR_SUITS = ['S', 'H', 'D', 'C'];

function krHas(hand, suit, rank) {
    return hand[suit].includes(rank);
}

function krCountHeld(hand, suit, ranks) {
    let n = 0;
    for (const r of ranks) if (krHas(hand, suit, r)) n++;
    return n;
}

function computeKaplanRubens(hand) {
    const len = {};
    KR_SUITS.forEach(s => { len[s] = hand[s].length; });

    // 321 count pour les As, Rois, Dames (honneurs "protégés" au sens large)
    let pakq = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'A')) pakq += 3;
        if (krHas(hand, s, 'K')) pakq += 2;
        if (krHas(hand, s, 'Q')) pakq += 1;
    });

    // Points de longueur : 4321 count pondéré par la longueur de la couleur
    let p2 = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'A')) p2 += len[s] * 4;
        if (krHas(hand, s, 'K')) p2 += len[s] * 3;
        if (krHas(hand, s, 'Q')) p2 += len[s] * 2;
        if (krHas(hand, s, 'J')) p2 += len[s] * 1;
    });

    // Bonus pour longues couleurs sans les honneurs bas (Dame/Valet) qui y seraient
    // de toute façon peu utiles.
    KR_SUITS.forEach(s => {
        const l = len[s];
        const hasQ = krHas(hand, s, 'Q');
        const hasJ = krHas(hand, s, 'J');
        if (l === 7) {
            // Le texte original ("1 point si Dame ou Valet manquant") est ambigu, et les
            // DEUX sources de référence de Jeff Goldsmith (C et Perl) le traitent
            // différemment l'une de l'autre pour ce cas précis : knrsource.c déclenche le
            // bonus dès qu'IL MANQUE AU MOINS L'UN des deux honneurs, alors que sa version
            // Perl exige qu'ils manquent TOUS LES DEUX (avec une note de l'auteur disant
            // lui-même ne pas être sûr de l'intention d'origine). On suit ici knrsource.c,
            // la source désignée comme référence.
            if (!hasQ || !hasJ) p2 += 7;
        }
        if (l === 8) {
            if (!hasQ) p2 += 16;
            else if (!hasJ) p2 += 8;
        }
        if (l > 8) {
            if (!hasQ) p2 += 2 * l;
            if (!hasJ) p2 += l;
        }
    });

    // Honneurs bas selon la longueur de la couleur (Dix, Neuf)
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (krHas(hand, s, 'T')) {
            if (l > 6) {
                p2 += 0.5 * l;
            } else {
                const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
                if (higher >= 2 || krHas(hand, s, 'J')) p2 += l;
                else p2 += 0.5 * l;
            }
        }
        if (krHas(hand, s, '9') && l <= 6) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
            if (higher >= 2 || krHas(hand, s, 'T') || krHas(hand, s, '8')) p2 += 0.5 * l;
        }
    });

    // Points de brièveté (chicane/singleton/doubleton) — on ne compte pas le 1er doubleton
    let pdist = 0;
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (l === 0) pdist += 3;
        else if (l === 1) pdist += 2;
        else if (l === 2) pdist += 1;
    });
    if (pdist !== 0) pdist -= 1;

    // Rois secs, Dames courtes ou longues sans As/Roi d'appui
    let p = pakq;
    KR_SUITS.forEach(s => {
        const l = len[s];
        if (krHas(hand, s, 'K') && l === 1) p -= 1.5;
        if (krHas(hand, s, 'Q') && l < 3) {
            p -= 1;
            if (krHas(hand, s, 'A') || krHas(hand, s, 'K')) p += 0.5;
            else if (l === 2) p += 0.25;
        }
        if (krHas(hand, s, 'Q') && l >= 3) {
            if (!krHas(hand, s, 'A') && !krHas(hand, s, 'K')) p -= 0.25;
        }
    });

    // Honneurs bas (Valet, Dix) soutenus par des honneurs supérieurs
    let p3 = 0;
    KR_SUITS.forEach(s => {
        if (krHas(hand, s, 'J')) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q']);
            if (higher === 2) p3 += 0.5;
            if (higher === 1) p3 += 0.25;
        }
        if (krHas(hand, s, 'T')) {
            const higher = krCountHeld(hand, s, ['A', 'K', 'Q', 'J']);
            if (higher === 2) p3 += 0.25;
            if (higher === 1 && krHas(hand, s, '9')) p3 += 0.25;
        }
    });

    // Pénalité pour la répartition 4-3-3-3
    const sortedLens = KR_SUITS.map(s => len[s]).sort((a, b) => b - a);
    const d = sortedLens[3] === 3 ? 0.5 : 0;

    return p + p2 / 10 + p3 + pdist - d;
}

// Sur mobile, une option d'affichage des mains ne doit pas déplacer brutalement la zone
// d'enchère si celle-ci est justement visible. On réutilise volontairement le même ancrage
// que pour les changements de hauteur du relevé : il ne s'active que pendant l'enchère,
// hors vue PAR, et seulement si la boîte d'enchères est réellement dans le viewport.
// Si l'utilisateur est remonté regarder les mains, aucune prise de contrôle du scroll.
function captureHandDisplayOptionViewportAnchor() {
    return captureMobileLedgerViewportAnchor();
}

function restoreHandDisplayOptionViewportAnchor(anchor) {
    scheduleMobileLedgerViewportRestore(anchor);
}

// Pour les rares corrections qui doivent aussi fonctionner lorsque la vue PAR est active,
// on ne réutilise pas captureMobileLedgerViewportAnchor (qui l'exclut volontairement).
// Ce helper reste strictement mobile et n'agit que si la cible est réellement visible.
function captureVisibleMobileViewportAnchor(element) {
    if (window.innerWidth > 760 || !deals || !element) return null;
    const rect = element.getBoundingClientRect();
    const viewportHeight = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    if (rect.bottom <= 0 || rect.top >= viewportHeight) return null;
    return { element, top: rect.top };
}

function restoreVisibleMobileViewportAnchor(anchor) {
    if (!anchor || !anchor.element) return;
    requestAnimationFrame(() => {
        if (!anchor.element.isConnected || window.innerWidth > 760 || !deals) return;
        const delta = anchor.element.getBoundingClientRect().top - anchor.top;
        if (Math.abs(delta) > 0.5) window.scrollBy(0, delta);
    });
}

function isAuctionParViewActive() {
    const stack = document.getElementById('auctionViewStack');
    return !!(stack && stack.classList.contains('show-par'));
}


// Même fondu 325 ms que les autres transitions de vue, mais appliqué seulement aux sous-
// éléments textuels qui changent réellement : rangs de cartes, badges HCP/K&R, et noms.
// On évite ainsi de faire clignoter tout le rectangle de main quand seul un petit texte
// apparaît/disparaît.
function visibleHandOptionContainers() {
    const myHandsEl = document.getElementById('myHandsContainer');
    const allHandsEl = document.getElementById('allHandsDiagram');
    const containers = [];

    if (myHandsEl && getComputedStyle(myHandsEl).display !== 'none') containers.push(myHandsEl);
    if (allHandsEl && getComputedStyle(allHandsEl).display !== 'none') containers.push(allHandsEl);

    return containers;
}

function collectVisibleOptionTargets(selectors, roots = visibleHandOptionContainers()) {
    const items = [];
    roots.forEach(root => {
        if (!root) return;
        root.querySelectorAll(selectors).forEach(el => items.push(el));
    });
    return items;
}

function fadeVisibleHandRankTargets() {
    replayQuickFadeGroup(collectVisibleOptionTargets('.cards'));
}

function fadeVisibleHandBadgeTargets(selector) {
    replayQuickFadeGroup(collectVisibleOptionTargets(selector));
}

function fadeVisibleLedgerNameTargets() {
    const targets = [];
    const header = document.getElementById('auctionLedgerHeader');
    const table = header ? header.closest('table') : null;
    if (header && table && getComputedStyle(table).display !== 'none') {
        header.querySelectorAll('.ledger-seat-label').forEach(el => targets.push(el));
    }
    collectVisibleOptionTargets('.hand-card-title-name', [document.getElementById('allHandsDiagram')]).forEach(el => targets.push(el));
    replayQuickFadeGroup(targets);
}

function uiToggleFrenchRanks() {
    const mobileBiddingAnchor = captureHandDisplayOptionViewportAnchor();
    useFrenchRanks = !useFrenchRanks;
    saveBoolPref('bridgeBidFrenchRanks', useFrenchRanks);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        // Voir échange avec Guillaume : le diagramme peut déjà être affiché avant la fin
        // de l'enchère (bascule manuelle de l'hôte, ou kibitz — voir checkAuctionEnd) —
        // sans ce même critère ici, ces boutons semblaient "sans effet" dans ce cas,
        // puisqu'ils ne rafraîchissaient que myHandsContainer, invisible à ce moment-là.
        renderAllHandsDiagram(); // toujours, même masqué (voir échange avec Guillaume) : garde la hauteur réservée synchronisée quoi qu'il arrive
        fadeVisibleHandRankTargets();
        restoreHandDisplayOptionViewportAnchor(mobileBiddingAnchor);
    }
}

function uiToggleShowHcp() {
    const mobileBiddingAnchor = captureHandDisplayOptionViewportAnchor();
    showHcp = !showHcp;
    saveBoolPref('bridgeBidShowHcp', showHcp);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        renderAllHandsDiagram(); // toujours, même masqué (voir échange avec Guillaume) : garde la hauteur réservée synchronisée quoi qu'il arrive
        fadeVisibleHandBadgeTargets('.hand-card-badges .hand-hcp-badge:first-child');
        restoreHandDisplayOptionViewportAnchor(mobileBiddingAnchor);
    }
}

function uiToggleShowKr() {
    const mobileBiddingAnchor = captureHandDisplayOptionViewportAnchor();
    showKr = !showKr;
    saveBoolPref('bridgeBidShowKr', showKr);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        renderAllHandsDiagram(); // toujours, même masqué (voir échange avec Guillaume) : garde la hauteur réservée synchronisée quoi qu'il arrive
        fadeVisibleHandBadgeTargets('.hand-card-badges .hand-hcp-badge:nth-child(2)');
        restoreHandDisplayOptionViewportAnchor(mobileBiddingAnchor);
    }
}

// Option « Affichage bandeau » : purement locale et persistée. Elle ne change que la
// présentation de la/les main(s) réellement contrôlée(s) par ce joueur ; le diagramme
// « Voir les 4 mains » conserve volontairement sa présentation 4 lignes.
function uiToggleHandStrip() {
    const mobileBiddingAnchor = captureHandDisplayOptionViewportAnchor();
    showHandStrip = !showHandStrip;
    saveBoolPref('bridgeBidShowHandStrip', showHandStrip);
    renderHandDisplayOptionButtons();
    if (deals) {
        renderMyHands();
        restoreHandDisplayOptionViewportAnchor(mobileBiddingAnchor);
    }
}

function uiToggleLedgerNames() {
    const mobileBiddingAnchor = captureHandDisplayOptionViewportAnchor();
    showLedgerNames = !showLedgerNames;
    saveBoolPref('bridgeBidShowLedgerNames', showLedgerNames);
    const btn = document.getElementById('ledgerNamesToggleBtn');
    if (btn) {
        btn.classList.toggle('is-active', showLedgerNames);
        btn.setAttribute('aria-pressed', showLedgerNames ? 'true' : 'false');
    }
    if (deals) {
        renderAuctionLedger();
        // Voir échange avec Guillaume : le diagramme des 4 mains (buildAllHandsHtml)
        // utilise désormais la même préférence (ledgerSeatLabel) que l'en-tête du tableau
        // d'enchères — sans ce re-rendu, il fallait attendre un tour d'enchère ou un autre
        // changement d'option pour que la bascule s'y reflète.
        renderAllHandsDiagram();
        fadeVisibleLedgerNameTargets();
        restoreHandDisplayOptionViewportAnchor(mobileBiddingAnchor);
    }
}

// Réservé à l'hôte QUI N'OCCUPE AUCUN SIÈGE (mode "maître du jeu" à 3, voir isKibbitz) :
// révèle les 4 mains à tout moment pendant la partie, même en pleine enchère (utile pour
// vérifier une donne, aider un débutant en direct, etc.). Purement local — jamais envoyé
// aux autres joueurs, qui ne voient toujours que ce qu'ils sont censés voir.
//
// Voir échange avec Guillaume : PRIVILÈGE DU VRAI HÔTE (voir isTrueOriginalHost), pas
// seulement d'un hôte spectateur — un hôte qui joue lui-même une main (ex. donner un
// cours) doit pouvoir l'activer pour tout voir. Mais "myRole==='host'" seul ne suffit
// pas non plus (voir isTrueOriginalHost) : depuis la reprise cloud (uiResumeFromCloud),
// celui qui reprend une salle différée abandonnée devient 'host' techniquement tout en
// étant un joueur ordinaire assis à un vrai siège — lui laisser ce privilège reviendrait
// à le laisser tricher sur sa propre main.
function uiToggleHostSeeAllHands() {
    if (!isTrueOriginalHost()) return;
    const parViewActive = isAuctionParViewActive();
    const mobileViewportAnchor = parViewActive
        ? captureVisibleMobileViewportAnchor(document.querySelector('.auction-panel'))
        : captureMobileLedgerViewportAnchor();
    hostSeeAllHands = !hostSeeAllHands;
    saveBoolPref('bridgeBidHostSeeAllHands', hostSeeAllHands);
    renderHandDisplayOptionButtons();
    if (deals) checkAuctionEnd();
    if (parViewActive) restoreVisibleMobileViewportAnchor(mobileViewportAnchor);
    else scheduleMobileLedgerViewportRestore(mobileViewportAnchor);
}

function renderHandDisplayOptionButtons() {
    const frBtn = document.getElementById('frenchRanksToggleBtn');
    if (frBtn) {
        frBtn.classList.toggle('is-active', useFrenchRanks);
        frBtn.setAttribute('aria-pressed', useFrenchRanks ? 'true' : 'false');
    }

    const hcpBtn = document.getElementById('hcpToggleBtn');
    if (hcpBtn) {
        hcpBtn.classList.toggle('is-active', showHcp);
        hcpBtn.setAttribute('aria-pressed', showHcp ? 'true' : 'false');
    }

    const krBtn = document.getElementById('krToggleBtn');
    if (krBtn) {
        krBtn.classList.toggle('is-active', showKr);
        krBtn.setAttribute('aria-pressed', showKr ? 'true' : 'false');
    }

    const handStripBtn = document.getElementById('handStripToggleBtn');
    if (handStripBtn) {
        handStripBtn.classList.toggle('is-active', showHandStrip);
        handStripBtn.setAttribute('aria-pressed', showHandStrip ? 'true' : 'false');
    }

    const hostSeeAllBtn = document.getElementById('hostSeeAllHandsBtn');
    if (hostSeeAllBtn) {
        // Voir échange avec Guillaume : ce bouton est un PRIVILÈGE DU VRAI HÔTE (voir
        // isTrueOriginalHost), pas seulement d'un hôte spectateur — un kibbitz voit déjà
        // les 4 mains en permanence par défaut, il n'a jamais besoin de ce bouton. Un
        // hôte qui joue lui-même une main doit pouvoir l'activer (donner un cours) — mais
        // "myRole==='host'" seul est TROP LARGE en mode différé (voir
        // isTrueOriginalHost) : n'importe quel joueur reprenant une salle abandonnée
        // devient 'host' techniquement, sans être le vrai créateur/organisateur.
        hostSeeAllBtn.style.display = isTrueOriginalHost() ? '' : 'none';
        hostSeeAllBtn.classList.toggle('is-active', hostSeeAllHands);
        hostSeeAllBtn.setAttribute('aria-pressed', hostSeeAllHands ? 'true' : 'false');
    }
}
let deals = null;           // tableau de donnes parsées
let boardIndex = 0;
let auctionHistory = [];    // historique de la donne en cours : [{seat, call}, ...]

// (Hôte) Résultat du fichier de donnes déjà lu et parsé au moment où il a été choisi (voir
// uiHandleDealFileChosen), pour afficher tout de suite une éventuelle erreur — pendant que
// l'hôte compose encore la table, PAS au moment de cliquer sur "Commencer la partie",
// puisqu'à cet instant l'écran du salon (et donc le message) disparaît immédiatement avec
// le passage à l'écran de jeu.
let pendingParsedDeals = null;
// Identifie la source dont pendingParsedDeals est le résultat, pour savoir si le cache
// est encore valable sans avoir à relire/re-fetch : soit l'objet File choisi via l'input
// upload, soit une chaîne 'library:nomDeFichier' pour une donne piochée dans la
// bibliothèque du club (voir uiHandleDealLibraryChosen) — comparée uniquement par
// égalité (===), jamais utilisée comme un vrai File au-delà de ce contrôle.
let pendingParsedSource = null;

// Ordre effectivement utilisé pour la partie : soit pendingParsedDeals tel quel (ordre du
// fichier), soit une copie mélangée, selon la case "Ordre aléatoire des donnes" (voir
// uiToggleRandomizeDeals). Calculé une seule fois par chargement de fichier / bascule de
// la case, et réutilisé à la fois par l'aperçu et par le lancement de la partie, pour que
// l'un corresponde toujours exactement à l'autre. Les numéros de donne d'origine (deal.board)
// sont conservés tels quels dans le fichier — seul l'ordre de passage est mélangé.
let pendingOrderedDeals = null;

// Mélange de Fisher-Yates (Math.random() suffit ici : besoin d'aléatoire simple pour
// varier l'ordre d'entraînement, pas de garanties cryptographiques).
function shuffleDealsArray(arr) {
    const shuffled = arr.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// ===== Génération de donnes aléatoires (voir échange avec Guillaume) =====
//
// Même algorithme que le générateur autonome (gen/generator.js, dont les fichiers ont été
// fournis pour cette fonctionnalité) : mélange Fisher-Yates d'un jeu de 52 cartes, une
// carte sur quatre à chaque position dans l'ordre N/E/S/O, tri par rang au sein de chaque
// couleur. Cycle donneur/vulnérabilité standard sur 16 donnes, identique à BRIDGE_CYCLE
// dans le générateur.
const RANDOM_DEAL_CARD_VALUES = ['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2'];
const RANDOM_DEAL_BRIDGE_CYCLE = [
    { dealer: 'N', vulnerable: 'None' }, { dealer: 'E', vulnerable: 'NS' },
    { dealer: 'S', vulnerable: 'EW' }, { dealer: 'W', vulnerable: 'Both' },
    { dealer: 'N', vulnerable: 'NS' }, { dealer: 'E', vulnerable: 'EW' },
    { dealer: 'S', vulnerable: 'Both' }, { dealer: 'W', vulnerable: 'None' },
    { dealer: 'N', vulnerable: 'EW' }, { dealer: 'E', vulnerable: 'Both' },
    { dealer: 'S', vulnerable: 'None' }, { dealer: 'W', vulnerable: 'NS' },
    { dealer: 'N', vulnerable: 'Both' }, { dealer: 'E', vulnerable: 'None' },
    { dealer: 'S', vulnerable: 'NS' }, { dealer: 'W', vulnerable: 'EW' }
];
// Nombre de nouvelles tentatives de mélange max par donne avant d'abandonner la contrainte
// pour celle-ci (voir dealSatisfiesHumanLineConstraint) — un filet de sécurité purement
// théorique : avec la contrainte demandée (12H+ chez au moins un des deux, dans une ligne
// à 2 humains), la probabilité d'échouer autant de fois de suite est astronomiquement
// faible, mais on évite quand même une boucle infinie dans l'absolu.
const RANDOM_DEAL_MAX_RETRIES = 500;

function shuffledDeck() {
    const deck = [];
    for (const suit of ['S', 'H', 'D', 'C']) {
        for (const rank of RANDOM_DEAL_CARD_VALUES) deck.push(suit + rank);
    }
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

// Distribue un jeu mélangé en 4 mains (une carte sur 4 à chaque position, dans l'ordre
// N/E/S/O), triées par rang au sein de chaque couleur — même logique que le générateur.
function dealFromDeck(deck) {
    const hands = { N: emptyHandBySuit(), E: emptyHandBySuit(), S: emptyHandBySuit(), W: emptyHandBySuit() };
    const positions = ['N', 'E', 'S', 'W'];
    deck.forEach((card, i) => {
        const suit = card[0], rank = card[1];
        hands[positions[i % 4]][suit] += rank;
    });
    for (const pos of positions) {
        for (const suit of ['S', 'H', 'D', 'C']) {
            hands[pos][suit] = hands[pos][suit]
                .split('')
                .sort((a, b) => RANDOM_DEAL_CARD_VALUES.indexOf(a) - RANDOM_DEAL_CARD_VALUES.indexOf(b))
                .join('');
        }
    }
    return hands;
}

function emptyHandBySuit() {
    return { S: '', H: '', D: '', C: '' };
}

// Contrainte demandée par Guillaume : dans toute ligne (NS ou EO) occupée par 2 humains
// (pas de robot), au moins l'un des deux doit avoir 12H+. Une ligne avec un seul humain
// (partenaire robot) ou aucun n'a pas de contrainte — rien à vérifier pour elle.
function dealSatisfiesHumanLineConstraint(hands, seatAssignment) {
    const lines = [['N', 'S'], ['E', 'W']];
    for (const [seatA, seatB] of lines) {
        const bothHuman = !!seatAssignment[seatA] && !!seatAssignment[seatB];
        if (!bothHuman) continue;
        const hcpA = computeHandHcp(hands[seatA]);
        const hcpB = computeHandHcp(hands[seatB]);
        if (hcpA < 12 && hcpB < 12) return false;
    }
    return true;
}

// Contraintes optionnelles demandées par Guillaume pour la génération aléatoire :
// fourchette de points H par siège, fourchette de points H combinés par ligne (NS/EO), et
// longueur minimale dans une couleur par siège. `constraints` a la forme :
// { seats: { N: {hcpMin, hcpMax, suit, suitMinLength}, E: {...}, S: {...}, W: {...} },
//   lines: { NS: {hcpMin, hcpMax}, EW: {hcpMin, hcpMax} } }
// N'importe quel champ omis/null n'est simplement pas vérifié — un objet vide ou absent
// équivaut à "aucune contrainte". Toujours vérifiée EN PLUS de
// dealSatisfiesHumanLineConstraint (voir generateRandomDeal), jamais à sa place.
function dealSatisfiesCustomConstraints(hands, constraints) {
    if (!constraints) return true;

    if (constraints.seats) {
        for (const seat of ['N', 'E', 'S', 'W']) {
            const c = constraints.seats[seat];
            if (!c) continue;
            const hcp = computeHandHcp(hands[seat]);
            if (c.hcpMin != null && hcp < c.hcpMin) return false;
            if (c.hcpMax != null && hcp > c.hcpMax) return false;
            if (c.suit && c.suitMinLength != null && hands[seat][c.suit].length < c.suitMinLength) return false;
        }
    }

    if (constraints.lines) {
        const lineSeats = { NS: ['N', 'S'], EW: ['E', 'W'] };
        for (const line of ['NS', 'EW']) {
            const c = constraints.lines[line];
            if (!c) continue;
            const [seatA, seatB] = lineSeats[line];
            const combined = computeHandHcp(hands[seatA]) + computeHandHcp(hands[seatB]);
            if (c.hcpMin != null && combined < c.hcpMin) return false;
            if (c.hcpMax != null && combined > c.hcpMax) return false;
        }
    }

    return true;
}

// Génère une seule donne (numéro de board donné), en retentant tant que les contraintes
// ne sont pas respectées (la fixe + les optionnelles éventuelles). `seatAssignment` figé au
// moment de la génération (voir uiGenerateRandomDeals) : un changement de composition de
// table après coup ne redéclenche pas une nouvelle génération, comme pour n'importe quel
// autre outil de génération. Si RANDOM_DEAL_MAX_RETRIES est atteint sans satisfaire les
// contraintes optionnelles (des fourchettes trop serrées simultanément, par exemple), la
// dernière donne tentée est renvoyée telle quelle plutôt que de bloquer indéfiniment —
// signalé à l'appelant via `constraintsUnmet` pour qu'il prévienne l'utilisateur.
function generateRandomDeal(boardNumber, seatAssignment, constraints) {
    let hands;
    let attempts = 0;
    let satisfied = false;
    do {
        hands = dealFromDeck(shuffledDeck());
        attempts++;
        satisfied = dealSatisfiesHumanLineConstraint(hands, seatAssignment)
            && dealSatisfiesCustomConstraints(hands, constraints);
    } while (!satisfied && attempts < RANDOM_DEAL_MAX_RETRIES);

    const cycle = RANDOM_DEAL_BRIDGE_CYCLE[(boardNumber - 1) % 16];
    return {
        board: boardNumber,
        dealer: cycle.dealer,
        vulnerable: cycle.vulnerable,
        hands,
        par: null,   // pas de résumé PAR préformaté (spécifique à l'import PBN) ; le
                     // double mort complet (ddTable) suffit à afficher le PAR en fin de
                     // donne, voir kickOffBackgroundDD et renderDDTable existant.
        ddTable: null,
        constraintsUnmet: !satisfied
    };
}

function generateRandomDeals(count, seatAssignment, constraints) {
    const deals = [];
    for (let i = 1; i <= count; i++) {
        deals.push(generateRandomDeal(i, seatAssignment, constraints));
    }
    return deals;
}

// Bouton "🎲 Générer" du salon : génère `count` donnes aléatoires et les branche sur
// EXACTEMENT le même circuit que l'import d'un fichier ou de la bibliothèque
// (pendingParsedSource/pendingParsedDeals/pendingOrderedDeals, voir uiStartGameAsHost) —
// aucune des deux ne connaît de traitement spécial, "random" n'est qu'une source de plus.
// Miroir automatique entre les fourchettes de ligne (voir échange avec Guillaume) : NS et
// EO se partagent TOUJOURS les 40 points H du jeu entier, donc "NS a au moins 24" équivaut
// mathématiquement à "EO a au plus 16" — remplir l'un remplit donc automatiquement l'autre
// (min d'une ligne <-> max de l'autre). Ne se déclenche que sur une vraie saisie
// utilisateur (oninput) : modifier .value par JS ne redéclenche pas cet événement, donc
// aucun risque de boucle infinie entre les deux champs.
function uiMirrorLineHcpConstraint(sourceId) {
    const mirrorOf = {
        'rdc-NS-hcpMin': 'rdc-EW-hcpMax',
        'rdc-NS-hcpMax': 'rdc-EW-hcpMin',
        'rdc-EW-hcpMin': 'rdc-NS-hcpMax',
        'rdc-EW-hcpMax': 'rdc-NS-hcpMin'
    };
    const targetId = mirrorOf[sourceId];
    const sourceEl = document.getElementById(sourceId);
    const targetEl = document.getElementById(targetId);
    if (!sourceEl || !targetEl) return;
    if (sourceEl.value === '') {
        targetEl.value = '';
        return;
    }
    const n = parseInt(sourceEl.value, 10);
    if (Number.isFinite(n)) targetEl.value = String(40 - n);
}

// Prévient si les contraintes ont changé depuis la dernière génération réussie (voir
// échange avec Guillaume) : rien ne se régénère automatiquement (comme pour les deux
// autres sources, fichier/bibliothèque), donc sans ce rappel on pourrait croire à tort que
// les donnes déjà générées reflètent les derniers réglages. Ne s'affiche que si une
// génération a déjà eu lieu (lastGeneratedConstraintsJSON défini) ET que la lecture
// actuelle des champs diffère de l'empreinte prise à ce moment-là.
function uiCheckConstraintsStale() {
    if (lastGeneratedConstraintsJSON === undefined) return;
    const { constraints } = readRandomDealConstraintsFromUI();
    if (JSON.stringify(constraints) !== lastGeneratedConstraintsJSON) {
        setHostSetupMessage('Contraintes modifiées depuis la dernière génération — cliquez de nouveau sur "🎲 Générer" pour les appliquer.', true);
    }
}

function uiToggleRandomDealConstraints() {
    const panel = document.getElementById('randomDealConstraintsPanel');
    const btn = document.getElementById('randomDealConstraintsToggle');
    if (!panel) return;
    const isOpen = panel.style.display !== 'none';
    const willOpen = !isOpen;
    panel.style.display = willOpen ? 'block' : 'none';
    if (btn) {
        btn.classList.toggle('is-active', willOpen);
        btn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    }
}

// Lit les champs du panneau de contraintes optionnelles (voir échange avec Guillaume) et
// construit l'objet attendu par dealSatisfiesCustomConstraints. Un champ vide est traité
// comme "pas de contrainte" (null), jamais comme 0 — un input number vide renvoie une
// chaîne vide, pas NaN, donc on teste explicitement sur '' plutôt que sur isNaN. Renvoie
// aussi une liste d'erreurs de validation (min > max) à afficher avant de lancer la
// génération, plutôt que de la découvrir seulement après 500 tentatives infructueuses.
function readRandomDealConstraintsFromUI() {
    const errors = [];
    const readNum = (id) => {
        const el = document.getElementById(id);
        if (!el || el.value === '') return null;
        const n = parseInt(el.value, 10);
        return Number.isFinite(n) ? n : null;
    };

    const seats = {};
    for (const [seat, label] of [['N', 'Nord'], ['E', 'Est'], ['S', 'Sud'], ['W', 'Ouest']]) {
        const hcpMin = readNum(`rdc-${seat}-hcpMin`);
        const hcpMax = readNum(`rdc-${seat}-hcpMax`);
        const suitEl = document.getElementById(`rdc-${seat}-suit`);
        const suit = suitEl && suitEl.value ? suitEl.value : null;
        const suitMinLength = readNum(`rdc-${seat}-suitLen`);
        if (hcpMin != null && hcpMax != null && hcpMin > hcpMax) {
            errors.push(`${label} : le H minimum dépasse le H maximum.`);
        }
        if (hcpMin != null || hcpMax != null || (suit && suitMinLength != null)) {
            seats[seat] = { hcpMin, hcpMax, suit, suitMinLength };
        }
    }

    const lines = {};
    for (const [line, label] of [['NS', 'Nord-Sud'], ['EW', 'Est-Ouest']]) {
        const hcpMin = readNum(`rdc-${line}-hcpMin`);
        const hcpMax = readNum(`rdc-${line}-hcpMax`);
        if (hcpMin != null && hcpMax != null && hcpMin > hcpMax) {
            errors.push(`${label} : le H minimum dépasse le H maximum.`);
        }
        if (hcpMin != null || hcpMax != null) lines[line] = { hcpMin, hcpMax };
    }

    const hasAny = Object.keys(seats).length > 0 || Object.keys(lines).length > 0;
    return { constraints: hasAny ? { seats, lines } : null, errors };
}

// Empreinte des contraintes utilisées à la DERNIÈRE génération réussie (voir échange avec
// Guillaume) — sert uniquement à détecter si les champs ont changé depuis, pour prévenir
// que les donnes déjà générées ne les reflètent plus. `undefined` tant qu'aucune génération
// n'a eu lieu (pas d'avertissement à afficher dans ce cas).
let lastGeneratedConstraintsJSON;

function uiGenerateRandomDeals() {
    const countInput = document.getElementById('randomDealCount');
    const count = countInput ? parseInt(countInput.value, 10) : NaN;
    if (!Number.isFinite(count) || count < 1 || count > 40) {
        setHostSetupMessage('Choisissez un nombre de donnes entre 1 et 40.', false);
        return;
    }

    const { constraints, errors } = readRandomDealConstraintsFromUI();
    if (errors.length > 0) {
        setHostSetupMessage(errors.join(' '), false);
        return;
    }
    lastGeneratedConstraintsJSON = JSON.stringify(constraints);
    schedulePonsClientPreload();

    // Désélectionne les deux autres sources, comme elles se désélectionnent déjà
    // mutuellement entre elles (voir uiHandleDealFileChosen/uiHandleDealLibraryChosen) :
    // une seule source active à la fois, pour éviter toute ambiguïté sur celle qui sera
    // effectivement utilisée.
    const fileInput = document.getElementById('dealFileInput');
    if (fileInput) fileInput.value = '';
    updateDealFileNameDisplay();
    const librarySelect = document.getElementById('dealLibrarySelect');
    if (librarySelect) librarySelect.value = '';

    const generated = generateRandomDeals(count, seatAssignment, constraints);
    pendingParsedSource = 'random';
    pendingParsedDeals = generated;
    refreshPendingOrderedDeals();

    // rien à prévisualiser pour du random (voir uiPreviewDeals) : bandeau vert sans son
    // bouton Prévisualiser.
    setDealStatusReady(`✅ ${count} donne${count > 1 ? 's' : ''} générée${count > 1 ? 's' : ''}`, false);

    // Voir échange avec Guillaume : avec des contraintes très serrées (plusieurs fourchettes
    // étroites simultanées), certaines donnes peuvent ne pas les satisfaire même après
    // RANDOM_DEAL_MAX_RETRIES tentatives (voir generateRandomDeal) — mieux vaut prévenir que
    // de laisser croire que toutes les donnes générées les respectent silencieusement. Voir
    // échange avec Guillaume (session du 23 juillet) : plus de mention du PAR ici — le
    // calcul du double mort en arrière-plan (voir kickOffBackgroundDD) tourne
    // systématiquement, plus la peine de le signaler.
    const unmetCount = generated.filter(d => d.constraintsUnmet).length;
    if (unmetCount > 0) {
        setHostSetupMessage(
            `${unmetCount} donne(s) n'ont pas pu satisfaire toutes les contraintes malgré ${RANDOM_DEAL_MAX_RETRIES} tentatives — essayez des fourchettes moins serrées.`,
            true
        );
    } else {
        clearHostSetupMessage();
    }

    kickOffBackgroundDD(generated);
}

// ===== Double mort en arrière-plan pour les donnes générées aléatoirement =====
//
// Réutilise TELLE QUELLE l'API serverless déjà utilisée par le générateur externe
// (gen/dds-controller.js, voir les fichiers fournis par Guillaume pour cette
// fonctionnalité) : même URL, même format de requête/réponse. Comme table-encheres est
// hébergé sur le même domaine (capgui13.github.io), le CORS déjà en place pour le
// générateur (Access-Control-Allow-Origin restreint à ce domaine, pas au sous-dossier)
// couvre aussi cette appli sans rien à reconfigurer côté serveur.
const RANDOM_DEAL_DD_SERVER_URL = 'https://api-gen-beta.vercel.app/api/dds';
const RANDOM_DEAL_DD_CHUNK_SIZE = 10; // donnes par requête HTTP, comme dds-controller.js

// Même format PBN que dealToPBNString dans generator.js (gen/), à ceci près que les mains
// sont déjà des chaînes ici (pas des tableaux de rangs) — pas de .join('') à faire.
function dealToPbnStringForDD(deal) {
    const hands = ['N', 'E', 'S', 'W']
        .map(pos => ['S', 'H', 'D', 'C'].map(suit => deal.hands[pos][suit]).join('.'))
        .join(' ');
    return 'N:' + hands;
}

// Incrémenté à chaque nouveau lancement de calcul (voir kickOffBackgroundDD) : si l'hôte
// change de source (nouveau fichier, nouvelle génération aléatoire) pendant qu'un calcul
// précédent est encore en vol, les résultats tardifs de l'ANCIEN lot doivent être ignorés
// plutôt que d'être appliqués à de nouvelles donnes qui partagent, par coïncidence, le
// même numéro de board (très courant : la plupart des fichiers/générations commencent à
// la donne 1). Même principe que ddCurrentGenerationId dans dds-controller.js (gen/).
let ddResultGenerationId = 0;

// Lance le calcul pour toutes les donnes fournies, par lots de RANDOM_DEAL_DD_CHUNK_SIZE
// envoyés en parallèle (pas de limite de concurrence ici contrairement à
// dds-controller.js : un lot de 40 donnes max, donc 4 requêtes au plus, largement sous ce
// qui justifierait de les échelonner). Un seul point d'appel, quelle que soit la source
// (donnes aléatoires ou fichier/bibliothèque sans PAR, voir validateAndUseDealText) :
// c'est ICI qu'un nouveau lot invalide implicitement tout lot précédent encore en vol.
function kickOffBackgroundDD(dealsList) {
    ddResultGenerationId++;
    const generationId = ddResultGenerationId;
    for (let i = 0; i < dealsList.length; i += RANDOM_DEAL_DD_CHUNK_SIZE) {
        sendDDChunk(dealsList.slice(i, i + RANDOM_DEAL_DD_CHUNK_SIZE), generationId);
    }
    scheduleDDWatchdog(dealsList, generationId);
}

// Voir échange avec Guillaume (session du 8 août — "des fois il ne se lance juste pas,
// il faudrait un garde-fou pour check au bout d'un moment et relancer si ça a merdé") :
// filet de sécurité GÉNÉRAL, indépendant des points de reprise existants (host-reconnect,
// reprise cloud — qui ne retentent QUE lors d'un événement précis, jamais pendant qu'on
// reste sur place à attendre). Après un délai généreux (largement au-dessus du temps
// normal de calcul, tentatives internes de sendDDChunk comprises), si des donnes de CE
// lot précis manquent encore ET qu'aucun lot plus récent n'a pris le relais entre-temps
// (voir ddResultGenerationId), on retente automatiquement — une seule fois par lot
// initial (pas de rappel récursif à ce garde-fou lui-même), pour ne jamais boucler à
// l'infini si le problème est persistant plutôt qu'un aléa ponctuel.
const DD_WATCHDOG_DELAY_MS = 20000;

function scheduleDDWatchdog(dealsList, generationId) {
    setTimeout(() => {
        if (generationId !== ddResultGenerationId) return; // un lot plus récent a déjà pris le relais
        const pool = deals || pendingParsedDeals;
        if (!pool) return;
        const stillMissing = dealsList.filter(d => {
            const current = pool.find(p => p.board === d.board);
            return current && !current.par && !current.ddTable;
        });
        if (stillMissing.length === 0) return;
        pushDebugLog(`Double mort : ${stillMissing.length} donne(s) toujours sans résultat après le délai de sécurité (${DD_WATCHDOG_DELAY_MS / 1000}s) — nouvelle tentative automatique.`);
        for (let i = 0; i < stillMissing.length; i += RANDOM_DEAL_DD_CHUNK_SIZE) {
            sendDDChunk(stillMissing.slice(i, i + RANDOM_DEAL_DD_CHUNK_SIZE), generationId);
        }
    }, DD_WATCHDOG_DELAY_MS);
}

// Voir échange avec Guillaume (session du 23 juillet — "une donne au milieu sans PAR
// calculé") : borne le nombre de fois où une même donne peut être retentée, pour éviter
// une boucle infinie si son calcul échoue systématiquement (distribution pathologique
// pour le solveur, pas un simple aléa ponctuel) — 2 tentatives suffisent largement pour
// absorber un timeout isolé côté serveur, sans s'acharner indéfiniment sur un cas
// réellement bloqué.
const DD_MAX_RETRIES_PER_DEAL = 2;
const DD_RETRY_DELAY_MS = 1500;

async function sendDDChunk(chunk, generationId, retryCount = 0) {
    const items = chunk.map(deal => ({ id: deal.board, pbn: dealToPbnStringForDD(deal) }));
    try {
        const response = await fetch(RANDOM_DEAL_DD_SERVER_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items })
        });
        if (!response.ok) throw new Error('HTTP ' + response.status);
        const data = await response.json();
        if (generationId !== ddResultGenerationId) return; // lot périmé, voir ddResultGenerationId

        // Voir échange avec Guillaume : un résultat sans `table` (voir applyDDResultToBoard,
        // qui ignore silencieusement ce cas) signifie très probablement un timeout ponctuel
        // du solveur côté serveur sur CETTE distribution précise — les autres donnes du même
        // lot, elles, ont bien abouti. On les identifie ici pour les retenter isolément,
        // plutôt que de les laisser filer sans PAR pour le reste de la partie.
        const succeededIds = new Set();
        for (const r of data.results) {
            if (r.table) {
                applyDDResultToBoard(r.id, r.table);
                succeededIds.add(r.id);
            }
        }
        const missingDeals = chunk.filter(d => !succeededIds.has(d.board));
        if (missingDeals.length > 0 && retryCount < DD_MAX_RETRIES_PER_DEAL) {
            pushDebugLog(`Double mort : ${missingDeals.length} donne(s) sans résultat dans ce lot — nouvelle tentative (${retryCount + 1}/${DD_MAX_RETRIES_PER_DEAL})…`);
            setTimeout(() => sendDDChunk(missingDeals, generationId, retryCount + 1), DD_RETRY_DELAY_MS);
        } else if (missingDeals.length > 0) {
            pushDebugLog(`Double mort : ${missingDeals.length} donne(s) toujours sans résultat après ${DD_MAX_RETRIES_PER_DEAL} tentatives — abandon pour elles (le reste de la partie n'est pas affecté).`);
        }
    } catch (err) {
        // Échec COMPLET du lot (réseau, erreur HTTP...) — même logique de retry borné que
        // pour un résultat partiel ci-dessus, plutôt que d'abandonner tout de suite sur un
        // aléa réseau transitoire.
        if (retryCount < DD_MAX_RETRIES_PER_DEAL) {
            pushDebugLog(`Double mort en arrière-plan : échec pour un lot (${(err && err.message) || err}) — nouvelle tentative (${retryCount + 1}/${DD_MAX_RETRIES_PER_DEAL})…`);
            setTimeout(() => sendDDChunk(chunk, generationId, retryCount + 1), DD_RETRY_DELAY_MS);
        } else {
            // Échec silencieux du point de vue du joueur : pas de PAR pour ce lot, mais la
            // partie elle-même n'est pas affectée (voir échange avec Guillaume — le calcul
            // DD est un bonus, jamais un prérequis pour jouer). Tracé dans le journal de
            // diagnostic pour comprendre après coup si ça arrive souvent.
            pushDebugLog(`Double mort en arrière-plan : échec définitif pour un lot après ${DD_MAX_RETRIES_PER_DEAL} tentatives (${(err && err.message) || err})`);
        }
    }
}

// Point d'entrée UNIQUE pour appliquer un résultat de double mort à une donne, quelle que
// soit la provenance : calcul local (si on est l'hôte, voir sendDDChunk) ou message relayé
// par l'hôte (voir handlePeerData, cas 'dd-result', côté invité comme côté hôte
// nouvellement transféré). `boardNumber` (deal.board), pas un index de tableau : l'ordre
// dans `deals` peut différer de l'ordre de génération si "Ordre aléatoire des donnes" est
// coché (voir refreshPendingOrderedDeals).
function applyDDResultToBoard(boardNumber, table) {
    // Avant le lancement de la partie, les donnes générées vivent dans pendingParsedDeals
    // (pas encore dans `deals`, qui ne prend vie qu'au clic sur "Commencer la partie" —
    // voir uiStartGameAsHost) : écrire ici sur les mêmes objets suffit, puisque
    // pendingOrderedDeals (donc `deals` ensuite) référence CES MÊMES objets, jamais une
    // copie (voir shuffleDealsArray, qui ne fait que réordonner, jamais cloner).
    const pool = deals || pendingParsedDeals;
    if (!pool) return;
    const idx = pool.findIndex(d => d.board === boardNumber);
    if (idx === -1) return;
    pool[idx].ddTable = table;

    if (deals && pool === deals) {
        // La partie est déjà lancée. Si on regarde justement cette donne-là, rafraîchir
        // dès que le PAR doit être visible : à la fin de l'enchère, ou immédiatement pour
        // le vrai hôte / un kibbitz. Le bouton PAR du vrai hôte ne dépend plus de
        // hostSeeAllHands, donc l'arrivée tardive du DD doit aussi rafraîchir ce bouton.
        if (idx === boardIndex && (isAuctionOver(auctionHistory) || isTrueOriginalHost() || isKibbitz())) checkAuctionEnd();

        // Relais aux invités : eux n'ont reçu qu'un instantané figé des donnes au moment
        // du 'start-game' (voir uiStartGameAsHost) — un résultat de double mort arrivé
        // après coup ne leur parviendrait jamais sans ce message dédié. Seul l'hôte
        // calcule le double mort (uiGenerateRandomDeals n'est accessible que depuis son
        // propre panneau), donc seul lui a besoin de le relayer.
        if (myRole === 'host') {
            participants.filter(p => p.id !== 'host' && !p.disconnected).forEach(p => {
                const guestIndex = guestIndexForParticipant(p.id);
                if (guestIndex != null) peerConn.send({ type: 'dd-result', boardNumber, table }, guestIndex);
            });
        }
    }
}

// Recalcule pendingOrderedDeals à partir de pendingParsedDeals et de l'état actuel de la
// case à cocher. Appelé au chargement du fichier et à chaque bascule de la case.
function refreshPendingOrderedDeals() {
    if (!pendingParsedDeals) {
        pendingOrderedDeals = null;
        return;
    }
    const checkbox = document.getElementById('randomizeDealsToggle');
    pendingOrderedDeals = (checkbox && checkbox.checked)
        ? shuffleDealsArray(pendingParsedDeals)
        : pendingParsedDeals;
}

// Appelé par la case "Ordre aléatoire des donnes" du salon d'attente.
function uiToggleRandomizeDeals() {
    refreshPendingOrderedDeals();
}

// ===== Bibliothèque de donnes du club =====
//
// donnes/catalogue.json est un simple tableau de noms de fichiers (voir donnes/README.md
// pour la marche à suivre pour en ajouter) : ["exemple.pbn", "autre-exemple.lin"]. Pas de
// backend — ajouter une donne à la bibliothèque, c'est déposer le fichier dans donnes/ et
// ajouter son nom à ce tableau, puis pousser sur GitHub comme le reste du site.
//
// Chargé une fois au démarrage de l'appli plutôt qu'à l'entrée dans le salon : peu de
// risque que le catalogue change en cours de session, et ça évite un aller-retour réseau
// à chaque fois que l'hôte revient sur cet écran.
let dealLibraryInitPromise = null;
function initDealLibrary() {
    if (dealLibraryInitPromise) return dealLibraryInitPromise;
    recordPlayPerfMilestone('deal-library-load-start');
    dealLibraryInitPromise = fetch('donnes/catalogue.json')
        .then(resp => {
            if (!resp.ok) throw new Error('catalogue absent ou illisible');
            return resp.json();
        })
        .then(filenames => {
            if (!Array.isArray(filenames) || filenames.length === 0) return; // bibliothèque vide : on laisse le groupe masqué

            const select = document.getElementById('dealLibrarySelect');
            const group = document.getElementById('dealLibraryGroup');
            if (!select || !group) return;

            // idempotent en cas de réouverture PeerJS de l'hôte : aucune option dupliquée.
            while (select.options.length > 1) select.remove(1);
            filenames.forEach(filename => {
                const option = document.createElement('option');
                option.value = filename;
                option.textContent = filename;
                select.appendChild(option);
            });
            group.style.display = 'block';
            recordPlayPerfMilestone('deal-library-load-ready', { count: filenames.length });
        })
        .catch(() => {
            // Pas de bibliothèque déployée (ou catalogue.json absent/vide) : ce n'est pas
            // une erreur pour l'utilisateur, juste une fonctionnalité qui ne s'active pas.
            // Le groupe reste masqué (voir style initial dans index.html), pas de message.
        });
    return dealLibraryInitPromise;
}

// --- Demande d'annulation (undo) ---
let undoRequestPending = false; // je suis le demandeur, en attente d'une réponse
let pendingUndoAsk = null;      // on me demande d'accepter/refuser une annulation
let hostPendingUndo = null;     // (hôte uniquement) demande en cours d'arbitrage
let undoRequestTimeoutId = null;

function currentDeal() {
    return deals[boardIndex];
}

// Un kibbitz (non assigné à un siège) ne peut pas naviguer entre les donnes ; tout
// joueur actif (hôte ou invité) le peut.
function canControlBoard() {
    return myRole === 'host' || (mySeats && mySeats.length > 0);
}

// En live, l'hôte reste le seul à déplacer la table entière. En différé, chaque joueur
// assis navigue indépendamment entre les donnes : cette liberté faisait partie du mode
// asynchrone stabilisé et ne doit pas dépendre du rôle technique P2P du moment.
function canNavigateBoards() {
    return myRole === 'host' || (deferredRoomMode && mySeats && mySeats.length > 0);
}

// R24 — reprise différée : un joueur qui rouvre la salle doit être amené à la PREMIÈRE
// donne, dans l'ordre 1, 2, 3..., qui attend réellement une de ses annonces. Cette règle
// est volontairement différente du fast-forward manuel, qui continue à chercher à partir
// de la donne courante et boucle ensuite. Ici on repart toujours du début de la séance.
//
// Fonction pure : ne change ni boardIndex ni les historiques. Elle sert aux deux chemins
// de reprise (cloud normal et repli local du créateur) et laisse le live inchangé.
function findFirstBoardWaitingForSeats(targetSeats, boardList = deals) {
    if (!Array.isArray(boardList) || boardList.length === 0) return -1;
    const mine = new Set(Array.isArray(targetSeats) ? targetSeats.filter(Boolean) : []);
    if (mine.size === 0) return -1;

    for (let idx = 0; idx < boardList.length; idx++) {
        const deal = boardList[idx];
        if (!deal) continue;
        const hist = Array.isArray(deal.auctionHistory) ? deal.auctionHistory : [];
        if (isAuctionOver(hist)) continue;
        const turnSeat = currentTurnSeat(deal.dealer, hist);
        if (mine.has(turnSeat)) return idx;
    }
    return -1;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
}

// Avatar rond (couleur + initiale) affiché devant un participant, dans la liste et dans
// les cases de sièges assignées — juste un repère visuel rapide pour distinguer les
// joueurs d'un coup d'œil, pas une vraie identité. La couleur est dérivée de l'id du
// participant (stable même s'il se renomme, change du coup si un autre participant
// prend sa place au même id ne se produit jamais — les id sont uniques par connexion).
// Palette de couleurs d'avatar : les 15 couleurs par défaut officielles de Twitch (celles
// proposées gratuitement dans son sélecteur "Chat Identity", sans abonnement Turbo/Prime)
// — même liste, mêmes valeurs hexadécimales exactes.
const AVATAR_COLOR_PALETTE = [
    '#FF0000', // Red
    '#0000FF', // Blue
    '#00FF00', // Green
    '#8A2BE2', // BlueViolet
    '#FF7F50', // Coral
    '#5F9EA0', // CadetBlue
    '#D2691E', // Chocolate
    '#1E90FF', // DodgerBlue
    '#B22222', // Firebrick
    '#DAA520', // GoldenRod
    '#FF69B4', // HotPink
    '#FF4500', // OrangeRed
    '#2E8B57', // SeaGreen
    '#00FF7F', // SpringGreen
    '#9ACD32', // YellowGreen
];

function isAllowedAvatarColor(value) {
    return typeof value === 'string' && AVATAR_COLOR_PALETTE.includes(value.toUpperCase());
}

function normalizeAvatarColor(value) {
    if (!isAllowedAvatarColor(value)) return null;
    return value.toUpperCase();
}

function normalizePublicParticipantList(list) {
    if (!Array.isArray(list)) return null;
    const out = [];
    const seen = new Set();
    for (const raw of list) {
        if (!raw || typeof raw !== 'object' || !isSafeParticipantId(raw.id) || seen.has(raw.id)) return null;
        const name = typeof raw.name === 'string' ? raw.name.trim().slice(0, 40) : '';
        if (!name) return null;
        if (Object.prototype.hasOwnProperty.call(raw, 'reconnectSecret')) return null;
        const avatarColor = raw.avatarColor == null ? null : normalizeAvatarColor(raw.avatarColor);
        if (raw.avatarColor != null && !avatarColor) return null;
        const p = {
            id: raw.id,
            name,
            disconnected: !!raw.disconnected,
            disconnectedAt: Number.isFinite(raw.disconnectedAt) ? raw.disconnectedAt : null
        };
        if (avatarColor) p.avatarColor = avatarColor;
        seen.add(p.id);
        out.push(p);
    }
    return out;
}

function normalizePublicSeatAssignment(value, participantList) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const ids = new Set((participantList || []).map(p => p.id));
    const out = {};
    for (const seat of SEATS) {
        const occupant = value[seat];
        if (occupant == null || occupant === '') out[seat] = null;
        else if (occupant === SEAT_PENDING) out[seat] = SEAT_PENDING;
        else if (isSafeParticipantId(occupant) && (ids.size === 0 || ids.has(occupant))) out[seat] = occupant;
        else return null;
    }
    return out;
}


function normalizeCloudAuctionHistory(deal, dealIndex) {
    if (!deal || !SEATS.includes(deal.dealer)) return null;
    const rawHistory = deal.auctionHistory == null ? [] : deal.auctionHistory;
    if (!Array.isArray(rawHistory) || rawHistory.length > 128) return null;
    const out = [];
    for (let i = 0; i < rawHistory.length; i++) {
        const raw = rawHistory[i];
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const seat = raw.seat;
        const call = typeof raw.call === 'string' ? raw.call.toUpperCase() : '';
        const callInVocabulary = call === 'PASS' || call === 'X' || call === 'XX' || /^([1-7])(NT|C|D|H|S)$/.test(call);
        if (!SEATS.includes(seat) || !callInVocabulary) return null;
        const expectedSeat = currentTurnSeat(deal.dealer, out);
        if (seat !== expectedSeat || !isCallLegal(out, call, seat)) return null;
        const clean = { seat, call };
        if (raw.explanation != null) {
            if (typeof raw.explanation !== 'string' || raw.explanation.length > 2000) return null;
            clean.explanation = raw.explanation;
        }
        out.push(clean);
    }
    return out;
}

function normalizeCloudChatMessages(list, participantList) {
    if (list == null) return [];
    if (!Array.isArray(list) || list.length > 5000) return null;
    const out = [];
    for (const raw of list) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const senderId = raw.senderId;
        const senderName = typeof raw.senderName === 'string' ? raw.senderName.trim().slice(0, 40) : '';
        const text = typeof raw.text === 'string' ? raw.text.trim() : '';
        // Un ancien expéditeur peut ne plus être dans participants (p. ex. après un
        // transfert d'hôte). On exige donc un ID public sûr, pas son appartenance à la
        // liste courante, afin de préserver l'historique sans rouvrir l'injection HTML.
        if (!isSafeParticipantId(senderId)) return null;
        if (!senderName || !text || text.length > 500) return null;
        if (raw.type != null && raw.type !== 'chat') return null;
        // Les premières versions du relais cloud stockaient le chat sans champ `type`.
        // Normaliser ce legacy sûr vers le format P2P courant permet aussi à l'hôte de
        // le relayer aux pairs encore connectés sans qu'il soit ignoré par handlePeerData.
        out.push({ type: 'chat', senderId, senderName, text });
    }
    return out;
}

function avatarColorForId(id) {
    // Surcharge manuelle (voir échange avec Guillaume, uiRandomizeAvatarColor) : si ce
    // participant a choisi une couleur (au clic, ou reprise automatiquement depuis
    // savedAvatarColor à la connexion — voir échange du 8 août, "qu'il récupère
    // automatiquement la dernière couleur utilisée"), elle prime sur le calcul
    // déterministe ci-dessous.
    const p = participants.find(x => x.id === id);
    if (p && p.avatarColor) return p.avatarColor;

    // Repli pour un participant SANS préférence sauvegardée (jamais choisi de couleur
    // sur cet appareil) : mélange le code de salon dans le hash (pas l'id seul) — une
    // couleur différente à chaque nouvelle partie plutôt qu'une "couleur de signature"
    // fixe, mais stable pendant toute la durée d'UNE partie, y compris après une
    // reconnexion (le code de salon ne change pas entre-temps, seul le jeton pourrait
    // changer de contexte). Sans code de salon connu (avant qu'une partie ait démarré),
    // repli sur l'id seul.
    let hash = 0;
    const str = (currentRoomCode || '') + '|' + String(id || '');
    for (let i = 0; i < str.length; i++) {
        hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
    }
    return AVATAR_COLOR_PALETTE[hash % AVATAR_COLOR_PALETTE.length];
}

// Certaines des 15 couleurs Twitch (Green, SpringGreen, HotPink...) sont trop claires
// pour rester lisibles avec le texte blanc fixe de l'initiale dans le rond d'avatar —
// Twitch, lui, ne les utilise qu'en texte sur fond sombre, jamais en aplat avec du blanc
// dessus. Calcule donc noir ou blanc selon la luminosité perçue de la couleur de fond
// (formule standard de luminance relative), plutôt qu'un blanc fixe qui échouerait sur
// les teintes claires de la palette.
function avatarTextColorFor(hexColor) {
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.55 ? '#17231d' : '#ffffff';
}



function avatarInitial(name) {
    const trimmed = (name || '').trim();
    return trimmed ? trimmed[0].toUpperCase() : '?';
}

// HTML de l'avatar pour un participant donné (par son id) ; chaîne vide si personne.
function avatarHtml(participantId) {
    const p = participants.find(x => x.id === participantId);
    if (!p) return '';
    const bg = avatarColorForId(p.id);
    return `<span class="mini-avatar" style="background:${bg};color:${avatarTextColorFor(bg)}">${escapeHtml(avatarInitial(p.name))}</span>`;
}

function defaultParticipantName(pid) {
    if (pid === 'host') return 'Hôte';
    // Nom par défaut d'un nouvel invité, basé sur son rang d'arrivée (pas sur son id, qui
    // est maintenant un jeton opaque et non plus un simple numéro de connexion).
    const guestCount = participants.filter(p => p.id !== 'host').length;
    return 'Guest #' + (guestCount + 1);
}

// ===== Navigation entre écrans =====

function showScreen(id) {
    document.querySelectorAll('.app-home-btn').forEach(btn => {
        btn.href = currentAppHomeUrl();
    });
    // Voir échange avec Guillaume (session du 23 juillet — "ça m'ouvre la page à mi
    // hauteur") : sans ça, le nouvel écran hérite de la position de défilement de
    // l'ancien — s'ils n'ont pas la même hauteur de contenu à cet endroit précis, on
    // atterrit au milieu de nulle part plutôt qu'en haut.
    window.scrollTo(0, 0);
    document.querySelectorAll('.screen').forEach(el => el.style.display = 'none');
    // '' (et non 'block' en dur) : un style inline a une priorité absolue sur n'importe
    // quelle règle de styles.css, y compris #screen-game { display: flex; ... } posé par
    // le layout plein écran mobile (voir @media max-width:1024px) — le forcer à 'block'
    // ici l'écrasait silencieusement et faisait s'effondrer tout le système de répartition
    // des hauteurs (mains/enchères/boîte fixée en bas), avec un retour au scroll de page
    // classique. Laisser vide restaure le display défini par la feuille de style (block
    // par défaut pour un <section>, flex pour #screen-game sous 1024px).
    document.getElementById(id).style.display = '';

    // Seul l'écran de jeu élargit .app-container afin de conserver les trois colonnes
    // mains / panneau central / chat permanent ; les autres écrans restent centrés et
    // étroits comme avant.
    const appContainer = document.querySelector('.app-container');
    if (appContainer) appContainer.classList.toggle('wide-layout', id === 'screen-game');

    // Voir échange avec Guillaume (chat qui recouvrait la boîte d'enchères sur mobile,
    // mesuré : le panneau flottant, à 555-834px, chevauchait la boîte à 547-945px) : dans
    // le salon comme en pleine partie, le chat n'est plus un panneau flottant par-dessus
    // le reste (voir dockChatIntoScreen/undockChatFromScreen) — il rejoint le flux normal
    // de la page, tout en bas. Seul l'écran d'accueil garde le panneau flottant classique
    // (le chat n'y a de toute façon aucun sens, voir plus bas — masqué avant même de se
    // poser la question de son ancrage).
    if (id === 'screen-game' || id === 'screen-lobby') dockChatIntoScreen(id);
    else undockChatFromScreen();

    // Le chat n'a de sens qu'une fois dans un salon ou en partie (il faut des participants
    // à qui parler) : masqué sur l'écran d'accueil, affiché partout ailleurs. Point de
    // contrôle unique ici plutôt que dispersé à chaque appel de showScreen (voir échange
    // avec Guillaume — le bouton était visible dès le chargement, avant toute connexion,
    // alors que non fonctionnel).
    const chatBtn = document.getElementById('chatToggleBtn');
    if (chatBtn) {
        chatBtn.style.display = (id === 'screen-landing') ? 'none' : '';
        // Le chat n'a de sens qu'une fois entré dans un salon ou en partie. Sur l'écran
        // d'accueil, on le masque explicitement ; ailleurs il reste désormais toujours
        // ouvert, et le bouton sert seulement de raccourci de défilement.
        if (id === 'screen-landing') hideChatPanelForLanding();
    }

    // Voir échange avec Guillaume : sur l'écran d'accueil, rien n'est encore connecté, le
    // trait de séparation sous la barre de statut n'a donc rien à séparer et fait juste
    // ligne parasite (voir la règle CSS body.on-landing-screen .connection-bar).
    document.body.classList.toggle('on-landing-screen', id === 'screen-landing');
    // Écrans jeu/salon : classes dédiées pour permettre les ajustements de géométrie
    // propres à chaque vue (notamment l'écart supérieur mobile), sans toucher à l'accueil.
    document.body.classList.toggle('on-game-screen', id === 'screen-game');
    document.body.classList.toggle('on-lobby-screen', id === 'screen-lobby');

    // Une mise à jour PWA détectée reste volontairement en attente pendant toute la vie
    // de cet onglet. Elle sera utilisée lors d'une prochaine vraie ouverture/navigation,
    // jamais en rechargeant automatiquement l'écran courant (voir initServiceWorker).
    tryAutoApplyUpdate();
}

function setConnectionStatus(connected) {
    recordSyncTrace('connection.ui', { connected: !!connected });
    const bar = document.getElementById('connectionBar');
    const status = document.getElementById('connectionStatus');
    bar.style.display = 'flex';
    status.textContent = connected ? '🟢 Connecté' : '🔴 Déconnecté';
    status.className = 'connection-status ' + (connected ? 'connected' : 'disconnected');
}

function showLandingError(msg) {
    const el = document.getElementById('landingError');
    el.textContent = msg;
    el.style.display = 'block';
}

// ===== Panneau de diagnostic (visible à l'écran, utile sur mobile sans accès aux DevTools) =====

const debugLogLines = [];

// ===== Trace structurée de synchronisation =====
// Complément du journal humain ci-dessus : événements courts et structurés pour diagnostiquer
// les courses P2P/cloud/reconnexion sans devoir déduire l'état à partir de phrases libres.
// IMPORTANT : aucune capacité, clé, credential ou secret n'est jamais conservé ici.
const syncTraceEntries = [];
const SYNC_TRACE_MAX_ENTRIES = 600;

function sanitizeSyncTraceDetail(value, key = '', depth = 0) {
    if (depth > 3) return '[depth-limit]';
    if (/(access|secret|writekey|hostwrite|credential|capability)/i.test(String(key))) return '[redacted]';
    if (value == null || typeof value === 'number' || typeof value === 'boolean') return value;
    if (typeof value === 'string') {
        // Les ids participant ne sont pas secrets, mais leur préfixe suffit largement au diagnostic.
        if (/participant|token|actor|target|sender/i.test(String(key)) && value.length > 12) return value.slice(0, 10) + '…';
        return value.length > 160 ? value.slice(0, 157) + '…' : value;
    }
    if (Array.isArray(value)) return value.slice(0, 12).map((v, i) => sanitizeSyncTraceDetail(v, `${key}[${i}]`, depth + 1));
    if (typeof value === 'object') {
        const out = {};
        for (const [k, v] of Object.entries(value).slice(0, 24)) out[k] = sanitizeSyncTraceDetail(v, k, depth + 1);
        return out;
    }
    return String(value);
}

function currentSyncTraceState() {
    let p2pConnected = false;
    let signalingOpen = false;
    try {
        p2pConnected = !!(peerConn && typeof peerConn.isConnected === 'function' && peerConn.isConnected());
        signalingOpen = !!(peerConn && peerConn.signalingOpen);
    } catch (e) { /* diagnostic uniquement */ }
    return {
        role: myRole || null,
        deferred: !!deferredRoomMode,
        room: currentRoomCode || null,
        board: Number.isInteger(boardIndex) ? boardIndex : null,
        cloudVersion: Number.isFinite(lastKnownCloudVersion) ? lastKnownCloudVersion : null,
        p2pConnected,
        signalingOpen,
        seats: Array.isArray(mySeats) ? mySeats.slice() : []
    };
}

function recordSyncTrace(eventName, detail = {}) {
    try {
        const entry = {
            ts: Date.now(),
            event: String(eventName || 'event'),
            state: currentSyncTraceState(),
            detail: sanitizeSyncTraceDetail(detail)
        };
        syncTraceEntries.push(entry);
        if (syncTraceEntries.length > SYNC_TRACE_MAX_ENTRIES) syncTraceEntries.splice(0, syncTraceEntries.length - SYNC_TRACE_MAX_ENTRIES);
        return entry;
    } catch (e) {
        return null;
    }
}

if (typeof window !== 'undefined') {
    window.recordSyncTrace = recordSyncTrace;
    window.getPlaySyncTrace = () => syncTraceEntries.map(entry => JSON.parse(JSON.stringify(entry)));
    window.clearPlaySyncTrace = () => { syncTraceEntries.length = 0; };
}

// Voir échange avec Guillaume ("un clic pour tout transmettre, sans avoir besoin du
// journal d'un joueur spécifique") : chaque ligne journalisée localement est aussi mise
// en file pour une remontée périodique vers le journal PARTAGÉ de la salle (voir
// api/session-log.js, côté repo api-gen) — pas une requête par ligne (bien trop de
// trafic vu la fréquence des lignes ICE), un lot toutes les REMOTE_LOG_FLUSH_INTERVAL_MS
// suffit largement pour un usage de diagnostic après coup, pas pour du temps réel.
let pendingRemoteLogEntries = [];
const REMOTE_LOG_FLUSH_INTERVAL_MS = 8000;
let remoteLogFlushTimer = null;

function scheduleRemoteLogFlush() {
    if (remoteLogFlushTimer) return;
    remoteLogFlushTimer = setTimeout(() => {
        remoteLogFlushTimer = null;
        flushRemoteLogQueue();
    }, REMOTE_LOG_FLUSH_INTERVAL_MS);
}

function flushRemoteLogQueue() {
    if (!currentRoomCode || typeof pushSessionLogEntries !== 'function' || pendingRemoteLogEntries.length === 0) return Promise.resolve();
    const batch = pendingRemoteLogEntries;
    pendingRemoteLogEntries = [];
    return pushSessionLogEntries(currentRoomCode, batch);
}

// Étiquette identifiant CE participant dans le journal combiné — sans elle, un journal à
// 4 joueurs mélangés serait illisible (impossible de savoir qui a fait quoi).
function debugLogFromLabel() {
    const me = participants.find(p => p.id === myParticipantId);
    const name = me ? me.name : (myRole === 'host' ? 'Hôte' : '?');
    const roleLabel = myRole === 'host' ? 'hôte' : 'invité';
    const seatsLabel = (mySeats && mySeats.length) ? `, ${mySeats.join('/')}` : '';
    return `${name} (${roleLabel}${seatsLabel})`;
}

function pushDebugLog(line) {
    const timestamp = new Date().toLocaleTimeString('fr-FR');
    debugLogLines.push(`[${timestamp}] ${line}`);
    const content = document.getElementById('debugLogContent');
    if (content) {
        content.textContent = debugLogLines.join('\n');
        content.scrollTop = content.scrollHeight;
    }
    // Pas la peine tant qu'on n'a pas encore rejoint de salle (currentRoomCode) : les
    // tout premiers logs, avant même de rejoindre, ne peuvent de toute façon aller nulle
    // part de partagé.
    if (currentRoomCode) {
        pendingRemoteLogEntries.push({ from: debugLogFromLabel(), text: line, ts: Date.now() });
        scheduleRemoteLogFlush();
    }
}

function uiToggleDebugPanel() {
    const panel = document.getElementById('debugPanel');
    panel.style.display = panel.style.display === 'none' ? 'flex' : 'none';
}

function uiCopyDebugLog() {
    const text = debugLogLines.join('\n');
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).catch(() => fallbackCopyDebugLog(text));
    } else {
        fallbackCopyDebugLog(text);
    }
}

function fallbackCopyDebugLog(text) {
    const content = document.getElementById('debugLogContent');
    const range = document.createRange();
    range.selectNodeContents(content);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('copy');
}

// Voir échange avec Guillaume ("Report a bug" — récupérer le journal à la main sur
// téléphone est galère, même avec le panneau de diagnostic visible : sélectionner du texte
// dans une popup, changer d'appli, coller... trop d'étapes en pleine partie) : ce bouton
// récupère tout SANS jamais avoir besoin d'ouvrir ce panneau, avec le contexte utile
// (salle, rôle, sièges, navigateur) déjà inclus — plus la peine de demander "et t'étais
// hôte ou invité ?" en plus du journal lui-même.

// Voir échange avec Guillaume ("un clic pour tout transmettre, sans avoir besoin du
// journal d'un joueur spécifique") : devenue async — essaie d'abord le journal COMBINÉ de
// toute la salle (voir api/session-log.js, côté repo api-gen), en flushant d'abord ma
// propre file en attente pour ne rien manquer de tout frais avant de relire tout le
// monde. Repli sur mon seul journal local si le serveur est injoignable, ou si je ne suis
// dans aucune salle.
async function buildBugReportText(maxLogChars) {
    const lines = [
        `Salle : ${currentRoomCode || '(aucune)'}`,
        `Rôle : ${myRole || '(aucun)'}`,
        `Sièges : ${(mySeats && mySeats.length) ? mySeats.join(', ') : '(aucun)'}`,
        `Heure : ${new Date().toLocaleString('fr-FR')}`,
        `Navigateur : ${navigator.userAgent}`,
        ''
    ];

    let combinedEntries = null;
    if (currentRoomCode && typeof pullSessionLog === 'function') {
        try {
            await flushRemoteLogQueue(); // pousse d'abord tout ce qui est encore en file localement
            combinedEntries = await pullSessionLog(currentRoomCode);
        } catch (e) {
            // Tant pis, repli sur le journal local ci-dessous.
        }
    }

    let log, totalLineCount;
    if (combinedEntries && combinedEntries.length > 0) {
        // Trié par heure d'arrivée : les entrées de plusieurs participants arrivent dans
        // le désordre (chacun pousse son propre lot toutes les REMOTE_LOG_FLUSH_INTERVAL_MS,
        // indépendamment des autres).
        const sorted = combinedEntries.slice().sort((a, b) => (a.ts || 0) - (b.ts || 0));
        const formatted = sorted.map(e => {
            const t = e.ts ? new Date(e.ts).toLocaleTimeString('fr-FR') : '?';
            return `[${t}] ${e.from || '?'} — ${e.text}`;
        });
        lines.push(`--- Journal combiné de la salle (${sorted.length} lignes, tous participants) ---`);
        log = formatted.join('\n');
        totalLineCount = formatted.length;
    } else {
        lines.push('--- Journal (local uniquement — journal partagé indisponible ou vide) ---');
        log = debugLogLines.join('\n');
        totalLineCount = debugLogLines.length;
    }

    // Voir plus bas (uiReportBug) : maxLogChars diffère selon le canal — généreux pour le
    // partage natif (pas de limite de longueur d'URL), plus serré pour mailto:, qui reste
    // fiable seulement en dessous de quelques milliers de caractères sur pas mal de clients
    // mail mobiles. On garde la FIN du journal (slice négatif) : c'est l'événement le plus
    // récent — donc le plus probablement en cause — qui compte le plus en cas de troncature.
    if (log.length > maxLogChars) {
        log = `[…tronqué, ${totalLineCount} lignes au total, voir la fin…]\n` + log.slice(-maxLogChars);
    }
    lines.push(log || '(journal vide)');

    // Ajoute la trace structurée en fin de rapport. Elle est volontairement locale : elle
    // décrit le chemin réseau de CET appareil et complète le journal combiné de la salle.
    // Limite séparée pour ne pas rendre le rapport inutilisable sur mobile.
    if (syncTraceEntries.length) {
        let traceText = syncTraceEntries.map(entry => JSON.stringify(entry)).join('\n');
        const traceLimit = Math.min(9000, Math.max(2500, Math.floor(maxLogChars * 0.45)));
        if (traceText.length > traceLimit) traceText = '[…trace tronquée, fin conservée…]\n' + traceText.slice(-traceLimit);
        lines.push('', `--- Trace synchro locale (${syncTraceEntries.length} événements) ---`, traceText);
    }

    return lines.join('\n');
}

async function uiReportBug() {
    const subject = `Bug — Table d'enchères (salle ${currentRoomCode || '?'})`;

    // Voir échange avec Guillaume ("le bouton bug ouvre le partage natif de Windows sur
    // PC") : isMobileOrTabletDevice() en plus de navigator.share — la seule présence de
    // l'API ne suffit pas à distinguer mobile de desktop (voir son commentaire plus haut).
    if (isMobileOrTabletDevice() && navigator.share) {
        const text = await buildBugReportText(20000);
        navigator.share({ title: subject, text }).catch(() => {
            // Annulé par l'utilisateur (ou échec silencieux) : la feuille de partage s'est
            // quand même affichée, rien à faire de plus ici — pas de repli automatique sur
            // la copie presse-papiers qui rouvrirait une seconde interface sans que ça ait
            // été demandé.
        });
        return;
    }

    // Voir échange avec Guillaume ("sur desktop, je voudrais que ça copie juste les logs,
    // comme ça j'ai qu'à cliquer et te le copier/coller") : plus de mailto: ici — sur PC,
    // le rapport part directement dans le presse-papiers, prêt à coller où il veut (chat
    // Claude, Slack, peu importe), sans ouvrir un client mail. Pas de limite de longueur à
    // respecter ici non plus (aucune URL impliquée), même généreux que le partage natif.
    const text = await buildBugReportText(20000);
    const toastEl = () => {
        let toast = document.getElementById('bugReportToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'bugReportToast';
            toast.className = 'call-explanation-toast'; // même style que les autres toasts, réutilisé tel quel
            document.body.appendChild(toast);
        }
        return toast;
    };
    const flash = (msg) => {
        const toast = toastEl();
        toast.textContent = msg;
        toast.classList.remove('visible');
        void toast.offsetWidth;
        toast.classList.add('visible');
        clearTimeout(toast._hideTimer);
        toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 2800);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
            .then(() => flash('📋 Rapport copié — colle-le où tu veux.'))
            .catch(() => fallbackCopyBugReport(text, flash));
    } else {
        fallbackCopyBugReport(text, flash);
    }
}

// Repli pour les navigateurs sans l'API Clipboard moderne (ou qui la refusent, ex. contexte
// non sécurisé) : même mécanique que fallbackCopyDebugLog (sélection + execCommand), mais
// via un <textarea> temporaire plutôt que le panneau de diagnostic — ce dernier n'est pas
// forcément ouvert (ni même présent dans le DOM avec du contenu à jour) au moment du clic
// sur 🐞.
function fallbackCopyBugReport(text, onDone) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
        document.execCommand('copy');
        onDone('📋 Rapport copié — colle-le où tu veux.');
    } catch (e) {
        onDone('❌ Échec de la copie — réessaie.');
    }
    document.body.removeChild(ta);
}

// ===== Écran d'accueil : créer / rejoindre =====

function tokenForGuestIndex(guestIndex) {
    return Object.keys(guestIndexByToken).find(t => guestIndexByToken[t] === guestIndex) || null;
}

// Voir échange avec Guillaume : bandeau plein écran affiché dès le clic sur "Créer" ou
// "Rejoindre", masqué une fois la connexion établie ou en cas d'erreur explicite. Un filet
// de sécurité (connectingOverlayTimeout) le masque de toute façon après 15s si aucun des
// deux ne s'est produit — pour ne pas laisser le joueur bloqué indéfiniment derrière un
// écran de chargement si la connexion traîne sans jamais aboutir ni échouer clairement.
let connectingOverlayTimeout = null;

function showConnectingOverlay(message) {
    const overlay = document.getElementById('connectingOverlay');
    if (!overlay) return;
    document.getElementById('connectingOverlayText').textContent = message;
    overlay.style.display = 'flex';
    clearTimeout(connectingOverlayTimeout);
    connectingOverlayTimeout = setTimeout(hideConnectingOverlay, 50000); // au-delà du timeout de connexion existant (45s, voir onTimeout), pur filet de sécurité
}

function hideConnectingOverlay() {
    clearTimeout(connectingOverlayTimeout);
    const overlay = document.getElementById('connectingOverlay');
    if (overlay) overlay.style.display = 'none';
}

// Le lien partagé reste désormais court dans TOUS les modes. En différé, le code à
// 4 chiffres suffit lui-même à reprendre la salle ; aucun secret supplémentaire n'est
// nécessaire dans l'URL. rememberRoomAccessFromUrl() reste présent pour accepter les
// anciens liens différés contenant encore #access/#pid/#secret.
function buildRoomShareUrl(roomCode) {
    const code = String(roomCode || '').trim();
    if (!/^\d{4}$/.test(code)) throw new Error('Code de salle invalide : 4 chiffres requis.');
    const url = new URL(window.location.href);
    url.searchParams.set('room', code);
    url.searchParams.delete('access');
    url.searchParams.delete('pid');
    url.searchParams.delete('secret');
    url.hash = '';
    return url;
}

function updateShareLinkForRoom(roomCode) {
    if (!roomCode) return;
    const input = document.getElementById('shareLinkInput');
    if (input) input.value = buildRoomShareUrl(roomCode).toString();
}

function rememberRoomAccessFromUrl(params) {
    if (!params || typeof rememberSessionAccessKey !== 'function') return;
    const room = params.get('room');
    const hashParams = new URLSearchParams(String(window.location.hash || '').replace(/^#/, ''));
    // Fragment = format normal. Query = compat avec les tout premiers prototypes locaux.
    const accessKey = hashParams.get('access') || params.get('access');
    const invitedParticipantId = hashParams.get('pid') || params.get('pid');
    const invitedReconnectSecret = hashParams.get('secret') || params.get('secret');
    if (!room || !accessKey) return;
    rememberSessionAccessKey(room, accessKey);
    if (isModernGuestParticipantId(invitedParticipantId) && isValidReconnectSecret(invitedReconnectSecret)) {
        rememberGuestRoomCredential(room, {
            participantId: invitedParticipantId,
            reconnectSecret: invitedReconnectSecret
        });
    }
    // Après capture, les capacités disparaissent aussi de l'historique/adresse locale.
    const cleanUrl = new URL(window.location.href);
    cleanUrl.searchParams.delete('access');
    cleanUrl.searchParams.delete('pid');
    cleanUrl.searchParams.delete('secret');
    const cleanHash = new URLSearchParams(String(cleanUrl.hash || '').replace(/^#/, ''));
    cleanHash.delete('access');
    cleanHash.delete('pid');
    cleanHash.delete('secret');
    cleanUrl.hash = cleanHash.toString();
    window.history.replaceState(null, '', cleanUrl.toString());
}

function uiCreateRoom() {
    deferredRoomMode = false;
    recordPlayPerfMilestone('create-click');
    document.getElementById('landingError').style.display = 'none';
    showConnectingOverlay('Création de la partie…');
    if (peerConn) peerConn.destroy();
    // Une nouvelle salle est un nouvel espace de versions cloud. Sans ce reset, une
    // version apprise dans la salle précédente pouvait être réutilisée comme
    // expectedVersion du premier PUT de la nouvelle salle et provoquer des 409 en boucle.
    resetCloudSyncContext(null);
    // Voir échange avec Guillaume (session du 8 août — "multi room") : on ne touche plus
    // aux sauvegardes existantes ici — créer une nouvelle partie n'a plus de raison
    // d'effacer les AUTRES salles encore reprenables (ancien comportement mono-salle).
    // On masque juste la bannière pour la durée de la création, purement visuel.
    const resumeBanner = document.getElementById('resumeSessionBanner');
    if (resumeBanner) resumeBanner.style.display = 'none';

    myRole = 'host';
    myParticipantId = 'host';
    participants = [{ id: 'host', name: savedNickname || 'Hôte', ...(normalizeAvatarColor(savedAvatarColor) ? { avatarColor: normalizeAvatarColor(savedAvatarColor) } : {}) }];
    // Voir échange avec Guillaume (session asynchrone à deux — "je ne veux pas de bascule
    // d'hôte") : figé une seule fois, ici, à la création — jamais réécrit ensuite, y
    // compris par une reprise cloud ou un transfert d'hôte manuel (voir uiResumeFromCloud). L'affichage "Hôte : X" (voir renderGameHeader) utilise TOUJOURS
    // cette valeur plutôt que le participant technique 'host' du moment — qui, lui,
    // continue de basculer en coulisses (nécessaire pour que d'autres puissent encore se
    // connecter au même code), mais ne doit plus jamais se voir.
    roomCreatorName = savedNickname || 'Hôte';
    roomCreatorToken = getReconnectToken();
    seatAssignment = { N: null, E: null, S: null, W: null };
    guestIndexByToken = {};
    guestReconnectSecretsByParticipantId = {};
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;
    chatMessages = [];
    chatUnreadCount = 0;
    updateChatUnreadBadge();
    lobbyChatAutoOpened = false;
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;
    clearHostSetupMessage();
    setDealStatusEmpty();

    peerConn = new BridgePeerConnection(buildHostHandlers());
    peerConn.createRoom();
}

// Handlers PeerJS côté hôte — partagés entre uiCreateRoom (nouvelle partie) et la prise de
// rôle après un transfert d'hôte (voir uiTransferHost/'prepare-become-host'), qui doivent
// tous deux traiter les connexions entrantes exactement de la même façon. Seul le
// comportement à l'ouverture du Peer diffère (onOpenExtra) : une toute nouvelle partie
// atterrit dans le salon normalement, une prise de rôle a besoin de faire autre chose
// d'abord (prévenir l'ancien hôte) avant de basculer l'écran.
function buildHostHandlers(onOpenExtra) {
    return {
        onOpen: (role, roomCode) => {
            hideConnectingOverlay();
            currentRoomCode = roomCode;
            ensureCloudSyncContext(roomCode);
            recordSyncTrace('p2p.host.open', { roomCode });
            // La réservation cloud courte est promue seulement APRÈS ouverture réelle de
            // PeerJS : une collision d'identifiant ne verrouille donc pas inutilement un
            // code, tandis qu'un salon qui reste ouvert longtemps garde sa capacité valide.
            if (typeof activateRoomAccess === 'function') {
                activateRoomAccess(roomCode).then(ok => {
                    if (!ok) pushDebugLog('Activation de la capacité cloud non confirmée (le premier snapshot réessaiera via la réservation si elle est encore valide).');
                });
            }
            const url = new URL(window.location.href);
            url.searchParams.set('room', roomCode);
            updateShareLinkForRoom(roomCode);
            document.getElementById('lobbyRoomCodeInline').textContent = `(code ${roomCode})`;
            // Voir échange avec Guillaume (session du 23 juillet) : reflète le code dans
            // la barre d'adresse elle-même, pas seulement dans le champ "lien de
            // connexion" caché — replaceState (pas pushState) pour ne pas empiler une
            // entrée d'historique de navigateur à chaque partie créée, sans recharger la
            // page (juste l'URL affichée qui change).
            // Voir échange avec Guillaume (session du 23 juillet) : sans ça, le statut
            // restait sur son dernier état affiché (ex. "🔴 Déconnecté" après une coupure)
            // jusqu'à ce qu'un premier invité se connecte (seul endroit qui l'appelait
            // jusqu'ici) — ne se voyait pas à la création initiale (rien à rafraîchir),
            // mais devenait trompeur après une reconnexion (manuelle ou automatique via
            // peer.reconnect()) tant que personne ne rejoignait entre-temps.
            setConnectionStatus(true);
            renderReconnectButton();
            // Voir échange avec Guillaume (session du 23 juillet) : succès (par n'importe
            // quelle voie — reconnexion légère ou réinitialisation complète, voir
            // uiHostReconnect) — plus besoin du watchdog qui basculerait sinon vers une
            // réinitialisation complète pour rien.
            clearTimeout(hostReconnectWatchdogTimer);
            window.history.replaceState(null, '', url.toString());
            if (onOpenExtra) {
                onOpenExtra(roomCode);
            } else if (deals) {
                // Voir échange avec Guillaume (session du 23 juillet — "ça me renvoie
                // dans le salon" après une mise en arrière-plan sur iPhone) : ce handler
                // se redéclenche à CHAQUE réouverture du Peer, pas seulement à la toute
                // première création — y compris une reconnexion AUTOMATIQUE
                // (peer.reconnect(), voir peer-connection.js) après une simple coupure
                // réseau en pleine partie. Sans ce garde-fou, enterLobbyScreen() était
                // appelée à chaque fois, arrachant l'hôte de sa partie en cours pour le
                // renvoyer au salon, alors que rien n'avait été perdu (deals intact).
                renderBoard();
            } else {
                enterLobbyScreen();
                initDealLibrary();
                recordPlayPerfMilestone('create-lobby-ready', { roomCode });
            }
        },
        onGuestConnected: (guestIndex, metadata) => {
            // Un ancien Peer hôte peut encore vider sa file de callbacks juste après un
            // transfert réussi. Une fois démotionné, il ne doit plus pouvoir rerendre ni
            // modifier l'interface comme hôte.
            if (myRole !== 'host') return;
            setConnectionStatus(true);
            // Identité invitée V2 : l'id est public, le secret de reconnexion ne l'est
            // jamais. Un participant existant n'est reconnu comme revenant QUE si le secret
            // présenté sur cette connexion correspond à celui enregistré localement par le
            // host. Connaître/copier un participantId vu dans lobby-state ne suffit donc plus.
            const token = metadata && typeof metadata.participantId === 'string'
                ? metadata.participantId.trim() : '';
            const reconnectSecret = metadata && typeof metadata.reconnectSecret === 'string'
                ? metadata.reconnectSecret.trim() : '';
            if (!isModernGuestParticipantId(token) || !isValidReconnectSecret(reconnectSecret)) {
                rejectPeerProtocolMessage({ type: 'identity' }, guestIndex, 'identité invitée invalide ou client obsolète');
                peerConn.send({ type: 'identity-rejected', reason: 'invalid-credential' }, guestIndex);
                const badConn = peerConn.conns && peerConn.conns[guestIndex];
                setTimeout(() => { try { if (badConn) badConn.close(); } catch (e) {} }, 80);
                return;
            }

            let p = participants.find(x => x.id === token);
            const isReturning = !!p;
            recordSyncTrace('p2p.host.guest-connected', { guestIndex, participantId: token, returning: isReturning });

            // En mode différé, la place PENDING possède UNE identité déterministe dérivée
            // du code à 4 chiffres (pré-autorisée côté serveur). Il faut utiliser cette même
            // identité même si le partenaire arrive pour la première fois pendant que
            // l'hôte est encore en ligne ; sinon la place serait attribuée à une identité
            // aléatoire P2P, puis impossible à retrouver plus tard depuis un nouvel appareil
            // avec le seul code. On ne force ce credential que pour un NOUVEL arrivant qui
            // s'apprête réellement à revendiquer la place PENDING ; les participants déjà
            // connus/reconnectés ne sont jamais concernés.
            if (!isReturning && currentRoomCode && SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING)) {
                const expectedDeferredCredential = getOrCreateDeferredInviteCredential(currentRoomCode);
                if (expectedDeferredCredential
                        && (token !== expectedDeferredCredential.participantId
                            || reconnectSecret !== expectedDeferredCredential.reconnectSecret)) {
                    rejectPeerProtocolMessage({ type: 'identity' }, guestIndex, 'credential différée requise pour la place en attente');
                    peerConn.send({ type: 'identity-rejected', reason: 'deferred-credential-required' }, guestIndex);
                    const badConn = peerConn.conns && peerConn.conns[guestIndex];
                    setTimeout(() => { try { if (badConn) badConn.close(); } catch (e) {} }, 80);
                    return;
                }
            }

            if (isReturning) {
                const expectedSecret = guestReconnectSecretsByParticipantId[token];
                if (!expectedSecret || expectedSecret !== reconnectSecret) {
                    // IMPORTANT : ne ferme surtout pas l'ancienne connexion légitime ici.
                    // Cette nouvelle connexion n'est pas encore liée à `token`, donc une
                    // tentative d'usurpation ne peut ni voler le siège ni éjecter son vrai
                    // propriétaire déjà connecté.
                    rejectPeerProtocolMessage({ type: 'identity' }, guestIndex, 'preuve de reconnexion invalide');
                    peerConn.send({ type: 'identity-rejected', reason: 'reconnect-proof-invalid' }, guestIndex);
                    const badConn = peerConn.conns && peerConn.conns[guestIndex];
                    setTimeout(() => { try { if (badConn) badConn.close(); } catch (e) {} }, 80);
                    return;
                }
            } else if (!registerHostGuestReconnectSecret(token, reconnectSecret)) {
                rejectPeerProtocolMessage({ type: 'identity' }, guestIndex, 'credential invitée non enregistrable');
                const badConn = peerConn.conns && peerConn.conns[guestIndex];
                setTimeout(() => { try { if (badConn) badConn.close(); } catch (e) {} }, 20);
                return;
            }

            // Seulement APRÈS authentification : une reconnexion valide peut remplacer une
            // ancienne DataConnection fantôme portant la même identité publique.
            const previousGuestIndex = guestIndexByToken[token];
            if (previousGuestIndex !== undefined && previousGuestIndex !== guestIndex) {
                const staleConn = peerConn.conns[previousGuestIndex];
                if (staleConn) {
                    pushDebugLog(`Participant ${token.slice(0, 10)}… déjà connecté à l'ancien index #${previousGuestIndex} — fermeture de cette connexion fantôme.`);
                    try { staleConn.close(); } catch (e) { /* déjà fermée, sans importance */ }
                    peerConn.conns[previousGuestIndex] = null;
                }
            }
            guestIndexByToken[token] = guestIndex;

            const wasDisconnected = isReturning && p.disconnected;
            const wasAlreadySeatedBeforeConnect = SEATS.some(seat => seatAssignment[seat] === token);
            if (!p) {
                const nickname = metadata && typeof metadata.nickname === 'string'
                    ? metadata.nickname.trim().slice(0, 20) : '';
                const avatarColorFromMeta = normalizeAvatarColor(metadata && metadata.avatarColor);
                p = { id: token, name: nickname || defaultParticipantName(token), disconnected: false, disconnectedAt: null };
                if (avatarColorFromMeta) p.avatarColor = avatarColorFromMeta;
                participants.push(p);
                // Un nouvel arrivant peut toujours revendiquer un siège explicitement
                // SEAT_PENDING. Son identité est déjà au format fermé et son secret a été
                // enregistré avant toute attribution.
                const pendingSeat = SEATS.find(seat => seatAssignment[seat] === SEAT_PENDING);
                if (pendingSeat) {
                    seatAssignment[pendingSeat] = token;
                    autoPassSeats = SEATS.filter(seat => !seatAssignment[seat]);
                    // Le secret d'invitation différée est à usage de la place PENDING :
                    // dès qu'elle est revendiquée, reconstruire le lien sans cette
                    // credential pour qu'un futur kibbitz ne réutilise pas l'identité.
                    if (currentRoomCode) updateShareLinkForRoom(currentRoomCode);
                    pushDebugLog(`Siège ${pendingSeat} en attente → attribué automatiquement à ${p.name} (${token.slice(0, 10)}…).`);
                }
            } else {
                p.disconnected = false;
                p.disconnectedAt = null;
            }
            pushDebugLog(`Connexion #${guestIndex} : identité ${token.slice(0, 10)}… → ${isReturning ? 'reconnexion prouvée (' + p.name + ')' : 'nouveau participant'}`);
            // Présence pendant une partie : même toast vert pour un retour après coupure
            // et pour une vraie nouvelle arrivée qui n'était pas connue au lancement.
            // Avant le lancement, le salon suffit : aucun toast d'arrivée n'est nécessaire.
            if (wasDisconnected) {
                flashPresenceToast(`✅ ${presenceLabelFor(p)} s'est reconnecté`, true);
            } else if (!isReturning && deals) {
                flashPresenceToast(`✅ ${presenceLabelFor(p)} a rejoint la partie`, true);
            }

            peerConn.send({
                type: 'welcome',
                yourId: token
            }, guestIndex);

            // Ne jamais donner la capacité cloud à un simple nouveau pair qui connaît
            // seulement le code 4 chiffres. Une reconnexion déjà assise, elle, prouve son
            // identité par sa preuve de reconnexion privée et peut récupérer la capacité.
            const isSeatedAfterConnect = SEATS.some(seat => seatAssignment[seat] === token);
            if ((isReturning && wasAlreadySeatedBeforeConnect) || (!isReturning && isSeatedAfterConnect)) {
                // Un siège PENDING revendiqué automatiquement est une autorisation de jeu
                // explicite au même titre qu'une attribution manuelle : enregistre d'abord
                // la preuve privée côté serveur, puis remet la capacité cloud.
                sendSessionAccessToParticipant(token);
            }

            if (deals) {
                // La partie est déjà lancée : on renvoie l'état complet (donnes, enchère en
                // cours, sièges) à ce joueur, qu'il soit nouveau ou de retour après coupure.
                // Les sièges "robot" restent ceux décidés au lancement (voir uiStartGameAsHost) :
                // un joueur déconnecté n'est PAS remplacé automatiquement, son siège attend
                // simplement qu'il revienne (voir le tour-indicateur pendant la partie).
                const seatsForThisGuest = SEATS.filter(seat => seatAssignment[seat] === token);
                peerConn.send({
                    type: 'resync',
                    deals, boardIndex, auctionHistory,
                    yourSeats: seatsForThisGuest,
                    botSeats: autoPassSeats,
                    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : jeton de l'hôte
                    // actuel, toujours utile pour qu'un invité identifie correctement
                    // l'hôte dans ses propres échanges avec le serveur (voir
                    // buildCloudStatePayload) — l’ancien identifiant de relais a disparu (plus
                    // d'élection automatique d'un autre hôte).
                    hostReconnectToken: getReconnectToken(),
                    roomCreatorName,
                    deferredRoomMode,
                    // Voir échange avec Guillaume (session du 23 juillet) : permet au client
                    // de distinguer un tout nouveau participant d'un simple retour de coupure
                    // (isReturning), pour n'ouvrir le chat automatiquement que dans le premier
                    // cas — voir le handler 'resync' côté invité.
                    isNewJoiner: !isReturning
                }, guestIndex);
            }

            broadcastLobbyState();
            renderLobby();
            if (deals) {
                renderBoard();
                saveHostGameStateToStorage();
            }
        },
        onPeerDisconnected: (guestIndex) => {
            // Symétrique de la garde des anciens handlers invité après promotion : après
            // un transfert, le Peer de l'ancien hôte est volontairement détruit et peut
            // encore émettre un callback de fermeture. Il ne doit surtout pas réappliquer
            // un rendu/état réservé à l'hôte alors que nous sommes déjà redevenus invité.
            if (myRole !== 'host') return;
            // Voir échange avec Guillaume (session du 23 juillet — même souci que
            // renderReconnectButton juste au-dessus) : signalingOpen (notre propre
            // connexion), pas isConnected() — sinon le statut passait à tort à "🔴
            // Déconnecté" dès que le DERNIER invité encore connecté se déconnectait, même
            // si notre propre lien au serveur de signalisation reste parfaitement sain.
            setConnectionStatus(peerConn ? peerConn.signalingOpen : false);
            renderReconnectButton();
            const token = tokenForGuestIndex(guestIndex);
            recordSyncTrace('p2p.host.guest-disconnected', { guestIndex, participantId: token || null });
            let presenceChanged = false;
            if (token) {
                delete guestIndexByToken[token];
                // R23 — même mutation que le signal explicite `presence-leaving`, mais
                // ce callback reste indispensable pour une vraie perte réseau / fermeture
                // brutale où aucun dernier message n'a pu partir.
                presenceChanged = markHostParticipantDisconnected(token, 'peer-close');
            }
            hostPendingUndo = null; // un invité qui part au milieu d'un arbitrage : on ne reste pas bloqué
            // Voir audit : si le participant qui vient de partir était justement la cible
            // d'un transfert d'hôte en cours, plus aucune réponse ('become-host-ready' ou
            // '-failed') n'arrivera jamais — sans ce filet, hostTransferInProgress resterait
            // bloqué à true pour toujours, empêchant tout nouveau transfert.
            if (hostTransferInProgress && token === pendingHostTransferTarget) {
                hostTransferInProgress = false;
                pendingHostTransferTarget = null;
                pendingHostTransferOldToken = null;
                pendingHostTransferOldCredential = null;
                showHostTransferStatus('Le participant visé par le transfert vient de se déconnecter. Transfert annulé, vous restez hôte.', true);
            }
            broadcastLobbyState();
            renderLobby();
            if (deals) {
                renderBoard();
                // Une coupure brutale n'est pas passée par `presence-leaving` : persister
                // alors la présence ici pour que le cloud et les autres clients convergent.
                if (presenceChanged) saveHostGameStateToStorage();
            }
        },
        onSlowConnection: () => {},
        onTimeout: () => {},
        onData: handlePeerData,
        // Voir onSignalingDisconnected côté invité (buildGuestHandlers) : même lacune côté
        // hôte, avec une conséquence différente — les invités déjà connectés continuent
        // parfois de fonctionner un moment via leur canal WebRTC direct, mais personne de
        // nouveau ne peut plus rejoindre la partie tant que ce n'est pas rétabli. Ça
        // correspond très probablement au souci "Aucune partie trouvée" déjà diagnostiqué
        // (host qui change d'appli sur iPhone juste après avoir créé la salle) : au moins,
        // maintenant, le statut reflète ce problème au lieu de rester "🟢 Connecté".
        onSignalingDisconnected: () => {
            // Callback tardif possible du Peer qui appartenait à l'ancien hôte.
            if (myRole !== 'host') return;
            recordSyncTrace('p2p.host.signaling-disconnected');
            setConnectionStatus(false);
            renderReconnectButton();
        },
        onError: (err) => {
            // Même frontière de rôle : une erreur retardée de l'ancien Peer hôte ne doit
            // pas polluer l'UI de l'ancien hôte maintenant connecté comme invité.
            if (myRole !== 'host') return;
            // Voir échange avec Guillaume (session du 23 juillet — "ça m'a fait
            // redevenir invité à tort") : PAS de bascule automatique en invité ici.
            // 'unavailable-id' peut arriver sur un simple peer.reconnect() automatique
            // (voir peer-connection.js) SANS qu'un autre hôte ait réellement pris le
            // relais — ambiguïté entre "quelqu'un d'autre a vraiment ce code" et "notre
            // propre ancienne session traîne encore, non nettoyée côté serveur PeerJS".
            // Cette bascule ne se déclenche maintenant QUE dans le filet de sécurité de
            // uiHostReconnect, après une réinitialisation complète (destroy + nouvelle
            // tentative) qui lève cette ambiguïté — voir son commentaire détaillé.
            // Pendant ce temps, le statut/bouton (déjà mis à jour par
            // onSignalingDisconnected) restent la seule indication ; rien d'autre à
            // afficher ici tant qu'on est en pleine partie (l'écran d'accueil, où
            // atterrirait ce message, n'est de toute façon pas visible).
            if (deals) return;
            hideConnectingOverlay();
            showLandingError('Erreur de connexion : ' + ((err && (err.message || err.type)) || err));
        }
    };
}

// Construit les handlers PeerJS côté invité — partagés entre uiJoinRoom (première
// connexion) et uiReconnect (après une coupure), pour ne pas dupliquer la logique.
function buildGuestHandlers() {
    // Voir connectAsGuest : capture la valeur au moment de la création de CES handlers,
    // pour que onError/onTimeout puissent reconnaître un essai devenu périmé (un nouveau
    // connectAsGuest() ayant démarré entre-temps) et ne pas dupliquer une bascule cloud
    // déjà déclenchée par ailleurs (voir le setTimeout de vérification en parallèle).
    const myAttemptToken = guestJoinAttemptToken;
    return {
        onOpen: (role, roomCode) => {
            recordSyncTrace('p2p.guest.signaling-open', { roomCode });
            document.getElementById('lobbyRoomCodeInline').textContent = `(code ${roomCode})`;
            // Voir échange avec Guillaume (session du 23 juillet) : même correctif que
            // côté hôte — la barre d'adresse ne reflétait jusqu'ici jamais le code de
            // salle, y compris en rejoignant via un code tapé à la main (pas via un lien
            // de partage qui l'aurait déjà dans l'URL).
            const url = new URL(window.location.href);
            url.searchParams.set('room', roomCode);
            window.history.replaceState(null, '', url.toString());
            // Voir échange avec Guillaume (session du 8 août — "le lien à copier devrait
            // apparaître même pour un non hôte") : shareLinkInput n'était rempli QUE côté
            // hôte (buildHostHandlers) — le bouton copier-lien était donc désormais
            // visible pour tous, mais copiait une chaîne vide côté invité. Même URL déjà
            // construite juste au-dessus, réutilisée ici.
            updateShareLinkForRoom(roomCode);
        },
        onGuestConnected: () => {
            recordSyncTrace('p2p.guest.connected-to-host');
            hideConnectingOverlay();
            everConnectedAsGuest = true;
            setConnectionStatus(true);
            renderReconnectButton();
            // Voir échange avec Guillaume ("si un joueur avait déjà été dans une
            // session, on ne doit pas lui redemander [son pseudo]") : marqué à CHAQUE
            // connexion réussie (premier join comme reconnexion), pas seulement une
            // fois — pour que le TTL (voir GUEST_ACTIVE_ROOM_TTL_MS) reste glissant
            // tant que la session est vraiment active, plutôt que de figer une seule
            // estampille au tout premier join.
            markGuestActiveRoom(currentRoomCode);
            // Voir échange avec Guillaume ("l'invité ne se reconnecte jamais tout seul") :
            // annule le cycle de reconnexion automatique en arrière-plan (voir
            // scheduleGuestAutoReconnect) — plus la peine une fois vraiment reconnecté.
            cancelGuestAutoReconnectTimer();
            // Voir échange avec Guillaume ("l'enchère disparaît une fois reconnecté") :
            // invalide toute relecture cloud encore en vol (voir guestPullSequence) —
            // 'resync', juste en dessous, est maintenant la source de vérité ; une
            // réponse de relecture qui arriverait après coup, même lancée juste avant
            // cette reconnexion, ne doit plus jamais pouvoir l'écraser.
            guestPullSequence++;
            // Voir échange avec Guillaume (session du 23 juillet — "on fait idem pour
            // l'host") : toast vert AVANT de réinitialiser selfDisconnectedAt — il faut
            // encore savoir qu'on ÉTAIT déconnecté pour décider d'afficher ce toast (pas
            // au tout premier succès de connexion, où il n'y a rien à "reconnecter").
            const hostEntry = participants.find(p => p.id === 'host');
            if (deals && selfDisconnectedAt) {
                if (deferredRoomMode) {
                    const label = hostEntry ? presenceLabelFor(hostEntry) : (roomCreatorName || 'L’autre joueur');
                    flashPresenceToast(`✅ ${label} s'est reconnecté`, true);
                } else {
                    flashPresenceToast('✅ Reconnecté à la partie', true);
                }
            }
            selfDisconnectedAt = null;
            // Voir échange avec Guillaume ("l'hôte devrait être affiché comme
            // déconnecté dans le chat") : levé ici — 'resync' ne renvoie jamais
            // `participants`, donc rien d'autre ne le remettrait à false tout seul.
            if (hostEntry) hostEntry.disconnected = false;
            // Dégèle la boîte d'enchères tout de suite (voir renderBiddingBox) — sans
            // ça, il faudrait attendre le prochain événement de jeu pour que ça se voie.
            if (deals) renderBoard();
            if (chatPanelOpen) { renderRoomBoard(); renderChat(); }
        },
        onPeerDisconnected: () => {
            recordSyncTrace('p2p.guest.peer-disconnected');
            // Un ancien BridgePeerConnection invité peut encore émettre son événement
            // de fermeture quelques millisecondes après un transfert d'hôte réussi.
            // À ce moment-là les globals ont déjà basculé vers le rôle hôte : ce handler
            // devenu obsolète ne doit surtout pas marquer l'entrée `host` comme déconnectée.
            if (myRole !== 'guest') return;
            // R23 — en différé, perdre le lien direct avec l'autre joueur ne signifie
            // pas perdre la salle : le cloud reste la voie normale de continuité. Ne pas
            // afficher un faux état global « Déconnecté » dans ce mode.
            setConnectionStatus(deferredRoomMode ? true : false);
            // Pendant toute coupure P2P, le cloud devient immédiatement la voie de
            // réception. En différé il reste également actif même après reconnexion afin de
            // suivre les autres donnes, qui évoluent indépendamment de celle regardée par
            // l'hôte. R22 : réarme aussi immédiatement l'accès/credential cloud.
            if (deferredRoomMode) enterDeferredGuestCloudContinuityAfterPeerLoss('peer-disconnected');
            else startDeferredPolling();
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : l'ancien planificateur de reprise automatique
            // a disparu d'ici (plus d'élection automatique d'un autre hôte) — seule reste la reconnexion
            // automatique en arrière-plan (voir scheduleGuestAutoReconnect), qui
            // concernait déjà TOUT invité déconnecté, pas seulement un participant désigné.
            scheduleGuestAutoReconnect();
            renderReconnectButton();
            // Voir échange avec Guillaume ("l'hôte devrait être affiché comme déconnecté
            // dans le chat") : marqué localement ici — 'resync' (au retour) ne renvoie
            // jamais `participants`, donc rien d'autre ne le ferait sinon. Toujours
            // 'host' en littéral ici (jamais un jeton) : ce chemin ne concerne QUE le
            // mode live, où l'hôte garde toujours cette identité fixe.
            const hostEntry = participants.find(p => p.id === 'host');
            if (hostEntry) hostEntry.disconnected = true;
            // Voir échange avec Guillaume (session du 23 juillet — compteur qui défile) :
            // posé seulement s'il ne l'était pas déjà — sinon un second événement de
            // coupure pendant qu'on est déjà déconnecté repousserait le départ du
            // compteur à chaque fois. Le toast ne part qu'à ce moment précis (première
            // détection), jamais répété pour les tentatives suivantes tant qu'on reste
            // déconnecté.
            if (!selfDisconnectedAt) {
                selfDisconnectedAt = Date.now();
                if (deals) {
                    if (deferredRoomMode) {
                        const label = hostEntry ? presenceLabelFor(hostEntry) : (roomCreatorName || 'L’autre joueur');
                        flashPresenceToast(`🔌 ${label} s'est déconnecté`, false);
                    } else {
                        flashPresenceToast("🔌 Connexion à l'hôte perdue", false);
                    }
                }
            }
            // Gèle la boîte d'enchères tout de suite (voir renderBiddingBox), pas
            // seulement au prochain événement de jeu.
            if (deals) renderBoard();
            // Voir renderBoard() (session du 23 juillet — "ça n'affiche plus à la 2e
            // déconnexion") : renderRoomBoard()/renderChat() vivent à part, pas
            // rafraîchis par renderBoard() lui-même — sans cet appel explicite ici, le
            // statut "déconnecté" de l'hôte dans le chat n'apparaîtrait qu'au hasard
            // d'un autre événement.
            if (chatPanelOpen) { renderRoomBoard(); renderChat(); }
        },
        // Voir échange avec Guillaume ("le bouton Se reconnecter n'apparaît pas") : sans ce
        // handler, une coupure de la connexion au serveur de signalisation (WebSocket) qui
        // ne provoque pas de fermeture propre de la DataConnection passait complètement
        // inaperçue — ni le statut ni le bouton ne se mettaient à jour.
        onSignalingDisconnected: () => {
            recordSyncTrace('p2p.guest.signaling-disconnected');
            // Même garde que pour onPeerDisconnected : après une promotion en hôte,
            // l'ancienne connexion invitée est volontairement détruite et ses callbacks
            // tardifs n'appartiennent plus au rôle courant.
            if (myRole !== 'guest') return;
            setConnectionStatus(deferredRoomMode ? true : false);
            if (deferredRoomMode) enterDeferredGuestCloudContinuityAfterPeerLoss('signaling-disconnected');
            else startDeferredPolling();
            scheduleGuestAutoReconnect();
            renderReconnectButton();
            // R23 — une coupure du serveur de signalisation n'implique pas que la
            // DataConnection WebRTC vers l'autre joueur soit tombée. En différé, ne pas
            // inventer une déconnexion de présence ici : `onPeerDisconnected` est le
            // signal réel, et le cloud assure déjà la continuité. Le live conserve son
            // comportement historique.
            if (!deferredRoomMode) {
                const hostEntry = participants.find(p => p.id === 'host');
                if (hostEntry) hostEntry.disconnected = true;
                if (!selfDisconnectedAt) {
                    selfDisconnectedAt = Date.now();
                    if (deals) flashPresenceToast("🔌 Connexion à l'hôte perdue", false);
                }
            }
            if (deals) renderBoard();
            if (chatPanelOpen) { renderRoomBoard(); renderChat(); }
        },
        onSlowConnection: () => {
            // Masque l'overlay ici (voir échange avec Guillaume) : sinon le message
            // "ça prend plus de temps..." resterait caché derrière l'écran de chargement
            // plein écran, invisible pour le joueur.
            hideConnectingOverlay();
            showLandingError("⏳ Ça prend plus de temps que d'habitude... Vérifie que le code est correct.");
        },
        onTimeout: () => {
            hideConnectingOverlay();
            if (myAttemptToken !== guestJoinAttemptToken) return; // un nouvel essai a pris le relais entre-temps
            if (deals) {
                // On était déjà en jeu : pas de retour à l'écran d'accueil, on laisse le
                // bouton "Se reconnecter" de la barre de connexion (renderReconnectButton).
                return;
            }
            // Voir même logique que dans onError (cas 'peer-unavailable') : un timeout pur
            // (parfois le seul signal reçu, selon l'aléa réseau) mérite la même proposition
            // de reprise cloud avant de conclure à un échec.
            const roomCodeAttempted = currentRoomCode;
            offerCloudResume(roomCodeAttempted).then(offered => {
                if (offered) return;
                showScreen('screen-landing');
                showLandingError(
                    "⚠️ La connexion n'a pas abouti après 45 secondes. Vérifie le code, que l'hôte est " +
                    "toujours connecté, et ouvre la console (F12) pour plus de détails avant de réessayer."
                );
            });
        },
        onData: handlePeerData,
        onError: (err) => {
            hideConnectingOverlay();
            if (myAttemptToken !== guestJoinAttemptToken) return; // un nouvel essai a pris le relais entre-temps
            // Voir échange avec Guillaume ("je suis ressorti du salon, puis 'Lost connection
            // to server' en retapant un code") : une erreur peut désormais survenir bien
            // après un premier join réussi — notamment quand la tentative de reconnexion
            // automatique en arrière-plan (voir peer.reconnect() dans peer-connection.js,
            // déclenché après une coupure de signalisation) échoue à son tour. Avant ce
            // correctif, TOUTE erreur ici renvoyait vers l'écran d'accueil avec un bandeau
            // "Erreur de connexion", même en plein milieu d'une session par ailleurs
            // fonctionnelle — perturbant pour rien et laissant l'appli dans un état confus
            // pour retaper un nouveau code ensuite. Désormais, seule une VRAIE première
            // tentative de connexion qui échoue (jamais connecté ne serait-ce qu'une fois)
            // déclenche ce comportement ; passé ce cap, on s'en remet simplement au statut
            // et au bouton "🔌 Se reconnecter" (déjà mis à jour par onSignalingDisconnected/
            // onPeerDisconnected), sans rien arracher à l'écran.
            if (!everConnectedAsGuest) {
                if (!deals) showScreen('screen-landing');
                if (err && err.type === 'peer-unavailable') {
                    // Voir échange avec Guillaume (session asynchrone à deux) : ce cas
                    // précis — personne ne répond sous ce code — est exactement celui d'un
                    // partenaire qui revient des heures après le départ de l'hôte. Avant de
                    // conclure "aucune partie", on regarde s'il existe un état sauvegardé
                    // dans le cloud pour ce code (voir offerCloudResume) ; si oui, on
                    // propose de reprendre plutôt que d'afficher une simple erreur.
                    //
                    // Voir aussi le setTimeout de vérification en parallèle dans
                    // connectAsGuest : si CETTE erreur arrive après coup (identifiant pas
                    // encore expiré côté serveur au moment de la tentative, voir
                    // EARLY_CLOUD_CHECK_DELAY_MS) et que la bascule cloud a déjà abouti
                    // entre-temps (`deals` déjà rempli), inutile de la refaire.
                    if (deals) return;
                    const roomCodeAttempted = currentRoomCode;
                    offerCloudResume(roomCodeAttempted).then(offered => {
                        if (!offered && !deals) {
                            showLandingError("Aucune partie trouvée avec ce code. Vérifiez le code ou demandez à l'hôte de le repartager.");
                        }
                    });
                } else {
                    showLandingError('Erreur de connexion : ' + ((err && (err.message || err.type)) || err));
                }
            } else {
                pushDebugLog('Erreur (après connexion déjà établie), ignorée côté interface : ' + ((err && (err.message || err.type)) || err));
            }
        }
    };
}

// Voir échange avec Guillaume (double tap nécessaire sur "Rejoindre" au clavier mobile) :
// valider directement depuis le clavier virtuel (touche "Aller", voir enterkeyhint="go"
// dans index.html) contourne complètement le souci, plutôt que de devoir taper le bouton.
function uiJoinCodeInputKeydown(event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    uiJoinRoom();
}

// Pavé de code de salle mobile : contrairement à un <input> éditable, il n'ouvre
// jamais le clavier système. C'est volontairement activé uniquement sur un appareil à
// interaction tactile/mobile ; desktop conserve la saisie clavier habituelle.
function mobileRoomCodeKeypadPreferred() {
    if (isIosDevice()) return true;
    if (/Android|Mobile|Tablet/i.test(navigator.userAgent || '')) return true;
    return !!(window.matchMedia && window.matchMedia('(hover: none) and (pointer: coarse)').matches);
}

function initMobileRoomCodeKeypad() {
    const input = document.getElementById('joinCodeInput');
    if (!input) return;
    const enabled = mobileRoomCodeKeypadPreferred();
    document.documentElement.classList.toggle('mobile-room-code-keypad-enabled', enabled);
    if (!enabled) return;

    // readonly + inputmode=none empêchent l'ouverture du clavier ; tabindex=-1 évite
    // qu'un tap ou un parcours clavier mobile ne place malgré tout le curseur dedans.
    input.readOnly = true;
    input.setAttribute('inputmode', 'none');
    input.setAttribute('aria-readonly', 'true');
    input.setAttribute('tabindex', '-1');
}

function uiJoinCodeKeypadDigit(digit) {
    if (!/^\d$/.test(String(digit))) return;
    const input = document.getElementById('joinCodeInput');
    if (!input) return;
    if (input.value.length >= 4) return;
    input.value += String(digit);
    const error = document.getElementById('landingError');
    if (error) error.style.display = 'none';
}

function uiJoinCodeKeypadBackspace() {
    const input = document.getElementById('joinCodeInput');
    if (!input) return;
    input.value = input.value.slice(0, -1);
    const error = document.getElementById('landingError');
    if (error) error.style.display = 'none';
}

// Voir échange avec Guillaume ("si un joueur avait déjà été dans une session, on ne doit
// pas lui redemander [son pseudo]") : distingue "rejoindre une salle où j'étais déjà
// activement présent" (silencieux, pas de modale) de "rejoindre une salle pour la première
// fois" (modale toujours affichée, voir ensureNicknameThenProceed). Marqué à chaque
// connexion invité réussie (voir onGuestConnected), purgé des entrées trop vieilles à
// chaque écriture — TTL généreux (une session de club peut s'étaler sur plusieurs heures
// avec pauses), même esprit que HOST_GAME_STATE_EXPIRY_MS côté hôte.
const GUEST_ACTIVE_ROOMS_KEY = 'bridgeBidGuestActiveRooms';
const GUEST_ACTIVE_ROOM_TTL_MS = 6 * 60 * 60 * 1000;

function markGuestActiveRoom(roomCode) {
    if (!roomCode) return;
    let map = {};
    try { map = JSON.parse(localStorage.getItem(GUEST_ACTIVE_ROOMS_KEY) || '{}'); } catch (e) { map = {}; }
    const now = Date.now();
    Object.keys(map).forEach(code => { if (now - map[code] > GUEST_ACTIVE_ROOM_TTL_MS) delete map[code]; });
    map[roomCode.toUpperCase()] = now;
    try { localStorage.setItem(GUEST_ACTIVE_ROOMS_KEY, JSON.stringify(map)); } catch (e) { /* tant pis, pas bloquant */ }
}

function isGuestActiveRoom(roomCode) {
    if (!roomCode) return false;
    let map = {};
    try { map = JSON.parse(localStorage.getItem(GUEST_ACTIVE_ROOMS_KEY) || '{}'); } catch (e) { return false; }
    const savedAt = map[roomCode.toUpperCase()];
    return !!savedAt && (Date.now() - savedAt <= GUEST_ACTIVE_ROOM_TTL_MS);
}

function uiJoinRoom() {
    document.getElementById('landingError').style.display = 'none';
    const code = document.getElementById('joinCodeInput').value.trim();
    if (!/^\d{4}$/.test(code)) {
        showLandingError('Entrez un code à 4 chiffres.');
        return;
    }
    // Voir échange avec Guillaume (session asynchrone à deux — "il faudrait un truc qui lui
    // demande de mettre son pseudo") : couvre à la fois un code tapé à la main ici ET un
    // lien direct ?room=XXXX (voir DOMContentLoaded plus bas, qui appelle aussi uiJoinRoom)
    // — un seul point de passage pour les deux façons d'arriver dans une salle.
    //
    // Voir juste au-dessus (isGuestActiveRoom) : si cet appareil était déjà activement
    // dans CETTE salle précise (ex. fenêtre fermée puis rouverte en pleine partie), on
    // saute la modale — inutile de redemander un pseudo qu'on connaît déjà pour une
    // session à laquelle on participe déjà, contrairement à une toute nouvelle salle.
    if (isGuestActiveRoom(code)) {
        chatMessages = [];
        chatUnreadCount = 0;
        updateChatUnreadBadge();
        showConnectingOverlay('Connexion en cours…');
        connectAsGuest(code, getReconnectToken(), savedNickname);
        return;
    }
    ensureNicknameThenProceed(() => {
        chatMessages = [];
        chatUnreadCount = 0;
        updateChatUnreadBadge();
        showConnectingOverlay('Connexion en cours…');
        connectAsGuest(code, getReconnectToken(), savedNickname);
    });
}

// Demande le pseudo avant de rejoindre une salle — affichée à CHAQUE fois. Si un pseudo
// existe déjà sur cet appareil, on ne le met plus dans `value` (ce qui le faisait apparaître
// sélectionné sur mobile) : on l'affiche comme placeholder grisé. Ainsi, valider sans rien
// taper conserve le pseudo précédent, tandis que commencer à écrire crée immédiatement une
// nouvelle valeur et remplace implicitement l'ancien pseudo sans aucune touche Effacer.
// `action` reste différée jusqu'à validation de la modale (voir uiConfirmNicknamePrompt).
let pendingJoinAfterNickname = null;
function ensureNicknameThenProceed(action) {
    pendingJoinAfterNickname = action;
    const input = document.getElementById('nicknamePromptInput');
    if (input) {
        input.value = '';
        input.placeholder = savedNickname || 'Votre pseudo';
    }
    const overlay = document.getElementById('nicknamePromptOverlay');
    if (overlay) overlay.style.display = 'flex';
    setTimeout(() => { if (input) input.focus(); }, 50);
}

function uiConfirmNicknamePrompt() {
    const input = document.getElementById('nicknamePromptInput');
    const typed = (input && input.value || '').trim();
    const trimmed = typed || (savedNickname || '').trim();
    if (!trimmed) {
        if (input) input.focus();
        return;
    }
    savedNickname = trimmed;
    saveStringPref('bridgeBidNickname', trimmed);
    const overlay = document.getElementById('nicknamePromptOverlay');
    if (overlay) overlay.style.display = 'none';
    const action = pendingJoinAfterNickname;
    pendingJoinAfterNickname = null;
    if (action) action();
}

// Même contournement que uiJoinCodeInputKeydown (double tap nécessaire sur clavier mobile) :
// valider directement depuis la touche "Aller" du clavier virtuel.
function uiNicknamePromptKeydown(event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    uiConfirmNicknamePrompt();
}

// Rejoint (ou re-rejoint) une salle en tant qu'invité, avec un jeton et un pseudo donnés.
// Partagé par uiJoinRoom (première connexion) et le transfert d'hôte (voir 'host-transferred'
// / 'become-host-ready' dans handlePeerData) : dans les deux cas, on repart d'un état de
// salon vierge, qui sera reconstitué dès réception du premier 'lobby-state' du nouvel hôte —
// exactement comme un rejoin normal.
function connectAsGuest(code, token, nickname, credentialOverride = null) {
    deferredRoomMode = false;
    if (peerConn) peerConn.destroy();
    // Statut honnête tout de suite : sans ça, la barre garde l'affichage précédent
    // ("Connecté") pendant tout le temps de la nouvelle connexion, ce qui pouvait laisser
    // penser à tort que quelque chose avait cassé pendant un transfert d'hôte alors que la
    // reconnexion était juste en cours (voir échange avec Guillaume).
    setConnectionStatus(false);

    myRole = 'guest';
    myParticipantId = null; // fixé à réception du message 'welcome'
    // Une bascule host -> guest (transfert volontaire) ne doit jamais conserver les
    // marqueurs d'autorité persistante de l'ancienne salle. Sans ce nettoyage, l'ancien
    // hôte gardait son roomCreatorToken en mémoire et pouvait le republier dans le cloud
    // de la NOUVELLE salle via buildCloudStatePayload(), malgré le transfert réussi.
    roomCreatorToken = null;
    currentHostReconnectToken = null;
    roomCreatorName = null;
    participants = [];
    seatAssignment = { N: null, E: null, S: null, W: null };
    currentRoomCode = code;
    ensureCloudSyncContext(code);
    everConnectedAsGuest = false;
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;
    lobbyChatAutoOpened = false;

    // Important lors d'un transfert d'hôte : le rôle global vient de passer de host à
    // guest, mais l'écran du salon contient encore les contrôles rendus pour l'ancien
    // rôle (chargement des donnes, robots, transfert d'hôte, menus de sièges...). Ne pas
    // attendre le premier lobby-state du nouvel hôte pour les retirer : selon l'ordre des
    // callbacks PeerJS, cet instantané peut arriver après un callback tardif de l'ancien
    // Peer et laisser des commandes host-only visibles. Le salon est donc rerendu
    // immédiatement avec le NOUVEAU rôle. En cours de partie on attend le resync normal,
    // afin de ne pas afficher transitoirement un plateau vidé de ses sièges.
    if (!deals) enterLobbyScreen();

    // Voir plus bas (setTimeout de vérification cloud en parallèle) : incrémenté ICI,
    // avant la construction des handlers, pour qu'ils capturent la bonne valeur et
    // puissent reconnaître un essai devenu périmé si un nouveau connectAsGuest() démarre
    // entre-temps.
    const attemptToken = ++guestJoinAttemptToken;
    peerConn = new BridgePeerConnection(buildGuestHandlers());
    let metadata;
    try {
        metadata = guestConnectionMetadata(code, nickname, credentialOverride);
    } catch (e) {
        hideConnectingOverlay();
        showLandingError('Impossible de créer une identité de reconnexion sécurisée sur cet appareil.');
        return;
    }
    pushDebugLog(`Connexion au salon ${code} avec l'identité ${metadata.participantId.slice(0, 10)}…`);
    peerConn.joinRoom(code, metadata);

    // Voir échange avec Guillaume ("connexion en cours en boucle" quand A vient tout juste
    // de lancer en mode différé) : dans ce mode, il n'y a jamais personne à trouver en
    // direct (voir NullPeerConnection) — mais l'identifiant de salle peut mettre quelques
    // secondes à expirer officiellement côté serveur de signalisation après sa destruction,
    // retardant l'erreur "peer-unavailable" habituelle (normalement quasi instantanée)
    // jusqu'au délai d'abandon complet de 45s (voir CONNECTION_TIMEOUT_MS). Plutôt que
    // d'attendre cet échec, on tente la bascule cloud EN PARALLÈLE, après un court délai —
    // le garde ci-dessous (attemptToken, et !everConnectedAsGuest/!deals) évite tout
    // conflit si la connexion directe aboutit entre-temps (mode live) ou si un nouvel
    // essai a déjà pris le relais.
    setTimeout(() => {
        if (attemptToken !== guestJoinAttemptToken) return; // un nouvel essai a pris le relais
        if (everConnectedAsGuest || deals) return; // déjà résolu (en direct, ou déjà en jeu) : rien à faire
        offerCloudResume(code);
    }, EARLY_CLOUD_CHECK_DELAY_MS);
}

// Reconnexion après coupure : même code de salon, même credential privée (localStorage) —
// l'hôte vérifie le secret et renvoie automatiquement les sièges et l'état de partie en cours.
function uiReconnect() {
    // Voir échange avec Guillaume (session du 23 juillet — "l'hôte n'a aucun bouton
    // Se reconnecter") : ce bouton (voir reconnectBtn dans index.html) sert maintenant
    // aux deux rôles — la logique diffère donc selon qui clique.
    if (myRole === 'host') {
        uiHostReconnect();
        return;
    }
    if (myRole !== 'guest' || !currentRoomCode) return;
    // Voir échange avec Guillaume ("l'invité ne se reconnecte jamais tout seul") : annule
    // le cycle automatique en arrière-plan avant de repartir sur cette tentative manuelle
    // — sinon un tick programmé plus tôt pourrait se déclencher en plein milieu et
    // redémarrer une seconde tentative concurrente inutilement. Se reprogrammera tout
    // seul si CETTE tentative échoue à son tour (voir onPeerDisconnected/
    // onSignalingDisconnected).
    cancelGuestAutoReconnectTimer();
    if (peerConn) peerConn.destroy();
    setConnectionStatus(false);
    peerConn = new BridgePeerConnection(buildGuestHandlers());
    const credential = getGuestRoomCredential(currentRoomCode, true);
    if (!credential) return;
    pushDebugLog(`Reconnexion au salon ${currentRoomCode} avec l'identité ${credential.participantId.slice(0, 10)}…`);
    peerConn.joinRoom(currentRoomCode, guestConnectionMetadata(currentRoomCode, savedNickname, credential));
}

// Voir échange avec Guillaume (session du 23 juillet) : la reconnexion AUTOMATIQUE de
// l'hôte (peer.reconnect(), voir peer-connection.js) est bornée à 5 tentatives rapprochées
// — si le réseau reste indisponible plus longtemps que ça (ex. écran de téléphone
// verrouillé un moment), l'hôte restait bloqué sans AUCUN moyen de relancer une tentative,
// même une fois le réseau revenu, contrairement à l'invité qui a toujours eu ce bouton.
// Contrairement à une reprise à froid, ici l'onglet n'a jamais fermé : tout l'état
// (donnes, enchère, sièges) est déjà intact en mémoire, rien à reconstruire — on retente
// juste de récupérer le même identifiant réseau sous le même code.
// Voir échange avec Guillaume (session du 23 juillet — "ça affichait connexion perdue
// sans jamais réussir") : surveille la tentative légère (manualReconnect) — peer.reconnect()
// sur une connexion restée hors ligne un moment n'est pas toujours fiable (limite connue
// de PeerJS, sans erreur explicite en cas d'échec silencieux). Si notre propre connexion
// n'est toujours pas rétablie après ce délai, on bascule sur la réinitialisation complète
// plutôt que de laisser le joueur bloqué indéfiniment sur "reconnexion en cours".
let hostReconnectWatchdogTimer = null;
const HOST_RECONNECT_WATCHDOG_MS = 4000;

function uiHostReconnect() {
    if (myRole !== 'host' || !currentRoomCode) return;
    const codeToReclaim = currentRoomCode;

    // Tentative légère d'abord : réutilise la connexion existante (voir manualReconnect
    // dans peer-connection.js), sans rien détruire — l'onOpen déjà câblé sur
    // buildHostHandlers gère tout seul le succès (statut, bouton, écran).
    if (peerConn && peerConn.manualReconnect()) {
        pushDebugLog(`Reconnexion manuelle en tant qu'hôte (peer.reconnect), salle ${codeToReclaim}…`);
        clearTimeout(hostReconnectWatchdogTimer);
        hostReconnectWatchdogTimer = setTimeout(() => {
            if (myRole === 'host' && (!peerConn || !peerConn.signalingOpen)) {
                pushDebugLog("La reconnexion légère n'a pas abouti — réinitialisation complète.");
                hardResetHostConnection(codeToReclaim);
            }
        }, HOST_RECONNECT_WATCHDOG_MS);
        return;
    }

    hardResetHostConnection(codeToReclaim);
}

// Réinitialisation complète : détruit la connexion actuelle, attend un court instant (le
// temps que le serveur de signalisation PeerJS enregistre cette destruction, pour éviter
// une collision avec notre PROPRE ancienne session), puis retente sous le même code forcé.
function hardResetHostConnection(codeToReclaim) {
    if (peerConn) peerConn.destroy();
    setConnectionStatus(false);
    renderReconnectButton();
    pushDebugLog(`Reconnexion manuelle en tant qu'hôte (nouveau Peer), salle ${codeToReclaim}…`);

    setTimeout(() => {
        if (myRole !== 'host') return; // entre-temps basculé autrement (ex. déjà résolu)
        const newPeerConn = new BridgePeerConnection(buildHostHandlers(() => {
            // État déjà intact (voir plus haut) : juste rafraîchir l'affichage, rien à
            // reconstruire côté salon/partie.
            renderReconnectButton();
            if (deals) renderBoard(); else renderLobby();
        }));
        peerConn = newPeerConn;
        // Voir échange avec Guillaume : ICI seulement (après une réinitialisation
        // complète, pas sur une simple reconnexion automatique — voir le onError partagé
        // de buildHostHandlers, qui ne bascule plus jamais en invité tout seul) un
        // 'unavailable-id' signifie que le code PeerJS est encore détenu par un autre peer live,
        // pas notre propre session zombie, qu'on vient de détruire
        // proprement juste avant.
        newPeerConn.handlers.onError = (err) => {
            if (err && err.type === 'unavailable-id' && deals) {
                pushDebugLog("Impossible de reprendre notre rôle d'hôte (déjà repris) — on rejoint la partie comme simple invité.");
                connectAsGuest(codeToReclaim, getReconnectToken(), savedNickname);
                return;
            }
            pushDebugLog("Échec de la reconnexion manuelle en tant qu'hôte : " + ((err && (err.message || err.type)) || err));
        };
        newPeerConn.createRoom(6, codeToReclaim);
    }, 500);
}

let everConnectedAsGuest = false;

function renderReconnectButton() {
    const btn = document.getElementById('reconnectBtn');
    if (!btn) return;
    // Voir échange avec Guillaume ("je ne veux pas que ce bouton apparaisse [côté
    // invité]") : masqué pour les invités désormais — la reconnexion automatique en
    // arrière-plan (voir scheduleGuestAutoReconnect) tourne déjà en continu, toutes les
    // GUEST_AUTO_RECONNECT_INTERVAL_MS ; ce bouton ne faisait alors plus que la même
    // chose en avance de quelques secondes, un gain jugé trop marginal pour justifier sa
    // présence. Gardé pour l'hôte, lui, qui n'a pas d'équivalent automatique aussi
    // systématique (voir uiHostReconnect).
    //
    // Attention — PAS le même critère que pour l'invité : isConnected() vaut
    // signalingOpen ET au moins une connexion active, ce qui est le bon critère pour un
    // invité (une seule connexion, vers l'hôte) mais donnerait un faux positif pour
    // l'hôte dès qu'il est seul dans son propre salon (aucun invité connecté n'importe
    // vraiment) — sa PROPRE connexion (signalingOpen) est le seul critère qui compte pour
    // lui, indépendamment du nombre d'invités présents.
    const shouldShow = peerConn && myRole === 'host' && !peerConn.signalingOpen;
    btn.style.display = shouldShow ? '' : 'none';
}

let copyShareLinkTimeoutId = null;
// `triggerBtn` : l'élément bouton qui vient de déclencher la copie, pour y afficher la
// confirmation temporaire au bon endroit — repli sur le bouton du salon (copyShareLinkBtn)
// si appelé sans argument, pour ne rien casser des appels existants.
function uiCopyShareLink(triggerBtn) {
    const input = document.getElementById('shareLinkInput');
    input.select();
    input.setSelectionRange(0, 99999);
    if (!navigator.clipboard) return;

    navigator.clipboard.writeText(input.value).then(() => {
        // Confirmation temporaire directement sur le bouton (pas de toast à part à
        // gérer) : le libellé change le temps d'un instant, puis revient à la normale.
        const btn = triggerBtn || document.getElementById('copyShareLinkBtn');
        if (!btn) return;
        const originalLabel = btn.textContent;
        clearTimeout(copyShareLinkTimeoutId);
        btn.textContent = '✅ Lien copié !';
        copyShareLinkTimeoutId = setTimeout(() => {
            btn.textContent = originalLabel;
        }, 1800);
    }).catch(() => { /* échec silencieux (permission navigateur, etc.) : pas de fausse confirmation */ });
}

// ===== Salon d'attente =====

function enterLobbyScreen() {
    showScreen('screen-lobby');
    // Voir échange avec Guillaume (session du 23 juillet) : voir HOSTING_PREGAME_KEY tout
    // en bas du fichier — reposé à chaque appel (enterLobbyScreen est réappelée à chaque
    // changement de participant), inoffensif de le refaire à chaque fois.
    if (myRole === 'host') markHostingPregame(currentRoomCode);
    // Le lien d'invitation est utile à tous les participants du salon : un invité peut
    // lui aussi inviter quelqu'un. updateShareLinkForRoom() est alimenté côté hôte ET
    // côté invité, donc ne pas masquer ce bloc selon le rôle.
    document.getElementById('lobbyRoomCodeBlock').style.display = 'block';
    document.getElementById('hostSetupPanel').style.display = myRole === 'host' ? 'block' : 'none';
    // Voir échange avec Guillaume (session du 23 juillet) : déplacé hors de hostSetupPanel
    // (voir index.html), donc sa visibilité host-only doit être pilotée séparément ici,
    // avec la même condition.
    document.getElementById('hostRobotModeGroup').style.display = myRole === 'host' ? 'flex' : 'none';
    document.getElementById('hostShortNtModeGroup').style.display = myRole === 'host' ? 'flex' : 'none';
    document.getElementById('guestWaitingNote').style.display = myRole === 'host' ? 'none' : 'block';

    // Voir échange avec Guillaume : reprend la préférence persistée (voir
    // robotBiddingMode/loadBoolPref) — sans ça, la case reviendrait toujours décochée par
    // défaut au rechargement, même si l'hôte l'avait activée la dernière fois.
    if (myRole === 'host') {
        const robotModeCheckbox = document.getElementById('robotBiddingModeCheckbox');
        if (robotModeCheckbox) robotModeCheckbox.checked = robotBiddingMode === 'smart';
        const shortNtCheckbox = document.getElementById('robotShortNtModeCheckbox');
        if (shortNtCheckbox) {
            shortNtCheckbox.checked = !!robotShortNtMode;
            shortNtCheckbox.disabled = robotBiddingMode === 'passOnly';
        }
    }

    const nameInput = document.getElementById('myNameInput');
    // On ne touche jamais au champ pendant que l'utilisateur est en train d'y taper
    // (sinon un lobby-state reçu pile pendant l'effacement du nom réécrase ce qu'il
    // est en train de saisir).
    if (!nameInput.value && document.activeElement !== nameInput) {
        const me = participants.find(p => p.id === myParticipantId);
        nameInput.value = me ? me.name : '';
    }

    // Voir échange avec Guillaume : dans le salon, le chat s'ouvre automatiquement — pas
    // besoin d'aller cliquer sur 💬 pour voir qui est là et papoter en attendant que tout
    // le monde arrive. `lobbyChatAutoOpened` évite de le rouvrir de force à chaque nouveau
    // 'lobby-state' reçu (enterLobbyScreen est réappelée à chaque changement de
    // participant) : une seule fois par entrée fraîche dans le salon, sinon on écraserait
    // le choix de quelqu'un qui l'aurait refermé volontairement entre-temps.
    if (!deals && !lobbyChatAutoOpened) {
        lobbyChatAutoOpened = true;
        if (!chatPanelOpen) uiToggleChat(false);
    }

    renderLobby();
}

function renderLobby() {
    renderParticipantsList();
    renderSeatAssignmentGrid();
    renderHostTransferWidget();
}

// Vrai si ce participant occupe un siège à la table — utilisé pour la coloration de son
// nom dans la liste des participants (bleu si placé, rouge sinon). Il n'y a plus de
// "place de kibbitz" à assigner à part : quiconque n'a pas de siège devient
// automatiquement kibbitz une fois la partie lancée (voir isKibbitz), donc rien
// d'autre à cocher ici.
function participantHasAPlace(participantId) {
    return SEATS.some(seat => seatAssignment[seat] === participantId);
}

// Changement de couleur d'avatar au clic (voir échange avec Guillaume) : l'hôte peut le
// faire pour n'importe qui, les autres seulement pour eux-mêmes. Exclut la couleur
// actuelle du tirage pour garantir un changement visible à chaque clic (un tirage
// purement aléatoire pourrait sinon retomber sur la même par hasard, donnant l'impression
// que le clic n'a rien fait).
function uiRandomizeAvatarColor(event, participantId) {
    event.stopPropagation();
    const canChange = myRole === 'host' || participantId === myParticipantId;
    if (!canChange) return;
    const p = participants.find(x => x.id === participantId);
    if (!p) return;
    const current = avatarColorForId(participantId);
    const choices = AVATAR_COLOR_PALETTE.filter(c => c !== current);
    p.avatarColor = choices[Math.floor(Math.random() * choices.length)];
    // Voir échange avec Guillaume (session du 8 août — "qu'il récupère automatiquement
    // la dernière couleur utilisée à chaque nouvelle connexion") : persisté uniquement
    // quand c'est MA PROPRE couleur qui change — l'hôte peut aussi changer celle d'un
    // AUTRE participant (voir canChange ci-dessus), ça ne doit alors rien sauvegarder
    // dans son propre localStorage.
    if (participantId === myParticipantId) saveStringPref('bridgeBidAvatarColor', p.avatarColor);
    if (myRole === 'host') {
        broadcastLobbyState();
    } else if (participantId === myParticipantId && deferredRoomMode) {
        // R14 — en différé, le cloud est l'autorité de convergence même si le P2P est
        // actuellement ouvert. Contrairement aux annonces (R11), une couleur d'avatar
        // n'a pas besoin d'un double chemin : l'UI locale est déjà mise à jour ci-dessus
        // et la mutation serveur est idempotente. Éviter le P2P ici supprime une course
        // où un message considéré "envoyé" pouvait se perdre silencieusement avant la
        // persistance par l'hôte.
        pushAvatarColorViaServerFallback(p.avatarColor);
    } else if (participantId === myParticipantId && peerConn && peerConn.isConnected()) {
        // Live connecté : chemin P2P historique. Un invité n'a jamais le droit d'émettre
        // un lobby-state complet ; l'hôte lie l'identité à la connexion, valide la palette
        // puis rediffuse son état public autoritaire.
        peerConn.send({ type: 'set-avatar-color', avatarColor: p.avatarColor });
    } else if (participantId === myParticipantId) {
        // Live avec coupure P2P : l'API restreinte autorise la mutation du profil propre.
        pushAvatarColorViaServerFallback(p.avatarColor);
    }
    renderLobby();
    // Voir échange avec Guillaume (session du 23 juillet) : le changement de couleur est
    // maintenant possible EN COURS DE PARTIE aussi (voir interactiveAvatarHtml dans
    // renderRoomBoard), pas seulement dans le salon — il faut alors aussi rafraîchir le
    // room board et le chat (la couleur du nom de l'expéditeur y reprend
    // avatarColorForId), sinon le changement resterait invisible jusqu'au prochain
    // rafraîchissement fortuit de l'écran de jeu. Ces deux fonctions se protègent déjà si
    // leurs éléments respectifs n'existent pas, donc rien à garder ici.
    renderRoomBoard();
    renderChat();
}

// Voir échange avec Guillaume (session du 23 juillet) : même mécanisme de changement de
// couleur au clic que dans le salon (voir avatar-color-trigger ci-dessous, dans
// renderParticipantsList), mais réutilisable ici pour le room board — permet à l'hôte de
// changer la couleur de N'IMPORTE QUI, et à chacun la sienne, y compris EN COURS DE
// PARTIE (avant, ce n'était possible que dans le salon, avant le lancement).
function interactiveAvatarHtml(participantId) {
    const canChangeColor = myRole === 'host' || participantId === myParticipantId;
    const html = avatarHtml(participantId);
    return canChangeColor
        ? `<span class="avatar-color-trigger" data-ui-click="randomize-avatar" data-participant-id="${escapeHtml(participantId)}" title="Changer de couleur">${html}</span>`
        : html;
}

function renderParticipantsList() {
    const list = document.getElementById('participantsList');
    // Si l'hôte est en train de renommer quelqu'un, on ne reconstruit pas la liste
    // (un reflow ici lui ferait perdre le focus et le curseur en pleine frappe).
    if (document.activeElement && document.activeElement.classList.contains('participant-rename-input')) {
        return;
    }
    const isHost = myRole === 'host';
    // Cette liste EST la liste kibbitz (voir échange avec Guillaume) : quelqu'un qui
    // arrive est kibbitz par défaut, et le reste tant que l'hôte ne lui a pas assigné de
    // siège — il n'y a donc plus besoin de distinguer "assis"/"pas assis" ici comme
    // avant (voir l'ancien placementClass), puisque tout le monde affiché ici est de
    // toute façon sans siège par construction. Une fois assis, quelqu'un disparaît d'ici
    // et apparaît dans sa case de siège à la place (voir renderSeatAssignmentGrid) — d'où
    // la fusion avec l'ancien bloc kibbitz séparé sous la grille, devenu redondant.
    const kibitzers = participants.filter(p => !participantHasAPlace(p.id));
    list.innerHTML = kibitzers.map(p => {
        const canRename = isHost && p.id !== myParticipantId;
        // Nom en texte simple par défaut, converti en champ éditable seulement au CLIC
        // explicite (voir échange avec Guillaume et uiStartRenamingParticipant) : un
        // <input> toujours présent capte le focus au moindre appui, y compris un
        // appui-maintenu qui visait en fait à démarrer un glisser-déposer — ce qui
        // basculait à tort en mode "renommer" au lieu de laisser le glisser s'amorcer.
        const nameHtml = canRename
            ? `<span class="participant-name participant-name-editable" data-ui-click="rename-participant" data-participant-id="${escapeHtml(p.id)}">${escapeHtml(p.name)}</span>`
            : `<span class="participant-name">${escapeHtml(p.name)}</span>`;
        // Glissable vers une case de siège (voir uiDropOnSeat) — seulement pour l'hôte,
        // seul à pouvoir réorganiser qui est où (voir uiDragStartParticipant).
        const dragAttrs = isHost ? ` draggable="true" data-ui-dragstart="participant" data-participant-id="${escapeHtml(p.id)}"` : '';
        // Clic sur l'avatar pour changer de couleur au hasard (voir échange avec
        // Guillaume, uiRandomizeAvatarColor) : l'hôte peut le faire pour n'importe qui,
        // les autres seulement pour eux-mêmes.
        const canChangeColor = isHost || p.id === myParticipantId;
        const avatarHtmlBlock = canChangeColor
            ? `<span class="avatar-color-trigger" data-ui-click="randomize-avatar" data-participant-id="${escapeHtml(p.id)}" title="Changer de couleur">${avatarHtml(p.id)}</span>`
            : avatarHtml(p.id);
        return `
        <li class="participant-item ${p.id === myParticipantId ? 'is-me' : ''}"${dragAttrs}>
            ${avatarHtmlBlock}
            ${nameHtml}
            ${p.id === 'host' ? ' <span class="host-tag">(hôte)</span>' : ''}
            ${p.id === myParticipantId ? ' <span class="me-tag">(vous)</span>' : ''}
            ${p.disconnected ? ' <span class="disconnected-tag">🔌 déconnecté — place réservée</span>' : ''}
        </li>
    `;
    }).join('');
}

// Remplace un span de nom par un champ éditable (voir échange avec Guillaume) — factorisé
// pour être appelable soit avec le span cliqué directement (voir uiStartRenamingParticipant
// ci-dessous), soit avec un span retrouvé autrement (voir uiHandleWizzableNameClick, où
// l'élément cliqué n'est pas exactement celui à remplacer — voir plus bas).
function startRenameOnSpan(span, participantId) {
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'participant-rename-input';
    input.maxLength = 20;
    // Repart du nom COMPLET stocké côté participant plutôt que de span.textContent : ce
    // dernier peut contenir des décorations qui ne font pas partie du nom lui-même (ex.
    // la cloche 🔔 dans le room board, voir wizzableNameHtml).
    const p = participants.find(x => x.id === participantId);
    input.value = p ? p.name : span.textContent;
    input.oninput = () => uiRenameParticipant(participantId, input.value);
    input.onblur = () => uiRenameParticipantBlur(participantId, input);
    span.replaceWith(input);
    input.focus();
    input.select();
}

// Convertit le nom (affiché en texte simple, voir renderParticipantsList) en champ
// éditable au clic explicite — voir échange avec Guillaume : un <input> permanent aurait
// capté le focus dès un simple appui-maintenu voulant démarrer un glisser-déposer.
// stopPropagation évite que ce clic ne déclenche autre chose sur le <li> parent.
function uiStartRenamingParticipant(event, participantId) {
    event.stopPropagation();
    startRenameOnSpan(event.currentTarget, participantId);
}

let participantRenameDebounceTimers = {};
// Renommage d'un participant par l'hôte. On met à jour et on diffuse, mais sans
// reconstruire la liste des participants pendant la frappe (voir garde ci-dessus) — la
// grille des sièges, elle, peut se rafraîchir sans risque puisqu'elle ne contient pas le
// champ en cours d'édition.
function uiRenameParticipant(participantId, value) {
    if (myRole !== 'host') return;
    clearTimeout(participantRenameDebounceTimers[participantId]);
    participantRenameDebounceTimers[participantId] = setTimeout(() => {
        const trimmed = value.trim();
        if (!trimmed) return; // idem que pour son propre nom : on attend le blur si le champ est vide
        const p = participants.find(x => x.id === participantId);
        if (!p) return;
        p.name = trimmed;
        broadcastLobbyState();
        renderSeatAssignmentGrid();
        // Voir échange avec Guillaume (session du 23 juillet) : le renommage est
        // maintenant aussi possible depuis le chat en cours de partie (voir renderChat) —
        // ces deux affichages reflètent aussi les noms, donc à tenir à jour ici comme
        // renderSeatAssignmentGrid. renderChat() se protège elle-même si SON PROPRE input
        // de renommage est actif (pas de risque de l'écraser en pleine frappe).
        renderRoomBoard();
        renderChat();
    }, 300);
}

// Si l'hôte quitte le champ en le laissant vide, on retombe sur le nom par défaut
// de ce participant plutôt que de laisser un pseudo vide.
function uiRenameParticipantBlur(participantId, inputEl) {
    if (myRole !== 'host') return;
    clearTimeout(participantRenameDebounceTimers[participantId]);
    const p = participants.find(x => x.id === participantId);
    if (!p) return;
    const trimmed = inputEl.value.trim();
    p.name = trimmed || defaultParticipantName(participantId);
    // Voir échange avec Guillaume (session du 23 juillet) : l'hôte peut désormais se
    // renommer lui-même via ce même mécanisme (voir wizzableNameHtml) — le champ pseudo
    // du salon (myNameInput) n'est mis à jour qu'à l'entrée dans le salon, donc à
    // resynchroniser explicitement ici pour ne pas y laisser l'ancien nom.
    if (participantId === myParticipantId) {
        const nameInput = document.getElementById('myNameInput');
        if (nameInput) nameInput.value = p.name;
    }
    broadcastLobbyState();
    renderLobby();
    // Voir échange avec Guillaume (session du 23 juillet) : idem qu'au-dessus — le champ
    // vient de perdre le focus (voir onblur), donc la garde de renderChat() ne bloque
    // plus rien : le nom se met à jour immédiatement dans les messages déjà affichés.
    renderRoomBoard();
    renderChat();
}

// Voir échange avec Guillaume (session du 23 juillet — passage à un brouillon pour la
// modale de réorganisation) : construction des 4 cases factorisée ici, partagée entre la
// grille LIVE du salon (renderSeatAssignmentGrid, applique immédiatement) et la grille
// PROVISOIRE de la modale de réorganisation en cours de partie (renderSeatReorgModalGrid,
// n'applique qu'à la validation) — `assignmentObj` est l'assignation à afficher (peut être
// `seatAssignment` la vraie, ou `seatReorgDraft` un brouillon), `onSelect` le nom de la
// fonction appelée au clic sur une option (diffère : immédiat pour le salon, brouillon
// seulement pour la modale). `enableDrag`/`withFlash` n'ont de sens que pour la grille live
// (le glisser-déposer et l'animation d'arrivée/départ ne concernent que l'état réel).
function robotSeatDisplayName(seat) {
    return SEAT_FULL_NAME[seat];
}

function buildSeatBoxesHtml(assignmentObj, onSelect, { enableDrag = false, withFlash = false } = {}) {
    const isHost = myRole === 'host';

    // Un siège "vient d'être assigné" si son occupant est non vide ET différent de ce
    // qu'il était au rendu précédent (couvre à la fois une case vide qui se remplit et un
    // changement d'occupant) — voir prevSeatAssignmentSnapshot pour le cas particulier du
    // tout premier rendu.
    const justAssigned = seat => {
        if (!withFlash || prevSeatAssignmentSnapshot === null) return false;
        const assignedId = assignmentObj[seat];
        return !!assignedId && assignedId !== prevSeatAssignmentSnapshot[seat];
    };

    // Symétrique de justAssigned (voir échange avec Guillaume) : un siège "vient d'être
    // libéré" s'il était occupé au rendu précédent et ne l'est plus maintenant — même
    // effet visuel que l'arrivée, pour signaler tout autant le départ.
    const justVacated = seat => {
        if (!withFlash || prevSeatAssignmentSnapshot === null) return false;
        return !!prevSeatAssignmentSnapshot[seat] && !assignmentObj[seat];
    };

    return SEATS.map(seat => {
        const assignedId = assignmentObj[seat];
        const flashClass = justAssigned(seat) ? ' just-assigned' : (justVacated(seat) ? ' just-vacated' : '');
        if (isHost) {
            // Menu déroulant personnalisé (voir échange avec Guillaume) plutôt qu'un
            // <select> natif : un <option> ne peut pas contenir d'avatar coloré, alors
            // Glissable depuis TOUTE la case, pas seulement le petit déclencheur (voir
            // échange avec Guillaume) — même surface que la zone de dépôt (déjà sur la
            // case entière, voir ondragover/ondrop plus bas), pour une prise en main
            // cohérente dans les deux sens. Uniquement sur la grille live (enableDrag) :
            // la modale de réorganisation n'a pas de glisser-déposer, seulement les menus.
            const isPending = assignedId === SEAT_PENDING;
            const occupantP = (assignedId && !isPending) ? participants.find(x => x.id === assignedId) : null;
            const canNativeDrag = enableDrag && occupantP
                && (!window.matchMedia || window.matchMedia('(hover: hover) and (pointer: fine)').matches);
            const boxDragAttrs = canNativeDrag ? ` draggable="true" data-ui-dragstart="participant" data-participant-id="${escapeHtml(assignedId)}" data-from-seat="${seat}"` : '';
            const dropAttrs = enableDrag ? ` data-ui-dragover="allow-drop" data-ui-dragenter="drop-target" data-ui-dragleave="drop-target" data-ui-drop="seat" data-seat="${seat}"` : '';
            const triggerContent = occupantP
                ? `${avatarHtml(assignedId)}<span class="kibitz-chip-name">${escapeHtml(occupantP.name)}</span>`
                : isPending
                    ? `<span class="mini-avatar mini-avatar-pending">⏳</span><span class="kibitz-chip-name">En attente…</span>`
                    : `<span class="mini-avatar mini-avatar-robot">🤖</span><span class="kibitz-chip-name">Robot</span>`;

            const robotOptionClass = assignedId ? '' : ' is-current';
            const pendingOptionClass = isPending ? ' is-current' : '';
            const canSelectPending = !deals || deferredRoomMode || isPending;
            const pendingOptionHtml = canSelectPending ? `
                <div class="seat-dropdown-option${pendingOptionClass}" data-seat-select="1" data-ui-seat-handler="${onSelect === 'uiStageSeatAssignment' ? 'stage' : 'assign'}" data-seat="${seat}" data-participant-id="${SEAT_PENDING}">
                    <span class="mini-avatar mini-avatar-pending">⏳</span><span>En attente d'un partenaire</span>
                </div>
            ` : '';
            const optionsHtml = [`
                <div class="seat-dropdown-option${robotOptionClass}" data-seat-select="1" data-ui-seat-handler="${onSelect === 'uiStageSeatAssignment' ? 'stage' : 'assign'}" data-seat="${seat}" data-participant-id="">
                    <span class="mini-avatar mini-avatar-robot">🤖</span><span>Robot</span>
                </div>
                ${pendingOptionHtml}
            `].concat(participants.map(p => {
                const currentClass = p.id === assignedId ? ' is-current' : '';
                return `
                    <div class="seat-dropdown-option${currentClass}" data-seat-select="1" data-ui-seat-handler="${onSelect === 'uiStageSeatAssignment' ? 'stage' : 'assign'}" data-seat="${seat}" data-participant-id="${escapeHtml(p.id)}">
                        ${avatarHtml(p.id)}<span>${escapeHtml(p.name)}</span>
                    </div>
                `;
            }));

            return `
                <div class="seat-box seat-pos-${seat}${flashClass}" data-seat-toggle="1" data-seat="${seat}"${boxDragAttrs}${dropAttrs}>
                    <span class="seat-box-label">${SEAT_FULL_NAME[seat]}</span>
                    <div class="seat-occupant-dropdown">
                        <button type="button" class="kibitz-chip seat-occupant-chip${occupantP ? '' : ' seat-occupant-chip-robot'}" data-seat="${seat}" aria-label="Choisir l’occupant du siège ${SEAT_FULL_NAME[seat]}">
                            ${triggerContent}
                            <span class="seat-dropdown-chevron">▾</span>
                        </button>
                        <div class="seat-dropdown-menu" style="display:none;">${optionsHtml.join('')}</div>
                    </div>
                </div>
            `;
        }
        const isPendingReadOnly = assignedId === SEAT_PENDING;
        const p = (assignedId && !isPendingReadOnly) ? participants.find(x => x.id === assignedId) : null;
        const name = p ? escapeHtml(p.name) : (isPendingReadOnly ? 'En attente…' : 'Robot');
        const nameRowHtml = p
            ? `${avatarHtml(assignedId)}<span class="seat-box-name">${name}</span>`
            : isPendingReadOnly
                ? `<span class="mini-avatar mini-avatar-pending">⏳</span><span class="seat-box-name">${name}</span>`
                : `<span class="mini-avatar mini-avatar-robot">🤖</span><span class="seat-box-name">${name}</span>`;
        return `
            <div class="seat-box seat-pos-${seat}${flashClass}">
                <span class="seat-box-label">${SEAT_FULL_NAME[seat]}</span>
                <span class="seat-box-name-row">
                    ${nameRowHtml}
                </span>
            </div>
        `;
    }).join('');
}

function bindSeatBoxToggleHandlers(container) {
    if (!container) return;

    // OLD avait deux gestes directs : le déclencheur ouvrait/fermait le menu et chaque
    // option appliquait le choix puis fermait. On reproduit cette mécanique sans onclick
    // inline, mais avec de VRAIS listeners sur les éléments rendus — aucun de ces gestes ne
    // dépend désormais d'un listener global sur document.
    container.querySelectorAll('.seat-dropdown-option[data-seat-select="1"]').forEach((option) => {
        option.addEventListener('click', (event) => {
            event.stopPropagation();
            const seat = option.dataset.seat || '';
            const participantId = option.dataset.participantId || '';
            try {
                if (option.dataset.uiSeatHandler === 'stage') uiStageSeatAssignment(seat, participantId);
                else uiAssignSeat(seat, participantId);
            } finally {
                // Même en cas d'erreur applicative aval, un choix ne doit jamais laisser
                // le menu visuellement coincé ouvert.
                uiCloseSeatDropdowns();
            }
        });
    });

    container.querySelectorAll('.seat-box[data-seat-toggle="1"]').forEach((seatBox) => {
        // Listener posé sur la CASE elle-même. Le stopPropagation se produit donc AVANT
        // d'atteindre document et ne dépend plus de l'ordre des listeners délégués.
        seatBox.addEventListener('click', (event) => {
            uiToggleSeatDropdown(event, seatBox.dataset.seat || '');
        });
    });
}

function renderSeatAssignmentGrid() {
    const container = document.getElementById('seatAssignmentGrid');
    if (!container) return;
    container.innerHTML = buildSeatBoxesHtml(seatAssignment, 'uiAssignSeat', { enableDrag: true, withFlash: true });
    bindSeatBoxToggleHandlers(container);
    prevSeatAssignmentSnapshot = { ...seatAssignment };
}

// Voir échange avec Guillaume (session du 23 juillet) : grille de la modale de
// réorganisation en cours de partie — affiche seatReorgDraft (le brouillon), pas
// seatAssignment (l'état réel), et route les sélections vers uiStageSeatAssignment (qui ne
// fait que modifier le brouillon) plutôt que uiAssignSeat (qui appliquerait immédiatement).
function renderSeatReorgModalGrid() {
    const container = document.getElementById('seatReorgModalGrid');
    if (!container || !seatReorgDraft) return;
    container.innerHTML = buildSeatBoxesHtml(seatReorgDraft, 'uiStageSeatAssignment', { enableDrag: false, withFlash: false });
    bindSeatBoxToggleHandlers(container);
}

let nameUpdateDebounceTimer = null;
function uiUpdateMyName() {
    clearTimeout(nameUpdateDebounceTimer);
    nameUpdateDebounceTimer = setTimeout(() => {
        const input = document.getElementById('myNameInput');
        const trimmed = input.value.trim();
        // Champ momentanément vide (l'utilisateur efface pour retaper autre chose) :
        // on n'impose pas le nom par défaut ici, seulement au blur (voir uiMyNameBlur).
        // Sinon on écrase ce que la personne est en train de saisir.
        if (!trimmed) return;

        const me = participants.find(p => p.id === myParticipantId);
        if (me) me.name = trimmed;
        saveStringPref('bridgeBidNickname', trimmed);
        savedNickname = trimmed;
        if (myRole === 'guest' && myParticipantId) rememberGuestRoomDisplayName(currentRoomCode, myParticipantId, trimmed);

        if (myRole === 'host') {
            broadcastLobbyState();
            renderLobby();
        } else if (peerConn) {
            peerConn.send({ type: 'set-name', name: trimmed });
            renderLobby();
        }
    }, 300);
}

// Si l'utilisateur quitte le champ en le laissant vide, on retombe sur le nom par
// défaut (au lieu de laisser un pseudo vide affiché aux autres) — et on efface le pseudo
// sauvegardé : revenir explicitement au nom générique doit aussi valoir pour la
// prochaine fois, pas seulement pour la session en cours.
function uiMyNameBlur() {
    const input = document.getElementById('myNameInput');
    if (input.value.trim()) return;
    clearTimeout(nameUpdateDebounceTimer);
    const name = defaultParticipantName(myParticipantId);
    input.value = name;
    const me = participants.find(p => p.id === myParticipantId);
    if (me) me.name = name;
    saveStringPref('bridgeBidNickname', null);
    savedNickname = null;

    if (myRole === 'host') {
        broadcastLobbyState();
        renderLobby();
    } else if (peerConn) {
        peerConn.send({ type: 'set-name', name });
        renderLobby();
    }
}

// Menu déroulant personnalisé des sièges (voir échange avec Guillaume) : un seul ouvert à
// la fois. stopPropagation empêche le clic d'atteindre le gestionnaire global qui ferme
// tout au clic ailleurs (voir plus bas) — sans ça, ouvrir un menu le refermerait aussitôt.
// Élève aussi le z-index de LA CASE ENTIÈRE (pas seulement le menu) tant qu'il est ouvert
// (voir échange avec Guillaume, menu de Nord/Est passant derrière une case voisine) : les
// cases de siège partagent toutes le même z-index de base, donc celle qui vient après dans
// le DOM peint par-dessus — augmenter le seul z-index du menu ne suffit pas, puisqu'il
// reste enfermé dans le contexte d'empilement (plus bas) de sa propre case.
function uiToggleSeatDropdown(event, seat) {
    event.stopPropagation();
    // Voir échange avec Guillaume (session du 23 juillet) : recherche scopée au bouton
    // cliqué (voir la structure HTML dans renderSeatAssignmentGrid — le menu est le
    // sibling suivant du bouton, tous deux enfants directs de .seat-occupant-dropdown),
    // plutôt qu'un id global "seatDropdownMenu-${seat}" — maintenant que la grille peut
    // exister en double (salon + modale de réorganisation en cours de partie), un id
    // global ne trouverait toujours que la PREMIÈRE des deux copies.
    const seatBox = event.currentTarget.closest ? event.currentTarget.closest('.seat-box') : null;
    const menu = seatBox ? seatBox.querySelector('.seat-dropdown-menu') : null;
    if (!menu) return;
    const wasOpen = menu.style.display !== 'none';
    uiCloseSeatDropdowns();
    if (!wasOpen) {
        menu.style.display = 'block';
        if (seatBox) seatBox.classList.add('dropdown-open');
    }
}

function uiCloseSeatDropdowns() {
    document.querySelectorAll('.seat-dropdown-menu').forEach(m => { m.style.display = 'none'; });
    document.querySelectorAll('.seat-box.dropdown-open').forEach(b => { b.classList.remove('dropdown-open'); });
}

// Ferme les menus seulement lors d'un VRAI clic extérieur. Depuis la migration CSP vers
// La case possède maintenant son propre listener réel (bindSeatBoxToggleHandlers), au lieu
// de faire remonter son toggle jusqu'au routeur global de ui-events.js. C'est le point qui
// reproduit réellement la sémantique de OLD : le second clic voit le menu encore ouvert,
// le ferme, puis stopPropagation empêche tout autre listener document de le rouvrir.
function uiCloseSeatDropdownsOnOutsideClick(event) {
    const target = event && event.target instanceof Element ? event.target : null;
    if (target && target.closest('.seat-box[data-seat-toggle="1"]')) return;
    uiCloseSeatDropdowns();
}
document.addEventListener('click', uiCloseSeatDropdownsOnOutsideClick);

async function uiAssignSeat(seat, participantId) {
    if (myRole !== 'host') return;
    // R10 — convertir une salle live déjà lancée en différé est une transition de sécurité
    // complète (rotation d'accessKey + pré-autorisation + changement d'autorité). L'ancien
    // menu exposait PENDING en pleine partie sans exécuter cette transition. Fail-closed :
    // le mode différé se choisit avant le lancement ; dans une partie déjà différée, PENDING
    // reste utilisable pour réouvrir une place partenaire.
    if (deals && !deferredRoomMode && participantId === SEAT_PENDING) {
        flashPresenceToast('⏳ Le mode différé se choisit avant de lancer la partie', false);
        return;
    }
    // PAS de retrait automatique de l'ancien siège de cette personne (voir échange avec
    // Guillaume) : contrôler plusieurs sièges à la fois est une fonctionnalité voulue
    // depuis le début (mySeats est un tableau, pas une valeur unique — voir
    // renderMyHands, showActiveState) — un ancien correctif avait traité ça à tort comme
    // un bug de duplication, alors que c'est exactement ce que cette assignation doit
    // pouvoir faire.
    const previousOccupant = seatAssignment[seat] || null;
    seatAssignment[seat] = participantId || null;
    // Dans une partie différée déjà lancée, une nouvelle attribution humaine ne devient
    // visible qu'après enregistrement de sa preuve serveur. Cela ferme la même fenêtre que
    // le bug R8/R9, mais lors d'une réorganisation de sièges plutôt qu'au join initial.
    if (deals && deferredRoomMode && participantId && participantId !== SEAT_PENDING && participantId !== 'host') {
        const p = participants.find(x => x && x.id === participantId);
        if (p && !p.disconnected && guestIndexForParticipant(participantId) != null) {
            const ready = await sendSessionAccessToParticipant(participantId);
            if (!ready) {
                seatAssignment[seat] = previousOccupant;
                autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
                flashPresenceToast('⚠️ Attribution annulée : accès serveur du joueur non prêt', false);
                renderLobby();
                if (deals) renderBoard();
                return;
            }
        }
    }
    // Prépare immédiatement l'identité secrète du futur partenaire tant que le host est
    // encore là. L'enregistrement HTTP tourne en arrière-plan ; le lien peut être copié
    // tout de suite et contient déjà la même credential.
    if (participantId === SEAT_PENDING && currentRoomCode) ensureDeferredInviteCredentialRegistered(currentRoomCode);
    // Le lien différé embarque ses capacités uniquement lorsqu'un siège PENDING est
    // réellement présent. Mettre le champ à jour immédiatement évite de copier l'ancien
    // lien court créé avant le choix "En attente…".
    if (!deals && currentRoomCode) updateShareLinkForRoom(currentRoomCode);
    // Voir échange avec Guillaume (session du 23 juillet — "le bot n'enchérit pas") :
    // autoPassSeats (qui détermine quels sièges sont pilotés par un robot) n'était calculé
    // qu'une fois, au lancement de la partie — jamais mis à jour quand un siège change de
    // main ensuite. Recalculé ici avant la diffusion, sinon un siège tout juste rendu à
    // "Robot" restait un simple trou muet, personne (ni humain ni robot) pour y jouer.
    if (deals) autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
    if (!deals || !deferredRoomMode) grantSessionAccessToSeatedParticipants();
    broadcastLobbyState();
    renderLobby();
    // Voir échange avec Guillaume ("ce qui n'est pas encore couvert" — changement de
    // sièges via le relais serveur) : sans ça, un participant en repli serveur (voir
    // ARCHITECTURE-P2P-SERVEUR.md, étape 3) ne voyait JAMAIS un changement de siège
    // avant de se reconnecter en P2P — rien ne le poussait jusqu'ici vers le cloud. Sans
    // effet avant le lancement de la partie (voir la garde `!deals` à l'intérieur de la
    // fonction elle-même).
    saveHostGameStateToStorage();
    // Voir échange avec Guillaume (session du 23 juillet — "le bot n'enchérit pas") :
    // cette grille est maintenant aussi accessible EN COURS DE PARTIE (voir
    // uiOpenSeatReorgModal) — même rafraîchissement de l'écran de jeu que pour le
    // glisser-déposer (uiDropOnSeat).
    if (deals) {
        mySeats = SEATS.filter(s => seatAssignment[s] === myParticipantId);
        renderBoard();
    }
}

// Cliquer-glisser pour réorganiser les sièges (voir échange avec Guillaume) : glisser un
// "bouton" (chip kibbitz ou occupant d'un siège) sur une case de siège l'y assigne ; sur
// la zone kibbitz, ça le libère. Si la cible était déjà occupée, on ÉCHANGE les deux
// places plutôt que d'écraser l'occupant précédent (qui redevient sinon kibbitz
// silencieusement) — sauf si la source vient déjà du kibbitz, auquel cas rien à échanger,
// l'ancien occupant de la case cible devient simplement kibbitz à son tour. Réservé à
// l'hôte (seul à pouvoir réorganiser les sièges) — voir les gardes `myRole !== 'host'`.
// Retour visuel sur la zone de dépôt survolée (voir échange avec Guillaume) : dragenter/
// dragleave plutôt que dragover pour basculer la classe — dragover se redéclenche en
// continu tant qu'on survole, alors qu'on ne veut ajouter/retirer la classe qu'une seule
// fois. `relatedTarget` (l'élément vers lequel le curseur va) sert à distinguer une
// VRAIE sortie de la zone d'un simple passage sur l'un de ses propres enfants (le bouton,
// le menu déroulant) — sans cette vérification, la surbrillance clignoterait en
// traversant ces enfants alors qu'on est toujours au-dessus de la même case (voir échange
// avec Guillaume : elle doit rester allumée tant qu'un dépôt y placerait effectivement la
// personne). Plus fiable qu'un simple compteur d'entrées/sorties, dont l'ordre de
// déclenchement entre navigateurs n'est pas garanti dans ce cas précis.
function uiDragEnterTarget(event) {
    if (myRole !== 'host') return;
    event.currentTarget.classList.add('drag-over-target');
}

function uiDragLeaveTarget(event) {
    const el = event.currentTarget;
    if (event.relatedTarget && el.contains(event.relatedTarget)) return; // reste dans la même zone, juste passé sur un enfant
    el.classList.remove('drag-over-target');
}

// Filet de sécurité : si le glisser se termine autrement que par un dépôt valide (touche
// Échap, relâché hors de toute zone reconnue...), retire toute surbrillance encore
// affichée plutôt que de la laisser collée jusqu'au prochain rendu.
document.addEventListener('dragend', () => {
    document.querySelectorAll('.drag-over-target').forEach(el => el.classList.remove('drag-over-target'));
    draggedParticipantId = null;
    draggedFromSeat = null;
});

let draggedParticipantId = null;
// Siège d'ORIGINE précis du glissé, mémorisé explicitement au démarrage (voir échange
// avec Guillaume) — plutôt que de le retrouver après coup via SEATS.find(seatAssignment
// === draggedParticipantId), qui tombe toujours sur le PREMIER siège occupé par cette
// personne, peu importe lequel a réellement été glissé. Ça cassait le retrait d'un siège
// précis quand la même personne en occupe deux à la fois (voir uiAssignSeat, qui autorise
// maintenant cette situation) : glisser sa case Sud vers le kibbitz libérait Nord à la
// place, puisque Nord était trouvé en premier dans SEATS. `null` si le glissé vient du
// kibbitz (pas de siège d'origine).
let draggedFromSeat = null;

// Voir échange avec Guillaume (session du 23 juillet) : brouillon d'assignation utilisé
// par la modale de réorganisation des sièges (voir uiOpenSeatReorgModal/
// uiStageSeatAssignment/uiValidateSeatReorg) — copie de seatAssignment modifiée localement
// pendant que la modale est ouverte, appliquée à la vraie assignation UNIQUEMENT au clic
// sur "Valider". `null` tant que la modale n'est pas ouverte.
let seatReorgDraft = null;

function uiDragStartParticipant(event, participantId, fromSeat) {
    if (myRole !== 'host') { event.preventDefault(); return; }
    draggedParticipantId = participantId;
    draggedFromSeat = fromSeat || null;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', participantId);
}

function uiAllowDrop(event) {
    if (myRole !== 'host') return;
    event.preventDefault(); // requis par l'API HTML5 drag-and-drop pour autoriser un drop ici
}

async function uiDropOnSeat(event, targetSeat) {
    event.preventDefault();
    if (myRole !== 'host' || !draggedParticipantId) return;
    const sourceSeat = draggedFromSeat;
    if (sourceSeat === targetSeat) {
        draggedParticipantId = null;
        draggedFromSeat = null;
        event.currentTarget.classList.remove('drag-over-target');
        return; // déposé sur sa propre case, rien à faire
    }

    const previousSeatAssignment = { ...seatAssignment };
    const targetOccupant = seatAssignment[targetSeat];
    seatAssignment[targetSeat] = draggedParticipantId;
    if (sourceSeat) seatAssignment[sourceSeat] = targetOccupant || null; // échange ; sinon (venait du kibbitz) l'ancien occupant cible devient kibbitz de lui-même, rien à écrire

    draggedParticipantId = null;
    draggedFromSeat = null;
    // Voir échange avec Guillaume (session du 23 juillet — voir uiAssignSeat) : même
    // recalcul, pour le glisser-déposer.
    if (deals) autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
    if (deals && deferredRoomMode) {
        const results = await grantSessionAccessToSeatedParticipants();
        if (!sessionAccessGrantResultsReady(results)) {
            seatAssignment = previousSeatAssignment;
            autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
            flashPresenceToast('⚠️ Déplacement annulé : accès serveur d’un joueur non prêt', false);
            renderLobby();
            renderBoard();
            return;
        }
    } else {
        grantSessionAccessToSeatedParticipants();
    }
    broadcastLobbyState();
    renderLobby();
    // Voir échange avec Guillaume ("changement de sièges via le relais serveur") : même
    // ajout que uiAssignSeat — sans effet avant le lancement de la partie.
    saveHostGameStateToStorage();
    // Voir échange avec Guillaume (session du 23 juillet) : réassignation de siège
    // maintenant possible EN COURS DE PARTIE (voir renderRoomBoard/renderAuctionLedger) —
    // renderLobby() seul ne touche pas l'écran de jeu, donc à rafraîchir explicitement ici
    // (mySeats recalculé au passage, au cas où l'hôte lui-même vient d'être déplacé).
    if (deals) {
        mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
        renderBoard();
    }
}

function uiDropOnKibitz(event) {
    event.preventDefault();
    if (myRole !== 'host' || !draggedParticipantId) return;
    if (draggedFromSeat) seatAssignment[draggedFromSeat] = null;
    draggedParticipantId = null;
    draggedFromSeat = null;
    // Voir échange avec Guillaume (session du 23 juillet — voir uiAssignSeat) : même
    // recalcul — un siège libéré vers le kibbitz redevient robot lui aussi.
    if (deals) autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
    broadcastLobbyState();
    renderLobby();
    // Voir échange avec Guillaume ("changement de sièges via le relais serveur") : même
    // ajout que uiAssignSeat/uiDropOnSeat.
    saveHostGameStateToStorage();
    // Voir uiDropOnSeat ci-dessus : même rafraîchissement du côté écran de jeu.
    if (deals) {
        mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
        renderBoard();
    }
}

const SEAT_CLOCKWISE_NEXT = { N: 'E', E: 'S', S: 'W', W: 'N' };

// Voir échange avec Guillaume ("l'invité ne se reconnecte jamais tout seul") : posé chez
// TOUT invité déconnecté (voir ARCHITECTURE-P2P-SERVEUR.md, étape 4 — l'ancienne
// toute distinction de participant de secours a disparu) — retente une reconnexion complète
// toutes les GUEST_AUTO_RECONNECT_INTERVAL_MS, en tâche de fond, sans qu'aucun clic ne
// soit nécessaire. Se reprogramme lui-même à chaque tentative tant que la déconnexion
// dure — onGuestConnected (voir buildGuestHandlers) l'annule dès qu'une reconnexion
// réussit, qu'elle vienne de ce minuteur ou d'un clic manuel entre-temps.
function scheduleGuestAutoReconnect() {
    if (myRole !== 'guest') return;
    if (guestAutoReconnectTimer) return; // déjà programmé, pas la peine d'en reposer un
    guestAutoReconnectTimer = setTimeout(() => {
        guestAutoReconnectTimer = null;
        attemptGuestAutoReconnect();
    }, GUEST_AUTO_RECONNECT_INTERVAL_MS);
}

function cancelGuestAutoReconnectTimer() {
    if (guestAutoReconnectTimer) {
        clearTimeout(guestAutoReconnectTimer);
        guestAutoReconnectTimer = null;
    }
}

// Revérifie tout avant d'agir (le contexte a pu changer entre-temps, ex. déjà reconnecté
// par un clic manuel juste avant que ce minuteur ne se déclenche) puis retente une
// reconnexion complète, exactement comme uiReconnect — et se reprogramme pour la
// prochaine tentative si celle-ci ne suffit pas à elle seule à rétablir la connexion
// (onGuestConnected annulera ce cycle dès que ça aboutit réellement).
// Voir échange avec Guillaume ("l'enchère disparaît une fois reconnecté") : incrémenté à
// chaque nouvelle relecture lancée dans attemptGuestAutoReconnect, ET à chaque
// reconnexion P2P réussie (voir onGuestConnected) — sert à rejeter une réponse arrivée en
// retard d'une relecture PRÉCÉDENTE, lancée avant que l'état ait bougé (ma propre annonce
// via le relais serveur, ou une reconnexion P2P entre-temps). Sans ça, plusieurs
// relectures se chevauchaient (une nouvelle lancée toutes les 4s, sans jamais annuler ni
// attendre la précédente) et pouvaient revenir DANS LE DÉSORDRE — la dernière à répondre
// l'emportait, pas la plus récente à avoir été lancée, écrasant parfois un état déjà
// correctement synchronisé (par la reconnexion) avec une version plus vieille.
let guestPullSequence = 0;

function attemptGuestAutoReconnect() {
    if (myRole !== 'guest' || !currentRoomCode) return;
    recordSyncTrace('reconnect.guest.attempt');
    if (peerConn && peerConn.isConnected()) return; // déjà reconnecté entre-temps (onGuestConnected a dû annuler ce cycle)
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : tant que la reconnexion P2P n'a pas
    // encore réussi, relit aussi l'état serveur en tâche de fond — sans ça, mon propre
    // écran resterait figé au moment exact de la coupure jusqu'à ce que je me
    // reconnecte vraiment, même si mon tour revient entre-temps via le relais serveur
    // (le partenaire/l'adversaire d'en face a annoncé, puis l'hôte ou un autre siège a
    // relayé cette annonce ailleurs). applyCloudUpdate est sûr à appeler ici même côté
    // invité : sa partie "relais P2P" ne se déclenche que pour myRole==='host', le
    // reste (recopie de l'état local) est neutre pour ce rôle.
    if (deals && typeof pullSessionState === 'function') {
        const mySequence = ++guestPullSequence;
        pullSessionState(currentRoomCode).then(result => {
            // Voir plus haut (guestPullSequence) : une reconnexion P2P (ou une relecture
            // plus récente) a pu aboutir entre-temps — ignore cette réponse si c'est le
            // cas, plutôt que d'écraser un état déjà à jour avec quelque chose de plus
            // vieux.
            if (mySequence !== guestPullSequence) return;
            if (peerConn && peerConn.isConnected()) return;
            if (result && result.version > lastKnownCloudVersion) applyCloudUpdate(result);
        }).catch(() => { /* panne réseau passagère, on retentera au prochain tick */ });
    }
    if (peerConn) peerConn.destroy();
    peerConn = new BridgePeerConnection(buildGuestHandlers());
    const credential = getGuestRoomCredential(currentRoomCode, true);
    if (!credential) return;
    pushDebugLog(`Reconnexion automatique en arrière-plan au salon ${currentRoomCode} avec l'identité ${credential.participantId.slice(0, 10)}…`);
    peerConn.joinRoom(currentRoomCode, guestConnectionMetadata(currentRoomCode, savedNickname, credential));
    scheduleGuestAutoReconnect();
}

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : les anciennes fonctions de prise automatique du rôle hôte ont été retirées d'ici —
// plus d'élection d'un nouvel hôte P2P en cas de coupure prolongée, superflue depuis le
// routage par siège (étape 3). L'hôte ne change plus jamais en cours de partie.

// Fait tourner l'assignation des sièges de 90° dans le sens horaire (voir échange avec
// Guillaume) : qui était à N se retrouve à E, qui était à E se retrouve à S, etc. Les
// mains restent fixées par position (N/E/S/O) — donc ça change qui joue quelle main à cet
// instant précis, pas les cartes elles-mêmes ni l'historique déjà enchéri (qui reste
// attaché aux sièges, comme au bridge réel). Volontairement utilisable à tout moment, y
// compris en pleine enchère (voir échange avec Guillaume, qui l'a explicitement demandé
// malgré le côté déroutant que ça peut avoir mi-enchère) — d'où le petit bandeau
// d'avertissement envoyé à tout le monde (voir flashSeatsRotatedToast), pour que personne
// ne découvre le changement de main en silence en plein réflexion.
function rotatedSeatAssignment(current) {
    const next = {};
    for (const seat of SEATS) {
        next[SEAT_CLOCKWISE_NEXT[seat]] = current[seat];
    }
    return next;
}

// Réservé au VRAI créateur (voir updateBoardControlVisibility et échange avec Guillaume,
// "en mode différé, l'invité ne devrait pas avoir... la rotation") : applique la rotation
// localement, recalcule mySeats/autoPassSeats en conséquence, diffuse le nouvel état à
// tout le monde, puis rafraîchit l'écran actuellement affiché (jeu ou salon selon le
// moment).
// Voir échange avec Guillaume : l'interrupteur est désormais formulé positivement :
// barre à droite / case cochée = robots ACTIFS. Purement local à l'hôte
// (voir robotBiddingMode) — pas de diffusion réseau nécessaire. La préférence persistée
// reste volontairement l'ancienne clé « passOnly » pour conserver la compatibilité avec
// les réglages déjà enregistrés : on sauvegarde donc son inverse.
function uiSetRobotBiddingMode(robotsActive) {
    if (myRole !== 'host') return;
    robotBiddingMode = robotsActive ? 'smart' : 'passOnly';
    saveBoolPref('bridgeBidRobotPassOnly', !robotsActive);
    const shortNtCheckbox = document.getElementById('robotShortNtModeCheckbox');
    if (shortNtCheckbox) shortNtCheckbox.disabled = !robotsActive;
}

// Active/désactive la variante 1SA faible. Le réglage est volontairement indépendant
// de « Robots actifs » : s'il est mémorisé pendant que les robots sont coupés, le
// système 12-14H reprend immédiatement dès qu'ils sont réactivés.
function uiSetRobotShortNtMode(enabled) {
    if (myRole !== 'host') return;
    robotShortNtMode = !!enabled;
    saveBoolPref('bridgeBidRobotShortNT', robotShortNtMode);
}

function uiRotateSeatsClockwise() {
    if (!isTrueOriginalHost()) return;
    seatAssignment = rotatedSeatAssignment(seatAssignment);
    autoPassSeats = SEATS.filter(seat => !seatAssignment[seat]);
    // myParticipantId plutôt que la chaîne littérale 'host' (voir échange avec Guillaume,
    // "2 modes : live / différé") : en mode différé, même le vrai créateur n'utilise plus
    // jamais 'host' (voir isDeferredMode au lancement) — seul myParticipantId identifie
    // correctement ses propres sièges dans les deux modes.
    mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);

    peerConn.send({ type: 'seats-rotated', seatAssignment, autoPassSeats });
    flashSeatsRotatedToast();
    // Voir échange avec Guillaume ("changement de sièges via le relais serveur") : même
    // ajout que uiAssignSeat.
    saveHostGameStateToStorage();

    if (deals) { renderBoard(); } else { renderLobby(); }
}

// Même mécanique de bandeau que les autres (voir flashWizzToast, uiShowCallExplanation) —
// prévient TOUT LE MONDE (hôte y compris) qu'une rotation vient d'avoir lieu, pour ne pas
// découvrir en silence qu'on joue soudain une autre main en pleine réflexion.
function flashSeatsRotatedToast() {
    let toast = document.getElementById('seatsRotatedToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'seatsRotatedToast';
        toast.className = 'call-explanation-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = '🔄 Les sièges ont tourné !';
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 3000);
}

function participantCredentialForCloudWrite() {
    if (!currentRoomCode || myParticipantId === 'host') return null;
    // R19 — ne PAS déduire mon autorité de la présence d'une hostWriteKey dans
    // localStorage : deux onglets/fenêtres du même profil la voient tous les deux.
    // L'identité produit (myParticipantId + preuve privée) décide de la voie participant ;
    // pushSessionState garantit ensuite qu'une credential explicitement fournie prime sur
    // toute clé hôte résiduelle du navigateur.
    const credential = getGuestRoomCredential(currentRoomCode, false);
    if (!credential || credential.participantId !== myParticipantId || !isValidReconnectSecret(credential.reconnectSecret)) return null;
    return credential;
}

function currentClientHasHostCloudWriteAuthority() {
    return isTrueOriginalHost()
        && typeof getSessionHostWriteKey === 'function'
        && !!getSessionHostWriteKey(currentRoomCode);
}

function currentClientParticipantCredentialForCloudWrite() {
    return isTrueOriginalHost() ? null : participantCredentialForCloudWrite();
}

// R22 — continuité d'un partenaire différé quand l'hôte disparaît.
//
// Le partenaire PENDING est volontairement pré-enregistré sous une identité déterministe
// dérivée du code. Après plusieurs cycles fermeture/reprise, la map locale de credential
// peut néanmoins être absente/ancienne alors que `myParticipantId` est toujours cette
// identité correcte. Dans ce cas, reconstruire uniquement SA preuve locale depuis le code
// est sûr : on ne change ni de participantId, ni de siège, ni les droits côté serveur.
function ensureDeferredGuestCloudWriteCredential() {
    if (myRole !== 'guest' || !deferredRoomMode || !currentRoomCode) {
        return participantCredentialForCloudWrite();
    }

    primeDeferredGuestCloudAccess();
    let credential = participantCredentialForCloudWrite();
    if (credential) return credential;

    if (typeof deferredCodeOnlyParticipantCredential !== 'function') return null;
    const deterministic = deferredCodeOnlyParticipantCredential(currentRoomCode);
    if (!deterministic || deterministic.participantId !== myParticipantId
            || !isValidReconnectSecret(deterministic.reconnectSecret)) return null;

    rememberGuestRoomCredential(currentRoomCode, deterministic);
    credential = participantCredentialForCloudWrite();
    if (credential) {
        recordSyncTrace('deferred.guest.credential-recovered-from-code', {
            roomCode: currentRoomCode, participantId: myParticipantId
        });
    }
    return credential;
}

function enterDeferredGuestCloudContinuityAfterPeerLoss(source) {
    if (myRole !== 'guest' || !deferredRoomMode || !currentRoomCode) return;
    primeDeferredGuestCloudAccess();
    ensureDeferredGuestCloudWriteCredential();
    startDeferredPolling();
    recordSyncTrace('deferred.guest.cloud-continuity', { source });
    // Le polling périodique est à 20 s : lors d'une vraie fermeture de l'hôte on relit
    // immédiatement pour partir de la dernière version cloud avant le prochain clic.
    Promise.resolve(pollCloudForUpdates()).catch(() => {});
}

// R9 — le mode différé par code seul ne doit jamais dépendre de l'ordre d'arrivée du
// message P2P `session-access`. Lors d'un join/rejoin, le host enregistre la preuve
// participant puis envoie la capacité de salle de façon asynchrone ; le `resync` peut
// donc arriver quelques millisecondes AVANT. Comme l'accès différé est volontairement
// dérivable du code à 4 chiffres, on peut l'installer immédiatement et sans élargir les
// droits : une salle live n'appelle jamais ce helper.
function primeDeferredGuestCloudAccess() {
    if (myRole !== 'guest' || !deferredRoomMode || !currentRoomCode) return false;
    let primed = false;

    if (typeof deferredCodeOnlyAccessKey === 'function' && typeof rememberSessionAccessKey === 'function') {
        const accessKey = deferredCodeOnlyAccessKey(currentRoomCode);
        if (accessKey) primed = rememberSessionAccessKey(currentRoomCode, accessKey) || primed;
    }

    if (typeof deferredCodeOnlyParticipantCredential === 'function') {
        const credential = deferredCodeOnlyParticipantCredential(currentRoomCode);
        if (credential && isModernGuestParticipantId(credential.participantId)
                && isValidReconnectSecret(credential.reconnectSecret)) {
            // R10 — l'identité déterministe appartient UNIQUEMENT au partenaire qui
            // revendique le siège PENDING. Une salle différée peut aussi contenir un autre
            // invité déjà assis avec sa propre credential aléatoire. Écraser cette dernière
            // par la credential code-only rendrait immédiatement ses PUT participant 403
            // (participantCredentialForCloudWrite exige que participantId === myParticipantId).
            // L'accessKey dérivable est bien commun à tous les invités de la salle ; la
            // preuve participant, elle, reste strictement propre à chaque identité.
            if (credential.participantId === myParticipantId) {
                rememberGuestRoomCredential(currentRoomCode, credential);
            }
            primed = true;
        }
    }
    return primed;
}

async function sendSessionAccessToParticipant(participantId) {
    if (myRole !== 'host' || !participantId || participantId === 'host') return false;
    if (typeof getSessionAccessKey !== 'function') return false;
    const accessKey = getSessionAccessKey(currentRoomCode);
    if (!accessKey) return false;
    const guestIndex = guestIndexForParticipant(participantId);
    if (guestIndex == null) return false;

    // Avant de remettre la capacité de lecture/relais à un participant, le serveur
    // enregistre sa preuve privée de reconnexion sous l'autorité d'écriture du host.
    // Ainsi, la capacité de salle seule ne suffit jamais à se faire passer pour un autre
    // participant lors d'une écriture de repli serveur.
    const reconnectSecret = guestReconnectSecretsByParticipantId[participantId];
    if (!reconnectSecret || typeof registerSessionParticipantCredential !== 'function') return false;
    const registered = await registerSessionParticipantCredential(currentRoomCode, participantId, reconnectSecret);
    if (!registered) {
        pushDebugLog(`Accès cloud non remis à ${participantId.slice(0, 10)}… : preuve participant non enregistrée côté serveur.`);
        return false;
    }
    // La connexion a pu changer pendant l'aller-retour HTTP.
    const currentGuestIndex = guestIndexForParticipant(participantId);
    if (currentGuestIndex == null) return false;
    peerConn.send({ type: 'session-access', accessKey }, currentGuestIndex);
    return true;
}

// Une capacité cloud est un droit durable, pas un simple attribut de connexion. L'hôte
// l'accorde aux participants qu'il a effectivement autorisés à jouer (siège attribué ou
// démarrage), jamais à tous les pairs qui parviennent à deviner/rejoindre le code court.
function grantSessionAccessToSeatedParticipants() {
    if (myRole !== 'host') return Promise.resolve([]);
    const ids = new Set(SEATS.map(seat => seatAssignment[seat]).filter(id => id && id !== SEAT_PENDING && id !== 'host'));
    // Une capacité ne peut être remise qu'à un peer actuellement joignable. Les joueurs
    // absents récupéreront leur accès à leur vraie reconnexion (onGuestConnected). Les
    // exclure ici permet d'utiliser le résultat comme vraie barrière de readiness pour les
    // joueurs connectés, notamment juste avant un start-game différé.
    const connectedIds = [...ids].filter(id => {
        const p = participants.find(x => x && x.id === id);
        return p && !p.disconnected && guestIndexForParticipant(id) != null;
    });
    return Promise.allSettled(connectedIds.map(id => sendSessionAccessToParticipant(id)));
}

function sessionAccessGrantResultsReady(results) {
    return Array.isArray(results) && results.every(r => r && r.status === 'fulfilled' && r.value === true);
}

let capabilityRotationInFlight = false;

function canRotateRoomCapabilities() {
    // En mode différé, l'accessKey DOIT rester la valeur déterministe dérivée du code
    // 4 chiffres. Une rotation manuelle vers une clé aléatoire casserait immédiatement
    // la promesse produit « code seul, même hôte hors ligne ». La rotation reste disponible
    // dans les salles live, où elle a précisément été conçue pour révoquer les anciens liens.
    return myRole === 'host' && !deferredRoomMode && !!currentRoomCode
        && typeof getSessionAccessKey === 'function' && !!getSessionAccessKey(currentRoomCode)
        && typeof getSessionHostWriteKey === 'function' && !!getSessionHostWriteKey(currentRoomCode)
        && typeof rotateSessionCapabilities === 'function';
}

function updateCapabilityRotationControls() {
    const enabled = canRotateRoomCapabilities() && !capabilityRotationInFlight;
    ['rotateCapabilitiesBtn', 'gameRotateCapabilitiesBtn'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        const shouldShow = canRotateRoomCapabilities();
        if (id === 'rotateCapabilitiesBtn') btn.style.display = shouldShow ? '' : 'none';
        else {
            btn.style.visibility = shouldShow ? '' : 'hidden';
            btn.style.pointerEvents = shouldShow ? '' : 'none';
        }
        btn.disabled = !enabled;
        btn.setAttribute('aria-busy', capabilityRotationInFlight ? 'true' : 'false');
    });
}

async function uiRotateRoomCapabilities() {
    if (!canRotateRoomCapabilities() || capabilityRotationInFlight) return;
    const ok = window.confirm(
        'Renouveler les accès de cette salle ?\n\nLes anciens liens/capacités cloud seront révoqués. Les joueurs actuellement connectés et assis recevront automatiquement le nouvel accès.'
    );
    if (!ok) return;

    capabilityRotationInFlight = true;
    updateCapabilityRotationControls();
    pushDebugLog('Rotation des capacités de salle : démarrage.');
    try {
        const rotated = await rotateSessionCapabilities(currentRoomCode);
        if (!rotated) {
            flashPresenceToast('⚠️ Renouvellement des accès impossible', false);
            pushDebugLog('Rotation des capacités de salle refusée/échouée ; anciennes capacités conservées localement.');
            return;
        }

        // L'abonnement Pusher privé est authentifié par accessKey : le recréer tout de
        // suite évite d'attendre une reconnexion/polling après la rotation.
        if (typeof subscribeToSessionUpdates === 'function') {
            subscribeToSessionUpdates(currentRoomCode, onCloudPusherEvent);
        }

        // Seuls les participants encore connectés ET assis reçoivent la nouvelle capacité.
        // Un ancien participant absent reste donc effectivement révoqué.
        const results = await grantSessionAccessToSeatedParticipants();
        const delivered = Array.isArray(results)
            ? results.filter(r => r.status === 'fulfilled' && r.value === true).length
            : 0;
        flashPresenceToast('🔐 Accès de la salle renouvelés', true);
        pushDebugLog(`Rotation des capacités terminée ; nouvel accès remis à ${delivered} participant(s) connecté(s).`);
    } catch (e) {
        flashPresenceToast('⚠️ Renouvellement des accès impossible', false);
        pushDebugLog(`Rotation des capacités : erreur ${String((e && e.message) || e)}`);
    } finally {
        capabilityRotationInFlight = false;
        updateCapabilityRotationControls();
    }
}

function broadcastLobbyState() {
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : l'ancien identifiant de relais a disparu d'ici (plus
    // d'élection automatique d'un autre hôte) — hostReconnectToken reste, toujours utile pour qu'un
    // invité identifie correctement l'hôte dans ses propres échanges avec le serveur.
    //
    // autoPassSeats inclus aussi (voir échange avec Guillaume — "le bot n'enchérit pas") :
    // peut changer en cours de partie (voir uiAssignSeat/uiDropOnSeat/uiDropOnKibitz), les
    // invités doivent rester informés de quels sièges sont robot, pas seulement au
    // lancement de la partie.
    peerConn.send({
        type: 'lobby-state',
        participants,
        seatAssignment,
        hostReconnectToken: getReconnectToken(),
        autoPassSeats,
        // Voir échange avec Guillaume ("je ne veux pas de bascule d'hôte") : sans ça, un
        // simple invité ne connaît roomCreatorName que localement à l'hôte — jamais reçu,
        // il retomberait sur le participant technique 'host' du moment pour l'affichage
        // (voir renderGameHeader), ce qui recrée exactement le problème qu'on corrige.
        roomCreatorName,
        // Le mode différé est une propriété de la SESSION, pas de la connexion P2P du
        // moment. Il doit donc accompagner chaque lobby-state, notamment après une
        // reconnexion de l'hôte : sinon l'invité pouvait retomber en mode live et perdre
        // ses flèches de navigation indépendante.
        deferredRoomMode
    });
    // Voir échange avec Guillaume (session du 23 juillet — reprise via localStorage) :
    // couvre les sièges/participants/renommages, qui passent tous par cette fonction.
    saveHostGameStateToStorage();
}

// Dans le salon mobile, un message de transfert peut ajouter ~60-76px au bloc Kibbitz.
// Plutôt que réserver cette hauteur en permanence, on conserve la position du premier bloc
// visible situé après le message (table puis configuration hôte). Si tout est hors écran,
// aucun scroll automatique n'est appliqué.
function captureHostTransferViewportAnchor() {
    if (window.innerWidth > 760) return null;
    const candidates = [
        document.querySelector('.lobby-table'),
        document.getElementById('ponsBuildBadge'),
        document.getElementById('hostSetupPanel')
    ];
    const viewportHeight = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    for (const element of candidates) {
        if (!element) continue;
        const style = getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden') continue;
        const rect = element.getBoundingClientRect();
        if (rect.bottom > 0 && rect.top < viewportHeight) return { element, top: rect.top };
    }
    return null;
}

function restoreHostTransferViewportAnchor(anchor) {
    if (!anchor || !anchor.element) return;
    requestAnimationFrame(() => {
        if (!anchor.element.isConnected || window.innerWidth > 760) return;
        const delta = anchor.element.getBoundingClientRect().top - anchor.top;
        if (Math.abs(delta) > 0.5) window.scrollBy(0, delta);
    });
}

// Affiche/masque le petit bandeau de statut du transfert d'hôte, dans le salon (distinct
// de #hostSetupError, réservé aux erreurs de chargement de fichier de donnes).
function showHostTransferStatus(message, isError) {
    const el = document.getElementById('hostTransferStatus');
    if (!el) return;
    const nextMessage = message || '';
    const isShown = getComputedStyle(el).display !== 'none';
    const stateChanges = (!!nextMessage) !== isShown || (nextMessage && el.textContent !== nextMessage);
    const mobileViewportAnchor = stateChanges ? captureHostTransferViewportAnchor() : null;
    if (!nextMessage) {
        el.style.display = 'none';
        el.textContent = '';
        restoreHostTransferViewportAnchor(mobileViewportAnchor);
        return;
    }
    el.textContent = nextMessage;
    el.className = 'error-banner' + (isError ? '' : ' is-warning');
    el.style.display = 'block';
    restoreHostTransferViewportAnchor(mobileViewportAnchor);
}

// Bouton unique à côté du pseudo (voir échange avec Guillaume : un seul bouton, pas un par
// participant dans la liste), qui ouvre un menu déroulant listant qui peut recevoir le
// rôle d'hôte. Visible seulement pour l'hôte, dans le salon, tant qu'au moins un autre
// participant connecté existe — sinon rien à proposer.
function renderHostTransferWidget() {
    updateCapabilityRotationControls();
    const widget = document.getElementById('hostTransferWidget');
    if (!widget) return;

    const isHost = myRole === 'host';
    // Voir échange avec Guillaume ("pas de raison de transférer l'hôte en différé") :
    // un siège encore SEAT_PENDING dans le salon indique qu'un participant est encore
    // attendu. Restriction laissée inchangée pour l'instant (voir
    // ARCHITECTURE-P2P-SERVEUR.md — hors périmètre de l'étape 2, qui ne touche que
    // uiStartGameAsHost) : à revisiter une fois le reste de la réorganisation en place,
    // puisque sa justification d'origine référençait la branche "mode différé"
    // maintenant retirée de uiStartGameAsHost.
    const hasPendingSeat = SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
    const eligible = isHost && !deals && !hasPendingSeat
        ? participants.filter(p => p.id !== myParticipantId && !p.disconnected)
        : [];

    if (!isHost || deals) {
        widget.style.display = 'none';
        widget.style.visibility = '';
        widget.style.pointerEvents = '';
        uiCloseTransferMenu();
        return;
    }

    // Un siège PENDING désactive temporairement le transfert, mais ne retire plus le bouton
    // du flux : visibility:hidden conserve exactement son empreinte et évite le saut de
    // ~41px mesuré dans le salon mobile. Dès que PENDING disparaît, le même slot redevient
    // interactif sans modifier la géométrie.
    widget.style.display = '';
    if (hasPendingSeat) {
        widget.style.visibility = 'hidden';
        widget.style.pointerEvents = 'none';
        uiCloseTransferMenu();
        return;
    }
    widget.style.visibility = '';
    widget.style.pointerEvents = '';

    const menu = document.getElementById('transferMenu');
    if (!menu) return;
    menu.innerHTML = eligible.length > 0
        ? eligible.map(p => `<button type="button" class="transfer-menu-item" data-ui-click="transfer-host" data-participant-id="${escapeHtml(p.id)}">${avatarHtml(p.id)}${escapeHtml(p.name)}</button>`).join('')
        : `<div class="transfer-menu-empty">Personne d'autre pour l'instant.</div>`;
}

function uiToggleTransferMenu() {
    const menu = document.getElementById('transferMenu');
    if (!menu) return;
    if (menu.style.display === 'block') {
        uiCloseTransferMenu();
    } else {
        menu.style.display = 'block';
        const btn = document.getElementById('hostTransferToggleBtn');
        if (btn) btn.setAttribute('aria-expanded', 'true');
        // Ferme au clic ailleurs sur la page — posé au tick suivant, sinon le clic sur le
        // bouton lui-même (qui vient de déclencher cette ouverture) le refermerait aussitôt.
        setTimeout(() => document.addEventListener('click', uiTransferMenuOutsideClick), 0);
    }
}

function uiCloseTransferMenu() {
    const menu = document.getElementById('transferMenu');
    if (menu) menu.style.display = 'none';
    const btn = document.getElementById('hostTransferToggleBtn');
    if (btn) btn.setAttribute('aria-expanded', 'false');
    document.removeEventListener('click', uiTransferMenuOutsideClick);
}

function uiTransferMenuOutsideClick(event) {
    const widget = document.getElementById('hostTransferWidget');
    if (widget && !widget.contains(event.target)) uiCloseTransferMenu();
}

// Lance le transfert du rôle d'hôte vers `targetId`, un participant actuellement connecté
// (voir le menu déroulant dans renderHostTransferWidget). Ne fait que la première moitié
// du travail : envoyer à ce participant tout ce qu'il faut pour qu'il devienne hôte à son
// tour (voir 'prepare-become-host' dans handlePeerData) ; la bascule effective de l'ancien
// hôte se fait plus tard, à la réception de 'become-host-ready'.
function uiTransferHost(targetId) {
    uiCloseTransferMenu();
    if (myRole !== 'host' || deals) return; // uniquement possible dans le salon, avant le lancement
    if (hostTransferInProgress) return;

    const guestIndex = guestIndexByToken[targetId];
    const target = participants.find(p => p.id === targetId);
    if (guestIndex === undefined || !target || target.disconnected) {
        showHostTransferStatus('Ce joueur doit être connecté pour devenir hôte.', true);
        return;
    }
    if (!confirm(`Transférer le rôle d'hôte à ${target.name} ? Vous redeviendrez un simple participant, sur une nouvelle salle.`)) {
        return;
    }

    hostTransferInProgress = true;
    pendingHostTransferTarget = targetId;
    // Prépare dès maintenant ma future identité INVITÉE dans la nouvelle salle. Le
    // participantId public est placé dans les sièges hérités ; le reconnectSecret privé
    // n'est transmis qu'au futur host dans le message ciblé prepare-become-host.
    pendingHostTransferOldCredential = createGuestReconnectCredential();
    pendingHostTransferOldToken = pendingHostTransferOldCredential.participantId;
    showHostTransferStatus(`Transfert de l'hôte à ${target.name} en cours...`, false);

    // On recalcule dès maintenant participants/seatAssignment tels qu'ils doivent apparaître
    // une fois le transfert effectif : mon entrée 'host' devient mon jeton personnel, et
    // l'entrée du participant ciblé devient 'host'. Envoyer un état déjà cohérent évite au
    // nouvel hôte d'avoir à faire lui-même cette traduction (il ne connaît pas forcément mon
    // jeton avant que je ne le lui donne ici).
    const newParticipants = participants.map(p => {
        if (p.id === 'host') return { ...p, id: pendingHostTransferOldToken };
        if (p.id === targetId) return { ...p, id: 'host' };
        return p;
    });
    const newSeatAssignment = {};
    SEATS.forEach(seat => {
        const occupant = seatAssignment[seat];
        if (occupant === 'host') newSeatAssignment[seat] = pendingHostTransferOldToken;
        else if (occupant === targetId) newSeatAssignment[seat] = 'host';
        else newSeatAssignment[seat] = occupant;
    });

    // Le transfert est une autorisation explicite de l'hôte : le futur hôte doit
    // pouvoir reprendre le cloud de la salle courante jusqu'à ce que son nouveau code soit prêt.
    sendSessionAccessToParticipant(targetId);
    const inheritedReconnectSecrets = { ...guestReconnectSecretsByParticipantId };
    delete inheritedReconnectSecrets[targetId]; // le futur host n'est plus un guest
    inheritedReconnectSecrets[pendingHostTransferOldCredential.participantId] = pendingHostTransferOldCredential.reconnectSecret;
    peerConn.send({
        type: 'prepare-become-host',
        participants: newParticipants,
        seatAssignment: newSeatAssignment,
        reconnectSecrets: inheritedReconnectSecrets
    }, guestIndex);

    // Filet de sécurité : au cas où ni 'become-host-ready' ni 'become-host-failed' ni même
    // onPeerDisconnected ne se déclenchent (silence radio complet — improbable mais pas
    // impossible), on ne reste jamais bloqué plus de 20s sur "transfert en cours".
    setTimeout(() => {
        if (hostTransferInProgress && pendingHostTransferTarget === targetId) {
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            pendingHostTransferOldCredential = null;
            showHostTransferStatus('Le transfert a expiré sans réponse. Vous restez hôte, réessayez si besoin.', true);
        }
    }, 20000);
}

// ===== Démarrage de la partie (hôte) =====

// Affiche un message dans la bannière du panneau de chargement des donnes.
// `isWarning` distingue visuellement (voir .error-banner.is-warning dans styles.css) un
// avertissement non bloquant — la partie peut démarrer quand même (PARs absents, format
// de fichier ambigu) — d'une vraie erreur qui empêche de continuer (fichier illisible,
// aucun fichier choisi).
// Accepte soit un booléen (ancien usage, rétro-compatible : true=warning, false=error),
// soit une chaîne 'error'/'warning'/'success' — voir échange avec Guillaume, qui voulait
// un état "succès" en vert distinct du jaune (contraintes à revoir) et du rouge (erreur
// bloquante), pour la confirmation de génération de donnes.
function setHostSetupMessage(text, type) {
    const errorEl = document.getElementById('hostSetupError');
    const kind = type === true ? 'warning' : type === false ? 'error' : (type || 'error');
    const prefix = kind === 'warning' ? '⚠️ ' : kind === 'success' ? '✅ ' : '';
    errorEl.textContent = prefix + text;
    errorEl.classList.remove('is-warning', 'is-success');
    if (kind === 'warning') errorEl.classList.add('is-warning');
    if (kind === 'success') errorEl.classList.add('is-success');
    errorEl.style.display = 'block';
}

function clearHostSetupMessage() {
    document.getElementById('hostSetupError').style.display = 'none';
}

// Voir échange avec Guillaume (session du 23 juillet) : bandeau de statut des donnes
// (#dealFileInfo), désormais TOUJOURS visible au même endroit plutôt qu'affiché seulement
// une fois des donnes prêtes. Ces deux fonctions pilotent son contenu (texte + couleur
// rouge/verte via la classe is-empty) ET l'état activé/grisé de "Commencer la partie" —
// les deux vont toujours de pair, pas la peine de les répéter à chaque appelant.
function setDealStatusEmpty() {
    const infoEl = document.getElementById('dealFileInfo');
    const textEl = document.getElementById('dealFileInfoText');
    const previewBtn = document.getElementById('dealPreviewBtn');
    const startBtn = document.getElementById('startGameBtn');
    infoEl.classList.add('is-empty');
    textEl.textContent = 'Veuillez charger ou générer des donnes';
    if (previewBtn) previewBtn.style.display = 'none';
    if (startBtn) startBtn.disabled = true;
}

function setDealStatusReady(text, showPreview = true) {
    const infoEl = document.getElementById('dealFileInfo');
    const textEl = document.getElementById('dealFileInfoText');
    const previewBtn = document.getElementById('dealPreviewBtn');
    const startBtn = document.getElementById('startGameBtn');
    infoEl.classList.remove('is-empty');
    textEl.textContent = text;
    if (previewBtn) previewBtn.style.display = showPreview ? '' : 'none';
    if (startBtn) startBtn.disabled = false;
}

// Parse et valide un texte de donnes déjà en main (peu importe sa provenance — fichier
// local lu via FileReader, ou donne de la bibliothèque récupérée via fetch, voir
// readAndValidateDealFile / readAndValidateDealFromLibrary), affichant tout de suite
// l'éventuelle erreur. `onDone` reçoit le tableau de donnes parsées, ou `null` si le
// parsing a échoué (l'erreur est alors déjà affichée).
function validateAndUseDealText(text, filename, onDone) {
    clearHostSetupMessage();
    setDealStatusEmpty();

    let parsedDeals;
    try {
        parsedDeals = parseDealFile(text, filename);
    } catch (err) {
        setHostSetupMessage(err.message, false);
        onDone(null);
        return;
    }

    const n = parsedDeals.length;
    setDealStatusReady(`✅ ${n} donne${n > 1 ? 's' : ''} chargée${n > 1 ? 's' : ''}`);

    // Avertissement non bloquant restant : format de fichier ambigu (voir parseDealFile).
    // Voir échange avec Guillaume (session du 23 juillet) : l'avertissement "PARs non
    // disponibles" a été retiré — le calcul du double mort en arrière-plan (voir
    // kickOffBackgroundDD ci-dessous) tourne désormais systématiquement et silencieusement
    // pour tout fichier sans PAR/table déjà fournie, plus la peine de le signaler.
    if (parsedDeals._formatWarning) {
        setHostSetupMessage(parsedDeals._formatWarning, true);
    }
    if (!parsedDeals.some(d => d.par || d.ddTable)) {
        kickOffBackgroundDD(parsedDeals);
    }

    onDone(parsedDeals);
}

// Lit un fichier local (upload) puis délègue à validateAndUseDealText.
function readAndValidateDealFile(file, onDone) {
    const reader = new FileReader();
    reader.onload = () => validateAndUseDealText(reader.result, file.name, onDone);
    reader.onerror = () => {
        clearHostSetupMessage();
        setDealStatusEmpty();
        setHostSetupMessage('Impossible de lire ce fichier.', false);
        onDone(null);
    };
    reader.readAsText(file);
}

// Récupère une donne de la bibliothèque du club (voir donnes/catalogue.json) puis délègue
// à validateAndUseDealText — même circuit de validation que l'upload, seule la façon
// d'obtenir le texte change.
function readAndValidateDealFromLibrary(filename, onDone) {
    fetch(`donnes/${encodeURIComponent(filename)}`)
        .then(resp => {
            if (!resp.ok) throw new Error(`Fichier introuvable dans la bibliothèque (HTTP ${resp.status}).`);
            return resp.text();
        })
        .then(text => validateAndUseDealText(text, filename, onDone))
        .catch(err => {
            clearHostSetupMessage();
            setDealStatusEmpty();
            setHostSetupMessage(err.message || 'Impossible de charger cette donne depuis la bibliothèque.', false);
            onDone(null);
        });
}

// Appelé dès que l'hôte choisit (ou change) le fichier de donnes, pour parser et valider
// tout de suite — voir readAndValidateDealFile. L'hôte voit ainsi l'éventuel message
// pendant qu'il compose encore la table, et uiStartGameAsHost n'a plus qu'à réutiliser ce
// résultat (pendingParsedDeals) sans relire le fichier une seconde fois.
// Tient à jour l'affichage du nom de fichier à côté du bouton "Choisir un fichier" (voir
// échange avec Guillaume : remplace le texte natif "Aucun fichier choisi" du navigateur,
// bien plus large que nécessaire, par un affichage compact qu'on contrôle nous-mêmes).
function updateDealFileNameDisplay() {
    const display = document.getElementById('dealFileNameDisplay');
    if (!display) return;
    const fileInput = document.getElementById('dealFileInput');
    const file = fileInput && fileInput.files && fileInput.files[0];
    display.textContent = file ? file.name : 'Aucun fichier choisi';
    display.classList.toggle('has-file', !!file);
}

function uiHandleDealFileChosen() {
    const fileInput = document.getElementById('dealFileInput');
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;
    updateDealFileNameDisplay();

    if (!fileInput.files || fileInput.files.length === 0) {
        clearHostSetupMessage();
        setDealStatusEmpty();
        return;
    }

    schedulePonsClientPreload();

    // Un fichier local et une donne de bibliothèque sont mutuellement exclusifs (une
    // seule source à la fois, pour éviter toute ambiguïté sur celle qui sera utilisée) :
    // choisir l'un désélectionne l'autre.
    const librarySelect = document.getElementById('dealLibrarySelect');
    if (librarySelect) librarySelect.value = '';

    const file = fileInput.files[0];
    readAndValidateDealFile(file, (parsedDeals) => {
        pendingParsedSource = file;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
    });
}

// Symétrique de uiHandleDealFileChosen, pour une donne piochée dans la bibliothèque du
// club (voir donnes/catalogue.json et initDealLibrary) plutôt qu'un fichier local.
function uiHandleDealLibraryChosen() {
    const select = document.getElementById('dealLibrarySelect');
    const filename = select ? select.value : '';
    pendingParsedDeals = null;
    pendingParsedSource = null;
    pendingOrderedDeals = null;

    if (!filename) {
        clearHostSetupMessage();
        setDealStatusEmpty();
        return;
    }

    schedulePonsClientPreload();

    // Réciproquement, choisir dans la bibliothèque désélectionne le fichier local.
    const fileInput = document.getElementById('dealFileInput');
    if (fileInput) fileInput.value = '';
    updateDealFileNameDisplay();

    readAndValidateDealFromLibrary(filename, (parsedDeals) => {
        pendingParsedSource = `library:${filename}`;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
    });
}

// ===== Aperçu des donnes chargées (avant de lancer la partie) =====

// Accessibilité clavier des modales.
// Une seule vraie modale peut être active à la fois dans PLAY.
let activeAccessibleModalState = null;

function modalFocusableElements(modal) {
    if (!modal) return [];
    const selector = [
        'a[href]',
        'button:not([disabled])',
        'input:not([disabled]):not([type="hidden"])',
        'select:not([disabled])',
        'textarea:not([disabled])',
        '[tabindex]:not([tabindex="-1"])'
    ].join(',');

    return Array.from(modal.querySelectorAll(selector)).filter(el => {
        if (!el || typeof el.getClientRects !== 'function') return false;
        const style = getComputedStyle(el);
        return style.visibility !== 'hidden'
            && style.display !== 'none'
            && el.getClientRects().length > 0;
    });
}

function handleAccessibleModalKeydown(evt) {
    const state = activeAccessibleModalState;
    if (!state || !state.modal || state.modal.style.display === 'none') return;

    if (evt.key === 'Escape') {
        // Réorganisation des sièges : closeOnEscape reste null. Cette modale ne se ferme
        // qu'avec Valider / Annuler, conformément au comportement existant.
        if (typeof state.closeOnEscape === 'function') {
            evt.preventDefault();
            state.closeOnEscape();
        }
        return;
    }

    if (evt.key !== 'Tab') return;

    const focusables = modalFocusableElements(state.modal);
    const panel = state.modal.querySelector('[role="dialog"]');
    if (!focusables.length) {
        evt.preventDefault();
        if (panel && typeof panel.focus === 'function') panel.focus();
        return;
    }

    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    const active = document.activeElement;
    const focusIsInside = state.modal.contains(active);

    if (evt.shiftKey) {
        if (!focusIsInside || active === first) {
            evt.preventDefault();
            last.focus();
        }
    } else if (!focusIsInside || active === last) {
        evt.preventDefault();
        first.focus();
    }
}

function activateAccessibleModal(modal, { closeOnEscape = null } = {}) {
    if (!modal) return;

    if (activeAccessibleModalState) {
        document.removeEventListener('keydown', handleAccessibleModalKeydown);
    }

    const previousFocus = document.activeElement
        && typeof document.activeElement.focus === 'function'
        ? document.activeElement
        : null;

    activeAccessibleModalState = {
        modal,
        previousFocus,
        closeOnEscape
    };
    document.addEventListener('keydown', handleAccessibleModalKeydown);

    requestAnimationFrame(() => {
        const state = activeAccessibleModalState;
        if (!state || state.modal !== modal || modal.style.display === 'none') return;

        const preferred = modal.querySelector('[data-modal-initial-focus]');
        const firstFocusable = modalFocusableElements(modal)[0];
        const fallbackPanel = modal.querySelector('[role="dialog"]');
        const target = preferred || firstFocusable || fallbackPanel;
        if (target && typeof target.focus === 'function') target.focus();
    });
}

function deactivateAccessibleModal(modal) {
    const state = activeAccessibleModalState;
    if (!state || state.modal !== modal) return;

    const previousFocus = state.previousFocus;
    activeAccessibleModalState = null;
    document.removeEventListener('keydown', handleAccessibleModalKeydown);

    requestAnimationFrame(() => {
        if (
            previousFocus
            && previousFocus.isConnected
            && typeof previousFocus.focus === 'function'
            && !previousFocus.disabled
        ) {
            previousFocus.focus();
        }
    });
}

function uiPreviewDeals() {
    if (!pendingOrderedDeals || pendingOrderedDeals.length === 0) return;
    renderDealPreview(pendingOrderedDeals);
    const modal = document.getElementById('dealPreviewModal');
    if (!modal) return;
    modal.style.display = 'flex';
    activateAccessibleModal(modal, { closeOnEscape: uiCloseDealPreview });
}

function uiCloseDealPreview() {
    const modal = document.getElementById('dealPreviewModal');
    if (!modal) return;
    modal.style.display = 'none';
    deactivateAccessibleModal(modal);
}

function uiCloseDealPreviewOnBackdrop(evt) {
    if (evt.target.id === 'dealPreviewModal') uiCloseDealPreview();
}

// Voir échange avec Guillaume (session du 23 juillet — "ça ne doit être effectif qu'à la
// fermeture") : ouvre la grille de réorganisation des sièges en cours de partie, en mode
// BROUILLON — les changements faits dans la modale (voir uiStageSeatAssignment) ne
// s'appliquent qu'au clic sur "Valider" (voir uiValidateSeatReorg), jamais en direct.
// Réservé au VRAI créateur (le bouton lui-même est déjà masqué pour tout autre rôle, voir
// updateBoardControlVisibility, mais on se protège quand même ici en cas d'appel direct) —
// isTrueOriginalHost(), pas myRole==='host' (voir échange avec Guillaume, "en mode
// différé, l'invité ne devrait pas avoir... la réorganisation des sièges").
function uiOpenSeatReorgModal() {
    if (!isTrueOriginalHost()) return;
    seatReorgDraft = { ...seatAssignment };
    renderSeatReorgModalGrid();
    const modal = document.getElementById('seatReorgModal');
    if (!modal) return;
    modal.style.display = 'flex';
    // Pas d'Escape ici : Valider / Annuler restent les deux seules sorties voulues.
    activateAccessibleModal(modal);
}

// Modifie UNIQUEMENT le brouillon (voir seatReorgDraft), jamais l'assignation réelle —
// aucune diffusion réseau, aucun rafraîchissement de l'écran de jeu tant que "Valider"
// n'a pas été cliqué (voir uiValidateSeatReorg).
function uiStageSeatAssignment(seat, participantId) {
    if (!isTrueOriginalHost() || !seatReorgDraft) return;
    if (deals && !deferredRoomMode && participantId === SEAT_PENDING) {
        flashPresenceToast('⏳ Le mode différé se choisit avant de lancer la partie', false);
        return;
    }
    seatReorgDraft[seat] = participantId || null;
    renderSeatReorgModalGrid();
}

// Applique enfin le brouillon à l'assignation réelle (même logique que uiAssignSeat, mais
// en un seul coup pour tous les sièges modifiés), diffuse, rafraîchit, puis ferme.
async function uiValidateSeatReorg() {
    if (!isTrueOriginalHost() || !seatReorgDraft) return;
    // Si le nombre de mains contrôlées change, renderBoard() peut modifier fortement la
    // hauteur au-dessus de la boîte d'enchères. Mémoriser l'ancre AVANT toute mutation ;
    // scheduleMobileLedgerViewportRestore conserve volontairement la première ancre du
    // frame, donc les sous-rendus ne peuvent pas l'écraser avec une position déjà déplacée.
    const parViewActive = isAuctionParViewActive();
    const mobileViewportAnchor = parViewActive
        ? captureVisibleMobileViewportAnchor(document.querySelector('.auction-panel'))
        : captureMobileLedgerViewportAnchor();
    // En vue enchères, réserver tout de suite la première ancre du frame afin que le
    // renderAuctionLedger() déclenché par renderBoard() ne la remplace pas après coup.
    if (!parViewActive) scheduleMobileLedgerViewportRestore(mobileViewportAnchor);
    const previousSeatAssignment = { ...seatAssignment };
    seatAssignment = { ...seatReorgDraft };
    // Voir échange avec Guillaume (session du 23 juillet — voir uiAssignSeat) : même
    // recalcul du statut robot des sièges.
    if (deals) autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
    if (deals && deferredRoomMode) {
        const results = await grantSessionAccessToSeatedParticipants();
        if (!sessionAccessGrantResultsReady(results)) {
            seatAssignment = previousSeatAssignment;
            autoPassSeats = SEATS.filter(s => !seatAssignment[s]);
            flashPresenceToast('⚠️ Réorganisation annulée : accès serveur d’un joueur non prêt', false);
            renderLobby();
            renderBoard();
            return;
        }
    } else {
        grantSessionAccessToSeatedParticipants();
    }
    broadcastLobbyState();
    renderLobby();
    // Voir échange avec Guillaume ("changement de sièges via le relais serveur") : même
    // ajout que uiAssignSeat.
    saveHostGameStateToStorage();
    if (deals) {
        mySeats = SEATS.filter(s => seatAssignment[s] === myParticipantId);
        renderBoard();
    }
    seatReorgDraft = null;
    const modal = document.getElementById('seatReorgModal');
    if (modal) {
        modal.style.display = 'none';
        deactivateAccessibleModal(modal);
    }
    uiCloseSeatDropdowns();
    if (parViewActive) restoreVisibleMobileViewportAnchor(mobileViewportAnchor);
}

// Ferme SANS appliquer le brouillon (voir échange avec Guillaume) : abandonne les
// changements en cours — utilisé par un clic hors de la modale (voir
// uiCloseSeatReorgModalOnBackdrop). Pas de bouton dédié pour ça dans la modale elle-même
// ("Fermer" a été remplacé par "Valider", voir index.html), mais cliquer à l'extérieur
// reste un moyen d'abandonner sans valider.
function uiCancelSeatReorg() {
    seatReorgDraft = null;
    const modal = document.getElementById('seatReorgModal');
    if (modal) {
        modal.style.display = 'none';
        deactivateAccessibleModal(modal);
    }
    uiCloseSeatDropdowns();
}

function uiCloseSeatReorgModalOnBackdrop(evt) {
    if (evt.target.id === 'seatReorgModal') uiCancelSeatReorg();
}

// Petite carte de main compacte pour l'aperçu (même principe que renderMyHands /
// renderAllHandsDiagram, mais toujours avec le HCP affiché, indépendamment de la
// préférence showHcp qui ne concerne que l'écran de jeu).
function dealPreviewHandCardHtml(seat, hand) {
    const lines = ['S', 'H', 'D', 'C'].map(suit => `
        <div class="card-line">
            <span class="suit-symbol">${suitIconHtml(suit)}</span>
            <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
        </div>
    `).join('');

    return `
        <div class="hand-card deal-preview-hand-card">
            <div class="hand-card-title">
                <span class="hand-card-title-name">${SEAT_FULL_NAME[seat]}</span>
                <span class="hand-card-badges"><span class="hand-hcp-badge">${computeHandHcp(hand)} HCP</span></span>
            </div>
            <div class="hand-cards">${lines}</div>
        </div>
    `;
}

function dealPreviewParText(par) {
    if (!par) return '';
    const contract = par.contract ? `${par.contract}${par.declarer ? ' ' + par.declarer : ''}` : '?';
    const scoreSign = par.score > 0 ? '+' : '';
    return ` · Par : ${contract} (${par.side} ${scoreSign}${par.score})`;
}

function renderDealPreview(dealsToPreview) {
    const n = dealsToPreview.length;
    document.getElementById('dealPreviewTitle').textContent = `Aperçu — ${n} donne${n > 1 ? 's' : ''}`;

    const content = document.getElementById('dealPreviewContent');
    content.innerHTML = dealsToPreview.map(deal => `
        <div class="deal-preview-board">
            <div class="deal-preview-board-header">
                <strong>Donne #${deal.board}</strong> — Donneur : ${SEAT_FULL_NAME[deal.dealer]} · ${VULN_LABEL[deal.vulnerable]}${dealPreviewParText(deal.par)}
            </div>
            <div class="deal-preview-hands">
                ${SEATS.map(seat => dealPreviewHandCardHtml(seat, deal.hands[seat])).join('')}
            </div>
        </div>
    `).join('');
}

async function uiStartGameAsHost() {
    const fileInput = document.getElementById('dealFileInput');
    const librarySelect = document.getElementById('dealLibrarySelect');
    const file = (fileInput.files && fileInput.files[0]) || null;
    const libraryFilename = librarySelect ? librarySelect.value : '';
    // Voir uiGenerateRandomDeals : une troisième source, au même niveau que le fichier et
    // la bibliothèque — déjà entièrement parsée en mémoire (pas de lecture asynchrone à
    // refaire, contrairement aux deux autres), donc toujours "à jour" tant que
    // pendingParsedSource vaut 'random'.
    const hasRandomDeals = pendingParsedSource === 'random' && !!pendingParsedDeals;

    if (!file && !libraryFilename && !hasRandomDeals) {
        setHostSetupMessage('Choisissez un fichier .pbn ou .lin, une donne dans la bibliothèque, ou générez des donnes aléatoires.', false);
        return;
    }

    // Le chargement différé ne doit JAMAIS changer le moteur réellement utilisé : si un
    // siège robot doit enchérir en mode normal, on attend explicitement PONS avant de
    // lancer la séance. Le mode « passe en boucle » n'a, lui, besoin d'aucun moteur.
    const needsPonsAtLaunch = robotBiddingMode !== 'passOnly' && SEATS.some(seat => !seatAssignment[seat]);
    if (needsPonsAtLaunch) {
        showConnectingOverlay('Préparation du moteur PONS…');
        try {
            await withPonsTimeout(ensurePonsClientReady(), 110000, 'Préparation complète du moteur PONS');
            hidePonsFailureDiagnostic();
        } catch (err) {
            hideConnectingOverlay();
            ponsLastLoadError = err;
            setHostSetupMessage('Le moteur PONS n’a pas pu être chargé. Le diagnostic ci-dessous indique maintenant l’étape exacte.', false);
            showPonsFailureDiagnostic();
            console.error('[PLAY/PONS lazy] lancement bloqué : moteur indisponible', err);
            return;
        }
        hideConnectingOverlay();
    }

    // En mode différé, le code à 4 chiffres doit suffire même si l'hôte ferme sa
    // fenêtre juste après le lancement. On attend donc ici la conversion cloud AVANT de
    // démarrer réellement la séance ; le clic dans le salon l'a déjà lancée en arrière-
    // plan, mais cette garde rend le comportement déterministe même si l'utilisateur est
    // très rapide.
    const launchingDeferred = SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
    if (launchingDeferred && currentRoomCode) {
        showConnectingOverlay('Préparation du mode différé…');
        const ready = await ensureDeferredInviteCredentialRegistered(currentRoomCode);
        if (!ready) {
            hideConnectingOverlay();
            setHostSetupMessage('Impossible de préparer la reprise différée par code. Vérifiez votre connexion puis réessayez.', false);
            return;
        }
        // R10 — une salle différée fait du serveur l'autorité des actions invitées. Tous
        // les joueurs DÉJÀ connectés et assis doivent donc avoir leur preuve participant
        // enregistrée AVANT de recevoir start-game. R9 lançait cet enregistrement en
        // fire-and-forget après le premier paint : sur un backend froid, un invité pouvait
        // enchérir pendant cette fenêtre puis prendre un 403 et perdre son action.
        const accessGrants = await grantSessionAccessToSeatedParticipants();
        hideConnectingOverlay();
        if (!sessionAccessGrantResultsReady(accessGrants)) {
            setHostSetupMessage('Impossible de préparer l’accès serveur d’un joueur connecté. Vérifiez la connexion puis réessayez.', false);
            return;
        }
    }

    // Reçoit les donnes déjà dans l'ordre à utiliser pour jouer (mélangé ou non, voir
    // pendingOrderedDeals / refreshPendingOrderedDeals) — jamais l'ordre brut du fichier.
    const proceedWithDeals = async (orderedDeals) => {
        if (!orderedDeals) return; // l'erreur est déjà affichée par readAndValidateDealFile/readAndValidateDealFromLibrary

        // Voir échange avec Guillaume ("nom de l'hôte doit être le nom quand l'hôte a
        // lancé la séance, pas le nom par défaut à l'ouverture de la room") :
        // roomCreatorName était figé à la CRÉATION de la room (uiCreateRoom, avec le
        // savedNickname de la session PRÉCÉDENTE) et jamais remis à jour ensuite — même si
        // l'hôte corrige son pseudo dans le salon d'attente juste avant de lancer (voir
        // uiUpdateMyName, qui met bien à jour participants[...].name en temps réel, mais
        // ignorait roomCreatorName). Remis à jour ici, au moment exact du lancement, avec
        // le nom courant de l'hôte — la seule chose qui change ensuite, c'est qu'on ne le
        // réécrit plus JAMAIS après ça (voir le commentaire original sur roomCreatorName).
        const hostParticipantAtLaunch = participants.find(p => p.id === myParticipantId);
        if (hostParticipantAtLaunch) roomCreatorName = hostParticipantAtLaunch.name;

        // Une nouvelle séance invalide toute passe de pré-calcul legacy encore planifiée
        // par une séance précédente dans le même onglet.
        cancelStartupLegacyRobotPrecalc();
        deals = orderedDeals;
        boardIndex = 0;
        if (!deals[0].auctionHistory) deals[0].auctionHistory = [];
        auctionHistory = deals[0].auctionHistory;
        // Voir échange avec Guillaume (session du 23 juillet) : la partie démarre
        // effectivement — retire le marqueur "encore dans le salon" (voir
        // HOSTING_PREGAME_KEY tout en bas du fichier) : un rechargement à partir de
        // maintenant a du sens de garder le code dans l'URL (reprise possible).
        clearHostingPregameMark();
        hostPendingUndo = null;
        clearUndoUiState();

        const botSeats = SEATS.filter(seat => !seatAssignment[seat]);
        autoPassSeats = botSeats;
        deferredRoomMode = SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
        if (deferredRoomMode) ensureDeferredInviteCredentialRegistered(currentRoomCode);
        if (currentRoomCode) updateShareLinkForRoom(currentRoomCode);

        // Toutes les informations nécessaires à l'affichage de la première donne sont
        // maintenant prêtes. Calculer les autres donnes, sérialiser toute la séance pour
        // le réseau/localStorage et démarrer le polling n'ont AUCUNE raison de retarder
        // le premier paint de la boîte d'enchères.
        mySeats = SEATS.filter(seat => seatAssignment[seat] === 'host');

        // R13 — invariant restauré depuis OLD : AVANT que l'écran de jeu devienne
        // utilisable, toutes les autres donnes doivent déjà avoir leur préfixe robot
        // calculé jusqu'au premier siège humain. OLD appelait synchroniquement
        // advanceRobotBidsOnAllBoards(boardIndex) ici, avant enterGameScreen/start-game.
        // PONS étant désormais asynchrone, on attend explicitement la passe séquentielle.
        // Ainsi, par exemple, avec Sud humain et Est donneur à la donne 6, l'annonce
        // d'Est existe déjà lorsque la partie apparaît — ouvrir la donne 6 ou cliquer sur
        // fast-forward ne doit jamais être ce qui déclenche cette première annonce.
        if (autoPassSeats.length > 0) {
            showConnectingOverlay('Préparation des enchères robots…');
            try {
                await resolveAllOtherRobotBoards(boardIndex, { quiet: true });
            } finally {
                hideConnectingOverlay();
            }
        }

        resetAuctionVisualModeForNewSession();
        enterGameScreen();

        const finishSessionStartAfterFirstPaint = () => {
            // La première donne est déjà peinte. On lance maintenant la séance SANS
            // recalculer d'un bloc toutes les donnes futures : sur le moteur legacy ce
            // pré-calcul était synchrone et pouvait monopoliser le thread principal juste
            // après l'apparition des boutons. Hôte et invités démarrent donc avec le MÊME
            // snapshot initial, puis les autres donnes sont enrichies progressivement en
            // arrière-plan (voir scheduleStartupLegacyRobotPrecalc / precalc-board).
            //
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 2) : plus de branche "mode différé"
            // séparée ici — la salle garde TOUJOURS une vraie connexion P2P hôte, même
            // avec un siège encore SEAT_PENDING.
            // En différé, la barrière de readiness a déjà été attendue AVANT le lancement
            // (voir uiStartGameAsHost). En live, conserver la remise best-effort historique.
            if (!deferredRoomMode) grantSessionAccessToSeatedParticipants();
            participants.filter(p => p.id !== 'host' && !p.disconnected).forEach(p => {
                const guestIndex = guestIndexForParticipant(p.id);
                if (guestIndex == null) return;
                const seatsForThisGuest = SEATS.filter(seat => seatAssignment[seat] === p.id);
                peerConn.send({
                    type: 'start-game',
                    deals, yourSeats: seatsForThisGuest, botSeats,
                    hostReconnectToken: getReconnectToken(),
                    roomCreatorName,
                    deferredRoomMode
                }, guestIndex);
            });

            saveHostGameStateToStorage(); // première sauvegarde du snapshot réellement lancé
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : polling de repli serveur.
            startDeferredPolling();

            // R13 : aucune pré-enchère de démarrage n'est déclenchée ici. Elles ont
            // toutes été terminées AVANT enterGameScreen(), selon l'invariant historique
            // de OLD. Le snapshot start-game ci-dessus contient donc déjà les historiques
            // pré-calculés. Les résolveurs d'arrière-plan restent utilisés ensuite pour
            // les continuations après une annonce humaine hors écran.
        };

        // Deux frames : la première applique le DOM du jeu, la seconde garantit qu'un
        // paint a eu l'occasion de se produire avant les travaux de fond ci-dessus.
        if (window.requestAnimationFrame) {
            requestAnimationFrame(() => requestAnimationFrame(finishSessionStartAfterFirstPaint));
        } else {
            setTimeout(finishSessionStartAfterFirstPaint, 0);
        }
    };

    // Source effectivement active : le fichier local prime sur la bibliothèque si les deux
    // sont, par un hasard quelconque, renseignés à la fois (ne devrait pas arriver, voir
    // uiHandleDealFileChosen/uiHandleDealLibraryChosen qui désélectionnent l'autre à
    // chaque choix, mais on tranche explicitement plutôt que de laisser un cas ambigu) ;
    // "random", lui, ne peut être actif que si aucun des deux ne l'est (voir
    // uiGenerateRandomDeals, qui les désélectionne tous les deux).
    const activeSource = hasRandomDeals ? 'random' : (file || `library:${libraryFilename}`);

    // Cas normal : la source a déjà été lue et parsée au moment où elle a été choisie
    // (voir uiHandleDealFileChosen / uiHandleDealLibraryChosen / uiGenerateRandomDeals) —
    // pas besoin de la relire, le bandeau de statut est déjà à jour depuis ce moment-là.
    if (pendingParsedSource === activeSource) {
        await proceedWithDeals(pendingOrderedDeals);
        return;
    }

    // Filet de sécurité si, pour une raison quelconque, le cache ne correspond pas à la
    // source actuellement sélectionnée (ex. écouteur 'change' non déclenché) : on relit,
    // puis on applique l'ordre aléatoire éventuel avant de démarrer. Ne concerne jamais
    // "random" (déjà entièrement en mémoire dès sa génération, jamais besoin d'une
    // relecture asynchrone) : rien à faire ici dans ce cas, la branche ci-dessus l'aura
    // déjà traité.
    const onReloaded = (parsedDeals) => {
        pendingParsedSource = activeSource;
        pendingParsedDeals = parsedDeals;
        refreshPendingOrderedDeals();
        proceedWithDeals(pendingOrderedDeals).catch(err => {
            hideConnectingOverlay();
            console.error('[PLAY/R13] lancement interrompu pendant le pré-calcul robot', err);
            setHostSetupMessage('Impossible de préparer les enchères robots avant le lancement.', false);
        });
    };
    if (file) {
        readAndValidateDealFile(file, onReloaded);
    } else {
        readAndValidateDealFromLibrary(libraryFilename, onReloaded);
    }
}

// ===== Réception des messages des autres joueurs =====

// Frontière de confiance du protocole P2P. Côté hôte, toute donnée entrante vient d'un
// invité et seuls les messages qu'un invité est réellement autorisé à produire sont
// acceptés. Côté invité, l'unique pair distant est l'hôte : on limite symétriquement les
// types reçus aux messages que l'hôte peut émettre/relayer.
//
// Important : ce filtre ne remplace PAS les validations métier propres à chaque message
// (tour/légalité d'une annonce, état d'un Undo, transfert d'hôte en cours, etc.). Il ferme
// seulement la classe de bugs où un client modifié pouvait envoyer directement un message
// d'autorité comme `lobby-state`, `start-game`, `goto-board` ou `undo-apply`.
const PEER_TYPES_FROM_GUEST = new Set([
    'set-name',
    'set-avatar-color',
    'presence-leaving',
    'call',
    'chat',
    'wizz',
    'undo-request',
    'become-host-ready',
    'become-host-failed'
]);

const PEER_TYPES_FROM_HOST = new Set([
    'welcome',
    'identity-rejected',
    'session-access',
    'prepare-become-host',
    'host-transferred',
    'lobby-state',
    'seats-rotated',
    'start-game',
    'resync',
    'call',
    'chat',
    'wizz',
    'precalc-board',
    'dd-result',
    'reset-auction',
    'goto-board',
    'undo-ask',
    'undo-apply',
    'undo-rejected'
]);

function rejectPeerProtocolMessage(msg, guestIndex, reason) {
    const type = msg && msg.type ? String(msg.type) : '?';
    const source = myRole === 'host' ? (tokenForGuestIndex(guestIndex) || `connexion #${guestIndex}`) : 'hôte';
    console.warn(`Message réseau rejeté (${reason}) : ${type} depuis ${source}`);
    if (typeof pushDebugLog === 'function') {
        pushDebugLog(`Protocole : message ${type} rejeté depuis ${source} (${reason}).`);
    }
}

function isPeerTypeAllowedFromCurrentRemote(type) {
    if (myRole === 'host') return PEER_TYPES_FROM_GUEST.has(type);
    if (myRole === 'guest') return PEER_TYPES_FROM_HOST.has(type);
    return false;
}

function authenticatedGuestId(guestIndex) {
    if (myRole !== 'host') return null;
    return tokenForGuestIndex(guestIndex);
}

// R23 — présence différée : une fermeture volontaire de l'invité peut être signalée
// avant même que PeerJS/WebRTC n'émette son callback `close`. Centraliser ici la mutation
// évite les doubles toasts lorsque le message explicite est suivi quelques ms plus tard
// par le vrai `onPeerDisconnected`.
function markHostParticipantDisconnected(participantId, source = 'p2p-close') {
    if (myRole !== 'host' || !participantId) return false;
    const p = participants.find(x => x.id === participantId);
    if (!p) return false;
    const wasDisconnected = !!p.disconnected;
    p.disconnected = true;
    if (!p.disconnectedAt) p.disconnectedAt = Date.now();
    if (!wasDisconnected && deals && SEATS.some(s => seatAssignment[s] === p.id)) {
        flashPresenceToast(`🔌 ${presenceLabelFor(p)} s'est déconnecté`, false);
    }
    recordSyncTrace('presence.host.participant-disconnected', { participantId, source, wasDisconnected });
    return !wasDisconnected;
}

function handlePeerData(msg, guestIndex) {
    if (!msg || typeof msg.type !== 'string' || !msg.type) return;
    if (!isPeerTypeAllowedFromCurrentRemote(msg.type)) {
        rejectPeerProtocolMessage(msg, guestIndex, 'type interdit pour ce rôle');
        return;
    }

    switch (msg.type) {
        case 'welcome': {
            if (!isSafeParticipantId(msg.yourId)) {
                rejectPeerProtocolMessage(msg, guestIndex, 'identifiant welcome invalide');
                break;
            }
            myParticipantId = msg.yourId;
            // Une récupération automatique qui a réussi ne doit pas condamner une future
            // reconnexion de cette même salle dans le même onglet : le garde anti-boucle
            // ne vaut que pour la tentative en cours.
            if (currentRoomCode) identityRecoveryAttemptedRooms.delete(currentRoomCode);
            break;
        }

        case 'identity-rejected': {
            if (myRole !== 'guest' || !currentRoomCode) break;
            const code = currentRoomCode;
            const needsDeferredCredential = msg.reason === 'deferred-credential-required';
            pushDebugLog(needsDeferredCredential
                ? "Place différée détectée — reconnexion immédiate avec l'identité stable liée au code."
                : "Identité de reconnexion refusée par l'hôte — nouvelle identité locale pour rejoindre sans voler une ancienne place.");
            if (identityRecoveryAttemptedRooms.has(code)) {
                hideConnectingOverlay();
                showLandingError('Impossible de valider votre identité de reconnexion. Rechargez PLAY puis rejoignez à nouveau la salle.');
                break;
            }
            identityRecoveryAttemptedRooms.add(code);
            if (peerConn) peerConn.destroy();

            if (needsDeferredCredential) {
                const deferredCredential = getOrCreateDeferredInviteCredential(code);
                if (!deferredCredential) {
                    hideConnectingOverlay();
                    showLandingError('Impossible de préparer l’identité de la place en attente.');
                    break;
                }
                rememberGuestRoomCredential(code, deferredCredential);
                setTimeout(() => connectAsGuest(code, null, savedNickname, deferredCredential), 120);
            } else {
                forgetGuestRoomCredential(code);
                setTimeout(() => connectAsGuest(code, null, savedNickname), 120);
            }
            break;
        }

        case 'session-access': {
            if (msg.accessKey && typeof rememberSessionAccessKey === 'function' && currentRoomCode) {
                rememberSessionAccessKey(currentRoomCode, msg.accessKey);
                updateShareLinkForRoom(currentRoomCode);
                // Une souscription Pusher avait pu être ignorée faute de clé au premier
                // démarrage du polling. La relancer ici est idempotent et remplace proprement
                // l'abonnement précédent si nécessaire.
                if (typeof subscribeToSessionUpdates === 'function') {
                    subscribeToSessionUpdates(currentRoomCode, onCloudPusherEvent);
                }
            }
            break;
        }

        // Reçu par le participant CIBLÉ par un transfert d'hôte (voir uiTransferHost) : il
        // doit créer sa propre salle (nouveau code, PeerJS ne permet pas de reprendre
        // fiablement l'ancien identifiant tout de suite) puis prévenir l'ancien hôte dès que
        // c'est prêt — c'est par CETTE connexion, celle qui reçoit ce message, qu'on le
        // préviendra, donc on ne la coupe qu'une fois le nouveau code obtenu et transmis.
        case 'prepare-become-host': {
            if (myRole !== 'guest') break;
            pushDebugLog('Transfert d\'hôte reçu, création de la nouvelle salle...');

            const inheritedParticipants = normalizePublicParticipantList(msg.participants);
            const inheritedSeatAssignment = normalizePublicSeatAssignment(msg.seatAssignment, inheritedParticipants || []);
            if (!inheritedParticipants || !inheritedSeatAssignment) {
                rejectPeerProtocolMessage(msg, guestIndex, 'état de transfert invalide');
                break;
            }
            const inheritedReconnectSecrets = {};
            if (msg.reconnectSecrets && typeof msg.reconnectSecrets === 'object' && !Array.isArray(msg.reconnectSecrets)) {
                for (const [id, secret] of Object.entries(msg.reconnectSecrets)) {
                    if (isModernGuestParticipantId(id) && isValidReconnectSecret(secret)) {
                        inheritedReconnectSecrets[id] = secret;
                    }
                }
            }
            // Gardée dans une variable locale plutôt que relue depuis la globale `peerConn`
            // plus bas : voir le commentaire juste après sur la bascule immédiate de l'état.
            const oldPeerConn = peerConn;

            const claimPeer = new BridgePeerConnection(buildHostHandlers((newRoomCode) => {
                // BASCULE IMMÉDIATE ET SYNCHRONE de tout l'état global, avant même de
                // prévenir l'ancien hôte. Sans ça (l'ancienne version attendait 300ms avant
                // de le faire) : `claimPeer` accepte déjà des connexions entrantes dès son
                // ouverture (le gestionnaire 'connection' de peer-connection.js est posé dès
                // la création), donc toute connexion arrivant pendant ces 300ms déclenchait
                // les handlers de buildHostHandlers alors qu'ils référençaient encore
                // l'ANCIEN état (peerConn pointant vers l'ancienne connexion, participants
                // pas encore hérités) — c'est très probablement ce qui causait les
                // déconnexions observées pendant un transfert (voir échange avec Guillaume).
                peerConn = claimPeer;
                myRole = 'host';
                myParticipantId = 'host';
                participants = inheritedParticipants;
                seatAssignment = inheritedSeatAssignment;

                // Le transfert crée une NOUVELLE salle : l'autorité persistante doit donc
                // appartenir au nouvel hôte, pas au créateur de l'ancienne salle. Ces trois
                // valeurs doivent être posées AVANT toute sauvegarde locale/cloud du nouveau
                // salon, faute de quoi roomCreatorToken pouvait retomber sur le token de
                // l'ancien hôte via currentHostReconnectToken et inverser l'autorité lors
                // d'une reprise à froid.
                const promotedHostToken = getReconnectToken();
                roomCreatorToken = promotedHostToken;
                currentHostReconnectToken = promotedHostToken;
                const promotedHostParticipant = participants.find(p => p.id === 'host');
                roomCreatorName = (promotedHostParticipant && promotedHostParticipant.name)
                    || savedNickname || 'Hôte';

                guestIndexByToken = {};
                guestReconnectSecretsByParticipantId = inheritedReconnectSecrets;
                persistHostGuestReconnectSecrets(newRoomCode);
                prevSeatAssignmentSnapshot = null;
                prevParticipantsDisconnectedSnapshot = null;
                lobbyChatAutoOpened = false;
                enterLobbyScreen();
                renderLobby();

                // Prévenir l'ancien hôte APRÈS la bascule locale (peu importe l'ordre réel
                // de réception chez lui, ça n'a plus d'incidence) puis fermer l'ancienne
                // connexion avec un court délai, pour laisser le message le temps de partir
                // sur le canal WebRTC avant de la couper.
                if (oldPeerConn) oldPeerConn.send({ type: 'become-host-ready', newRoomCode });
                setTimeout(() => { if (oldPeerConn) oldPeerConn.destroy(); }, 300);
            }));
            // Repli propre si la création de la nouvelle salle échoue (réseau, etc.) :
            // prévenir l'ancien hôte plutôt que de le laisser attendre indéfiniment, sans
            // toucher à quoi que ce soit côté local (on reste un invité normal, connecté
            // comme avant à l'ancien hôte).
            claimPeer.handlers.onError = (err) => {
                pushDebugLog('Échec de la prise de rôle hôte : ' + ((err && (err.message || err.type)) || err));
                if (oldPeerConn) oldPeerConn.send({ type: 'become-host-failed', reason: (err && err.type) || 'erreur inconnue' });
            };
            claimPeer.createRoom();
            break;
        }

        // Reçu par l'ANCIEN hôte : le participant ciblé a bien créé sa nouvelle salle. On
        // prévient tous les autres invités connectés (pas lui, il le sait déjà), puis on
        // rejoint nous-mêmes cette nouvelle salle comme simple participant.
        case 'become-host-ready': {
            if (myRole !== 'host' || !hostTransferInProgress) break;
            const targetIndex = guestIndexByToken[pendingHostTransferTarget];
            if (targetIndex === undefined || guestIndex !== targetIndex) {
                rejectPeerProtocolMessage(msg, guestIndex, 'réponse de transfert provenant d’un autre participant');
                break;
            }
            const newRoomCode = typeof msg.newRoomCode === 'string' ? msg.newRoomCode.trim() : '';
            if (!/^\d{4}$/.test(newRoomCode)) {
                rejectPeerProtocolMessage(msg, guestIndex, 'code de nouvelle salle invalide');
                break;
            }
            peerConn.sendExcept({ type: 'host-transferred', newRoomCode }, targetIndex);

            const myOldToken = pendingHostTransferOldToken;
            const myOldCredential = pendingHostTransferOldCredential;
            const myName = savedNickname;
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            pendingHostTransferOldCredential = null;
            showHostTransferStatus(null);
            // Voir échange avec Guillaume (session du 23 juillet — reprise via
            // localStorage) : on vient de transférer l'hôte volontairement à quelqu'un
            // d'autre — la sauvegarde locale de CETTE partie n'a plus lieu d'être
            // proposée à la reprise, on n'en est plus le responsable légitime. Les
            // AUTRES salles reprenables (session du 8 août — "multi room") ne sont pas
            // affectées.
            clearHostGameStateStorage(currentRoomCode);

            connectAsGuest(newRoomCode, myOldToken, myName, myOldCredential);
            break;
        }

        // Reçu par l'ANCIEN hôte : le transfert a échoué chez le participant ciblé (voir
        // 'prepare-become-host' ci-dessus) — on reste hôte, rien d'autre à faire.
        case 'become-host-failed': {
            if (myRole !== 'host' || !hostTransferInProgress) break;
            const targetIndex = guestIndexByToken[pendingHostTransferTarget];
            if (targetIndex === undefined || guestIndex !== targetIndex) {
                rejectPeerProtocolMessage(msg, guestIndex, 'échec de transfert provenant d’un autre participant');
                break;
            }
            hostTransferInProgress = false;
            pendingHostTransferTarget = null;
            pendingHostTransferOldToken = null;
            pendingHostTransferOldCredential = null;
            showHostTransferStatus("Le transfert a échoué (" + (msg.reason || 'raison inconnue') + "). Vous restez hôte.", true);
            break;
        }

        // Reçu par tout invité qui n'était NI la cible du transfert (déjà géré dans
        // 'prepare-become-host') NI l'ancien hôte (déjà géré dans 'become-host-ready') :
        // on rejoint simplement la nouvelle salle avec son propre jeton, comme un join normal.
        case 'host-transferred': {
            if (myRole !== 'guest') break;
            const newRoomCode = typeof msg.newRoomCode === 'string' ? msg.newRoomCode.trim() : '';
            if (!/^\d{4}$/.test(newRoomCode)) break;
            pushDebugLog('Hôte transféré, on rejoint la nouvelle salle ' + newRoomCode);
            // Le nouvel host a reçu, de façon ciblée, la preuve de reconnexion associée à
            // mon participantId actuel. Je réutilise donc cette même credential dans la
            // nouvelle salle afin de conserver mes sièges sans jamais diffuser le secret.
            const inheritedCredential = getGuestRoomCredential(currentRoomCode, false);
            if (inheritedCredential) rememberGuestRoomCredential(newRoomCode, inheritedCredential);
            connectAsGuest(newRoomCode, null, savedNickname, inheritedCredential);
            break;
        }

        case 'presence-leaving': {
            // R23 — fermeture volontaire d'un onglet invité. L'identité vient uniquement
            // de la DataConnection authentifiée ; le message ne peut jamais désigner un
            // autre participant. Le `close` WebRTC qui suit est idempotent grâce au helper.
            if (myRole !== 'host') break;
            const pid = authenticatedGuestId(guestIndex);
            if (!pid) {
                rejectPeerProtocolMessage(msg, guestIndex, 'présence sans identité invitée authentifiée');
                break;
            }
            const changed = markHostParticipantDisconnected(pid, 'guest-pagehide');
            if (changed) {
                broadcastLobbyState();
                renderLobby();
                if (deals) renderBoard();
                saveHostGameStateToStorage();
            }
            break;
        }

        case 'set-name': {
            if (myRole !== 'host') return;
            const pid = authenticatedGuestId(guestIndex);
            if (!pid) {
                rejectPeerProtocolMessage(msg, guestIndex, 'connexion invitée non authentifiée');
                return;
            }
            const p = participants.find(x => x.id === pid);
            const requestedName = typeof msg.name === 'string' ? msg.name.trim().slice(0, 20) : '';
            if (!p || !requestedName) {
                rejectPeerProtocolMessage(msg, guestIndex, 'pseudo invalide');
                return;
            }
            p.name = requestedName;
            broadcastLobbyState();
            renderLobby();
            break;
        }

        case 'set-avatar-color': {
            if (myRole !== 'host') return;
            const pid = authenticatedGuestId(guestIndex);
            const color = normalizeAvatarColor(msg.avatarColor);
            const p = pid ? participants.find(x => x.id === pid) : null;
            if (!pid || !p || !color) {
                rejectPeerProtocolMessage(msg, guestIndex, 'couleur avatar invalide');
                return;
            }
            p.avatarColor = color;
            broadcastLobbyState();
            renderLobby();
            if (deals) {
                renderRoomBoard();
                renderChat();
            }
            break;
        }

        case 'lobby-state': {
            const newParticipants = normalizePublicParticipantList(msg.participants);
            const newSeatAssignment = normalizePublicSeatAssignment(msg.seatAssignment, newParticipants || []);
            if (!newParticipants || !newSeatAssignment) {
                rejectPeerProtocolMessage(msg, guestIndex, 'état public du salon invalide');
                break;
            }
            // Voir échange avec Guillaume (session du 23 juillet — "un bandeau similaire
            // à celui du wizz") : détecte maintenant les DEUX transitions (pas seulement
            // le retour) pour les AUTRES participants — la déconnexion utilise le même
            // toast que côté hôte (voir onPeerDisconnected), restreinte aux joueurs
            // ASSIS. Un diff est nécessaire ici, contrairement au côté hôte qui connaît
            // déjà l'événement précis au moment où il se produit (voir onGuestConnected) :
            // ce message ne porte qu'un instantané, pas la nature du changement.
            // seatAssignment appliqué AVANT ce diff (pas après, comme c'était le cas) :
            // presenceLabelFor a besoin du siège À JOUR pour construire son libellé.
            seatAssignment = newSeatAssignment;
            if (deals && prevParticipantsDisconnectedSnapshot) {
                newParticipants.forEach(p => {
                    if (p.id === myParticipantId) return; // notre propre transition est gérée à part (voir onGuestConnected/onPeerDisconnected)
                    const wasDisconnected = prevParticipantsDisconnectedSnapshot[p.id];
                    if (wasDisconnected === undefined) {
                        // Le snapshot précédent existe déjà : cette identité est donc une
                        // vraie nouvelle arrivée en cours de partie, pas l'initialisation
                        // de la liste au premier affichage.
                        if (!p.disconnected) flashPresenceToast(`✅ ${presenceLabelFor(p)} a rejoint la partie`, true);
                        return;
                    }
                    if (wasDisconnected && !p.disconnected) {
                        flashPresenceToast(`✅ ${presenceLabelFor(p)} s'est reconnecté`, true);
                    } else if (!wasDisconnected && p.disconnected && SEATS.some(s => seatAssignment[s] === p.id)) {
                        flashPresenceToast(`🔌 ${presenceLabelFor(p)} s'est déconnecté`, false);
                    }
                });
            }
            prevParticipantsDisconnectedSnapshot = {};
            newParticipants.forEach(p => { prevParticipantsDisconnectedSnapshot[p.id] = !!p.disconnected; });

            participants = newParticipants;
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : l'ancien identifiant de relais a disparu
            // (plus d'élection automatique d'un autre hôte) — hostReconnectToken reste, reçu à chaque
            // diffusion (voir broadcastLobbyState), toujours utile pour identifier
            // correctement l'hôte dans mes propres échanges avec le serveur.
            currentHostReconnectToken = msg.hostReconnectToken || null;
            // Un lobby-state ancien/partiel ne doit jamais effacer un mode différé déjà
            // établi. Les nouveaux hôtes envoient toujours le booléen (voir
            // broadcastLobbyState), mais cette garde rend la reconnexion compatible avec
            // un message transitoire qui ne le porterait pas.
            if (typeof msg.deferredRoomMode === 'boolean') deferredRoomMode = msg.deferredRoomMode;
            if (deferredRoomMode) {
                primeDeferredGuestCloudAccess();
                startDeferredPolling();
            }
            if (msg.roomCreatorName) roomCreatorName = msg.roomCreatorName;
            // Ce message est aussi renvoyé quand la connectivité change en pleine partie
            // (quelqu'un se (re)connecte) : on ne bascule à l'écran du salon que si la
            // partie n'a pas encore commencé, sinon ça arracherait un invité de sa table.
            // Dans le cas contraire (partie en cours), on doit quand même rafraîchir
            // l'écran de jeu — sans ça, la bannière de reconnexion et le tour-indicateur
            // resteraient figés jusqu'à la prochaine annonce.
            if (myRole === 'guest' && !deals) enterLobbyScreen();
            else if (deals) {
                // Voir échange avec Guillaume (session du 23 juillet) : seatAssignment peut
                // maintenant changer EN COURS DE PARTIE (réassignation de siège par glisser-
                // déposer, voir uiDropOnSeat) — recalculer mySeats ici, comme le fait déjà
                // 'seats-rotated' pour la rotation, sinon ce joueur resterait affiché avec
                // son ancienne main/son ancien rôle jusqu'à sa prochaine reconnexion.
                mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
                // Voir échange avec Guillaume (session du 23 juillet — "le bot n'enchérit
                // pas") : autoPassSeats peut changer lui aussi en cours de partie (un
                // siège réassigné à "Robot") — à tenir à jour ici comme mySeats.
                autoPassSeats = msg.autoPassSeats || autoPassSeats;
                renderBoard();
                // Voir échange avec Guillaume (session du 23 juillet) : l'hôte peut
                // maintenant changer la couleur d'avatar ou renommer n'importe qui EN
                // COURS DE PARTIE (voir uiRandomizeAvatarColor/uiRenameParticipant) — ce
                // changement arrive ici via ce même message ; renderBoard() ne rafraîchit
                // pas le chat, donc on l'appelle en plus (il se protège tout seul si SON
                // PROPRE input de renommage est actif, aucun risque de l'écraser).
                renderChat();
            }
            break;
        }

        // Diffusé par l'hôte (voir uiRotateSeatsClockwise) : recalcule ma propre place à
        // la table à partir de la nouvelle assignation, puis rafraîchit l'écran actuel.
        case 'seats-rotated': {
            seatAssignment = msg.seatAssignment;
            autoPassSeats = msg.autoPassSeats || [];
            mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
            flashSeatsRotatedToast();
            if (deals) renderBoard();
            else if (myRole === 'guest') enterLobbyScreen();
            break;
        }

        case 'start-game': {
            deals = msg.deals;
            mySeats = msg.yourSeats;
            autoPassSeats = msg.botSeats || [];
            boardIndex = 0;
            if (!deals[0].auctionHistory) deals[0].auctionHistory = [];
            auctionHistory = deals[0].auctionHistory;
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : l'ancien identifiant de relais a disparu
            // d'ici (plus d'élection automatique d'un autre hôte) — hostReconnectToken reste, connu dès
            // le lancement (voir uiStartGameAsHost, qui l'inclut dans ce message).
            currentHostReconnectToken = msg.hostReconnectToken || null;
            deferredRoomMode = !!msg.deferredRoomMode;
            if (deferredRoomMode) {
                primeDeferredGuestCloudAccess();
                startDeferredPolling();
            }
            if (msg.roomCreatorName) roomCreatorName = msg.roomCreatorName;
            hostPendingUndo = null;
            clearUndoUiState();
            resetAuctionVisualModeForNewSession();
            enterGameScreen();
            break;
        }

        // Reçu après une (re)connexion alors que la partie est déjà en cours : remet ce
        // joueur exactement là où en est la table (donne, enchère, sièges), qu'il soit
        // nouveau ou de retour après une coupure.
        case 'resync': {
            // En différé, `boardIndex` est une vue LOCALE. Une reconnexion P2P ne doit
            // donc jamais recopier la donne affichée par l'hôte. Un NOUVEL arrivant part
            // explicitement de la donne 1 ; un joueur déjà présent qui reconnecte garde
            // sa propre donne si elle existe encore. En live seulement, le boardIndex de
            // l'hôte reste l'autorité de table partagée.
            const localBoardBeforeResync = Number.isInteger(boardIndex) ? boardIndex : 0;
            const hadLocalGameBeforeResync = Array.isArray(deals) && deals.length > 0;
            deals = msg.deals;
            mySeats = msg.yourSeats;
            autoPassSeats = msg.botSeats || [];
            if (typeof msg.deferredRoomMode === 'boolean') deferredRoomMode = msg.deferredRoomMode;
            if (deferredRoomMode) {
                boardIndex = msg.isNewJoiner || !hadLocalGameBeforeResync
                    ? 0
                    : (deals[localBoardBeforeResync] ? localBoardBeforeResync : 0);
            } else {
                boardIndex = Number.isInteger(msg.boardIndex) && deals[msg.boardIndex] ? msg.boardIndex : 0;
            }
            if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
            auctionHistory = deals[boardIndex].auctionHistory;
            // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 4) : voir le commentaire
            // équivalent dans 'start-game' — l'ancien identifiant de relais a disparu.
            currentHostReconnectToken = msg.hostReconnectToken || null;
            if (deferredRoomMode) {
                primeDeferredGuestCloudAccess();
                startDeferredPolling();
            }
            if (msg.roomCreatorName) roomCreatorName = msg.roomCreatorName;
            hostPendingUndo = null;
            clearUndoUiState();
            enterGameScreen();
            // Voir échange avec Guillaume (session du 23 juillet) : élargi à TOUT
            // 'resync' — au départ réservé à un tout nouveau kibitz sans siège
            // (isNewJoiner), mais un joueur qui REVIENT après une vraie coupure a tout
            // autant besoin de voir le chat pour se resituer (qui est là, qu'est-ce qui
            // s'est passé...), qu'il ait un siège ou non.
            if (!chatPanelOpen) {
                uiToggleChat(false);
            }
            break;
        }

        case 'call': {
            if (!deals || !Number.isInteger(msg.boardIndex) || !deals[msg.boardIndex]) return;

            // En live, toute la table partage encore une seule donne : une annonce d'un
            // autre boardIndex reste invalide. En différé, chacun peut au contraire être
            // sur une donne différente ; le P2P de secours doit donc mettre à jour LA
            // DONNE PORTÉE PAR LE MESSAGE, sans déplacer la vue locale du destinataire.
            const targetBoardIndex = msg.boardIndex;
            if (!deferredRoomMode && targetBoardIndex !== boardIndex) return;

            if (myRole === 'host') {
                const senderId = authenticatedGuestId(guestIndex);
                if (!senderId || seatAssignment[msg.seat] !== senderId) {
                    rejectPeerProtocolMessage(msg, guestIndex, 'annonce au nom d’un siège non contrôlé');
                    return;
                }
            }

            const targetDeal = deals[targetBoardIndex];
            if (!targetDeal.auctionHistory) targetDeal.auctionHistory = [];
            const targetHistory = targetDeal.auctionHistory;
            const expectedSeat = currentTurnSeat(targetDeal.dealer, targetHistory);

            // Si le cloud a gagné la course et a déjà apporté cette même annonce, le P2P
            // peut arriver quelques millisecondes après. Ce n'est pas une erreur : ne pas
            // la dupliquer et ne pas transformer une course normale en rejet protocolaire.
            const lastEntry = targetHistory[targetHistory.length - 1];
            const alreadyPresent = !!lastEntry
                && lastEntry.seat === msg.seat
                && String(lastEntry.call || '').toUpperCase() === String(msg.call || '').toUpperCase();
            if (alreadyPresent) {
                relayIfHost(msg, guestIndex);
                break;
            }

            if (msg.seat !== expectedSeat || !isCallLegal(targetHistory, msg.call, msg.seat)) {
                console.warn('Annonce reçue invalide, ignorée :', msg);
                return;
            }

            // R16 — le même filet que pour l'annonce optimiste locale doit couvrir une
            // annonce fraîche REÇUE par P2P côté guest différé. Exemple réel : Sud arrive,
            // puis Ouest robot arrive par P2P ; un snapshot cloud intermédiaire ne contenant
            // encore que Sud ne doit pas faire disparaître Ouest avant la version suivante.
            // begin... clone le préfixe AVANT l'ajout ; côté host/live la fonction est no-op.
            beginDeferredOptimisticAuctionGuard(targetBoardIndex, targetHistory, msg.seat, msg.call);

            targetHistory.push(msg.explanation
                ? { seat: msg.seat, call: msg.call, explanation: msg.explanation }
                : { seat: msg.seat, call: msg.call });

            if (targetBoardIndex === boardIndex) {
                auctionHistory = targetHistory;
                renderAfterNormalCall();
                maybeRobotBid();
            } else if (myRole === 'host') {
                // R12 — en différé, l'hôte et le guest peuvent regarder deux donnes
                // différentes. L'ancienne garde ne lançait le robot que sur `boardIndex`,
                // donc un bot suivant une annonce guest restait muet jusqu'au retour de
                // l'hôte sur cette donne. On poursuit désormais LA DONNE CIBLE en fond.
                continueRobotBidsOnBoardInBackground(targetBoardIndex);
            }

            // Même hors de la donne actuellement regardée par l'hôte, la copie P2P est
            // immédiatement durable. Le resolver R12 republiera ensuite le suffixe robot
            // lorsqu'il sera calculé ; le chemin participant parallèle reste un filet de
            // sécurité serveur et ne doit plus être l'unique déclencheur de PONS.
            saveHostGameStateToStorage();
            relayIfHost(msg, guestIndex);
            break;
        }

        case 'chat': {
            let chatMsg = msg;
            if (myRole === 'host') {
                const senderId = authenticatedGuestId(guestIndex);
                const sender = participants.find(p => p.id === senderId);
                const text = typeof msg.text === 'string' ? msg.text.trim().slice(0, 500) : '';
                if (!senderId || !sender || !text) {
                    rejectPeerProtocolMessage(msg, guestIndex, 'message de chat invalide ou identité inconnue');
                    return;
                }
                // L'identité réseau prime toujours sur les champs fournis par le client :
                // impossible de se présenter comme l'hôte ou comme un autre invité.
                chatMsg = { ...msg, senderId, senderName: sender.name, text };
            }
            addChatMessage(chatMsg);
            relayIfHost(chatMsg, guestIndex);
            break;
        }

        // Voir échange avec Guillaume : le "wizz" façon MSN Messenger. Contrairement au
        // chat (diffusé à tout le monde), un wizz est ciblé — relayIfHost ne convient pas
        // ici puisqu'il diffuserait à TOUS les autres invités, pas seulement au bon. Un
        // hôte qui reçoit un wizz qui n'est pas pour lui le retransmet spécifiquement au
        // bon invité (topologie en étoile : c'est le seul chemin possible entre deux
        // invités) ; un invité, lui, ne reçoit jamais un wizz qui ne lui est pas destiné
        // (l'hôte a déjà fait ce tri avant de relayer), donc l'applique directement.
        case 'wizz': {
            let wizzMsg = msg;
            if (myRole === 'host') {
                const senderId = authenticatedGuestId(guestIndex);
                const sender = participants.find(p => p.id === senderId);
                if (!senderId || !sender) {
                    rejectPeerProtocolMessage(msg, guestIndex, 'wizz provenant d’une identité inconnue');
                    break;
                }
                wizzMsg = { ...msg, senderName: sender.name };
            }
            if (myRole === 'host' && wizzMsg.targetId !== 'host') {
                const targetGuestIndex = guestIndexByToken[wizzMsg.targetId];
                // Voir échange avec Guillaume ("le wizz ne marche pas, aucune trace même
                // juste après") : trace ajoutée ici aussi — si le relais échoue
                // silencieusement (cible plus dans guestIndexByToken, ou send() qui
                // échoue contre une connexion pas tout à fait ouverte), rien ne le disait
                // jusqu'ici.
                if (targetGuestIndex !== undefined) {
                    peerConn.send(wizzMsg, targetGuestIndex);
                    pushDebugLog(`Wizz reçu de ${wizzMsg.senderName || '?'}, relayé vers ${wizzMsg.targetId.slice(0, 10)}… (index ${targetGuestIndex}).`);
                } else {
                    pushDebugLog(`Wizz reçu de ${wizzMsg.senderName || '?'} pour ${wizzMsg.targetId.slice(0, 10)}… : relais abandonné, cible plus dans guestIndexByToken.`);
                }
                break;
            }
            pushDebugLog(`Wizz reçu de ${wizzMsg.senderName || '?'} — déclenchement de l'effet.`);
            triggerWizzEffect();
            break;
        }

        // Une donne FUTURE a été pré-calculée progressivement par l'hôte après le
        // lancement. Le message ne transporte que son historique d'enchères, pas toute la
        // séance : les invités restent ainsi synchronisés sans ressérialiser `deals` en
        // entier à chaque petite tranche de travail. Un hôte n'accepte jamais ce message
        // d'un invité : la source de vérité reste strictement l'hôte.
        case 'precalc-board': {
            if (myRole === 'host' || !deals) break;
            const idx = Number(msg.boardIndex);
            if (!Number.isInteger(idx) || idx < 0 || idx >= deals.length || !Array.isArray(msg.auctionHistory)) break;
            const localHistory = deals[idx].auctionHistory || [];
            // Un snapshot de fond ne peut qu'ÉTENDRE l'historique déjà connu. S'il est
            // plus court ou diverge (ex. une annonce/undo plus récent a déjà été reçu),
            // on l'ignore au lieu d'écraser un état plus frais.
            const localIsPrefix = localHistory.length <= msg.auctionHistory.length
                && localHistory.every((entry, i) => {
                    const incoming = msg.auctionHistory[i];
                    return incoming && entry.seat === incoming.seat && entry.call === incoming.call;
                });
            if (!localIsPrefix) break;
            // R20 — R17 envoie volontairement `call` + `precalc-board` pour fiabiliser
            // la propagation. Quand `call` a déjà installé EXACTEMENT le même historique,
            // le snapshot redondant ne doit surtout pas reconstruire tout le plateau :
            // c'était une source directe de petits clignotements sans changement d'état.
            if (sameCloudData(
                cloneAuctionHistoryForWire(localHistory),
                cloneAuctionHistoryForWire(msg.auctionHistory)
            )) {
                recordSyncTrace('peer.precalc-board.duplicate-skip-render', { boardIndex: idx, length: localHistory.length });
                break;
            }
            // R18 — ce snapshot P2P peut être plus frais que le cloud. Armer la garde
            // monotone AVANT le remplacement, avec l'ancien préfixe comme base. Sans cela,
            // le cas réel Nord→Est puis Sud→Ouest pouvait afficher Ouest, recevoir ensuite
            // un cloud encore arrêté à Sud, masquer Ouest, puis le réafficher plus tard.
            beginDeferredSnapshotAuctionGuard(idx, localHistory, msg.auctionHistory);
            deals[idx].auctionHistory = msg.auctionHistory;
            if (idx === boardIndex) {
                auctionHistory = deals[idx].auctionHistory;
                // R20 — une extension d'enchère reçue par snapshot se rend comme une
                // annonce normale. `renderBoard()` était beaucoup trop lourd ici : il
                // reconstruisait notamment les mains alors que seules enchère/tour/undo
                // ont changé, d'où le flash visible sur certains appareils.
                renderAfterNormalCall();
            } else {
                const overview = document.getElementById('boardOverviewModal');
                if (overview && overview.style.display !== 'none') renderBoardOverview();
            }
            break;
        }

        // Résultat de double mort arrivé APRÈS le lancement de la partie (voir
        // applyDDResultToBoard côté hôte, qui envoie ce message) — un invité n'a reçu
        // qu'un instantané figé des donnes via 'start-game', donc ce relais est le seul
        // moyen pour lui de recevoir un PAR calculé après coup.
        case 'dd-result': {
            if (!deals) break;
            const idx = deals.findIndex(d => d.board === msg.boardNumber);
            if (idx === -1) break;
            deals[idx].ddTable = msg.table;
            if (idx === boardIndex && (isAuctionOver(auctionHistory) || isTrueOriginalHost() || isKibbitz())) checkAuctionEnd();
            break;
        }

        case 'reset-auction': {
            if (!deals || msg.boardIndex !== boardIndex) return;
            // R16 — un reset P2P explicite est une réduction autoritaire, pas un snapshot
            // cloud retardataire : aucune garde de fraîcheur d'annonce ne doit la masquer.
            clearDeferredOptimisticAuctionGuard(boardIndex, null, null, 'peer-reset');
            auctionHistory = [];
            deals[boardIndex].auctionHistory = auctionHistory; // reste la référence partagée
            hostPendingUndo = null;
            clearUndoUiState();
            renderAuctionLedger();
            renderBiddingBox();
            renderMyHands();
            checkAuctionEnd();
            relayIfHost(msg, guestIndex);
            maybeRobotBid(); // sans effet si on n'est pas l'hôte ; couvre le cas où c'est
                              // un invité qui a demandé le reset (l'hôte doit prendre le relais)
            break;
        }

        case 'goto-board': {
            if (!deals) return;
            // R14 — en différé, boardIndex est strictement local. Un ancien onglet ou un
            // ancien Service Worker peut encore faire émettre un goto-board par l'hôte :
            // le RECEIVER doit donc lui aussi être fail-closed, pas seulement l'émetteur
            // moderne dans gotoBoard(). C'est volontairement un simple ignore : l'état
            // des enchères converge déjà par cloud/precalc/call indépendamment de la vue.
            if (deferredRoomMode) {
                recordSyncTrace('peer.goto-board.ignored-deferred', { requestedBoardIndex: msg.boardIndex });
                break;
            }
            const targetBoardIndex = Number(msg.boardIndex);
            if (!Number.isInteger(targetBoardIndex) || targetBoardIndex < 0 || targetBoardIndex >= deals.length) {
                rejectPeerProtocolMessage(msg, guestIndex, 'index de donne invalide');
                break;
            }
            boardIndex = targetBoardIndex;
            // Depuis le pré-calcul progressif au lancement, goto-board transporte aussi
            // l'historique AUTORITAIRE de la donne cible. Ainsi un saut très rapide vers
            // une donne encore non diffusée par precalc-board ne peut jamais laisser un
            // invité avec un snapshot différent de celui de l'hôte. Compatibilité avec
            // les anciens messages : si le champ manque, on garde la copie locale.
            if (Array.isArray(msg.auctionHistory)) {
                deals[boardIndex].auctionHistory = msg.auctionHistory;
            } else if (!deals[boardIndex].auctionHistory) {
                deals[boardIndex].auctionHistory = [];
            }
            auctionHistory = deals[boardIndex].auctionHistory;
            hostPendingUndo = null;
            clearUndoUiState();
            renderBoard();
            // Quand l'hôte change de donne, le navigateur mobile de l'invité conservait
            // parfois l'ancien scroll et le clampait au nouveau bas de page — typiquement
            // directement dans le chat. Le même recalage que le bouton "Donne suivante"
            // de l'hôte est donc appliqué au destinataire après le rendu de la nouvelle
            // donne. Sans effet sur desktop.
            positionNextBoardAfterParNavigation();
            relayIfHost(msg, guestIndex);
            break;
        }

        // --- Demande d'annulation (undo) ---
        // Voir la section "Demande d'annulation (undo)" plus bas pour le détail du protocole.
        // L'hôte est toujours l'arbitre : 'undo-request' et 'undo-answer' ne sont traités
        // que par lui ; 'undo-ask', 'undo-apply' et 'undo-rejected' sont ce qu'il diffuse.
        case 'undo-request': {
            if (myRole !== 'host') return;
            const senderId = authenticatedGuestId(guestIndex);
            if (!senderId || msg.requesterId !== senderId) {
                rejectPeerProtocolMessage(msg, guestIndex, 'requesterId d’Undo ne correspond pas à la connexion');
                return;
            }
            hostHandleUndoRequest(msg);
            break;
        }

        case 'undo-ask': {
            pendingUndoAsk = msg;
            renderUndoAskBanner();
            renderUndoControls();
            break;
        }

        case 'undo-answer': {
            if (myRole !== 'host') return;
            hostReceiveUndoAnswer(msg);
            break;
        }

        case 'undo-apply': {
            if (!deals) return;
            const targetBoardIndex = Number(msg.boardIndex);
            if (!Number.isInteger(targetBoardIndex) || targetBoardIndex < 0 || targetBoardIndex >= deals.length || !deals[targetBoardIndex]) return;
            if (!deferredRoomMode && targetBoardIndex !== boardIndex) return;

            // R28 — un Undo P2P porte sur SA donne, sans déplacer la navigation locale du
            // destinataire. Cela permet à Nord d'annuler sur la donne 3 pendant que Sud
            // regarde la 7, et garde aussi les autres invités cohérents hors écran.
            const targetDeal = deals[targetBoardIndex];
            if (!Array.isArray(targetDeal.auctionHistory)) targetDeal.auctionHistory = [];
            const targetHistory = targetDeal.auctionHistory;

            // R16 — un Undo explicitement reçu prime immédiatement sur les protections
            // anti-clignotement/snapshot de cette donne, y compris hors écran.
            clearDeferredOptimisticAuctionGuard(targetBoardIndex, null, null, 'peer-undo');
            if (typeof msg.newLength === 'number') {
                targetHistory.length = Math.max(0, Math.min(msg.newLength, targetHistory.length));
            } else if (targetHistory.length > 0) {
                targetHistory.pop(); // compat, ne devrait plus arriver
            }

            if (targetBoardIndex === boardIndex) {
                auctionHistory = targetHistory;
                renderAuctionLedger();
                renderBiddingBox();
                renderMyHands();
                checkAuctionEnd();
                clearUndoUiState();
            } else {
                const overview = document.getElementById('boardOverviewModal');
                if (overview && overview.style.display !== 'none') renderBoardOverview();
            }
            break;
        }

        case 'undo-rejected': {
            if (msg.requesterId !== myParticipantId) return;
            clearUndoUiState();
            setUndoStatus(undoRejectReasonText(msg.reason));
            break;
        }
    }
}

// Quand l'hôte reçoit un message d'un invité, il le relaie aux AUTRES invités (les invités
// ne sont jamais connectés entre eux). Ne fait rien de plus en configuration à 2 joueurs.
function relayIfHost(msg, fromGuestIndex) {
    if (myRole === 'host') {
        peerConn.sendExcept(msg, fromGuestIndex);
    }
}

function advanceRobotBidsOnBoard(idx) {
    // PONS est asynchrone (WASM). Depuis son chargement différé, l'absence momentanée de
    // window.PonsEngine signifie « pas encore chargé », JAMAIS « utiliser le legacy ».
    // Ce helper synchrone ne reste donc valable que pour le mode volontaire passOnly.
    if (robotBiddingMode !== 'passOnly') return;
    if (!deals || !deals[idx]) return;
    const deal = deals[idx];
    if (!deal.auctionHistory) deal.auctionHistory = [];
    const hist = deal.auctionHistory;
    let safety = 0; // garde-fou, largement au-delà de toute enchère réelle possible
    while (!isAuctionOver(hist) && safety < 60) {
        const turnSeat = currentTurnSeat(deal.dealer, hist);
        if (!autoPassSeats.includes(turnSeat)) break;
        const call = 'PASS';
        const explanation = 'Mode « passe en boucle » activé';
        hist.push({ seat: turnSeat, call, explanation });
        safety++;
    }
}

// Avancement PONS hors écran, donne par donne.
//
// R12 — ce mécanisme n'est PLUS réservé aux tables 100 % robots. Sur une table mixte,
// toute donne doit pouvoir avancer en arrière-plan tant que c'est le tour d'un robot,
// puis s'arrêter exactement au premier siège humain (ou à la fin de l'enchère). C'est
// indispensable à deux comportements produit :
//   1. au lancement, les robots qui parlent avant les humains préparent TOUTES les donnes ;
//   2. en différé, si un guest annonce sur une donne que l'hôte ne regarde pas, le robot
//      suivant doit répondre sans attendre que l'hôte revienne sur cette donne.
//
// Un Set verrouille chaque donne pendant un calcul PONS asynchrone. La génération invalide
// proprement les travaux d'une séance précédente/reprise et les contrôles après chaque await
// empêchent un résultat calculé sur un ancien historique d'être appliqué après une mutation.
let robotBackgroundGeneration = 0;
const robotBoardsResolving = new Set();

async function resolveRobotBoardInBackground(idx, generation = robotBackgroundGeneration, options = {}) {
    if (!deals || !deals[idx] || generation !== robotBackgroundGeneration) return;
    if (!autoPassSeats || autoPassSeats.length === 0) return;
    if (robotBoardsResolving.has(idx)) return;

    const deal = deals[idx];
    if (!deal.auctionHistory) deal.auctionHistory = [];
    const hist = deal.auctionHistory;
    if (isAuctionOver(hist)) return;
    const historyLengthAtStart = hist.length;

    robotBoardsResolving.add(idx);
    try {
        let safety = 0;
        while (!isAuctionOver(hist) && safety < 60) {
            if (generation !== robotBackgroundGeneration || !deals || deals[idx] !== deal) return;
            const turnSeat = currentTurnSeat(deal.dealer, hist);
            if (!autoPassSeats.includes(turnSeat)) return; // premier humain atteint

            const historyLengthBeforeDecision = hist.length;
            let call, explanation;
            if (robotBiddingMode === 'passOnly') {
                call = 'PASS';
                explanation = 'Mode « passe en boucle » activé';
            } else {
                try {
                    const pons = await ensurePonsClientReady();
                    ({ call, explanation } = await pons.decideRobotCallForApp(turnSeat, deal, hist, autoPassSeats, { shortNT: robotShortNtMode }));
                } catch (err) {
                    console.error('[PLAY/PONS strict] calcul robot arrière-plan arrêté : PONS indisponible', err);
                    return;
                }
            }

            // Une annonce humaine, un undo ou une resynchronisation cloud a pu modifier
            // l'historique pendant le calcul WASM : jeter ce résultat devenu obsolète.
            if (generation !== robotBackgroundGeneration || !deals || deals[idx] !== deal) return;
            if (hist.length !== historyLengthBeforeDecision) continue;
            if (isAuctionOver(hist) || currentTurnSeat(deal.dealer, hist) !== turnSeat) continue;

            if (!isCallLegal(hist, call, turnSeat)) {
                console.warn('[Robot PONS arrière-plan] annonce illégale reçue, repli Passe', call);
                call = 'PASS';
                explanation = `${explanation || 'Moteur robot'} · annonce illégale rejetée par PLAY`;
            }
            hist.push(explanation ? { seat: turnSeat, call, explanation } : { seat: turnSeat, call });
            safety++;
        }
    } finally {
        robotBoardsResolving.delete(idx);
        const stillSameDeal = deals && deals[idx] === deal && generation === robotBackgroundGeneration;
        const historyChanged = stillSameDeal && deal.auctionHistory.length !== historyLengthAtStart;
        if (historyChanged && !options.quiet) {
            // `precalc-board` est un snapshot monotone : il met à jour aussi le guest qui
            // travaille sur cette donne sans déplacer la vue locale de l'hôte.
            broadcastPrecalculatedBoard(idx);
            if (boardIndex === idx) {
                auctionHistory = deal.auctionHistory;
                renderBoard();
            }
            saveHostGameStateToStorage();
        }
    }
}

async function ensureRobotPrefixReadyOnBoard(idx) {
    if (!deals || !deals[idx] || !autoPassSeats || autoPassSeats.length === 0) return;
    // Si le scheduler de lancement travaille déjà sur cette donne, attendre son résultat
    // plutôt que de conclure trop tôt que la donne n'attend personne.
    while (robotBoardsResolving.has(idx)) {
        await new Promise(resolve => setTimeout(resolve, 16));
        if (!deals || !deals[idx]) return;
    }
    await resolveRobotBoardInBackground(idx, robotBackgroundGeneration);
}

function continueRobotBidsOnBoardInBackground(idx) {
    if (myRole !== 'host' || !deals || !deals[idx]) return;
    const generation = robotBackgroundGeneration;
    resolveRobotBoardInBackground(idx, generation).catch(err =>
        console.warn(`[Robot PONS arrière-plan] donne ${idx + 1} interrompue`, err)
    );
}

async function resolveAllOtherRobotBoards(excludeIdx, options = {}) {
    if (!deals || !autoPassSeats || autoPassSeats.length === 0) return;
    const generation = ++robotBackgroundGeneration;
    for (let idx = 0; idx < deals.length; idx++) {
        if (generation !== robotBackgroundGeneration || !deals) return;
        if (idx === excludeIdx || isAuctionOver(deals[idx].auctionHistory || [])) continue;
        await resolveRobotBoardInBackground(idx, generation, options);
    }
}

// Prépare toutes les autres donnes jusqu'au prochain tour humain. En PONS/WASM, le calcul
// est asynchrone et séquentiel pour ne pas lancer des dizaines d'inférences concurrentes.
// En passOnly, le même resolver est immédiat mais on garde une seule sémantique commune.
function advanceRobotBidsOnAllBoards(excludeIdx) {
    if (myRole !== 'host') return;
    if (!deals || !autoPassSeats || autoPassSeats.length === 0) return;
    if (robotBiddingMode !== 'passOnly' && !window.PonsEngine) {
        ensurePonsClientReady()
            .then(() => advanceRobotBidsOnAllBoards(excludeIdx))
            .catch(err => console.warn('[Robot PONS arrière-plan] moteur indisponible', err));
        return;
    }
    resolveAllOtherRobotBoards(excludeIdx).catch(err =>
        console.warn('[Robot PONS arrière-plan] pré-calcul interrompu', err)
    );
}

// ===== Lancement fluide : pré-calcul legacy progressif =====
//
// `advanceRobotBidsOnAllBoards()` reste inchangé pour les chemins historiques qui ont
// explicitement besoin d'un état immédiatement complet (reprise, vue d'ensemble, etc.).
// Seul le lancement d'une NOUVELLE séance utilise ce scheduler : une seule donne legacy
// est préparée par créneau libre, puis le navigateur récupère la main avant la suivante.
// Cela évite un long bloc synchrone juste après le premier paint sans changer les règles
// d'enchère ni le contenu final des historiques.
let startupLegacyPrecalcGeneration = 0;
let startupLegacyPrecalcHandle = null;
let startupLegacyPrecalcHandleKind = null;

function cloneAuctionHistoryForWire(hist) {
    // R21 — ne jamais laisser un détail purement UI voyager avec l'état métier.
    // `_flashed` était autrefois posé directement sur l'entrée d'enchère par
    // renderAuctionLedger(); le cloud le normalise/supprime, ce qui faisait croire à
    // R20 qu'une confirmation identique était une mutation et réarmait le flash.
    return (hist || []).map(entry => {
        const clean = { seat: entry.seat, call: entry.call };
        if (entry.explanation != null) clean.explanation = entry.explanation;
        return clean;
    });
}

function cloneDealsForCloudPayload(sourceDeals) {
    return (sourceDeals || []).map(deal => ({
        ...deal,
        auctionHistory: cloneAuctionHistoryForWire((deal && deal.auctionHistory) || [])
    }));
}

function broadcastPrecalculatedBoard(idx) {
    if (myRole !== 'host' || !deals || !deals[idx] || !peerConn) return;
    peerConn.send({
        type: 'precalc-board',
        boardIndex: idx,
        auctionHistory: cloneAuctionHistoryForWire(deals[idx].auctionHistory || [])
    });
}

// R17 — en différé, un simple message `call` ne doit jamais être l'unique véhicule d'une
// réponse robot. La recette réelle a montré un cas où Nord avait bien sa propre annonce,
// Est avait déjà joué côté hôte, mais le petit paquet P2P de l'annonce d'Est n'avait pas
// encore produit d'état visible chez Nord ; la séquence ne réapparaissait qu'à l'écriture
// suivante de Sud. On réutilise donc `precalc-board` comme snapshot monotone de la DONNE :
// il peut uniquement étendre l'historique côté guest et ne déplace jamais sa navigation.
//
// Ce helper couvre l'autre moitié du problème : si le robot a été calculé par l'autorité
// serveur (et non localement par l'hôte), applyCloudUpdate doit republier toute donne dont
// l'historique vient de s'allonger, y compris une donne hors écran de l'hôte.
function sameAuctionCallForDeferredSnapshot(a, b) {
    return !!a && !!b
        && a.seat === b.seat
        && String(a.call || '').toUpperCase() === String(b.call || '').toUpperCase();
}

function auctionCallsArePrefixForDeferredSnapshot(prefix, full) {
    if (!Array.isArray(prefix) || !Array.isArray(full) || prefix.length > full.length) return false;
    return prefix.every((entry, i) => sameAuctionCallForDeferredSnapshot(entry, full[i]));
}

function broadcastDeferredExtendedBoardSnapshots(previousAuctionHistories) {
    if (myRole !== 'host' || !deferredRoomMode || !peerConn || !deals) return 0;
    const previous = Array.isArray(previousAuctionHistories) ? previousAuctionHistories : [];
    let sent = 0;
    for (let idx = 0; idx < deals.length; idx++) {
        const before = Array.isArray(previous[idx]) ? previous[idx] : [];
        const after = Array.isArray(deals[idx] && deals[idx].auctionHistory) ? deals[idx].auctionHistory : [];
        if (after.length <= before.length) continue;
        if (!auctionCallsArePrefixForDeferredSnapshot(before, after)) continue;
        broadcastPrecalculatedBoard(idx);
        sent++;
    }
    return sent;
}

function cancelStartupLegacyRobotPrecalc() {
    startupLegacyPrecalcGeneration++;
    if (startupLegacyPrecalcHandle != null) {
        if (startupLegacyPrecalcHandleKind === 'idle' && window.cancelIdleCallback) {
            window.cancelIdleCallback(startupLegacyPrecalcHandle);
        } else {
            clearTimeout(startupLegacyPrecalcHandle);
        }
    }
    startupLegacyPrecalcHandle = null;
    startupLegacyPrecalcHandleKind = null;
}

function scheduleStartupLegacyRobotPrecalc(excludeIdx) {
    cancelStartupLegacyRobotPrecalc();
    // Le legacy n'est plus un substitut temporaire pendant le lazy-load de PONS.
    if (!deals || window.PonsEngine || robotBiddingMode !== 'passOnly') return;

    const generation = startupLegacyPrecalcGeneration;
    const queue = deals.map((_, idx) => idx).filter(idx => idx !== excludeIdx);
    let cursor = 0;

    const scheduleNext = (run) => {
        if (generation !== startupLegacyPrecalcGeneration || cursor >= queue.length) return;
        if (window.requestIdleCallback) {
            startupLegacyPrecalcHandleKind = 'idle';
            startupLegacyPrecalcHandle = window.requestIdleCallback(run, { timeout: 120 });
        } else {
            // Safari/iOS ne fournit pas requestIdleCallback : 16 ms laisse au minimum
            // l'occasion d'un frame et des événements utilisateur entre deux donnes.
            startupLegacyPrecalcHandleKind = 'timeout';
            startupLegacyPrecalcHandle = setTimeout(run, 16);
        }
    };

    const runOneBoard = () => {
        startupLegacyPrecalcHandle = null;
        startupLegacyPrecalcHandleKind = null;
        if (generation !== startupLegacyPrecalcGeneration || !deals) return;

        if (cursor >= queue.length) {
            saveHostGameStateToStorage();
            return;
        }

        const idx = queue[cursor++];
        // Si l'utilisateur a déjà navigué sur cette donne, le chemin visible (gotoBoard /
        // maybeRobotBid) est prioritaire. Ne jamais la modifier silencieusement derrière
        // son dos ; on passe simplement à la suivante.
        if (idx !== boardIndex) {
            advanceRobotBidsOnBoard(idx);
            broadcastPrecalculatedBoard(idx);
        }

        if (cursor < queue.length) {
            scheduleNext(runOneBoard);
        } else {
            // Une seule sauvegarde consolidée en fin de passe : évite de sérialiser toute
            // la séance et de pousser le cloud après CHAQUE donne, ce qui recréerait une
            // autre forme de charge juste après le démarrage.
            saveHostGameStateToStorage();
        }
    };

    scheduleNext(runOneBoard);
}

function maybeRobotBid() {
    if (allPassInProgress) return;
    if (myRole !== 'host') return;
    if (robotBoardsResolving.has(boardIndex)) return;
    if (!autoPassSeats || autoPassSeats.length === 0) return;
    if (!deals || isAuctionOver(auctionHistory)) return;

    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    if (!autoPassSeats.includes(turnSeat)) return;

    // Autorité PONS serveur en mode relais/différé : un client qui n'a PAS la capacité
    // d'écriture host mais possède une preuve participant ne calcule plus l'annonce robot
    // localement. Il pousse seulement son snapshot courant ; api/session.js ignore toute
    // proposition robot et fait progresser PONS côté serveur à partir de l'état Redis.
    // Le host live conserve le chemin local historique (latence minimale + P2P direct).
    const relayCredential = participantCredentialForCloudWrite();
    const hasHostCloudAuthority = typeof getSessionHostWriteKey === 'function'
        && !!getSessionHostWriteKey(currentRoomCode);
    if (relayCredential && !hasHostCloudAuthority) {
        pushDebugLog(`Tour robot ${turnSeat} : décision déléguée à l'autorité PONS serveur.`);
        pushCloudGameState();
        return;
    }

    const boardAtSchedule = boardIndex;
    const historyLengthAtSchedule = auctionHistory.length;

    setTimeout(async () => {
        if (allPassInProgress) return;
        if (boardIndex !== boardAtSchedule) return;
        if (auctionHistory.length !== historyLengthAtSchedule) return;
        if (isAuctionOver(auctionHistory)) return;
        const stillTurnSeat = currentTurnSeat(currentDeal().dealer, auctionHistory);
        if (stillTurnSeat !== turnSeat) return;

        let call, explanation;
        if (robotBiddingMode === 'passOnly') {
            call = 'PASS';
            explanation = 'Mode « passe en boucle » activé';
        } else {
            try {
                const pons = await ensurePonsClientReady();
                ({ call, explanation } = await pons.decideRobotCallForApp(turnSeat, currentDeal(), auctionHistory, autoPassSeats, { shortNT: robotShortNtMode }));
            } catch (err) {
                console.error("[PLAY/PONS strict] robot bloqué : PONS v2.61 n'est pas disponible", err);
                return;
            }
        }

        // PONS est asynchrone : vérifier que rien n'a changé pendant son calcul.
        if (allPassInProgress) return;
        if (boardIndex !== boardAtSchedule) return;
        if (auctionHistory.length !== historyLengthAtSchedule) return;
        if (isAuctionOver(auctionHistory)) return;
        if (currentTurnSeat(currentDeal().dealer, auctionHistory) !== turnSeat) return;
        if (!isCallLegal(auctionHistory, call, turnSeat)) {
            console.warn('[Robot PONS] annonce illégale reçue, repli Passe', call);
            call = 'PASS';
            explanation = `${explanation || 'Moteur robot'} · annonce illégale rejetée par PLAY`;
        }

        applyCall(turnSeat, call, explanation);
        peerConn.send({ type: 'call', boardIndex, seat: turnSeat, call, explanation });
    }, 300);
}

// ===== Écran de jeu =====

function enterGameScreen() {
    showScreen('screen-game');
    // Voir échange avec Guillaume (session du 8 août — "le lien à copier devrait
    // apparaître même pour un non hôte") : point d'entrée UNIQUE et universel — les
    // chemins live (buildHostHandlers/buildGuestHandlers) le remplissaient déjà chacun
    // de leur côté, mais la reprise cloud et le mode différé (NullPeerConnection) ne
    // passent par AUCUN des deux, et n'auraient donc jamais rempli ce champ sans ça.
    if (currentRoomCode) updateShareLinkForRoom(currentRoomCode);
    renderBoard();
}

function seatFullName(seat) {
    return SEAT_FULL_NAME[seat];
}

// Voir échange avec Guillaume (session du 23 juillet) : "Nom (Siège)" pour un joueur
// assis, juste "Nom" pour un kibitz — utilisé par les toasts de (dé)connexion
// (flashPresenceToast) pour un texte cohérent, avec ou sans siège selon le cas.
function presenceLabelFor(p) {
    const seat = SEATS.find(s => seatAssignment[s] === p.id);
    return seat ? `${p.name} (${seatFullName(seat)})` : p.name;
}

// ===== Bannière de reconnexion =====
//
// Signale, pendant toute la partie (pas seulement quand c'est son tour — voir aussi
// #turnIndicator/.disconnected-turn dans renderGameHeader pour ce cas précis), tout
// joueur assis à la table actuellement déconnecté. Un joueur déconnecté n'est PAS
// remplacé par un robot (voir onPeerDisconnected) : son siège attend simplement qu'il
// revienne. L'ancienne bannière persistante a été remplacée par des toasts ponctuels.

// Affiche brièvement "X est de retour" à la place de la bannière d'attente, puis revient
// automatiquement à l'affichage normal après quelques secondes.
// Voir échange avec Guillaume (session du 23 juillet — "un bandeau similaire à celui du
// wizz") : même mécanique d'apparition que flashWizzToast, deux teintes (voir
// .presence-toast dans styles.css) — remplace l'ancienne bannière persistante pour les
// annonces ponctuelles de (dé)connexion d'un participant, y compris notre propre coupure.
function flashPresenceToast(text, isConnect) {
    let toast = document.getElementById('presenceToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'presenceToast';
        document.body.appendChild(toast);
    }
    toast.className = 'presence-toast ' + (isConnect ? 'is-connect' : 'is-disconnect');
    toast.textContent = text;
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 4000);
}

// Voir échange avec Guillaume ("je ne veux que le message, pas le bandeau avec le temps
// qui défile") : la bannière persistante (avec son compteur de secondes) a été retirée —
// seul le toast rouge initial (flashPresenceToast, "🔌 Connexion à l'hôte perdue")
// signale désormais une déconnexion, plus rien de permanent à l'écran pendant toute la
// durée de la coupure. L'élément HTML #reconnectionBanner reste en place (masqué en
// permanence) plutôt que retiré, au cas où ce choix serait révisé plus tard.
function renderReconnectionBanner() {
    const banner = document.getElementById('reconnectionBanner');
    if (!banner) return;
    banner.style.display = 'none';
}

function renderBoard() {
    renderGameHeader();
    renderHandDisplayOptionButtons();
    renderMyHands();
    renderAuctionLedger();
    renderBiddingBox();
    checkAuctionEnd();
    updateBoardControlVisibility();
    renderUndoControls();
    renderUndoAskBanner();
    renderBoardSkipControls();
    renderReconnectionBanner();
    // Voir échange avec Guillaume (session du 23 juillet — "ça n'affiche plus à la 2e
    // déconnexion") : renderChat() manquait ici, contrairement à renderRoomBoard()
    // juste en dessous — la couleur rouge des noms déconnectés dans le chat (voir
    // renderChat) ne se mettait donc à jour que par coïncidence, si un AUTRE événement
    // (nouveau message...) déclenchait un rendu au même moment. Même garde que
    // renderRoomBoard : seulement si le panneau est effectivement ouvert.
    if (chatPanelOpen) {
        renderRoomBoard();
        renderChat();
    }
    maybeRobotBid();
}

function updateBoardControlVisibility() {
    updateCapabilityRotationControls();
    const resetBtn = document.getElementById('resetAuctionBtn');
    // Voir échange avec Guillaume (session du 8 août — "recommencer l'enchère ne devrait
    // pas apparaître pour un non hôte") : réservé à l'hôte seul, pas canControlBoard()
    // (qui autorise aussi tout joueur assis) — recommencer une enchère pour toute la
    // table reste une décision d'organisation, comme la rotation des sièges juste en
    // dessous.
    // Voir échange avec Guillaume ("en mode différé, l'invité ne devrait pas avoir
    // recommencer l'enchère, ni la rotation, ni la réorganisation des sièges") :
    // isTrueOriginalHost() plutôt que myRole==='host' — en mode différé, TOUT participant
    // qui reprend la salle obtient myRole='host' localement (voir uiResumeFromCloud, pur
    // contrôle technique, pas une identité), donc ce critère seul montrait ces boutons à
    // n'importe quel invité différé, pas seulement au vrai créateur.
    if (resetBtn) resetBtn.style.display = isTrueOriginalHost() ? '' : 'none';
    const allPassBtn = document.getElementById('allPassBtn');
    if (allPassBtn) {
        const canAllPass = isTrueOriginalHost();
        allPassBtn.style.visibility = canAllPass ? '' : 'hidden';
        allPassBtn.style.pointerEvents = canAllPass ? '' : 'none';
        allPassBtn.disabled = !canAllPass || !deals || isAuctionOver(auctionHistory);
    }
    // Réservé à l'hôte (voir échange avec Guillaume) : changer qui est assis où reste une
    // décision d'organisation de la table, pas quelque chose qu'un simple joueur assis
    // devrait pouvoir déclencher pour tout le monde.
    //
    // Update UI 21/08 : sur la vue invité desktop, les emplacements invisibles de Rotation /
    // Réorganiser ne doivent plus réserver de largeur sur la 2e ligne. L'export de session
    // reste bien sur cette 2e ligne, mais devient son premier bouton visible. On utilise donc
    // display:none pour ces contrôles hôte sur un invité (au lieu de visibility:hidden).
    const isOriginalHost = isTrueOriginalHost();
    const rotateBtn = document.getElementById('rotateSeatsBtn');
    if (rotateBtn) {
        rotateBtn.style.display = isOriginalHost ? '' : 'none';
        rotateBtn.style.visibility = isOriginalHost ? '' : 'hidden';
        rotateBtn.style.pointerEvents = isOriginalHost ? '' : 'none';
    }
    // Voir échange avec Guillaume (session du 23 juillet) : même traitement que
    // "Rotation" juste au-dessus — réservé à l'hôte, seul à pouvoir réorganiser qui joue
    // où (voir uiOpenSeatReorgModal).
    const seatReorgBtn = document.getElementById('seatReorgBtn');
    if (seatReorgBtn) {
        seatReorgBtn.style.display = isOriginalHost ? '' : 'none';
        seatReorgBtn.style.visibility = isOriginalHost ? '' : 'hidden';
        seatReorgBtn.style.pointerEvents = isOriginalHost ? '' : 'none';
    }
    const gameRotateCapabilitiesBtn = document.getElementById('gameRotateCapabilitiesBtn');
    if (gameRotateCapabilitiesBtn) {
        gameRotateCapabilitiesBtn.style.display = isOriginalHost ? '' : 'none';
        if (!isOriginalHost) {
            gameRotateCapabilitiesBtn.style.visibility = 'hidden';
            gameRotateCapabilitiesBtn.style.pointerEvents = 'none';
        }
    }
    // Export de session : le choix Local / GitHub est disponible à tout joueur actif,
    // avec la même authentification cloud que l'export PBN d'une donne.
    const exportBtn = document.getElementById('exportSessionBtn');
    if (exportBtn) exportBtn.style.display = canControlBoard() ? '' : 'none';
}

// URL d'accueil de CETTE copie de l'application.
// On conserve exactement le chemin courant et on retire uniquement query/hash :
// - https://capgui13.github.io/play/?room=2745 -> https://capgui13.github.io/play/
// - file:///C:/.../play/index.html?room=5858 -> file:///C:/.../play/index.html
function currentAppHomeUrl() {
    try {
        const url = new URL(window.location.href);
        url.search = '';
        url.hash = '';
        return url.toString();
    } catch (e) {
        return 'index.html';
    }
}

// Fondu 325 ms réservé aux navigations explicites entre donnes.
// On anime uniquement ce qui change réellement : numéro, ligne donneur/vulnérabilité/
// position jouée et rectangle de cartes actuellement visible.
function fadeBoardNavigationTargets() {
    const targets = [
        document.getElementById('boardNumberLabel'),
        document.getElementById('dealerVulnLabel')
    ];

    const myHandsEl = document.getElementById('myHandsContainer');
    const allHandsEl = document.getElementById('allHandsDiagram');

    if (myHandsEl && getComputedStyle(myHandsEl).display !== 'none') targets.push(myHandsEl);
    if (allHandsEl && getComputedStyle(allHandsEl).display !== 'none') targets.push(allHandsEl);

    replayQuickFadeGroup(targets.filter(Boolean));
}

function renderGameHeader() {
    const deal = currentDeal();
    document.getElementById('boardNumberLabel').textContent = `Donne #${deal.board} (${boardIndex + 1}/${deals.length})`;
    const mySeatsLabel = mySeats && mySeats.length > 0 ? mySeats.map(seatFullName).join(' + ') : 'kibbitz';
    document.getElementById('dealerVulnLabel').textContent =
        `Donneur : ${seatFullName(deal.dealer)} · ${VULN_LABEL[deal.vulnerable]} · Vous jouez : ${mySeatsLabel}`;
    // Voir échange avec Guillaume : le code de salle n'était visible que dans le salon
    // d'attente, plus du tout une fois la partie lancée — utile pourtant en cours de
    // route (inviter quelqu'un en plein milieu, ou simplement s'en souvenir).
    const roomCodeEl = document.getElementById('gameRoomCodeLabel');
    if (roomCodeEl) {
        // Voir échange avec Guillaume (session du 24 juillet) : nom de l'hôte affiché à
        // côté du code — utile pour un joueur (ou un kibitz) qui rejoint en cours de
        // route et se demande qui héberge la partie.
        // Voir échange avec Guillaume ("je ne veux pas de bascule d'hôte") : roomCreatorName
        // est figé une fois pour toutes à la création (voir uiCreateRoom) et ne bouge plus
        // jamais, contrairement au participant technique 'host', qui lui peut changer de
        // main (reprise cloud ou reconnexion) sans que ça doive se voir ici. Repli sur le
        // participant 'host' actuel uniquement si roomCreatorName n'est pas encore défini
        // (session en mémoire créée avant l'ajout de ce champ).
        const hostParticipant = participants.find(p => p.id === 'host');
        const displayedHostName = roomCreatorName || (hostParticipant ? hostParticipant.name : null);
        if (currentRoomCode) {
            // Salle/Hôte restent sur deux lignes, mais sans repousser les trois icônes :
            // le span invisible ci-dessous réserve EXACTEMENT la largeur qu'occupait
            // l'ancien libellé sur une seule ligne (« Salle : XXXX · Hôte : Nom »). Les
            // boutons retrouvent donc leur ancienne position ; le bloc visible à deux
            // lignes est simplement centré dans cette largeur historique.
            const roomLine = `<span class="game-room-code-main"><span class="game-room-code-key">Salle</span><span class="game-room-code-sep">&nbsp;:&nbsp;</span><span class="game-room-code-value">${escapeHtml(String(currentRoomCode))}</span></span>`;
            const hostLine = displayedHostName
                ? `<span class="game-room-code-host"><span class="game-room-code-key">Hôte</span><span class="game-room-code-sep">&nbsp;:&nbsp;</span><span class="game-room-code-value">${escapeHtml(String(displayedHostName))}</span></span>`
                : '';
            const historicalOneLine = `Salle : ${escapeHtml(String(currentRoomCode))}${displayedHostName ? ` · Hôte : ${escapeHtml(String(displayedHostName))}` : ''}`;
            roomCodeEl.innerHTML = `<span class="game-room-code-sizer" aria-hidden="true">${historicalOneLine}</span><span class="game-room-code-visible">${roomLine}${hostLine}</span>`;
        } else {
            roomCodeEl.textContent = '';
        }
    }
    // Voir échange avec Guillaume (session du 8 août — "le lien à copier devrait
    // apparaître même pour un non hôte") : visible pour tout le monde désormais — copier
    // le lien de la salle pour inviter quelqu'un d'autre n'a aucune raison d'être
    // réservé à l'hôte.
    const headerCopyLinkBtn = document.getElementById('gameHeaderCopyLinkBtn');
    if (headerCopyLinkBtn) headerCopyLinkBtn.style.display = '';
}

// ===== Chat =====
//
// Diffusion par le même mécanisme que les enchères (voir 'call' dans handlePeerData) :
// un invité envoie à l'hôte, qui relaie aux autres invités (relayIfHost) — les invités ne
// sont jamais connectés entre eux. L'hôte, lui, diffuse directement à tout le monde.
// Historique gardé en mémoire pour la session en cours seulement : pas inclus dans
// 'resync', un joueur qui se reconnecte ne revoit pas les messages d'avant sa coupure —
// acceptable pour une fonctionnalité de confort, pas une donnée de jeu à préserver à tout
// prix.
let chatMessages = [];
let chatPanelOpen = false;
// Compatibilité d'état historique : indique que l'initialisation du chat du salon a déjà
// eu lieu pour l'entrée en cours. Le panneau reste désormais affiché en continu une fois
// dans le salon ou la partie.
let lobbyChatAutoOpened = false;
let chatUnreadCount = 0;

// Déplace physiquement #chatPanel dans le flux normal du document. Sur mobile, l'ancien
// panneau flottant (position:fixed) pouvait recouvrir la boîte d'enchères ou le salon ;
// le chat permanent est donc ancré dans le layout. L'opération est idempotente et peut
// être répétée à chaque changement d'écran.
// Sur l'écran de jeu spécifiquement (voir échange avec Guillaume) : ancré DANS
// .game-content-row, comme 3ème colonne à côté de .game-body (voir styles.css), plutôt
// qu'à la toute fin de l'écran — sinon il s'empilerait sous le reste du contenu de jeu
// (tableau d'enchères, case du contrat), pas à droite. Le salon, lui, n'a pas cette
// structure en colonnes : comportement inchangé, ancré à la fin de l'écran.
function dockChatIntoScreen(screenId) {
    const panel = document.getElementById('chatPanel');
    const gameContentRow = screenId === 'screen-game' ? document.querySelector('.game-content-row') : null;
    const targetScreen = gameContentRow || document.getElementById(screenId);
    if (!panel || !targetScreen) return;
    if (panel.parentElement !== targetScreen) targetScreen.appendChild(panel);
    panel.classList.add('chat-panel-docked');
}

// Symétrique : replace le chat dans son emplacement d'origine (juste après la barre de
// connexion), en panneau flottant classique — utilisé uniquement sur l'écran d'accueil,
// où le chat n'a de toute façon aucun sens (personne à qui parler) et reste masqué.
function undockChatFromScreen() {
    const panel = document.getElementById('chatPanel');
    const connectionBar = document.getElementById('connectionBar');
    if (!panel || !connectionBar) return;
    panel.classList.remove('chat-panel-docked');
    if (panel.previousElementSibling !== connectionBar) {
        connectionBar.insertAdjacentElement('afterend', panel);
    }
}


// Voir échange avec Guillaume (session du 23 juillet — "ça m'ouvre la page à mi hauteur") :
// l'ancien bouton ouvrait/fermait le panneau et pouvait déclencher un scroll non désiré.
// Désormais, le chat reste ouvert en continu dans le salon et en partie ; le bouton 💬
// sert seulement de raccourci pour défiler jusqu'au panneau.
function uiEnsureChatVisible(focusInput = false) {
    const panel = document.getElementById('chatPanel');
    if (!panel) return;

    chatPanelOpen = true;
    panel.style.display = 'flex';
    panel.classList.add('chat-panel-visible');

    const chatBtn = document.getElementById('chatToggleBtn');
    if (chatBtn) {
        chatBtn.setAttribute('aria-expanded', 'true');
        chatBtn.setAttribute('aria-label', 'Aller au chat');
    }

    renderChat();
    renderRoomBoard();

    if (focusInput) {
        const input = document.getElementById('chatInput');
        if (input && typeof input.focus === 'function') input.focus({ preventScroll: true });
    }

    requestAnimationFrame(markChatReadIfLatestVisible);
}

function hideChatPanelForLanding() {
    const panel = document.getElementById('chatPanel');
    if (panel) {
        panel.classList.remove('chat-panel-visible');
        panel.style.display = 'none';
    }
    chatPanelOpen = false;
    const chatBtn = document.getElementById('chatToggleBtn');
    if (chatBtn) {
        chatBtn.setAttribute('aria-expanded', 'false');
        chatBtn.setAttribute('aria-label', 'Aller au chat');
    }
}

function uiToggleChat(focusInput = true) {
    uiEnsureChatVisible(focusInput);
}

function prefersReducedMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
}

function uiScrollToChat() {
    uiEnsureChatVisible(false);
    const panel = document.getElementById('chatPanel');
    if (!panel) return;
    const reducedMotion = prefersReducedMotion();
    panel.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
    if (reducedMotion) requestAnimationFrame(markChatReadIfLatestVisible);
    else setTimeout(markChatReadIfLatestVisible, 380);
}

function updateChatUnreadBadge() {
    const badge = document.getElementById('chatUnreadBadge');
    if (!badge) return;
    if (chatUnreadCount > 0) {
        badge.textContent = chatUnreadCount > 9 ? '9+' : String(chatUnreadCount);
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
}

function isChatMessageStreamVisibleOnScreen() {
    if (!chatPanelOpen) return false;
    const stream = document.getElementById('chatMessages');
    if (!stream) return false;
    const rect = stream.getBoundingClientRect();
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    return rect.bottom > 0 && rect.top < viewportHeight;
}

function isLatestChatMessageVisibleOnScreen() {
    if (!isChatMessageStreamVisibleOnScreen()) return false;
    const stream = document.getElementById('chatMessages');
    const last = stream ? stream.lastElementChild : null;
    if (!last) return true;
    const streamRect = stream.getBoundingClientRect();
    const lastRect = last.getBoundingClientRect();
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    return lastRect.bottom > 0
        && lastRect.top < viewportHeight
        && lastRect.top >= streamRect.top - 1
        && lastRect.bottom <= Math.min(streamRect.bottom, viewportHeight) + 1;
}

function markChatReadIfLatestVisible() {
    if (chatUnreadCount <= 0) return;
    if (isLatestChatMessageVisibleOnScreen()) {
        chatUnreadCount = 0;
        updateChatUnreadBadge();
    }
}

function initChatVisibilityTracking() {
    window.addEventListener('scroll', markChatReadIfLatestVisible, { passive: true });
    window.addEventListener('resize', markChatReadIfLatestVisible);
    const stream = document.getElementById('chatMessages');
    if (stream) stream.addEventListener('scroll', markChatReadIfLatestVisible, { passive: true });
}

// Compatibilité interne : cet ancien nom reste utilisé par quelques chemins historiques,
// mais la notion utile est désormais "le dernier message est-il réellement visible à
// l'écran ?" plutôt que "le panneau de chat est-il quelque part dans le viewport ?".
function isChatPanelVisibleOnScreen() {
    return isLatestChatMessageVisibleOnScreen();
}

// Bandeau en haut de l'écran pour un message de chat reçu pendant que le panneau n'est
// pas visible (voir échange avec Guillaume — même mécanique que le wizz) : même style que
// les autres bandeaux, réutilisé tel quel.
function flashChatMessageToast(senderName, text) {
    let toast = document.getElementById('chatMessageToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'chatMessageToast';
        toast.className = 'call-explanation-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = `💬 ${senderName} : ${text}`;
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 3500);
}

// Point d'entrée UNIQUE pour tout message de chat, qu'il vienne de moi (voir
// uiSendChatMessage) ou d'un autre participant (voir handlePeerData) : ajoute au journal,
// met à jour l'affichage, et — seulement pour un message de quelqu'un d'AUTRE que moi, et
// seulement si le panneau n'est pas visible à l'écran (voir isChatPanelVisibleOnScreen) —
// incrémente le badge et affiche un bandeau (voir échange avec Guillaume : le badge doit
// apparaître même si le panneau est techniquement "ouvert" mais hors du champ de vision).
function addChatMessage(msg) {
    chatMessages.push(msg);
    renderChat();
    // Voir échange avec Guillaume (session du 23 juillet — reprise via localStorage) :
    // sans effet si on n'est pas hôte ou si la partie n'est pas lancée (voir la garde à
    // l'intérieur de la fonction elle-même).
    saveHostGameStateToStorage();
    const isMine = msg.senderId === myParticipantId;
    if (!isMine && !isLatestChatMessageVisibleOnScreen()) {
        chatUnreadCount++;
        updateChatUnreadBadge();
        flashChatMessageToast(msg.senderName, msg.text);
    }
}

function renderChat() {
    const el = document.getElementById('chatMessages');
    if (!el) return;
    // Conserver la lecture d'historique : un nouveau message ne doit coller le flux au bas
    // que si l'utilisateur y était déjà (petite tolérance tactile), ou au tout premier
    // rendu. Une insertion en fin de liste ne déplace pas le contenu situé au-dessus, donc
    // restaurer scrollTop suffit lorsque l'utilisateur est remonté lire d'anciens messages.
    const hadRenderedMessages = el.childElementCount > 0;
    const previousScrollTop = el.scrollTop;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const shouldStickToBottom = !hadRenderedMessages || distanceFromBottom <= 32;
    el.innerHTML = chatMessages.map(m => {
        // Tous les messages partent de la gauche, y compris les siens (pas de bulle
        // alignée à droite façon messagerie) — le nom précède toujours le message, avec
        // sa couleur reprise de avatarColorForId (même couleur que la petite pastille
        // d'avatar de ce participant ailleurs dans l'appli, pour un repère cohérent).
        // Voir échange avec Guillaume (session du 23 juillet) : SAUF si ce participant
        // est actuellement déconnecté — rouge (--suit-red, même couleur que
        // .disconnected-tag ailleurs dans l'appli) prend alors le pas sur sa couleur
        // d'avatar habituelle, pour repérer d'un coup d'œil qui a décroché même en
        // relisant d'anciens messages.
        const senderP = participants.find(p => p.id === m.senderId);
        const senderColor = (senderP && senderP.disconnected) ? 'var(--suit-red)' : avatarColorForId(m.senderId);
        // Voir échange avec Guillaume (session du 23 juillet — "pas en cliquant sur le nom
        // des gens dans le chat") : renommage réservé au "qui est là" (voir
        // wizzableNameHtml/renderRoomBoard), plus proposé ici — un simple nom, pas de
        // double-clic ni de titre associé.
        const senderSpan = `<span class="chat-message-sender" style="color:${senderColor}">${escapeHtml(m.senderName)}</span>`;
        return `<div class="chat-message">${senderSpan} : <span class="chat-message-text">${escapeHtml(m.text)}</span></div>`;
    }).join('');
    if (shouldStickToBottom) el.scrollTop = el.scrollHeight;
    else el.scrollTop = previousScrollTop;
    requestAnimationFrame(markChatReadIfLatestVisible);
}

function uiChatInputKeydown(event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    uiSendChatMessage();
}

function uiSendChatMessage() {
    const input = document.getElementById('chatInput');
    // En différé, le chat doit rester utilisable même pendant une reconnexion P2P : le
    // relais cloud ne dépend pas de peerConn. Le live conserve plus bas son chemin P2P.
    if (!input) return;
    // Voir échange avec Guillaume (session du 24 juillet — "je ne suis plus dedans si je
    // clique 2x") : remis AVANT la vérification du texte, pas après — sinon un clic sur
    // "Envoyer" avec un champ déjà vide (ex. un second clic accidentel juste après le
    // premier envoi) sortait du champ sans y revenir, contrairement à un clic avec du
    // texte à envoyer.
    input.focus();
    const text = input.value.trim().slice(0, 500);
    if (!text) return;
    input.value = '';

    const me = participants.find(p => p.id === myParticipantId);
    const msg = { type: 'chat', senderId: myParticipantId, senderName: me ? me.name : '?', text };
    // R32 — capturer TOUJOURS le préfixe avant l'ajout optimiste pour un invité en
    // différé. `peerConn.isConnected()` peut rester vrai pendant la courte fenêtre qui
    // suit la fermeture réelle de l'hôte ; conditionner la garde R31 à ce booléen laissait
    // précisément un snapshot cloud ancien faire disparaître le message avant que le
    // callback de fermeture WebRTC arrive.
    const isDeferredGuestChat = myRole === 'guest' && deferredRoomMode;
    const chatBeforeLocalSend = isDeferredGuestChat
        ? cloneCloudData(chatMessages || [])
        : null;
    addChatMessage(msg);
    // R32 — en différé, le P2P reste le chemin temps-réel quand l'hôte est joignable, mais
    // il n'est plus l'unique garantie de livraison. La persistance participant/cloud est
    // lancée en parallèle avec le préfixe exact capturé AVANT ce message. Ainsi :
    //   - hôte réellement présent : il voit le P2P immédiatement ; le fallback cloud
    //     constate son éventuel commit et devient idempotent ;
    //   - hôte venant juste de fermer mais P2P encore marqué `open` : le message est quand
    //     même durable, sans attendre la détection tardive de `close` ;
    //   - un snapshot cloud en retard ne peut pas l'effacer visuellement grâce à la garde.
    if (isDeferredGuestChat) {
        beginDeferredOptimisticChatGuard(chatBeforeLocalSend || [], msg);
        if (peerConn && peerConn.isConnected()) peerConn.send(msg);
        pushChatViaServerFallback(msg, { expectedBaseChat: chatBeforeLocalSend || [] });
        return;
    }
    // Live avec P2P coupé : conserve le fallback serveur historique.
    if (myRole === 'guest' && (!peerConn || !peerConn.isConnected())) {
        pushChatViaServerFallback(msg);
        return;
    }
    // Live connecté / hôte : chemin P2P historique.
    if (peerConn) peerConn.send(msg);
}

// Synchronisation de la couleur propre quand l'invité n'a plus de P2P. Le snapshot
// proposé reste complet pour le contrat d'API existant, mais le serveur reconstruit lui-même
// l'état autorisé et n'accepte que la mutation du profil de cet acteur authentifié.
async function pushAvatarColorViaServerFallback(avatarColor) {
    const color = normalizeAvatarColor(avatarColor);
    if (!color || !currentRoomCode || typeof pullSessionState !== 'function' || typeof pushSessionState !== 'function') return;
    const cloudCtx = captureCloudSyncContext(currentRoomCode);

    let pulled;
    try {
        pulled = await pullSessionState(cloudCtx.roomCode);
        if (!isCloudSyncContextActive(cloudCtx)) return;
        if (pulled) pulled = validateCloudSnapshot(pulled, cloudCtx.roomCode);
    } catch (e) {
        pushDebugLog('Couleur avatar : lecture serveur impossible : ' + ((e && e.message) || e));
        return;
    }
    if (!pulled) return;

    let authoritative = pulled;
    const maxConflictRebases = 3;
    try {
        for (let conflictAttempt = 0; conflictAttempt <= maxConflictRebases; conflictAttempt++) {
            const proposed = cloneCloudData(authoritative.state);
            const me = (proposed.participants || []).find(p => p.id === myParticipantId);
            if (!me) return;

            // Idempotence après réponse perdue : si la couleur demandée est déjà la valeur
            // autoritaire, le serveur a fait le travail. Ne crée pas une version de plus.
            if (normalizeAvatarColor(me.avatarColor) === color) {
                lastKnownCloudVersion = authoritative.version;
                cloudLastSyncedState = cloneCloudData(authoritative.state);
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                recordSyncTrace('avatar.cloud-fallback.already-committed', { version: authoritative.version });
                return;
            }

            me.avatarColor = color;
            let conflictCurrent = null;
            const result = await pushSessionState(cloudCtx.roomCode, { ...proposed, savedAt: Date.now() }, authoritative.version, {
                participantCredential: participantCredentialForCloudWrite(),
                onConflict: (current) => {
                    if (!isCloudSyncContextActive(cloudCtx)) return;
                    const validCurrent = current && validateCloudSnapshot(current, cloudCtx.roomCode);
                    if (validCurrent) {
                        conflictCurrent = validCurrent;
                        lastKnownCloudVersion = validCurrent.version;
                        cloudLastSyncedState = cloneCloudData(validCurrent.state);
                    }
                    recordSyncTrace('avatar.cloud-fallback.conflict', { version: validCurrent && validCurrent.version, attempt: conflictAttempt + 1 });
                }
            });
            if (!isCloudSyncContextActive(cloudCtx)) return;
            if (result) {
                const restricted = validateCloudSnapshot({ version: result.version, updatedAt: result.updatedAt, state: result.state }, cloudCtx.roomCode);
                if (restricted) {
                    lastKnownCloudVersion = restricted.version;
                    cloudLastSyncedState = cloneCloudData(restricted.state);
                    applyCloudUpdate(restricted, { expectedRoomCode: cloudCtx.roomCode });
                }
                return;
            }
            if (conflictCurrent && conflictAttempt < maxConflictRebases) {
                authoritative = conflictCurrent;
                continue;
            }
            if (conflictCurrent) applyCloudUpdate(conflictCurrent, { expectedRoomCode: cloudCtx.roomCode });
            pushDebugLog('Couleur avatar : trop de conflits successifs, état serveur conservé.');
            return;
        }
    } catch (e) {
        pushDebugLog('Couleur avatar : écriture serveur impossible : ' + ((e && e.message) || e));
    }
}

// Voir échange avec Guillaume ("chat via le relais serveur") : même principe que
// pushCallViaServerFallback — relit l'état serveur, ajoute CE message à sa liste de chat,
// puis repousse avec le verrou de version. Pas de "légalité" à revalider ici
// (contrairement à une annonce) : un message de chat n'a pas de tour, il s'ajoute
// simplement à la suite.
async function pushChatViaServerFallback(msg, options = {}) {
    if (!currentRoomCode || typeof pullSessionState !== 'function' || typeof pushSessionState !== 'function') return;
    const cloudCtx = captureCloudSyncContext(currentRoomCode);

    // R29 — même garantie de continuité que les enchères différées. Après plusieurs
    // fermetures/reprises, la credential participant locale peut manquer alors que la
    // preuve déterministe dérivée du code 4 chiffres reste valide côté serveur. Le chat
    // utilisait encore participantCredentialForCloudWrite() directement : son PUT partait
    // alors sans credential et était refusé, puis le prochain snapshot cloud effaçait le
    // message affiché optimistiquement. En différé guest, récupérer/réarmer la preuve AVANT
    // toute lecture/écriture, exactement comme pushCallViaServerFallback().
    let chatWriteCredential = participantCredentialForCloudWrite();
    if (deferredRoomMode && myRole === 'guest') {
        chatWriteCredential = ensureDeferredGuestCloudWriteCredential();
        if (!chatWriteCredential) {
            recordSyncTrace('chat.cloud-fallback.no-participant-credential', {
                participantId: myParticipantId || null
            });
            pushDebugLog('Message de chat : credential participant différée indisponible.');
            return;
        }
    }

    let pulled;
    try {
        pulled = await pullSessionState(cloudCtx.roomCode);
        if (!isCloudSyncContextActive(cloudCtx)) return;
        if (pulled) pulled = validateCloudSnapshot(pulled, cloudCtx.roomCode);
    } catch (e) {
        pushDebugLog('Remontée serveur du message de chat impossible (lecture) : ' + ((e && e.message) || e));
        return;
    }
    if (!pulled) return;

    const initialChat = cloneCloudData((pulled.state && pulled.state.chatMessages) || []);
    // R32 — quand le même message part aussi en P2P, l'hôte peut le commiter entre notre
    // clic et ce GET (ou pendant notre PUT). Le préfixe d'intention capturé AVANT l'ajout
    // local permet de reconnaître ce commit comme LE NÔTRE et d'éviter tout doublon.
    // Sans option (anciens appels/live), conserver exactement le comportement historique
    // fondé sur l'état lu au début du fallback.
    const intentBaseChat = Array.isArray(options.expectedBaseChat)
        ? cloneCloudData(options.expectedBaseChat)
        : initialChat;
    let authoritative = pulled;
    const maxConflictRebases = 3;

    try {
        for (let conflictAttempt = 0; conflictAttempt <= maxConflictRebases; conflictAttempt++) {
            const baseState = cloneCloudData(authoritative.state);
            if (!baseState.chatMessages) baseState.chatMessages = [];
            const serverChat = baseState.chatMessages;

            // Le chat serveur est append-only. Si le préfixe initial a été réécrit par une
            // action hôte exceptionnelle, on ne tente pas de reconstruire l'intention sur
            // une histoire différente. Sinon on peut rebaser sans risque après un conflit
            // causé par une enchère, une présence ou une autre donne.
            const prefixStillIntact = serverChat.length >= intentBaseChat.length
                && sameCloudData(serverChat.slice(0, intentBaseChat.length), intentBaseChat);
            if (!prefixStillIntact) {
                pushDebugLog('Message de chat : historique serveur réécrit pendant le conflit, resynchronisation sans réinsertion.');
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                return;
            }

            // R32 — idempotence dual-path. Le commit peut avoir été effectué par l'hôte
            // après réception P2P AVANT notre GET, ou pendant notre PUT (409/rebase). Un
            // autre message peut aussi avoir été commité entre-temps : chercher donc notre
            // message dans TOUT le suffixe postérieur au préfixe d'intention, pas seulement
            // à l'index suivant.
            const committed = serverChat.slice(intentBaseChat.length).some(entry => sameCloudData(entry, msg));
            if (committed) {
                lastKnownCloudVersion = authoritative.version;
                cloudLastSyncedState = cloneCloudData(authoritative.state);
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                recordSyncTrace('chat.cloud-fallback.already-committed', { version: authoritative.version });
                return;
            }

            baseState.chatMessages.push(msg);
            const stateToPush = { ...baseState, savedAt: Date.now() };
            let conflictCurrent = null;
            const result = await pushSessionState(cloudCtx.roomCode, stateToPush, authoritative.version, {
                participantCredential: chatWriteCredential,
                onConflict: (current) => {
                    if (!isCloudSyncContextActive(cloudCtx)) return;
                    const validCurrent = current && validateCloudSnapshot(current, cloudCtx.roomCode);
                    if (validCurrent) {
                        conflictCurrent = validCurrent;
                        lastKnownCloudVersion = validCurrent.version;
                        cloudLastSyncedState = cloneCloudData(validCurrent.state);
                    }
                    recordSyncTrace('chat.cloud-fallback.conflict', { version: validCurrent && validCurrent.version, attempt: conflictAttempt + 1 });
                }
            });
            if (!isCloudSyncContextActive(cloudCtx)) return;
            if (result) {
                lastKnownCloudVersion = result.version;
                cloudLastSyncedState = cloneCloudData(result.state || stateToPush);
                if (result.state) {
                    const restricted = validateCloudSnapshot({ version: result.version, updatedAt: result.updatedAt, state: result.state }, cloudCtx.roomCode);
                    if (restricted) applyCloudUpdate(restricted, { expectedRoomCode: cloudCtx.roomCode });
                }
                pushDebugLog(`Message de chat remonté au serveur avec succès (version ${result.version}).`);
                return;
            }
            if (conflictCurrent && conflictAttempt < maxConflictRebases) {
                authoritative = conflictCurrent;
                recordSyncTrace('chat.cloud-fallback.rebase', { version: conflictCurrent.version, attempt: conflictAttempt + 1 });
                continue;
            }
            if (conflictCurrent) applyCloudUpdate(conflictCurrent, { expectedRoomCode: cloudCtx.roomCode });
            pushDebugLog('Message de chat : trop de conflits successifs, resynchronisation sans forcer l\'écriture.');
            return;
        }
    } catch (e) {
        pushDebugLog('Remontée serveur du message de chat impossible (écriture) : ' + ((e && e.message) || e));
    }
}

// ===== Panneau "Salle" (qui est présent pendant la partie) =====
//
// Le salon d'attente montre déjà qui est là et où (renderSeatAssignmentGrid), mais cet
// écran disparaît une fois la partie lancée — il n'y avait alors plus aucun moyen de voir
// qui est présent. Les déconnexions sont signalées ponctuellement par toast, tandis que
// l'état courant reste lisible ici.
// Fusionné dans le panneau de chat plutôt qu'un panneau séparé : un bandeau "qui est
// présent", toujours visible en haut du chat, complète naturellement les messages.
// ===== Wizz (voir échange avec Guillaume : le "nudge" de MSN Messenger — cliquer sur le
// nom de quelqu'un fait trembler son écran) =====
//
// Un seul message réseau ('wizz'), avec un routage à deux vitesses selon qui l'envoie :
// - l'hôte connaît directement la connexion de chaque invité (guestIndexByToken), donc
//   lui envoie le wizz en ciblé, sans détour ;
// - un invité, lui, n'a qu'une seule connexion possible (l'hôte) : il lui envoie le wizz
//   à charge pour l'hôte de le relayer vers le vrai destinataire si ce n'est pas lui-même
//   (voir le cas 'wizz' dans handlePeerData) — topologie en étoile oblige.
const WIZZ_COOLDOWN_MS = 4000; // évite le spam frénétique entre amis, sans l'interdire
const wizzCooldownUntil = {}; // targetId -> timestamp, purement local (pas besoin de sync réseau)

// Nom cliquable pour envoyer un wizz — y compris le sien (voir échange avec Guillaume :
// utile pour tester l'effet sans avoir besoin d'un second appareil/participant) et sauf
// celui de quelqu'un de déconnecté (personne pour le recevoir). Sur son propre nom,
// déclenche l'effet directement en local (voir uiSelfWizz) plutôt que de faire un
// aller-retour réseau inutile.
// Voir échange avec Guillaume (session du 23 juillet) : nom et cloche de wizz séparés en
// deux éléments (au lieu d'un seul span cliquable pour tout) — un double-clic sur le nom
// déclenche maintenant le renommage (host, pour n'importe qui, y compris lui-même — voir
// uiStartRenamingParticipant) pendant qu'un simple clic sur 🔔 déclenche le wizz. Les
// fusionner posait deux problèmes : le texte de la cloche (" 🔔") se serait retrouvé dans
// le champ d'édition du renommage, et un double-clic aurait de toute façon déclenché 2
// wizz au passage (2 clics avant le dblclick) avant d'ouvrir le renommage.
function wizzableNameHtml(p) {
    const canRename = myRole === 'host';
    // Voir échange avec Guillaume (session du 23 juillet — voir aussi renderChat) : même
    // rouge que dans les messages du chat pour un participant déconnecté, cohérent d'un
    // bout à l'autre du même panneau.
    const colorStyle = p.disconnected ? ' style="color:var(--suit-red)"' : '';
    const nameAttrs = canRename
        ? ` class="room-board-name room-board-name-editable" data-ui-dblclick="rename-participant" data-participant-id="${escapeHtml(p.id)}" title="Double-cliquer pour renommer"${colorStyle}`
        : ` class="room-board-name"${colorStyle}`;
    const nameSpan = `<span${nameAttrs}>${escapeHtml(p.name)}</span>`;

    if (p.disconnected) return nameSpan;
    if (p.id === myParticipantId) {
        return `${nameSpan}<span class="room-board-wizz-btn" data-ui-click="self-wizz" title="Tester l'effet wizz sur soi-même">🔔</span>`;
    }
    // Voir échange avec Guillaume ("j'essaye de wizz l'autre mais ça ne marche pas, en
    // mode différé") : pas de canal live en mode différé (NullPeerConnection, voir
    // isWizzTargetReachable) — la cloche échouait donc en silence à chaque clic, sans
    // rien indiquer d'autre qu'une ligne dans un journal masqué. Masquée ici plutôt que de
    // laisser un geste qui ne peut structurellement jamais aboutir dans ce mode.
    if (peerConn instanceof NullPeerConnection) return nameSpan;
    return `${nameSpan}<span class="room-board-wizz-btn" data-ui-click="send-wizz" data-participant-id="${escapeHtml(p.id)}" title="Faire trembler l'écran de ${escapeHtml(p.name)}">🔔</span>`;
}

// Voir échange avec Guillaume : déclenche l'effet wizz directement en local, sans passer
// par le réseau — pour pouvoir tester le rendu (tremblement, son, bandeau) sans avoir
// besoin d'un second appareil ou d'un autre participant connecté. Pas de cooldown ici non
// plus (contrairement à uiSendWizz) : en test, pouvoir redéclencher immédiatement est plus
// utile qu'une protection anti-spam qui n'a pas de sens quand on se cible soi-même.
function uiSelfWizz() {
    triggerWizzEffect();
}

// Vérifie que la connexion réseau nécessaire pour atteindre CE destinataire précis est
// vraiment ouverte — pas seulement que peerConn existe (voir échange avec Guillaume,
// session du 8 août, "le wizz ne marchait plus"). Côté hôte : la connexion spécifique
// vers ce jeton doit être ouverte. Côté invité : sa seule connexion (vers l'hôte) doit
// l'être — peerConn.isConnected() convient déjà pour ce cas (une seule connexion
// possible), inutile de dupliquer sa logique.
function isWizzTargetReachable(targetId) {
    if (!peerConn) return false;
    if (myRole === 'host') {
        const guestIndex = guestIndexByToken[targetId];
        if (guestIndex === undefined) return false;
        const conn = peerConn.conns && peerConn.conns[guestIndex];
        return !!(conn && conn.open);
    }
    return peerConn.isConnected();
}

function uiSendWizz(targetId) {
    // Voir échange avec Guillaume ("le wizz ne marche pas, aucune trace dans le journal
    // même juste après avoir cliqué") : log de départ ajouté ici, avant même le premier
    // retour anticipé — jusqu'ici, seul le cas "connexion pas encore prête" laissait une
    // trace ; tous les autres retours silencieux (peerConn absent, cooldown, envoi
    // "réussi" mais peut-être jamais reçu côté destinataire) ne laissaient absolument
    // rien, rendant impossible de savoir jusqu'où le clic était allé.
    pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… : clic reçu.`);
    if (!peerConn) {
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… abandonné : aucune connexion (peerConn absent).`);
        return;
    }
    if (targetId === myParticipantId) {
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… abandonné : cible = moi-même (ne devrait pas arriver depuis ce bouton).`);
        return;
    }
    const now = Date.now();
    if (wizzCooldownUntil[targetId] && now < wizzCooldownUntil[targetId]) {
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… abandonné : encore en sablier (${Math.ceil((wizzCooldownUntil[targetId] - now) / 1000)}s restantes).`);
        return;
    }

    // Voir échange avec Guillaume (session du 8 août — "le wizz ne marchait plus, je
    // pouvais juste pas le faire") : bug trouvé — le cooldown était posé AVANT même de
    // savoir si l'envoi allait réussir. peerConn.send() abandonne silencieusement un
    // message si la connexion cible n'est pas encore pleinement ouverte (voir conn.open
    // dans peer-connection.js) — un cas plausible juste après une reconnexion, où le
    // statut semble déjà "connecté" mais la DataConnection elle-même termine encore son
    // établissement. Sans ce contrôle, un envoi raté posait quand même le cooldown,
    // empêchant toute nouvelle tentative pendant 4s de plus, alors que rien n'était
    // jamais parti.
    if (!isWizzTargetReachable(targetId)) {
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… abandonné : connexion pas encore prête.`);
        return;
    }
    wizzCooldownUntil[targetId] = now + WIZZ_COOLDOWN_MS;

    const me = participants.find(p => p.id === myParticipantId);
    const senderName = me ? me.name : '?';
    const msg = { type: 'wizz', targetId, senderName };

    if (myRole === 'host') {
        // L'hôte connaît directement la connexion du destinataire : envoi ciblé, pas de
        // relais nécessaire.
        const guestIndex = guestIndexByToken[targetId];
        if (guestIndex === undefined) {
            pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… abandonné : plus dans guestIndexByToken (déconnecté entre-temps ?).`);
            return; // plus connecté entre-temps, tant pis
        }
        peerConn.send(msg, guestIndex);
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… envoyé (ciblé, index ${guestIndex}).`);
    } else {
        // Invité : un seul destinataire réseau possible (l'hôte), qui relaiera si besoin
        // (voir handlePeerData, cas 'wizz' avec targetId !== 'host').
        peerConn.send(msg);
        pushDebugLog(`Wizz vers ${targetId.slice(0, 10)}… envoyé à l'hôte (à charge pour lui de relayer si besoin).`);
    }
}

// Effet visuel + sonore reçu quand on se fait wizzer : tremblement bref de l'écran et un
// petit bip généré à la volée (pas de fichier audio à charger). Respecte
// prefers-reduced-motion : le tremblement est alors sauté, seul le bandeau reste pour
// prévenir sans désagrément visuel.
//
// Web Animations API (element.animate()) plutôt qu'une classe CSS + @keyframes (voir
// échange avec Guillaume) : le bandeau et le son fonctionnaient déjà correctement sur son
// iPhone, mais le tremblement ne s'affichait jamais, quelle que soit la cible CSS essayée
// (body, .app-container) — signe que le souci n'était pas la cible mais le mécanisme
// d'animation CSS lui-même. .animate() ne dépend pas du cycle de vie des animations CSS
// (classes, reflow forcé) et a un historique de compatibilité plus fiable sur Safari.
function triggerWizzEffect() {
    const reducedMotion = prefersReducedMotion();
    if (!reducedMotion && document.body.animate) {
        // Voir échange avec Guillaume : masque temporairement le débordement pendant le
        // tremblement — animer document.body en transform peut faire apparaître des
        // barres de défilement (à droite/en bas) le temps de l'animation, selon le
        // navigateur, puisque body est déplacé au-delà de sa position normale. Restauré
        // dès l'animation terminée (overflow d'origine, pas juste '' — au cas où une autre
        // partie du code l'aurait déjà réglé à quelque chose de spécifique).
        const previousOverflow = document.documentElement.style.overflow;
        document.documentElement.style.overflow = 'hidden';
        const animation = document.body.animate([
            { transform: 'translate(0, 0)' },
            { transform: 'translate(-6px, 2px)' },
            { transform: 'translate(5px, -3px)' },
            { transform: 'translate(-5px, -2px)' },
            { transform: 'translate(6px, 3px)' },
            { transform: 'translate(-4px, 2px)' },
            { transform: 'translate(4px, -2px)' },
            { transform: 'translate(-3px, 1px)' },
            { transform: 'translate(3px, -1px)' },
            { transform: 'translate(-2px, 1px)' },
            { transform: 'translate(0, 0)' }
        ], { duration: 1200, easing: 'ease-in-out' });
        animation.finished.then(() => {
            document.documentElement.style.overflow = previousOverflow;
        }).catch(() => {
            document.documentElement.style.overflow = previousOverflow;
        });
    }
    playWizzSound();
    flashWizzToast();
}

// Bip classique généré via Web Audio (deux notes brèves) plutôt qu'un fichier son à
// héberger — cohérent avec le reste de l'appli (aucun asset audio nulle part ailleurs).
// Échoue silencieusement si l'API n'est pas dispo ou si le navigateur bloque l'audio sans
// interaction préalable (peu grave : l'effet visuel + le bandeau suffisent à prévenir).
function playWizzSound() {
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        [880, 660].forEach((freq, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq;
            gain.gain.value = 0.15;
            osc.connect(gain).connect(ctx.destination);
            const start = ctx.currentTime + i * 0.12;
            osc.start(start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.15);
            osc.stop(start + 0.16);
        });
    } catch (e) { /* tant pis, l'effet visuel suffit */ }
}

// Petit bandeau temporaire en haut de l'écran, plutôt qu'une alert() bloquante — cohérent
// avec le ton léger de la fonctionnalité. Interpelle la personne wizzée par son propre
// pseudo (voir échange avec Guillaume), pas par celui de l'expéditeur.
function flashWizzToast() {
    let toast = document.getElementById('wizzToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'wizzToast';
        toast.className = 'wizz-toast';
        document.body.appendChild(toast);
    }
    const me = participants.find(p => p.id === myParticipantId);
    const myName = me ? me.name : '';
    toast.textContent = `🔔 Réveillez-vous ${myName}, on vous attend !`;
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 4000);
}

// Outil de diagnostic (voir échange avec Guillaume) : affiche pourquoi un robot a fait
// telle annonce (H/HL calculés, branche de décision) — tap sur une case d'enchère jouée
// par un robot dans le relevé (voir formatCallCellHtml, qui pose l'attribut
// data-explanation). Même mécanique de bandeau que le wizz, en plus long (texte
// explicatif, pas juste une alerte) et réutilisable sur desktop comme sur mobile — pas de
// tooltip pur (title) seul, qui ne fonctionne pas au tap sur tactile.
function uiShowCallExplanation(el) {
    const text = el.getAttribute('data-explanation');
    if (!text) return;
    let toast = document.getElementById('callExplanationToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'callExplanationToast';
        toast.className = 'call-explanation-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = `🤖 ${text}`;
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 3500);
}

function renderRoomBoard() {
    const el = document.getElementById('roomBoard');
    if (!el) return;
    // Voir échange avec Guillaume (session du 23 juillet) : même garde que
    // renderParticipantsList — si l'hôte est en train de renommer quelqu'un ici (voir
    // wizzableNameHtml/uiStartRenamingParticipant), on ne reconstruit pas, ça
    // détruirait l'input actif en pleine frappe.
    if (document.activeElement && document.activeElement.classList.contains('participant-rename-input')) {
        return;
    }

    // Seuls les sièges réellement occupés par un participant apparaissent ici : les
    // robots ne sont pas des "personnes dans la salle", ça n'a pas sa place dans ce
    // panneau (contrairement au relevé d'enchères, où "Bot" reste utile pour savoir qui
    // a annoncé quoi — voir ledgerSeatLabel).
    //
    // Regroupement par participant plutôt qu'une ligne par siège : en mode diagonale ou
    // "maître du jeu", une même personne peut occuper 2 sièges — elle ne doit apparaître
    // qu'une fois, avec ses sièges listés ensemble (ex. "Nord + Sud"), pas deux fois.
    //
    // Voir échange avec Guillaume (session du 23 juillet) : ordre d'affichage N, S, E, O
    // (par paires de partenaires — Nord/Sud d'abord, puis Est/Ouest) plutôt que l'ordre de
    // rotation habituel N, E, S, O (voir SEATS) — un ordre propre à ce panneau, sans
    // rapport avec l'ordre de jeu.
    const ROOM_BOARD_SEAT_ORDER = ['N', 'S', 'E', 'W'];
    const seatsByParticipant = new Map(); // id -> [seat, seat, ...], dans l'ordre N/S/E/O
    ROOM_BOARD_SEAT_ORDER.forEach(seat => {
        const pid = seatAssignment[seat];
        if (!pid) return;
        if (!seatsByParticipant.has(pid)) seatsByParticipant.set(pid, []);
        seatsByParticipant.get(pid).push(seat);
    });

    const seatRows = [...seatsByParticipant.keys()].map(pid => {
        const seatsLabel = seatsByParticipant.get(pid).map(seatFullName).join(' + ');
        // Voir échange avec Guillaume (session asynchrone à deux) : un siège 'PENDING'
        // n'a pas de participant réel derrière (personne n'a encore ouvert le lien) — on
        // l'affiche quand même ici, avec un badge dédié, plutôt que de le faire disparaître
        // silencieusement comme un robot (ce n'en est pas un : l'enchère l'attend vraiment).
        if (pid === SEAT_PENDING) {
            return `<div class="room-board-seat"><span class="room-board-seat-label">${seatsLabel}</span><span class="mini-avatar mini-avatar-pending">⏳</span><span class="room-board-pending-label">En attente d'un partenaire</span></div>`;
        }
        const p = participants.find(x => x.id === pid);
        if (!p) return '';
        const disconnectedTag = p.disconnected ? ' <span class="disconnected-tag">🔌</span>' : '';
        const occupant = `${interactiveAvatarHtml(p.id)}${wizzableNameHtml(p)}${disconnectedTag}`;
        return `<div class="room-board-seat"><span class="room-board-seat-label">${seatsLabel}</span>${occupant}</div>`;
    }).filter(Boolean).join('');

    // Quiconque n'occupe aucun siège est kibbitz (voir isKibbitz) : plus de liste à part à
    // maintenir, on liste simplement tous les participants absents de seatAssignment. Mais
    // seulement une fois la partie lancée (voir échange avec Guillaume) : dans le salon,
    // ne pas avoir de siège ne veut encore rien dire — l'hôte est peut-être justement en
    // train de composer la table — donc l'étiquette "Kibbitz" n'y a pas sa place.
    const kibbitzNames = deals ? participants.filter(p => !seatsByParticipant.has(p.id)) : [];
    // Voir échange avec Guillaume (session du 23 juillet) : chaque kibitz dans sa PROPRE
    // ligne (room-board-kibitz-person), comme les sièges ci-dessus — avant, ils étaient
    // tous des enfants directs de .room-board-kibitz (flex-wrap), donc affichés plusieurs
    // par ligne au lieu d'un par ligne.
    //
    // Glissable vers un siège (voir échange avec Guillaume — réassignation de siège en
    // pleine partie) : réutilise exactement le même mécanisme que la zone kibbitz du salon
    // (uiDragStartParticipant, fromSeat=null puisque justement kibitz), déposable sur
    // l'en-tête d'une colonne du relevé d'enchères (voir renderAuctionLedger, uiDropOnSeat
    // rafraîchit maintenant aussi l'écran de jeu). Réservé à l'hôte, seul à pouvoir
    // réorganiser qui joue où — voir la garde dans uiDragStartParticipant lui-même.
    // PORTÉE ACTUELLE : seulement les kibitz (pas encore les joueurs déjà assis, dont le
    // siège d'origine serait ambigu s'ils en occupent 2 à la fois — voir ROOM_BOARD_SEAT_ORDER
    // ci-dessus qui les regroupe) — à étendre plus tard si besoin.
    const isHost = myRole === 'host';
    const kibbitzHtml = kibbitzNames.length > 0
        ? `<div class="room-board-kibbitz">
               <span class="room-board-section-label">👁 Kibbitz :</span>
               ${kibbitzNames.map(p => {
                   const dragAttrs = isHost ? ` draggable="true" data-ui-dragstart="participant" data-participant-id="${escapeHtml(p.id)}"` : '';
                   return `<div class="room-board-kibitz-person"${dragAttrs}>${interactiveAvatarHtml(p.id)}${wizzableNameHtml(p)}</div>`;
               }).join('')}
           </div>`
        : '';

    if (!seatRows && !kibbitzHtml) {
        // Rien à afficher (personne d'autre pour l'instant) : on laisse vide plutôt que
        // d'occuper de la place avec un message (voir échange avec Guillaume — superflu).
        // .room-board:empty se masque déjà tout seul (voir styles.css).
        el.innerHTML = '';
        return;
    }

    el.innerHTML = `<div class="room-board-seats">${seatRows}</div>${kibbitzHtml}`;
}

// Bordure colorée selon la vulnérabilité (voir échange avec Guillaume) : même convention
// que .vuln-bar dans le relevé d'enchères (vert = non vulnérable, rouge = vulnérable),
// appliquée directement sur la carte de main plutôt que sur une simple barre, pour la
// repérer d'un coup d'œil aussi bien sur sa propre main que sur "Voir les 4 mains".
function handCardVulnClass(seat, dealVulnerable) {
    const isVuln = dealVulnerable === 'Both' || dealVulnerable === partnershipOf(seat);
    return isVuln ? 'hand-card-vuln' : 'hand-card-safe';
}

function renderMyHands() {
    const deal = currentDeal();
    const container = document.getElementById('myHandsContainer');

    if (!mySeats || mySeats.length === 0) {
        // Plus de statut "spectateur" séparé : quiconque n'a pas de siège est kibbitz et
        // voit les 4 mains dès le début (voir isKibbitz). Les mains elles-mêmes
        // s'affichent dans #allHandsDiagram (voir checkAuctionEnd/renderAllHandsDiagram) —
        // le même emplacement central, en grille N/E/S/O, que celui utilisé quand l'hôte
        // active "Voir les 4 mains". Les construire ici, dans le panneau latéral étroit
        // des mains, les aurait affichées à l'étroit et mal calibrées plutôt qu'au centre.
        container.classList.remove('my-hands-multi', 'hand-strip-mode');
        container.innerHTML =
            '<div class="info-text kibbitz-note">👁 Vous suivez la partie en kibbitz : vous voyez les 4 mains ci-dessous.</div>';
        return;
    }

    // Voir échange avec Guillaume (session du 23 juillet) : classe posée quand plusieurs
    // sièges sont joués, pour permettre un affichage côte à côte sur mobile plutôt qu'empilé
    // (voir la règle #myHandsContainer.my-hands-multi dans styles.css) — avant, jouer 2
    // mains les empilait verticalement même sur mobile, où l'espace horizontal disponible
    // suffit largement pour les mettre côte à côte.
    container.classList.toggle('my-hands-multi', mySeats.length > 1);
    container.classList.toggle('hand-strip-mode', showHandStrip);

    // Distinction main active / inactive : seulement utile quand on contrôle plusieurs
    // sièges, et seulement pendant l'enchère (une fois terminée, plus de "tour" à signaler).
    const showActiveState = mySeats.length > 1 && !isAuctionOver(auctionHistory);
    const turnSeat = showActiveState ? currentTurnSeat(deal.dealer, auctionHistory) : null;

    container.innerHTML = mySeats.map(seat => {
        const hand = deal.hands[seat];
        const lines = showHandStrip
            ? `<div class="strip-physical-cards">${['S', 'H', 'D', 'C'].map((suit, suitIndex) => {
                const ranks = String(formatRanksForDisplay(hand[suit]) || '');
                return ranks.split('').map((rank, rankIndex) => `
                    <span class="mini-bridge-card mini-bridge-card-${suit}${suitIndex > 0 && rankIndex === 0 ? ' mini-bridge-card-suit-start' : ''}">
                        <span class="mini-bridge-card-rank">${rank}</span>
                        <span class="mini-bridge-card-suit">${suitIconHtml(suit)}</span>
                    </span>
                `).join('');
            }).join('')}</div>`
            : ['S', 'H', 'D', 'C'].map(suit => `
                <div class="card-line">
                    <span class="suit-symbol">${suitIconHtml(suit)}</span>
                    <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
                </div>
            `).join('');

        // Voir échange avec Guillaume : les deux badges sont TOUJOURS générés (visibility
        // plutôt que display/absence), pour que la structure du titre reste rigoureusement
        // identique qu'ils soient affichés ou non — sans ça, la carte changeait très
        // légèrement de hauteur en bascule (alignement "baseline" du titre, voir
        // .hand-card-title), ce qui décalait la main centrée verticalement dans son module.
        const hcpBadge = `<span class="hand-hcp-badge"${showHcp ? '' : ' style="visibility:hidden;"'}>${computeHandHcp(hand)} HCP</span>`;
        const krBadge = `<span class="hand-hcp-badge"${showKr ? '' : ' style="visibility:hidden;"'}>K&R ${computeKaplanRubens(hand).toFixed(2)}</span>`;
        const stateClass = showActiveState ? (seat === turnSeat ? 'hand-card-active' : 'hand-card-inactive') : '';
        const vulnClass = handCardVulnClass(seat, deal.vulnerable);

        return `
            <div class="hand-card ${vulnClass} ${stateClass}">
                <div class="hand-card-title">
                    <span class="hand-card-title-name">${seatFullName(seat)}</span>
                    <span class="hand-card-badges">${hcpBadge}${krBadge}</span>
                </div>
                <div class="hand-cards${showHandStrip ? ' hand-cards-strip hand-cards-physical-strip' : ''}">${lines}</div>
            </div>
        `;
    }).join('');
}

// Rendu coloré d'une annonce en dehors de la boîte d'enchères (relevé, contrat final) :
// même logique de classe de couleur que les boutons (SUIT_CLASSES), avec l'icône de
// couleur à la place du caractère Unicode brut (voir formatStrainLabel/suitIconHtml).
// Accepte soit une chaîne d'annonce brute (Passe/X/1SA...), soit une entrée complète de
// l'historique ({seat, call, explanation?}). L'outil de diagnostic (voir échange avec
// Guillaume) reste en sommeil côté affichage — pas assez abouti pour l'instant — mais le
// CALCUL de l'explication continue de tourner et d'être stocké sur chaque entrée
// (utile ailleurs, ex. export de session), seul le petit point tapable est désactivé ici.
// Pour le réactiver : décommenter le bloc `if (!explanation) return inner;` ci-dessous.
function formatCallCellHtml(entry) {
    const call = (typeof entry === 'string') ? entry : entry.call;

    const b = parseBid(call);
    const inner = !b
        ? escapeHtml(formatCallForDisplay(call)) // Passe / X / XX : pas de couleur de suite
        : `<span class="call-suit ${SUIT_CLASSES[b.strain] || 'notrump'}">${b.level}${formatStrainLabel(b.strain)}</span>`;

    return inner;

    // Outil de diagnostic (désactivé, voir commentaire plus haut) :
    // const explanation = (typeof entry === 'string') ? null : entry.explanation;
    // if (!explanation) return inner;
    // Ancienne variante cliquable retirée : la délégation d’événements vit désormais dans ui-events.js.
}

// Libellé affiché pour un siège donné : soit le nom du joueur qui l'occupe (préférence
// showLedgerNames), soit le nom complet du siège (Nord/Est/Sud/Ouest — voir échange avec
// Guillaume, session du 8 août, "je voudrais que ce soit Nord/Est/Sud/Ouest au lieu de
// N/E/S/O" — plus l'abréviation SEAT_ABBR_FR utilisée avant ici). Un siège robot (non
// assigné) ou sans nom exploitable retombe sur le nom complet du siège.
// Utilisé à la fois dans l'en-tête du tableau d'enchères (renderAuctionLedger) et dans le
// diagramme des 4 mains (buildAllHandsHtml — voir échange avec Guillaume : "je voudrais
// que quand on active l'option noms, on ait également les noms sur l'affichage des 4
// mains plutôt que les noms des positions") — même préférence, même logique de repli,
// partagées entre les deux affichages plutôt que dupliquées.
function ledgerSeatLabel(seat) {
    if (!showLedgerNames) return SEAT_FULL_NAME[seat];
    const pid = typeof seatAssignment !== 'undefined' ? seatAssignment[seat] : null;
    if (!pid) return `${SEAT_FULL_NAME[seat]} 🤖`; // siège non assigné : joué par le robot (voir maybeRobotBid)
    const p = participants.find(x => x.id === pid);
    const name = p && p.name ? p.name.trim() : '';
    return name || SEAT_FULL_NAME[seat]; // quelqu'un est bien assigné ici, pas un bot : jamais "Bot" dans ce cas
}

// Réduit automatiquement la taille des noms longs dans les zones étroites (cartes des
// 4 mains et en-têtes du tableau d'enchères). Les seuils sont volontairement simples et
// locaux à l'affichage : ils n'altèrent jamais le pseudo lui-même.
function playerNameLengthClass(label) {
    const len = String(label || '').trim().length;
    if (len >= 13) return 'name-very-long';
    if (len >= 9) return 'name-long';
    return '';
}

// Voir échange avec Guillaume ("chaque joueur voit son nom en vert, son partenaire en
// bleu, les 2 adversaires en rouge") : relation ENTRE ce siège et le point de vue de la
// personne qui regarde (mySeats), pas une propriété du siège en lui-même — deux personnes
// à la même table voient donc des couleurs différentes sur les mêmes 4 sièges. Un kibitz
// (mySeats vide) n'a pas de camp : jamais de classe, couleur neutre par défaut.
function seatRelationClass(seat) {
    if (!mySeats || mySeats.length === 0) return '';
    if (mySeats.includes(seat)) return 'seat-relation-mine';
    if (mySeats.some(s => partnershipOf(s) === partnershipOf(seat))) return 'seat-relation-partner';
    return 'seat-relation-opponent';
}

// Mobile : lorsqu'une nouvelle rangée apparaît/disparaît dans le relevé, elle ne doit
// pas pousser brutalement la boîte d'enchères dans le viewport. On laisse le tableau
// grandir/rétrécir naturellement (aucune hauteur fixe, aucune limite de longueur), mais
// on mémorise la position des boutons puis on compense exactement le déplacement par le
// scroll. Le desktop reste totalement inchangé.
let pendingMobileLedgerViewportAnchor = null;
let pendingMobileLedgerViewportRaf = 0;

function captureMobileLedgerViewportAnchor() {
    if (window.innerWidth > 760 || !deals || isAuctionOver(auctionHistory)) return null;

    const stack = document.getElementById('auctionViewStack');
    // Si l'utilisateur regarde le PAR pendant l'enchère, ne jamais le déplacer à cause
    // d'une évolution du relevé qui se trouve au-dessus.
    if (stack && stack.classList.contains('show-par')) return null;

    const box = document.getElementById('biddingBox');
    if (!box || !box.querySelector('.two-step-bidding-controls')) return null;
    const style = getComputedStyle(box);
    if (style.display === 'none' || style.visibility === 'hidden') return null;

    const rect = box.getBoundingClientRect();
    const viewportHeight = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    // Correction seulement lorsque les boutons sont réellement dans/près de ce que
    // l'utilisateur regarde. S'il a remonté la page pour consulter autre chose, aucune
    // prise de contrôle automatique du scroll.
    if (rect.bottom <= 0 || rect.top >= viewportHeight) return null;

    return { element: box, top: rect.top };
}

function scheduleMobileLedgerViewportRestore(anchor) {
    if (!anchor) return;

    // Si plusieurs rendus arrivent avant le prochain frame, conserver l'ancre du PREMIER :
    // la compensation couvrira alors le déplacement cumulé sans risque de double scroll.
    if (!pendingMobileLedgerViewportAnchor) pendingMobileLedgerViewportAnchor = anchor;
    if (pendingMobileLedgerViewportRaf) return;

    pendingMobileLedgerViewportRaf = requestAnimationFrame(() => {
        pendingMobileLedgerViewportRaf = 0;
        const saved = pendingMobileLedgerViewportAnchor;
        pendingMobileLedgerViewportAnchor = null;
        if (!saved || !saved.element || !saved.element.isConnected) return;
        if (window.innerWidth > 760 || !deals || isAuctionOver(auctionHistory)) return;

        const stack = document.getElementById('auctionViewStack');
        if (stack && stack.classList.contains('show-par')) return;

        const newTop = saved.element.getBoundingClientRect().top;
        const delta = newTop - saved.top;
        if (Math.abs(delta) > 0.5) {
            window.scrollBy(0, delta);
        }
    });
}

function renderAuctionLedger() {
    const mobileLedgerAnchor = captureMobileLedgerViewportAnchor();
    const body = document.getElementById('auctionLedgerBody');
    const previousRowCount = body ? body.children.length : 0;

    const deal = currentDeal();
    const header = document.getElementById('auctionLedgerHeader');
    const toggleBtn = document.getElementById('ledgerNamesToggleBtn');
    if (toggleBtn) {
        toggleBtn.classList.toggle('is-active', showLedgerNames);
        toggleBtn.setAttribute('aria-pressed', showLedgerNames ? 'true' : 'false');
    }
    const turnSeat = isAuctionOver(auctionHistory) ? null : currentTurnSeat(deal.dealer, auctionHistory);
    // Les effets pulsants servent uniquement à attirer l'attention de la personne qui doit
    // réellement enchérir sur CET appareil. Le repère de tour (fond clair via turn-col) reste
    // visible pour tout le monde, mais le clignotement nom/colonne n'est local qu'au joueur
    // qui contrôle le siège courant.
    const localTurnAttention = !!(turnSeat && mySeats && mySeats.includes(turnSeat));
    // Voir échange avec Guillaume (session du 23 juillet) : cible de dépôt pour
    // réassigner un siège en pleine partie (glisser un kibitz depuis le chat, voir
    // renderRoomBoard) — mêmes gestionnaires que dans le salon (uiAllowDrop,
    // uiDragEnterTarget/uiDragLeaveTarget pour la surbrillance), réservés à l'hôte
    // (chacune de ces fonctions se protège déjà individuellement).
    const isHost = myRole === 'host';
    const dropAttrs = isHost
        ? (s) => ` data-ui-dragover="allow-drop" data-ui-dragenter="drop-target" data-ui-dragleave="drop-target" data-ui-drop="seat" data-seat="${s}"`
        : () => '';
    header.innerHTML = SEATS.map(s => {
        const pair = partnershipOf(s);
        const isVulnerable = deal.vulnerable === 'Both' || deal.vulnerable === pair;
        const vulnClass = isVulnerable ? 'vuln-bar-danger' : 'vuln-bar-safe';
        // Voir échange avec Guillaume ("le nom de celui dont c'est le tour ne devrait pas
        // être en rouge, le fond blanc suffit déjà à l'indiquer") : turn-col garde son
        // inversion de fond (voir styles.css), mais ne colore plus le texte lui-même —
        // remplacé par seat-relation-* ci-dessus, une couleur PERMANENTE (pas liée au tour)
        // reflétant la relation de ce siège avec le point de vue de qui regarde.
        const classes = [
            s === turnSeat ? 'turn-col' : '',
            (s === turnSeat && localTurnAttention) ? 'local-turn-attention' : '',
            seatRelationClass(s)
        ].filter(Boolean).join(' ');
        const seatLabel = ledgerSeatLabel(s);
        const nameSizeClass = playerNameLengthClass(seatLabel);
        return `<th class="${classes}"${dropAttrs(s)}>
            <span class="ledger-seat-label${nameSizeClass ? ' ' + nameSizeClass : ''}">${escapeHtml(seatLabel)}</span>
            <span class="vuln-bar ${vulnClass}"></span>
        </th>`;
    }).join('');

    const dealerIdx = SEATS.indexOf(deal.dealer);
    const slots = new Array(dealerIdx).fill('');
    auctionHistory.forEach(entry => slots.push(formatCallCellHtml(entry)));
    // Index de la toute dernière enchère jouée (pas juste la dernière case du tableau,
    // qui peut être vide en fin de ligne) : sert à lui appliquer un bref flash visuel à
    // chaque NOUVELLE annonce.
    const lastIndex = auctionHistory.length > 0 ? slots.length - 1 : -1;
    const lastEntry = auctionHistory.length > 0 ? auctionHistory[auctionHistory.length - 1] : null;
    // R21 — le droit de flasher est une transaction de rendu, jamais une propriété de
    // l'objet métier. Ainsi un snapshot cloud/P2P identique ne peut plus supprimer un
    // `_flashed` local puis rejouer artificiellement l'animation.
    const shouldFlashLatest = !!(lastEntry && pendingLatestCallFlash);
    pendingLatestCallFlash = false;

    const rows = [];
    for (let i = 0; i < slots.length || rows.length === 0; i += 4) {
        rows.push(slots.slice(i, i + 4));
        if (i + 4 >= slots.length) break;
    }

    let flatIndex = 0;
    body.innerHTML = rows.map(row => {
        const turnSeatIndex = turnSeat ? SEATS.indexOf(turnSeat) : -1;
        const cells = [0, 1, 2, 3].map(i => {
            const isLatest = flatIndex === lastIndex && shouldFlashLatest;
            flatIndex++;
            const cellClasses = [];
            if (isLatest) cellClasses.push('is-latest-call');
            if (localTurnAttention && i === turnSeatIndex) cellClasses.push('turn-column-cell');
            const cls = cellClasses.length ? ` class="${cellClasses.join(' ')}"` : '';
            return `<td${cls}>${row[i] != null ? row[i] : ''}</td>`;
        });
        return `<tr>${cells.join('')}</tr>`;
    }).join('');

    // Une annonce qui reste dans la même rangée ne change pas la géométrie : aucune
    // correction. La compensation n'intervient qu'à la création/suppression réelle d'une
    // rangée (séquence longue, undo, reset...).
    if (body.children.length !== previousRowCount) {
        scheduleMobileLedgerViewportRestore(mobileLedgerAnchor);
    }
}

// Sélection temporaire du palier pour la boîte d'enchères en deux temps.
// Le moteur conserve ses appels canoniques (1C/1D/1H/1S/1NT, etc.) : cette variable
// ne concerne que l'interface. Elle est remise à zéro dès qu'une annonce est jouée,
// lorsque le tour change, ou à la fin de l'enchère.
let selectedBiddingLevel = null;
// R21 — état UI éphémère : renderAfterNormalCall arme UNE seule animation de dernière
// enchère et renderAuctionLedger la consomme immédiatement. Ne jamais stocker ce marqueur
// dans auctionHistory, qui est synchronisé par P2P/cloud.
let pendingLatestCallFlash = false;
// R10 — une action participant envoyée au serveur reste unique jusqu'à confirmation.
// R22 — ce verrou ne doit plus pouvoir condamner l'invité jusqu'au reload si un fetch
// reste suspendu pendant la disparition/recréation du Peer hôte. Chaque tentative reçoit
// un token + watchdog : une réponse tardive d'une ancienne tentative ne peut pas libérer
// (ni écraser) le verrou d'une tentative plus récente.
let participantServerCallInFlight = false;
let participantServerCallToken = 0;
let participantServerCallWatchdogTimer = null;
const PARTICIPANT_SERVER_CALL_WATCHDOG_MS = 12000;

function beginParticipantServerCallGuard() {
    if (participantServerCallInFlight) return null;
    participantServerCallInFlight = true;
    const token = ++participantServerCallToken;
    if (participantServerCallWatchdogTimer) clearTimeout(participantServerCallWatchdogTimer);
    participantServerCallWatchdogTimer = setTimeout(() => {
        if (!participantServerCallInFlight || token !== participantServerCallToken) return;
        participantServerCallInFlight = false;
        participantServerCallWatchdogTimer = null;
        recordSyncTrace('call.cloud-fallback.watchdog-release', { token, roomCode: currentRoomCode || null });
        // Ne jamais fabriquer d'état local au timeout : relire simplement le cloud. Si le
        // PUT ancien a finalement été commité, cette lecture le récupérera ; sinon le garde
        // optimiste expirera normalement et l'état serveur reprendra la main.
        if (deferredRoomMode && myRole === 'guest') {
            startDeferredPolling();
            Promise.resolve(pollCloudForUpdates()).catch(() => {});
        }
        if (deals) renderBiddingBox();
    }, PARTICIPANT_SERVER_CALL_WATCHDOG_MS);
    return token;
}

function endParticipantServerCallGuard(token) {
    if (token == null || token !== participantServerCallToken) return false;
    participantServerCallInFlight = false;
    if (participantServerCallWatchdogTimer) {
        clearTimeout(participantServerCallWatchdogTimer);
        participantServerCallWatchdogTimer = null;
    }
    return true;
}

function resetParticipantServerCallGuard() {
    participantServerCallInFlight = false;
    participantServerCallToken++;
    if (participantServerCallWatchdogTimer) {
        clearTimeout(participantServerCallWatchdogTimer);
        participantServerCallWatchdogTimer = null;
    }
}

// R26 — un Undo participant ne doit jamais relire le cloud pendant que sa propre
// enchère est encore en cours de commit. Sinon le pull peut voir l'état juste AVANT
// cette enchère et conclure à tort « rien à annuler ». On sérialise donc l'Undo derrière
// le PUT d'annonce en cours. Le watchdog R22 borne déjà ce verrou à 12 s ; cette attente
// n'ajoute aucune nouvelle autorité ni aucun nouveau transport.
async function waitForParticipantServerCallBeforeUndo(cloudCtx) {
    if (!participantServerCallInFlight) return true;
    const tokenAtStart = participantServerCallToken;
    const deadline = Date.now() + PARTICIPANT_SERVER_CALL_WATCHDOG_MS + 1000;
    recordSyncTrace('undo.wait-call.begin', { token: tokenAtStart, roomCode: cloudCtx && cloudCtx.roomCode });
    while (participantServerCallInFlight && tokenAtStart === participantServerCallToken && Date.now() < deadline) {
        if (cloudCtx && !isCloudSyncContextActive(cloudCtx)) return false;
        await new Promise(resolve => setTimeout(resolve, 50));
    }
    recordSyncTrace('undo.wait-call.end', {
        token: tokenAtStart,
        stillInFlight: participantServerCallInFlight,
        roomCode: cloudCtx && cloudCtx.roomCode
    });
    return !participantServerCallInFlight;
}

// R16 — stabilité visuelle des annonces fraîches en différé.
//
// R15 protégeait l'annonce optimiste d'un guest pendant sa confirmation serveur. La recette
// réelle a montré le cas symétrique : un guest peut recevoir très vite par P2P l'annonce de
// l'hôte puis la réponse robot, alors qu'un snapshot cloud intermédiaire ne contient encore
// que la première carte. Sans garde, applyCloudUpdate raccourcit alors momentanément la
// séquence (le robot disparaît), puis la rallonge au snapshot suivant.
//
// La même protection monotone couvre donc désormais DEUX origines fraîches :
// - annonce guest locale envoyée en double chemin ;
// - annonce reçue en P2P par un guest différé.
// Une divergence de cartes d'enchère libère immédiatement la garde et le serveur redevient
// autoritaire ; on ne transforme pas ce filet visuel en seconde autorité métier.
const DEFERRED_OPTIMISTIC_AUCTION_GUARD_MAX_AGE_MS = 30000;
const deferredOptimisticAuctionGuards = new Map();

function sameAuctionCallForOptimisticGuard(a, b) {
    return !!a && !!b
        && a.seat === b.seat
        && String(a.call || '').toUpperCase() === String(b.call || '').toUpperCase();
}

function auctionCallPrefixForOptimisticGuard(prefix, full) {
    if (!Array.isArray(prefix) || !Array.isArray(full) || prefix.length > full.length) return false;
    for (let i = 0; i < prefix.length; i++) {
        if (!sameAuctionCallForOptimisticGuard(prefix[i], full[i])) return false;
    }
    return true;
}

function beginDeferredOptimisticAuctionGuard(targetBoardIndex, baseHistory, seat, call) {
    if (!deferredRoomMode || myRole !== 'guest') return;
    const idx = Number(targetBoardIndex);
    if (!Number.isInteger(idx) || idx < 0) return;
    deferredOptimisticAuctionGuards.set(idx, {
        baseHistory: cloneCloudData(Array.isArray(baseHistory) ? baseHistory : []),
        seat,
        call: String(call || '').toUpperCase(),
        startedAt: Date.now()
    });
    recordSyncTrace('call.optimistic-guard.begin', { targetBoardIndex: idx, seat, call });
}

// R18 — `precalc-board` est désormais un véhicule de convergence de premier rang en
// différé (R17). Lorsqu'il apporte un suffixe P2P plus long, ce suffixe est tout aussi
// frais qu'une `call` reçue directement : le prochain snapshot cloud peut encore être en
// retard d'une ou plusieurs cartes. Armer la même garde AVANT de remplacer l'historique
// local empêche ce snapshot retardataire de faire clignoter le suffixe reçu.
function beginDeferredSnapshotAuctionGuard(targetBoardIndex, localHistory, incomingHistory) {
    if (!deferredRoomMode || myRole !== 'guest') return false;
    if (!Array.isArray(localHistory) || !Array.isArray(incomingHistory)) return false;
    if (incomingHistory.length <= localHistory.length) return false;
    if (!auctionCallPrefixForOptimisticGuard(localHistory, incomingHistory)) return false;
    const firstFreshEntry = incomingHistory[localHistory.length];
    if (!firstFreshEntry || !firstFreshEntry.seat || !firstFreshEntry.call) return false;
    beginDeferredOptimisticAuctionGuard(
        targetBoardIndex,
        localHistory,
        firstFreshEntry.seat,
        firstFreshEntry.call
    );
    recordSyncTrace('call.snapshot-guard.begin', {
        targetBoardIndex: Number(targetBoardIndex),
        fromLength: localHistory.length,
        toLength: incomingHistory.length
    });
    return true;
}

function clearDeferredOptimisticAuctionGuard(targetBoardIndex, seat = null, call = null, reason = 'clear') {
    const idx = Number(targetBoardIndex);
    const guard = deferredOptimisticAuctionGuards.get(idx);
    if (!guard) return;
    if (seat != null && guard.seat !== seat) return;
    if (call != null && guard.call !== String(call || '').toUpperCase()) return;
    deferredOptimisticAuctionGuards.delete(idx);
    recordSyncTrace('call.optimistic-guard.end', { targetBoardIndex: idx, reason });
}

function stabilizeDeferredOptimisticAuctionHistories(remoteDeals) {
    if (!deferredRoomMode || myRole !== 'guest' || !Array.isArray(remoteDeals)
        || !Array.isArray(deals) || deferredOptimisticAuctionGuards.size === 0) return remoteDeals;

    const now = Date.now();
    for (const [idx, guard] of Array.from(deferredOptimisticAuctionGuards.entries())) {
        if (!guard || now - Number(guard.startedAt || 0) > DEFERRED_OPTIMISTIC_AUCTION_GUARD_MAX_AGE_MS) {
            clearDeferredOptimisticAuctionGuard(idx, null, null, 'expired');
            continue;
        }
        const localDeal = deals[idx];
        const remoteDeal = remoteDeals[idx];
        if (!localDeal || !remoteDeal) {
            clearDeferredOptimisticAuctionGuard(idx, null, null, 'board-missing');
            continue;
        }
        const localHistory = Array.isArray(localDeal.auctionHistory) ? localDeal.auctionHistory : [];
        const remoteHistory = Array.isArray(remoteDeal.auctionHistory) ? remoteDeal.auctionHistory : [];
        const baseHistory = Array.isArray(guard.baseHistory) ? guard.baseHistory : [];

        // La branche locale doit toujours contenir exactement l'annonce optimiste qui a
        // créé la garde, à la position suivant le préfixe de départ. Sinon elle a déjà été
        // annulée/remplacée localement : ne rien protéger.
        const guardedEntry = localHistory[baseHistory.length];
        const branchStillOurs = auctionCallPrefixForOptimisticGuard(baseHistory, localHistory)
            && guardedEntry
            && guardedEntry.seat === guard.seat
            && String(guardedEntry.call || '').toUpperCase() === guard.call;
        if (!branchStillOurs) {
            clearDeferredOptimisticAuctionGuard(idx, null, null, 'local-branch-changed');
            continue;
        }

        // Snapshot cloud en retard mais compatible : garder l'histoire locale visible.
        // Cela couvre aussi une réponse robot P2P déjà reçue alors que le cloud ne contient
        // encore que l'annonce humaine. Les explications peuvent différer : l'identité
        // métier d'une carte est siège + call, pas le texte d'explication.
        if (auctionCallPrefixForOptimisticGuard(remoteHistory, localHistory)) {
            if (remoteHistory.length < localHistory.length) {
                remoteDeal.auctionHistory = cloneCloudData(localHistory);
                recordSyncTrace('call.optimistic-guard.preserve', {
                    targetBoardIndex: idx,
                    remoteLength: remoteHistory.length,
                    localLength: localHistory.length
                });
            } else {
                clearDeferredOptimisticAuctionGuard(idx, null, null, 'cloud-caught-up');
            }
            continue;
        }

        // Le cloud a rattrapé puis prolongé notre branche : il est désormais pleinement
        // autoritaire. Toute autre divergence est également acceptée immédiatement ; elle
        // représente un vrai conflit de même donne, pas un simple snapshot en retard.
        if (auctionCallPrefixForOptimisticGuard(localHistory, remoteHistory)) {
            clearDeferredOptimisticAuctionGuard(idx, null, null, 'cloud-extended');
        } else {
            clearDeferredOptimisticAuctionGuard(idx, null, null, 'cloud-diverged');
        }
    }
    return remoteDeals;
}

// R31 — stabilité visuelle du chat guest pendant le fallback cloud avec hôte fermé.
//
// Le message est affiché optimistiquement avant son PUT participant. Un poll qui a démarré
// juste avant ce PUT peut revenir entre-temps avec l'ancien historique et ne doit pas
// effacer visuellement le message pour le faire réapparaître au poll suivant. Contrairement
// à une autorité métier, cette garde est strictement temporaire : elle ne protège que le
// suffixe local issu du préfixe capturé au moment de l'envoi, accepte les messages
// concurrents du serveur, puis disparaît dès que le cloud contient notre message.
const DEFERRED_OPTIMISTIC_CHAT_GUARD_MAX_AGE_MS = 30000;
const deferredOptimisticChatGuards = [];

function beginDeferredOptimisticChatGuard(baseChat, msg) {
    if (!deferredRoomMode || myRole !== 'guest' || !msg) return;
    deferredOptimisticChatGuards.push({
        baseChat: cloneCloudData(Array.isArray(baseChat) ? baseChat : []),
        msg: cloneCloudData(msg),
        startedAt: Date.now()
    });
    recordSyncTrace('chat.optimistic-guard.begin', {
        baseLength: Array.isArray(baseChat) ? baseChat.length : 0,
        senderId: msg.senderId || null
    });
}

function clearDeferredOptimisticChatGuard(guard, reason = 'clear') {
    const idx = deferredOptimisticChatGuards.indexOf(guard);
    if (idx >= 0) deferredOptimisticChatGuards.splice(idx, 1);
    recordSyncTrace('chat.optimistic-guard.end', { reason });
}

function resetDeferredOptimisticChatGuards() {
    deferredOptimisticChatGuards.length = 0;
}

function stabilizeDeferredOptimisticChatMessages(remoteChat) {
    if (!deferredRoomMode || myRole !== 'guest' || deferredOptimisticChatGuards.length === 0) return remoteChat;
    let stabilized = cloneCloudData(Array.isArray(remoteChat) ? remoteChat : []);
    const localNow = cloneCloudData(Array.isArray(chatMessages) ? chatMessages : []);
    const now = Date.now();

    for (const guard of Array.from(deferredOptimisticChatGuards)) {
        if (!guard || now - Number(guard.startedAt || 0) > DEFERRED_OPTIMISTIC_CHAT_GUARD_MAX_AGE_MS) {
            clearDeferredOptimisticChatGuard(guard, 'expired');
            continue;
        }
        const base = Array.isArray(guard.baseChat) ? guard.baseChat : [];
        const msg = guard.msg;
        const localHasBase = arrayIsPrefix(base, localNow);
        const localSuffix = localHasBase ? localNow.slice(base.length) : [];
        const localStillHasMessage = localSuffix.some(entry => sameCloudData(entry, msg));
        if (!localStillHasMessage) {
            clearDeferredOptimisticChatGuard(guard, 'local-branch-changed');
            continue;
        }

        // Si le cloud contient déjà ce message dans le suffixe postérieur au préfixe de
        // départ, la confirmation est arrivée : ne plus protéger.
        if (arrayIsPrefix(base, stabilized)
            && stabilized.slice(base.length).some(entry => sameCloudData(entry, msg))) {
            clearDeferredOptimisticChatGuard(guard, 'cloud-caught-up');
            continue;
        }

        // Tant que le préfixe de départ est intact, fusionner le suffixe local optimiste
        // au snapshot reçu. mergeChatThreeWay conserve aussi tout message concurrent déjà
        // commité côté serveur, sans dupliquer une occurrence identique.
        if (arrayIsPrefix(base, stabilized)) {
            const merged = mergeChatThreeWay(base, localNow, stabilized);
            if (!sameCloudData(merged, stabilized)) {
                stabilized = merged;
                recordSyncTrace('chat.optimistic-guard.preserve', {
                    baseLength: base.length,
                    remoteLength: Array.isArray(remoteChat) ? remoteChat.length : 0,
                    stabilizedLength: stabilized.length
                });
            }
            continue;
        }

        // Une réécriture réelle de l'historique chat ne doit jamais être masquée.
        clearDeferredOptimisticChatGuard(guard, 'cloud-diverged');
    }
    return stabilized;
}

// Si le même navigateur contrôle plusieurs sièges, `myTurn` peut rester vrai après une
// annonce alors que le joueur à la table a changé. On mémorise donc explicitement le siège
// dont la boîte est affichée, afin de repartir du palier minimal légal à CHAQUE nouveau tour.
let selectedBiddingTurnSeat = null;

// Ordre d'affichage demandé : Trèfle, Carreau, Cœur, Pique, SA.
// Convention mnémotechnique française : T, K, C, P, SA.
// Les codes internes restent ceux de bidding-rules.js.
const TWO_STEP_BID_STRAINS = ['C', 'D', 'H', 'S', 'NT'];

function uiSelectBidLevel(level) {
    const numericLevel = Number(level);
    if (!Number.isInteger(numericLevel) || numericLevel < 1 || numericLevel > 7) return;

    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    const myTurn = mySeats && mySeats.includes(turnSeat);
    if (!myTurn) return;

    // Un palier n'est sélectionnable que s'il reste au moins une souche légale à ce palier.
    const hasLegalStrain = TWO_STEP_BID_STRAINS.some(strain =>
        isCallLegal(auctionHistory, `${numericLevel}${strain}`, turnSeat)
    );
    if (!hasLegalStrain) return;

    selectedBiddingLevel = numericLevel;
    renderBiddingBox();
}

function uiSelectBidStrain(strain) {
    if (selectedBiddingLevel == null || !TWO_STEP_BID_STRAINS.includes(strain)) return;

    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    if (!mySeats || !mySeats.includes(turnSeat)) return;

    const call = `${selectedBiddingLevel}${strain}`;
    if (!isCallLegal(auctionHistory, call, turnSeat)) return;

    // Réinitialisé avant uiMakeCall : applyCall() rerend immédiatement la boîte.
    selectedBiddingLevel = null;
    uiMakeCall(call);
}

function renderBiddingBox() {
    const box = document.getElementById('biddingBox');
    const turnPanel = document.getElementById('turnIndicator');
    const deal = currentDeal();

    if (isAuctionOver(auctionHistory)) {
        selectedBiddingLevel = null;
        selectedBiddingTurnSeat = null;
        box.innerHTML = '';
        box.classList.remove('my-turn');
        // Voir échange avec Guillaume (session du 8 août — "il y a parfois une
        // persistence de la barre... il n'y a plus les lettres mais on voit l'effet
        // visuel mouvant") : le texte était bien vidé, mais la CLASSE (turn-indicator
        // my-turn/their-turn/disconnected-turn) restait — le halo pulsant continuait de
        // tourner sur un élément désormais vide.
        turnPanel.className = 'turn-indicator';
        turnPanel.textContent = '';
        return;
    }

    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : ne gèle plus la boîte d'enchères
    // pour un invité déconnecté de l'hôte — uiMakeCall peut utiliser le relais serveur.
    const myTurn = mySeats && mySeats.includes(turnSeat) && !participantServerCallInFlight;

    // Nouveau joueur à l'enchère = nouvelle sélection. C'est important même si le même
    // utilisateur contrôle deux sièges consécutifs : `myTurn` resterait vrai, mais le palier
    // choisi au tour précédent ne doit jamais être conservé pour le siège suivant.
    if (selectedBiddingTurnSeat !== turnSeat) {
        selectedBiddingLevel = null;
        selectedBiddingTurnSeat = turnSeat;
    }

    const turnOwnerId = seatAssignment[turnSeat];
    const turnOwner = turnOwnerId ? participants.find(p => p.id === turnOwnerId) : null;
    const ownerDisconnected = !!(turnOwner && turnOwner.disconnected);

    const showBlockingDisconnectedTurn = ownerDisconnected && !deferredRoomMode;
    if (myTurn) {
        turnPanel.textContent = `À vous d'enchérir (${seatFullName(turnSeat)})`;
    } else if (showBlockingDisconnectedTurn) {
        turnPanel.textContent = `🔌 En attente que ${turnOwner.name} se reconnecte (${seatFullName(turnSeat)})...`;
    } else {
        // R23 — en différé la présence P2P n'est pas une condition de fonctionnement :
        // chacun peut continuer via le cloud. La déconnexion est signalée ponctuellement
        // par le toast de présence, pas transformée en message d'erreur persistant ici.
        turnPanel.textContent = `En attente de ${seatFullName(turnSeat)}...`;
    }
    turnPanel.className = 'turn-indicator ' + (showBlockingDisconnectedTurn ? 'disconnected-turn' : (myTurn ? 'my-turn' : 'their-turn'));
    box.classList.toggle('my-turn', myTurn);

    // Une sélection de palier ne doit jamais survivre au passage du tour à un autre joueur.
    if (!myTurn) selectedBiddingLevel = null;

    // Liste des paliers encore jouables. Si le palier sélectionné est devenu illégal
    // (par exemple après un rerendu synchronisé), on repart proprement sans sélection.
    const legalLevels = new Set();
    if (myTurn) {
        for (let level = 1; level <= 7; level++) {
            if (TWO_STEP_BID_STRAINS.some(strain =>
                isCallLegal(auctionHistory, `${level}${strain}`, turnSeat)
            )) {
                legalLevels.add(level);
            }
        }
    }
    if (selectedBiddingLevel != null && !legalLevels.has(selectedBiddingLevel)) {
        selectedBiddingLevel = null;
    }

    // Pré-sélection automatique du PALIER MINIMAL encore légal au début du tour.
    // Exemple : après 1SA, aucune enchère au palier de 1 n'est encore possible ; 2♣ est la
    // première enchère contractuelle légale, donc le bouton « 2 » est sélectionné d'office.
    // La souche n'est PAS choisie automatiquement : le joueur clique ensuite T/K/C/P/SA.
    if (myTurn && selectedBiddingLevel == null && legalLevels.size > 0) {
        selectedBiddingLevel = Math.min(...legalLevels);
    }

    const levelRow = Array.from({ length: 7 }, (_, i) => i + 1).map(level => {
        const legal = legalLevels.has(level);
        const selected = selectedBiddingLevel === level;
        return `<button type="button" class="call-btn bid-level-btn${selected ? ' selected' : ''}" ${legal ? '' : 'disabled'} aria-pressed="${selected ? 'true' : 'false'}" data-ui-click="select-bid-level" data-level="${level}">${level}</button>`;
    }).join('');

    const strainRow = TWO_STEP_BID_STRAINS.map(strain => {
        const call = selectedBiddingLevel == null ? null : `${selectedBiddingLevel}${strain}`;
        const legal = !!(myTurn && call && isCallLegal(auctionHistory, call, turnSeat));
        const label = formatStrainLabel(strain);
        const suitClass = SUIT_CLASSES[strain] || 'notrump';
        const title = selectedBiddingLevel == null
            ? 'Choisissez d’abord un palier'
            : `${selectedBiddingLevel}${strain === 'NT' ? 'SA' : SUIT_SYMBOLS[strain]}`;
        const accessibleStrain = {
            C: 'Trèfle',
            D: 'Carreau',
            H: 'Cœur',
            S: 'Pique',
            NT: 'Sans-atout'
        }[strain] || strain;
        return `<button type="button" class="call-btn bid-strain-btn ${suitClass}" ${legal ? '' : 'disabled'} title="${title}" aria-label="${accessibleStrain}" data-ui-click="select-bid-strain" data-strain="${strain}">${label}</button>`;
    }).join('');

    const specialLabels = { PASS: 'Passe', X: 'X', XX: 'XX' };
    const specialAriaLabels = { PASS: 'Passe', X: 'Contre', XX: 'Surcontre' };
    const specialClasses = {
        PASS: 'call-btn-pass',
        X: 'call-btn-double',
        XX: 'call-btn-redouble'
    };
    const specialRow = ['PASS', 'X', 'XX'].map(call => {
        const legal = myTurn && isCallLegal(auctionHistory, call, turnSeat);
        return `<button type="button" class="call-btn call-btn-special ${specialClasses[call]}" ${legal ? '' : 'disabled'} aria-label="${specialAriaLabels[call]}" data-ui-click="make-call" data-call="${call}">${specialLabels[call]}</button>`;
    }).join('');

    box.innerHTML = `
        <div class="two-step-bidding-controls">
            <div class="bid-level-row" role="group" aria-label="Choisir le palier">${levelRow}</div>
            <div class="bid-strain-row" role="group" aria-label="Choisir la couleur">${strainRow}</div>
            <div class="two-step-special-row" role="group" aria-label="Actions d'enchère">${specialRow}</div>
        </div>
    `;
}

function uiMakeCall(call) {
    const deal = currentDeal();
    const turnSeat = currentTurnSeat(deal.dealer, auctionHistory);
    if (!mySeats || !mySeats.includes(turnSeat)) return;
    if (!isCallLegal(auctionHistory, call, turnSeat)) return;

    const p2pConnected = !!(peerConn && peerConn.isConnected());
    const usesServerAuthority = myRole === 'guest' && (deferredRoomMode || !p2pConnected);
    selectedBiddingLevel = null;

    if (usesServerAuthority) {
        const participantCallToken = beginParticipantServerCallGuard();
        if (participantCallToken == null) return;

        // R11 — en différé, le serveur reste l'autorité de convergence/PONS, MAIS une
        // DataConnection P2P déjà ouverte n'est plus jetée à la poubelle. C'était le trou
        // de R9/R10 : le premier clic de B dépendait à 100 % d'un PUT participant et d'un
        // retour cloud, alors qu'A était souvent joignable directement au même instant.
        //
        // On utilise donc DEUX chemins complémentaires quand ils existent :
        //   1. chemin P2P immédiat : affichage local + message à l'hôte ; l'hôte valide et
        //      persiste avec son autorité host ;
        //   2. chemin serveur participant : conserve l'autorité différée, les conflits CAS
        //      et surtout l'avancement PONS de la bonne donne si chacun navigue séparément.
        //
        // Le serveur et le handler P2P sont idempotents vis-à-vis du même préfixe : si l'un
        // a déjà commité l'annonce, l'autre absorbe simplement l'état plus récent sans la
        // dupliquer. Ainsi une panne d'un seul transport ne fait plus disparaître l'annonce.
        if (deferredRoomMode) {
            // R22 — le mode différé doit conserver exactement la même UX lorsque l'hôte
            // vient de fermer : l'annonce est appliquée localement tout de suite, puis le
            // serveur la confirme. Auparavant cette branche optimiste était réservée au cas
            // P2P encore connecté ; dès la coupure, un clic ne modifiait plus l'écran avant
            // le retour HTTP et paraissait donc "ne pas rester".
            ensureDeferredGuestCloudWriteCredential();
            beginDeferredOptimisticAuctionGuard(boardIndex, auctionHistory, turnSeat, call);
            applyCall(turnSeat, call);
            if (p2pConnected) peerConn.send({ type: 'call', boardIndex, seat: turnSeat, call });
        } else {
            // Live sans P2P : pas d'affichage optimiste, le relais serveur est le seul
            // chemin disponible et doit confirmer avant de modifier l'écran.
            renderBiddingBox();
        }

        Promise.resolve(pushCallViaServerFallback(boardIndex, turnSeat, call)).finally(() => {
            if (endParticipantServerCallGuard(participantCallToken) && deals) renderBoard();
        });
        return;
    }

    applyCall(turnSeat, call);
    peerConn.send({ type: 'call', boardIndex, seat: turnSeat, call });
}

// Transaction de rendu ciblée pour UNE annonce normale.
//
// Audit point 8 : ces rendus étaient déjà appelés successivement dans le même task JS,
// donc les décaler globalement dans requestAnimationFrame n'aurait pas garanti moins de
// paints et aurait introduit une fenêtre de 1 frame où les anciens boutons restent
// cliquables. On garde donc un rendu SYNCHRONE et le même ordre, mais on retire deux
// travaux réellement redondants.
//
// - 0/1 siège contrôlé : renderMyHands() ne change rien après une annonce (le halo actif/
//   inactif n'existe que si plusieurs mains sont jouées sur cet appareil).
// - diagramme 4 mains masqué : une annonce ne change ni les cartes ni sa géométrie.
//   checkAuctionEnd peut donc éviter de le reconstruire/mesurer tant qu'il reste caché.
//   S'il doit devenir visible (hôte/kibbitz/fin d'enchère), il est toujours rerendu.
//
// Si l'annonce TERMINE l'enchère sur mobile, l'ancre de fin est capturée ici, APRÈS la
// mise à jour de l'état mais AVANT toute écriture DOM. Cela évite de forcer une mesure de
// layout après renderAuctionLedger/renderBiddingBox.
function renderAfterNormalCall() {
    // Une vraie extension visible mérite exactement UN flash. Tout rerendu structurel ou
    // toute confirmation réseau ultérieure doit rester neutre.
    pendingLatestCallFlash = true;
    const auctionEndsNow = isAuctionOver(auctionHistory);
    const endDiagram = auctionEndsNow ? document.getElementById('allHandsDiagram') : null;
    const preCapturedMobileAuctionEndAnchor = auctionEndsNow
        ? captureMobileAuctionEndViewportAnchor(true, endDiagram)
        : undefined;

    renderAuctionLedger();
    renderBiddingBox();

    // Une seule main n'a aucun état visuel de tour à mettre à jour. Avec plusieurs mains,
    // renderMyHands reste obligatoire pour déplacer l'état actif/inactif.
    if (mySeats && mySeats.length > 1) {
        renderMyHands();
    }

    const endOptions = {
        skipHiddenAllHandsRefresh: true
    };
    if (auctionEndsNow) {
        endOptions.preCapturedMobileAuctionEndAnchor = preCapturedMobileAuctionEndAnchor;
    }
    checkAuctionEnd(endOptions);
    renderUndoControls();
}

function applyCall(seat, call, explanation) {
    auctionHistory.push(explanation ? { seat, call, explanation } : { seat, call });
    renderAfterNormalCall();
    maybeRobotBid();
    // Voir échange avec Guillaume (session du 23 juillet — reprise via localStorage) :
    // sans effet si on n'est pas hôte ou si la partie n'est pas lancée (voir la garde à
    // l'intérieur de la fonction elle-même).
    saveHostGameStateToStorage();
    // R17 — redondance volontaire en différé : après CHAQUE annonce appliquée par l'hôte
    // (humaine ou robot), pousser aussi l'historique complet de cette donne. Le message
    // `call` reste le chemin ultra-court ; `precalc-board` garantit qu'un guest ne dépend
    // jamais du prochain geste humain pour voir un robot déjà calculé.
    if (myRole === 'host' && deferredRoomMode) broadcastPrecalculatedBoard(boardIndex);
}

// Construit le HTML des 4 mains, affiché dans #allHandsDiagram (voir
// renderAllHandsDiagram) — révélé à tout le monde une fois l'enchère terminée, à l'hôte
// seul s'il active "Voir les 4 mains" en cours d'enchère, et en continu à un kibbitz
// (voir checkAuctionEnd).
function buildAllHandsHtml(deal) {
    // Même halo doré que renderMyHands pour repérer le tour en cours (voir échange avec
    // Guillaume : absent jusqu'ici de cette vue-là) — plus de "seulement si on contrôle
    // plusieurs sièges" ici, puisque les 4 mains sont de toute façon toujours affichées
    // ensemble dans cette vue. Rien à distinguer une fois l'enchère terminée (plus de
    // "tour" à signaler).
    const showActiveState = !isAuctionOver(auctionHistory);
    const turnSeat = showActiveState ? currentTurnSeat(deal.dealer, auctionHistory) : null;

    return SEATS.map(seat => {
        const hand = deal.hands[seat];
        const lines = ['S', 'H', 'D', 'C'].map(suit => `
            <div class="card-line">
                <span class="suit-symbol">${suitIconHtml(suit)}</span>
                <span class="cards">${formatRanksForDisplay(hand[suit]) || '—'}</span>
            </div>
        `).join('');

        const hcpBadge = `<span class="hand-hcp-badge"${showHcp ? '' : ' style="visibility:hidden;"'}>${computeHandHcp(hand)} HCP</span>`;
        const krBadge = `<span class="hand-hcp-badge"${showKr ? '' : ' style="visibility:hidden;"'}>K&R ${computeKaplanRubens(hand).toFixed(2)}</span>`;
        const vulnClass = handCardVulnClass(seat, deal.vulnerable);
        const stateClass = showActiveState ? (seat === turnSeat ? 'hand-card-active' : 'hand-card-inactive') : '';
        const seatLabel = ledgerSeatLabel(seat);
        const nameSizeClass = playerNameLengthClass(seatLabel);

        return `
            <div class="hand-card hand-${seat} ${vulnClass} ${stateClass}">
                <div class="hand-card-title">
                    <span class="hand-card-title-name${nameSizeClass ? ' ' + nameSizeClass : ''}">${seatLabel}</span>
                    <span class="hand-card-badges">${hcpBadge}${krBadge}</span>
                </div>
                <div class="hand-cards">${lines}</div>
            </div>
        `;
    }).join('');
}

function renderAllHandsDiagram() {
    const container = document.getElementById('allHandsDiagram');
    container.innerHTML = buildAllHandsHtml(currentDeal());
    syncHandsPanelMinHeight();
}

// Voir échange avec Guillaume : mesure dynamiquement la hauteur réellement nécessaire au
// mode "4 mains" (qui varie selon les options actives — HCP et K&R affichés ensemble
// rendent chaque carte plus haute que dans un cas plus simple — et selon le contenu des
// mains) et la réserve en permanence sur .hands-panel, plutôt qu'une valeur fixe en dur
// qui ne correspondait qu'à un cas de test précis et pouvait être dépassée en vrai jeu.
// Fonctionne même quand le diagramme n'est pas actuellement affiché : le rend
// temporairement mesurable (hors flux, invisible) le temps de la mesure, sans jamais
// l'exposer visuellement ni perturber la mise en page pendant ce court instant.
function syncHandsPanelMinHeight() {
    const panel = document.querySelector('.hands-panel');
    const diagram = document.getElementById('allHandsDiagram');
    if (!panel || !diagram) return;

    // Voir échange avec Guillaume (session du 23 juillet) : cette réservation de hauteur
    // n'a de sens qu'en desktop, où .game-body affiche les mains et le panneau d'enchères
    // côte à côte (voir .game-body, breakpoint 1024px) — aligner leurs hauteurs évite un
    // décalage visuel entre les deux colonnes. Sur mobile, game-body passe en une seule
    // colonne empilée : il n'y a plus rien à aligner, et cette hauteur réservée pour le
    // mode "4 mains" ne faisait que pousser la boîte d'enchères hors écran avec un grand
    // vide en dessous de la main affichée (constaté en test réel — avant, mains et
    // enchères tenaient sur le même écran).
    if (window.innerWidth <= 760) {
        panel.style.minHeight = '';
        return;
    }

    const panelStyles = getComputedStyle(panel);
    const paddingTop = parseFloat(panelStyles.paddingTop) || 0;
    const paddingBottom = parseFloat(panelStyles.paddingBottom) || 0;
    const paddingLeft = parseFloat(panelStyles.paddingLeft) || 0;
    const paddingRight = parseFloat(panelStyles.paddingRight) || 0;

    const wasHidden = getComputedStyle(diagram).display === 'none';
    let previousPosition, previousVisibility, previousDisplay, previousWidth;
    if (wasHidden) {
        previousPosition = diagram.style.position;
        previousVisibility = diagram.style.visibility;
        previousDisplay = diagram.style.display;
        previousWidth = diagram.style.width;
        diagram.style.position = 'absolute';
        diagram.style.visibility = 'hidden';
        diagram.style.display = 'grid';
        // Voir échange avec Guillaume : largeur explicitement contrainte à celle du
        // panneau (moins son padding) — position:absolute seul ne préserve pas la largeur
        // du flux normal (il se réduit à son contenu par défaut), ce qui pouvait changer
        // légèrement le retour à la ligne du texte, donc la hauteur mesurée, par rapport
        // à l'affichage réel en flux normal (petit résidu de 1-2px observé sans ça).
        diagram.style.width = (panel.getBoundingClientRect().width - paddingLeft - paddingRight) + 'px';
    }

    const diagramHeight = diagram.getBoundingClientRect().height;
    // Voir échange avec Guillaume : +4px de marge de sécurité — un écart résiduel de
    // 1-2px subsiste entre cette mesure (temporairement hors flux) et le rendu réel une
    // fois véritablement affiché et étiré par .game-content-row (arrondi sous-pixel),
    // mieux vaut réserver très légèrement plus que pas assez.
    panel.style.minHeight = Math.ceil(diagramHeight + paddingTop + paddingBottom + 4) + 'px';

    if (wasHidden) {
        diagram.style.position = previousPosition;
        diagram.style.visibility = previousVisibility;
        diagram.style.display = previousDisplay;
        diagram.style.width = previousWidth;
    }
}

const STRAIN_ORDER = ['N', 'S', 'H', 'D', 'C']; // N = sans-atout (SA), pas Nord
// Classe de couleur CSS par couleur d'enchère, pour la table du double mort — mêmes
// classes que SUIT_CLASSES, complétées de 'notrump' pour la ligne SA.
const STRAIN_CLASS = { N: 'notrump', S: 'spades', H: 'hearts', D: 'diamonds', C: 'clubs' };

// Convertit un nombre de levées (sur 13) en palier de contrat réalisable : il faut
// 6 levées de base + le palier, donc palier = levées - 6. En dessous de 7 levées, aucun
// contrat n'est réalisable (le palier serait nul ou négatif) : on affiche "―".
function tricksToContractLevel(tricks) {
    if (tricks == null) return '—';
    const level = tricks - 6;
    return level >= 1 ? String(level) : '―';
}

// ===== Mise en évidence du meilleur contrat (table du double mort) =====
//
// Portée depuis le générateur de donnes (dds-controller.js) — même algorithme exact, pour
// que les deux applis restent cohérentes visuellement. Principe : pour chaque case
// (couleur x déclarant), on suppose que le camp du déclarant enchérit tout juste au
// palier permis par le double mort (ni plus, ni moins), et on calcule le score de
// duplicate correspondant (barème SEF/FFB standard, non contré, selon la vulnérabilité
// réelle de la donne). Calcul INDÉPENDANT par camp (NS et EW n'enchérissent pas le même
// contrat) : chelem prime sur manche, qui prime sur partielle ; seules les cases du
// palier le plus haut atteint par ce camp sont mises en évidence — la ou les meilleures
// en vert vif, les autres du même palier en vert plus doux (sauf en partielle, qui n'a
// pas de prime notable : seule la meilleure y est marquée, pas de dégradé secondaire).

function trickPoints(strain, level) {
    if (strain === 'N') return 40 + (level - 1) * 30;
    if (strain === 'H' || strain === 'S') return level * 30;
    return level * 20; // C ou D
}

function contractScoreFromTrickPoints(trickPts, level, vulnerable) {
    let total = trickPts;
    total += trickPts >= 100 ? (vulnerable ? 500 : 300) : 50; // prime de manche ou de partielle
    if (level === 6) total += vulnerable ? 750 : 500;         // petit chelem
    else if (level === 7) total += vulnerable ? 1500 : 1000;  // grand chelem
    return total;
}

// Voir échange avec Guillaume (session du 8 août — "si un camp a une manche, ne pas
// afficher en vert le meilleur contrat de l'autre camp, sauf si ils ont sacrifice") :
// score d'une chute CONTRÉE (barème standard SEF/FFB), nécessaire pour évaluer si
// sacrifier au-dessus de la manche/chelem adverse est rentable. Non-vulnérable :
// -100/-200/-200/-300/-300... ; vulnérable : -200/-300/-300... (chaque levée
// supplémentaire au-delà de la 1ère coûte 300, sauf les 2ème et 3ème non-vulnérables
// à 200 chacune).
function doubledUndertrickScore(undertricks, vulnerable) {
    if (undertricks <= 0) return 0;
    if (vulnerable) return -(200 + (undertricks - 1) * 300);
    if (undertricks <= 3) return -(100 + (undertricks - 1) * 200);
    return -(100 + 2 * 200 + (undertricks - 3) * 300);
}

// `dealVulnerable` : la valeur normalisée habituelle ('None'/'NS'/'EW'/'Both', voir
// deal-parser.js) — contrairement au générateur, pas besoin de la recalculer depuis le
// numéro de donne, currentDeal().vulnerable la donne déjà directement.
function computeDDScores(ddTable, dealVulnerable) {
    const nsVuln = (dealVulnerable === 'NS' || dealVulnerable === 'Both');
    const ewVuln = (dealVulnerable === 'EW' || dealVulnerable === 'Both');

    const info = {};
    const bySide = { NS: [], EW: [] };

    for (const strain of STRAIN_ORDER) {
        info[strain] = {};
        for (const pos of DD_TABLE_SEAT_ORDER) {
            const side = (pos === 'N' || pos === 'S') ? 'NS' : 'EW';
            const tricks = ddTable[strain][pos];
            const level = tricks - 6;

            let score = null;
            let tier = null;
            if (level >= 1) {
                const trickPts = trickPoints(strain, level);
                score = contractScoreFromTrickPoints(trickPts, level, side === 'NS' ? nsVuln : ewVuln);
                tier = level >= 6 ? 'slam' : (trickPts >= 100 ? 'game' : 'partial');
            }

            info[strain][pos] = { score, tier, side };
            if (tier) bySide[side].push({ score, tier });
        }
    }

    const sideSummary = {};
    for (const side of ['NS', 'EW']) {
        const cells = bySide[side];
        let activeTier = null;
        if (cells.some(c => c.tier === 'slam')) activeTier = 'slam';
        else if (cells.some(c => c.tier === 'game')) activeTier = 'game';
        else if (cells.some(c => c.tier === 'partial')) activeTier = 'partial';

        let bestScore = null;
        if (activeTier) {
            bestScore = Math.max(...cells.filter(c => c.tier === activeTier).map(c => c.score));
        }

        sideSummary[side] = { activeTier, bestScore };
    }

    return { info, sideSummary };
}

// Ordre d'affichage des colonnes de la table du double mort : N S E O (les deux camps
// groupés côte à côte), plus pratique à lire que l'ordre de rotation des enchères N E S O
// utilisé partout ailleurs (SEATS, dans bidding-rules.js) — surtout ne pas réutiliser
// SEATS ici, sous peine de casser la logique de tour de parole.
// Voir échange avec Guillaume (session du 23 juillet — "décalage EO") : aligné sur
// l'ordre du relevé d'enchères (N, E, S, O — voir SEATS dans bidding-rules.js), pas
// l'ordre par paires de partenaires (N, S, E, O) utilisé ailleurs (room board) — ce
// tableau est affiché juste en dessous du relevé d'enchères, dont l'ordre de colonnes
// doit rester cohérent pour que les deux s'alignent visuellement.
// Voir échange avec Guillaume ("dans le tableau du PAR, NS devraient être collés et EO
// ensuite au lieu d'alterner") : N,S,E,W plutôt que N,E,S,W — les deux camps groupés
// plutôt qu'alternés, plus lisible pour comparer visuellement NS vs EO d'un coup d'œil.
const DD_TABLE_SEAT_ORDER = ['N', 'S', 'E', 'W'];

// Construit le tableau HTML du double mort (5 lignes SA/♠/♥/♦/♣ x 4 colonnes N/S/E/O),
// tel qu'éventuellement fourni dans le fichier PBN chargé (tag [OptimumResultTable]).
// Affiche le palier de contrat réalisable (et non le nombre brut de levées), avec le
// meilleur contrat de chaque camp mis en évidence (voir computeDDScores ci-dessus).
// Voir échange avec Guillaume ("si un camp a une manche, ne pas afficher en vert le
// meilleur contrat de l'autre camp, sauf si ils ont sacrifice. Ex : NS gagne 4♥ en étant
// rouge contre vert... EO a un bon sacrifice si ils ont 5x-3 à jouer") : pour chaque
// camp qui a une VRAIE manche ou chelem, vérifie si l'AUTRE camp (dont le meilleur
// contrat n'est qu'une partielle) aurait un sacrifice rentable en enchérissant un cran
// au-dessus (contré) — sinon, son contrat n'est plus mis en évidence du tout (il n'y a
// rien à viser). Si l'autre camp a AUSSI sa propre manche/chelem, ou si aucun camp n'a
// de manche, rien ne change (mise en évidence normale des 2 côtés).
function computeSacrificeAwareVisibility(ddTable, dealVulnerable, info, sideSummary) {
    const nsVuln = (dealVulnerable === 'NS' || dealVulnerable === 'Both');
    const ewVuln = (dealVulnerable === 'EW' || dealVulnerable === 'Both');
    const visible = { NS: true, EW: true };

    const bestLevelForSide = (side, tier, score) => {
        for (const strain of STRAIN_ORDER) {
            for (const pos of (side === 'NS' ? ['N', 'S'] : ['E', 'W'])) {
                const cell = info[strain][pos];
                if (cell.tier === tier && cell.score === score) return ddTable[strain][pos] - 6;
            }
        }
        return null;
    };

    for (const gameSide of ['NS', 'EW']) {
        const otherSide = gameSide === 'NS' ? 'EW' : 'NS';
        const gameSummary = sideSummary[gameSide];
        const otherSummary = sideSummary[otherSide];
        if (gameSummary.activeTier !== 'game' && gameSummary.activeTier !== 'slam') continue; // rien à protéger ici
        if (otherSummary.activeTier === 'game' || otherSummary.activeTier === 'slam') continue; // l'autre a AUSSI son propre gros contrat
        if (!otherSummary.activeTier) { visible[otherSide] = false; continue; } // l'autre camp ne fait rien du tout : pas de sacrifice possible

        const gameLevel = bestLevelForSide(gameSide, gameSummary.activeTier, gameSummary.bestScore);
        const otherLevel = bestLevelForSide(otherSide, otherSummary.activeTier, otherSummary.bestScore);
        if (gameLevel === null || otherLevel === null) continue;

        const sacrificeLevel = gameLevel + 1;
        const undertricks = sacrificeLevel - otherLevel;
        const otherVuln = otherSide === 'NS' ? nsVuln : ewVuln;
        const penalty = doubledUndertrickScore(undertricks, otherVuln);
        if (Math.abs(penalty) >= gameSummary.bestScore) visible[otherSide] = false; // sacrifice pas rentable
    }
    return visible;
}

// Voir échange avec Guillaume (session du 8 août — "dans les PAR, ça serait bien de
// fondre les colonnes d'une ligne si c'est le même PAR... conserver la taille des 2
// colonnes additionnées mais faire en sorte que ça n'en fasse plus qu'une seule") :
// fusionne 2 cellules partenaires (N/S ou E/O) sur UNE ligne en une seule <td colspan=2>
// quand elles ont exactement la même valeur affichée ET la même mise en évidence —
// sinon garde 2 cellules séparées. Appliqué ligne par ligne (pas table entière) : une
// donne peut avoir SA différent entre les 2 partenaires mais toutes les autres couleurs
// identiques (voir l'exemple de Guillaume), auquel cas seule la ligne SA reste à 2
// cellules.
function renderDDCellPairHtml(strain, posA, posB, ddTable, info, sideSummary, sideVisibility) {
    const buildCell = (pos) => {
        const cellInfo = info[strain][pos];
        const summary = sideSummary[cellInfo.side];
        let cls = '';
        if (sideVisibility[cellInfo.side] && summary.activeTier && cellInfo.tier === summary.activeTier) {
            if (cellInfo.score === summary.bestScore) cls = 'dd-best-contract';
            else if (summary.activeTier !== 'partial') cls = 'dd-secondary-contract';
        }
        return { cls, text: tricksToContractLevel(ddTable[strain][pos]) };
    };
    const a = buildCell(posA);
    const b = buildCell(posB);
    const merged = a.text === b.text && a.cls === b.cls;
    if (merged) {
        return { html: `<td colspan="2"${a.cls ? ` class="${a.cls}"` : ''}>${a.text}</td>`, merged };
    }
    return { html: `<td${a.cls ? ` class="${a.cls}"` : ''}>${a.text}</td><td${b.cls ? ` class="${b.cls}"` : ''}>${b.text}</td>`, merged };
}

function renderDDTable(ddTable, dealVulnerable) {
    if (!ddTable) return '';
    const { info, sideSummary } = computeDDScores(ddTable, dealVulnerable);
    const sideVisibility = computeSacrificeAwareVisibility(ddTable, dealVulnerable, info, sideSummary);
    let allNSMerged = true;
    let allEWMerged = true;
    const rows = STRAIN_ORDER.map(strain => {
        const labelHtml = formatStrainLabel(strain);
        const ns = renderDDCellPairHtml(strain, 'N', 'S', ddTable, info, sideSummary, sideVisibility);
        const ew = renderDDCellPairHtml(strain, 'E', 'W', ddTable, info, sideSummary, sideVisibility);
        if (!ns.merged) allNSMerged = false;
        if (!ew.merged) allEWMerged = false;
        return `<tr><th class="${STRAIN_CLASS[strain]}">${labelHtml}</th>${ns.html}${ew.html}</tr>`;
    }).join('');
    // Voir échange avec Guillaume (session du 8 août — "je parle des cases tout en haut,
    // celle où il y a écrit 'N' et celle où il y a écrit 'S'") : l'en-tête lui-même
    // fusionne en une seule case "NS"/"EO" quand TOUTES les lignes ont fusionné pour
    // cette paire (pas juste certaines, voir allNSMerged/allEWMerged ci-dessus) — sinon
    // les 2 en-têtes séparés restent nécessaires pour rester alignés avec des cellules
    // qui, elles, ne fusionnent pas partout.
    const headerHtml = allNSMerged
        ? `<th colspan="2">NS</th>`
        : `<th>${SEAT_ABBR_FR.N}</th><th>${SEAT_ABBR_FR.S}</th>`;
    const headerHtmlEW = allEWMerged
        ? `<th colspan="2">EO</th>`
        : `<th>${SEAT_ABBR_FR.E}</th><th>${SEAT_ABBR_FR.W}</th>`;
    return `
        <div class="dd-table-title">Table du double mort</div>
        <table class="dd-table">
            <thead><tr><th></th>${headerHtml}${headerHtmlEW}</tr></thead>
            <tbody>${rows}</tbody>
        </table>
    `;
}

// ===== Export PBN d'une donne jouée =====
//
// Les deux exports (donne seule et session) proposent maintenant le même choix :
// téléchargement local ou envoi GitHub. L'envoi GitHub passe par la fonction serverless
// existante, qui écrit les fichiers PBN dans donnes_export/ ; le jeton d'écriture reste
// entièrement côté serveur et n'est jamais exposé dans le navigateur.
const DEAL_EXPORT_SERVER_URL = 'https://api-gen-beta.vercel.app/api/export-deal';

// Construit le contenu PBN d'une donne JOUÉE : mêmes tags que buildPBNBlock dans
// generator.js (gen/) pour la donne elle-même et la table du double mort si disponible,
// complétés par le contrat obtenu et l'enchère réellement menée.
function buildPlayedDealPBN(deal, history) {
    const handsStr = ['N', 'E', 'S', 'W']
        .map(pos => ['S', 'H', 'D', 'C'].map(suit => deal.hands[pos][suit]).join('.'))
        .join(' ');

    let pbn = '';
    pbn += `[Event "Table d'enchères"]\n`;
    pbn += `[Site "capgui13.github.io/play"]\n`;
    pbn += `[Board "${deal.board}"]\n`;
    pbn += `[Dealer "${deal.dealer}"]\n`;
    pbn += `[Vulnerable "${deal.vulnerable}"]\n`;
    pbn += `[Deal "N:${handsStr}"]\n`;

    const contract = determineContract(history);
    if (contract) {
        pbn += `[Contract "${contract.level}${contract.strain}${contract.doubled}"]\n`;
        pbn += `[Declarer "${contract.declarer}"]\n`;
    }

    if (history.length > 0) {
        pbn += `[Auction "${deal.dealer}"]\n`;
        const tokens = history.map(entry => (isPass(entry.call) ? 'Pass' : entry.call));
        for (let i = 0; i < tokens.length; i += 4) {
            pbn += tokens.slice(i, i + 4).join(' ') + '\n';
        }
    }

    if (deal.ddTable) {
        pbn += `[OptimumResultTable "Declarer;Denomination\\2R;Result\\2R"]\n`;
        const denomForStrain = { N: 'NT', S: 'S', H: 'H', D: 'D', C: 'C' };
        ['N', 'E', 'S', 'W'].forEach(declarer => {
            ['N', 'S', 'H', 'D', 'C'].forEach(strain => {
                pbn += `${declarer} ${denomForStrain[strain]} ${deal.ddTable[strain][declarer]}\n`;
            });
        });
    }

    pbn += `\n`;
    return pbn;
}

function setDealExportStatus(text, isError) {
    const el = document.getElementById('dealExportStatus');
    if (!el) return;
    el.textContent = text;
    el.classList.toggle('is-error', !!isError);
}

function exportTimestamp(includeSeconds = true) {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const day = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
    const time = `${pad(now.getHours())}${pad(now.getMinutes())}${includeSeconds ? pad(now.getSeconds()) : ''}`;
    return `${day}-${time}`;
}

function downloadPbnContent(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function cloudPbnExportCredentials() {
    const accessKey = (typeof getSessionAccessKey === 'function' && currentRoomCode)
        ? getSessionAccessKey(currentRoomCode) : null;
    const hostWriteKey = currentClientHasHostCloudWriteAuthority()
        ? getSessionHostWriteKey(currentRoomCode) : null;
    const participantCredential = hostWriteKey ? null : currentClientParticipantCredentialForCloudWrite();
    if (!currentRoomCode || !accessKey || (!hostWriteKey && !participantCredential)) return null;

    const headers = {
        'Content-Type': 'application/json',
        'X-Bridge-Session-Key': accessKey
    };
    if (hostWriteKey) {
        headers['X-Bridge-Host-Write-Key'] = hostWriteKey;
    } else {
        headers['X-Bridge-Participant-Id'] = participantCredential.participantId;
        headers['X-Bridge-Reconnect-Secret'] = participantCredential.reconnectSecret;
    }
    return headers;
}

async function exportPbnToGitHub(filename, content) {
    const headers = cloudPbnExportCredentials();
    if (!headers) throw new Error('accès sécurisé à la salle indisponible');
    const response = await fetch(DEAL_EXPORT_SERVER_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify({ roomCode: currentRoomCode, filename, content })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.ok) throw new Error(data.error || ('HTTP ' + response.status));
    return data;
}

// ===== Choix Local / GitHub =====
let pendingPbnExportKind = null; // 'deal' | 'session'

function openPbnExportChoice(kind) {
    const modal = document.getElementById('exportChoiceModal');
    const title = document.getElementById('exportChoiceTitle');
    if (!modal || !title) return;
    pendingPbnExportKind = kind;
    title.textContent = kind === 'session' ? 'Exporter la session' : 'Exporter le PBN';
    modal.style.display = 'flex';
    activateAccessibleModal(modal, { closeOnEscape: uiCloseExportChoice });
}

function uiCloseExportChoice() {
    const modal = document.getElementById('exportChoiceModal');
    if (!modal) return;
    modal.style.display = 'none';
    pendingPbnExportKind = null;
    deactivateAccessibleModal(modal);
}

function uiCloseExportChoiceOnBackdrop(evt) {
    if (evt.target.id === 'exportChoiceModal') uiCloseExportChoice();
}

function uiChooseExportLocal() {
    const kind = pendingPbnExportKind;
    uiCloseExportChoice();
    if (kind === 'deal') exportCurrentDealPbnLocal();
    else if (kind === 'session') exportSessionPbnLocal();
}

function uiChooseExportGitHub() {
    const kind = pendingPbnExportKind;
    uiCloseExportChoice();
    if (kind === 'deal') exportCurrentDealPbnGitHub();
    else if (kind === 'session') exportSessionPbnGitHub();
}

// Le bouton de la donne ouvre seulement le choix de destination. Il reste disponible pour
// tout joueur assis, hôte ou invité, comme auparavant.
function uiExportDealPBN() {
    if (!canControlBoard() || !currentDeal()) return;
    openPbnExportChoice('deal');
}

function exportCurrentDealPbnLocal() {
    if (!canControlBoard()) return;
    const deal = currentDeal();
    if (!deal) return;
    const content = buildPlayedDealPBN(deal, auctionHistory);
    const filename = `donne-${deal.board}-${exportTimestamp(true)}.pbn`;
    downloadPbnContent(content, filename);
    // Confirmation volontairement sans chemin ni nom de fichier.
    setDealExportStatus('✅ Export local effectué.', false);
}

function exportCurrentDealPbnGitHub() {
    if (!canControlBoard()) return;
    const deal = currentDeal();
    if (!deal) return;

    const btn = document.getElementById('dealExportBtn');
    if (btn) btn.disabled = true;
    setDealExportStatus('⏳ Export GitHub en cours...', false);

    const content = buildPlayedDealPBN(deal, auctionHistory);
    const filename = `donne-${deal.board}-${exportTimestamp(true)}.pbn`;

    exportPbnToGitHub(filename, content)
        .then(() => {
            // Ne jamais afficher data.path / filename dans la confirmation.
            setDealExportStatus('✅ Export GitHub réussi.', false);
        })
        .catch((err) => {
            setDealExportStatus('❌ Échec de l\'export : ' + ((err && err.message) || err), true);
        })
        .finally(() => {
            if (btn) btn.disabled = false;
        });
}

function playedSessionDeals() {
    if (!deals) return [];
    return deals.filter(d => d.auctionHistory && isAuctionOver(d.auctionHistory));
}

// Le bouton session propose désormais lui aussi Local / GitHub.
function uiExportSessionPBN() {
    if (!canControlBoard()) return;
    const playedDeals = playedSessionDeals();
    if (playedDeals.length === 0) {
        flashSessionExportToast('Aucune donne terminée à exporter pour l\'instant.');
        return;
    }
    openPbnExportChoice('session');
}

function exportSessionPbnLocal() {
    if (!canControlBoard()) return;
    const playedDeals = playedSessionDeals();
    if (playedDeals.length === 0) {
        flashSessionExportToast('Aucune donne terminée à exporter pour l\'instant.');
        return;
    }
    const content = playedDeals.map(d => buildPlayedDealPBN(d, d.auctionHistory)).join('');
    const filename = `session-${exportTimestamp(false)}.pbn`;
    downloadPbnContent(content, filename);
    flashSessionExportToast(`📦 ${playedDeals.length} donne(s) exportée(s) localement.`);
}

function exportSessionPbnGitHub() {
    if (!canControlBoard()) return;
    const playedDeals = playedSessionDeals();
    if (playedDeals.length === 0) {
        flashSessionExportToast('Aucune donne terminée à exporter pour l\'instant.');
        return;
    }

    const btn = document.getElementById('exportSessionBtn');
    if (btn) btn.disabled = true;
    flashSessionExportToast('⏳ Export GitHub en cours...');

    const content = playedDeals.map(d => buildPlayedDealPBN(d, d.auctionHistory)).join('');
    // Même endpoint que l'export d'une donne : côté serveur, il écrit dans donnes_export/.
    const filename = `session-${exportTimestamp(true)}.pbn`;

    exportPbnToGitHub(filename, content)
        .then(() => {
            // Confirmation volontairement sans chemin ni nom de fichier.
            flashSessionExportToast(`✅ Session exportée sur GitHub (${playedDeals.length} donne(s)).`);
        })
        .catch((err) => {
            flashSessionExportToast('❌ Échec de l\'export : ' + ((err && err.message) || err));
        })
        .finally(() => {
            if (btn) btn.disabled = false;
        });
}

// Même mécanique de bandeau que flashWizzToast/uiShowCallExplanation (voir ces
// fonctions) — un id dédié plutôt que de les réutiliser, pour ne pas se marcher dessus si
// deux notifications se déclenchent presque en même temps (ex. wizz reçu pile pendant un
// export).
function flashSessionExportToast(text) {
    let toast = document.getElementById('sessionExportToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'sessionExportToast';
        toast.className = 'call-explanation-toast'; // même style que le toast de diagnostic, réutilisé tel quel
        document.body.appendChild(toast);
    }
    toast.textContent = text;
    toast.classList.remove('visible');
    void toast.offsetWidth;
    toast.classList.add('visible');
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), 2800);
}


// Placeholder de double mort utilisé UNIQUEMENT comme gabarit de hauteur sur mobile
// pendant que le vrai PAR est encore en calcul. Même nombre de lignes/cellules que la
// table finale : quand le résultat arrive, sa hauteur ne change donc pas.
function renderDDTablePlaceholder() {
    const rows = STRAIN_ORDER.map(strain => `
        <tr>
            <th class="${STRAIN_CLASS[strain]}">${formatStrainLabel(strain)}</th>
            <td>–</td><td>–</td><td>–</td><td>–</td>
        </tr>
    `).join('');
    return `
        <div class="dd-table-title">Table du double mort</div>
        <table class="dd-table" aria-hidden="true">
            <thead><tr><th></th><th>N</th><th>S</th><th>E</th><th>O</th></tr></thead>
            <tbody>${rows}</tbody>
        </table>
    `;
}

let lastAuctionVisualMode = null;

// Nouvelle séance : repartir d'un état visuel neutre AVANT le premier renderBoard.
// Sans ce reset, une séance lancée dans le même onglet après une donne terminée pouvait
// hériter de la classe mobile `show-par` de la séance précédente ; les boutons de la
// première donne entraient alors dans le crossfade de 325 ms, perçu comme une latence.
function resetAuctionVisualModeForNewSession() {
    lastAuctionVisualMode = null;
    const stack = document.getElementById('auctionViewStack');
    const resultEl = document.getElementById('contractResult');
    const biddingViewEl = document.getElementById('auctionBiddingView');
    if (stack) stack.classList.remove('is-mobile-stacked', 'is-desktop-par-stacked', 'show-par', 'show-bidding');
    if (resultEl) {
        resultEl.style.display = 'none';
        resultEl.innerHTML = '';
        resultEl.removeAttribute('aria-hidden');
        if ('inert' in resultEl) resultEl.inert = false;
    }
    if (biddingViewEl) {
        biddingViewEl.style.display = '';
        biddingViewEl.removeAttribute('aria-hidden');
        if ('inert' in biddingViewEl) biddingViewEl.inert = false;
    }
    // Force le navigateur à enregistrer cet état neutre avant que renderBoard() ne
    // réapplique la pile mobile. Ainsi, la vue boutons part déjà d'une opacité de 1 et
    // n'entre pas dans le crossfade de 325 ms au premier affichage de la séance.
    if (stack) void stack.offsetWidth;
}

// Rejoue le fondu sur plusieurs éléments avec UN SEUL flush de layout.
// Ancien comportement : replayQuickFade() lu séparément sur chaque cible => un offsetWidth
// forcé par élément. Pour une navigation de donne (numéro + méta + cartes), c'était du
// travail synchrone inutile. On retire toutes les classes, on force UNE mesure, puis on
// réactive toutes les animations ensemble.
function replayQuickFadeGroup(elements) {
    const targets = Array.from(new Set(
        (elements || []).filter(el => el && el.classList)
    ));
    if (!targets.length) return;

    targets.forEach(el => el.classList.remove('ui-quick-fade-in'));
    void targets[0].offsetWidth;
    targets.forEach(el => el.classList.add('ui-quick-fade-in'));
}

function replayQuickFade(el) {
    replayQuickFadeGroup([el]);
}

// Centralise Enchères ↔ PAR.
// - mobile : superposition CSS, donc hauteur stable dès le premier rendu et crossfade.
// - desktop pendant l'enchère : même réservation de hauteur pour figer le bouton de
//   bascule, avec le simple fondu historique sur la vue entrante.
function setAuctionVisualMode(mode, { parCapable = false, ddTableHtml = '' } = {}) {
    const stack = document.getElementById('auctionViewStack');
    const resultEl = document.getElementById('contractResult');
    const biddingViewEl = document.getElementById('auctionBiddingView');
    if (!stack || !resultEl || !biddingViewEl) return;

    const mobile = window.matchMedia && window.matchMedia('(max-width: 1024px), ((hover: none) and (pointer: coarse) and (max-width: 1366px))').matches;
    const shouldStackMobile = mobile && (parCapable || mode === 'final');
    // Desktop, pendant l'enchère seulement : garder Enchères et PAR dans la même cellule
    // de grille, comme sur mobile. La vue masquée continue ainsi de réserver sa hauteur :
    // le bouton de bascule reste EXACTEMENT au même Y entre « Voir le PAR » et
    // « Voir les enchères ». Aucun changement de géométrie n'est appliqué au mobile.
    const shouldStackDesktopPar = !mobile && parCapable && mode !== 'final';
    const modeChanged = lastAuctionVisualMode !== mode;

    // Toujours alimenter la vue PAR avec le double mort de LA DONNE COURANTE.
    // Sur mobile, même quand on affiche encore les boutons, la vue PAR invisible doit
    // déjà contenir le PAR courant (ou son gabarit si le calcul n'est pas terminé) :
    // elle participe à la hauteur de la pile et empêche tout resizing au clic. Cela
    // évite aussi de conserver, sur la donne suivante, le résultat final de la donne
    // précédente dans la vue invisible.
    if ((shouldStackMobile || shouldStackDesktopPar) && mode !== 'final') {
        resultEl.innerHTML = ddTableHtml || renderDDTablePlaceholder();
    } else if (mode === 'par' && ddTableHtml) {
        // Desktop : injection explicite au moment d'afficher le PAR — indispensable dès
        // la première donne, où aucun ancien contenu n'existe encore dans contractResult.
        resultEl.innerHTML = ddTableHtml;
    }

    if (shouldStackMobile || shouldStackDesktopPar) {

        resultEl.style.display = 'block';
        biddingViewEl.style.display = 'block';
        stack.classList.toggle('is-mobile-stacked', shouldStackMobile);
        stack.classList.toggle('is-desktop-par-stacked', shouldStackDesktopPar);
        stack.classList.toggle('show-par', mode === 'par' || mode === 'final');
        stack.classList.toggle('show-bidding', mode === 'bidding');

        const resultHidden = mode === 'bidding';
        resultEl.setAttribute('aria-hidden', resultHidden ? 'true' : 'false');
        biddingViewEl.setAttribute('aria-hidden', resultHidden ? 'false' : 'true');
        if ('inert' in biddingViewEl) biddingViewEl.inert = !resultHidden;
        if ('inert' in resultEl) resultEl.inert = resultHidden;
        // Desktop conservait un léger fondu de la vue entrante : on le garde, sans
        // crossfade ni changement de position du bouton de bascule.
        if (shouldStackDesktopPar && modeChanged) {
            replayQuickFade(resultHidden ? biddingViewEl : resultEl);
        }
    } else {
        stack.classList.remove('is-mobile-stacked', 'is-desktop-par-stacked', 'show-par', 'show-bidding');
        resultEl.removeAttribute('aria-hidden');
        biddingViewEl.removeAttribute('aria-hidden');
        if ('inert' in biddingViewEl) biddingViewEl.inert = false;
        if ('inert' in resultEl) resultEl.inert = false;

        if (mode === 'bidding') {
            resultEl.style.display = 'none';
            biddingViewEl.style.display = '';
            if (modeChanged) replayQuickFade(biddingViewEl);
        } else {
            resultEl.style.display = 'block';
            biddingViewEl.style.display = 'none';
            if (modeChanged && mode !== 'final') replayQuickFade(resultEl);
        }
    }

    lastAuctionVisualMode = mode;
}

// Lors de la FIN d'une enchère sur mobile, le remplacement de la/les main(s) du joueur
// par les 4 mains augmente la hauteur de la zone située AU-DESSUS du panneau central.
// On ne change aucune taille : on compense uniquement le scroll au même frame de rendu
// pour que le panneau d'enchères/PAR reste exactement au même endroit dans le viewport.
// Si les 4 mains étaient déjà visibles (host "Voir les 4 mains" / kibbitz), rien à faire.
function captureMobileAuctionEndViewportAnchor(auctionOver, diagramEl) {
    if (!auctionOver || window.innerWidth > 760 || !diagramEl) return null;
    if (getComputedStyle(diagramEl).display !== 'none') return null;

    const panel = document.querySelector('.auction-panel');
    if (!panel) return null;

    const rect = panel.getBoundingClientRect();
    const viewportHeight = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    // Ne corrige que si le panneau est réellement dans/près du viewport : si l'utilisateur
    // regarde ailleurs, on ne lui impose aucun déplacement.
    if (rect.bottom <= 0 || rect.top >= viewportHeight) return null;

    return { element: panel, top: rect.top };
}

function restoreMobileAuctionEndViewportAnchor(anchor) {
    if (!anchor || !anchor.element) return;
    requestAnimationFrame(() => {
        if (!anchor.element.isConnected) return;
        const newTop = anchor.element.getBoundingClientRect().top;
        const delta = newTop - anchor.top;
        if (Math.abs(delta) > 0.5) {
            // Déplacement instantané, sans animation : le changement de contenu et la
            // compensation sont peints ensemble, donc pas de "saut" visible.
            window.scrollBy(0, delta);
        }
    });
}

function uiToggleParBiddingView() {
    if (!deals || isAuctionOver(auctionHistory)) return;
    // Le PAR pendant l'enchère est un privilège du vrai hôte, même s'il n'a PAS activé
    // « Voir les 4 mains ». Un kibbitz y a également accès. Ne pas lier ce bouton à
    // hostSeeAllHands : sinon l'hôte peut perdre le bouton alors qu'il reste l'organisateur.
    const canViewParDuringAuction = isTrueOriginalHost() || isKibbitz();
    if (!canViewParDuringAuction || !currentDeal() || !currentDeal().ddTable) return;
    showParDuringAuction = !showParDuringAuction;
    renderBiddingBox();
    checkAuctionEnd();
}

function checkAuctionEnd(renderOptions = {}) {
    const resultEl = document.getElementById('contractResult');
    const diagramEl = document.getElementById('allHandsDiagram');

    const auctionOver = isAuctionOver(auctionHistory);
    // Sur le chemin d'une annonce normale qui vient de terminer l'enchère, l'ancre peut
    // avoir été capturée AVANT les écritures DOM (renderAfterNormalCall). Tous les autres
    // appelants gardent exactement le comportement historique.
    const mobileAuctionEndAnchor = Object.prototype.hasOwnProperty.call(
        renderOptions,
        'preCapturedMobileAuctionEndAnchor'
    )
        ? renderOptions.preCapturedMobileAuctionEndAnchor
        : captureMobileAuctionEndViewportAnchor(auctionOver, diagramEl);
    // L'hôte peut choisir de voir les 4 mains à tout moment (voir uiToggleHostSeeAllHands),
    // même pendant l'enchère — un outil réservé à lui seul (vérifier une donne, aider un
    // débutant en direct...), jamais envoyé ni visible pour les autres joueurs. Un
    // kibbitz, lui, voit toujours les 4 mains dès le début (voir renderMyHands) — pas
    // besoin d'attendre la fin de l'enchère ni une action de l'hôte, puisqu'il n'est
    // assis à aucun siège et ne peut donc rien "tricher" en les voyant.
    //
    // Voir échange avec Guillaume : PRIVILÈGE DU VRAI HÔTE (voir isTrueOriginalHost) —
    // un hôte qui joue lui-même une main (ex. donner un cours) doit pouvoir l'activer
    // pour tout voir, mais "myRole==='host'" seul est trop large en mode différé
    // (n'importe quel joueur reprenant une salle abandonnée devient 'host' techniquement
    // sans être le vrai créateur — lui laisser ce privilège reviendrait à le laisser
    // tricher sur sa propre main, voir isTrueOriginalHost pour le détail).
    const hostForcedReveal = isTrueOriginalHost() && hostSeeAllHands;
    const showAllHandsEarly = hostForcedReveal || isKibbitz();
    // Indépendant de « Voir les 4 mains » : le vrai hôte garde toujours son bouton PAR.
    const canViewParDuringAuction = isTrueOriginalHost() || isKibbitz();

    if (!auctionOver) {
        const myHandsEl = document.getElementById('myHandsContainer');
        const toggleWrap = document.getElementById('parBiddingToggleWrap');
        const toggleBtn = document.getElementById('parBiddingToggleBtn');
        const ddTableHtml = canViewParDuringAuction ? renderDDTable(currentDeal().ddTable, currentDeal().vulnerable) : '';

        if (showAllHandsEarly) {
            const wasDiagramHidden = getComputedStyle(diagramEl).display === 'none';
            renderAllHandsDiagram();
            diagramEl.style.display = 'grid';
            if (wasDiagramHidden) replayQuickFade(diagramEl);
            if (myHandsEl) myHandsEl.style.display = 'none';
        } else {
            const wasMyHandsHidden = myHandsEl && getComputedStyle(myHandsEl).display === 'none';
            diagramEl.style.display = 'none';
            if (myHandsEl) {
                myHandsEl.style.display = '';
                if (wasMyHandsHidden) replayQuickFade(myHandsEl);
            }
            // Desktop : pré-rendu nécessaire pour syncHandsPanelMinHeight().
            // Mobile : cette réservation de hauteur est volontairement désactivée, donc
            // construire les 4 mains invisibles ici ne sert à rien et retarde le premier
            // affichage des boutons au chargement d'une nouvelle séance.
            if (window.innerWidth > 760 && !renderOptions.skipHiddenAllHandsRefresh) {
                renderAllHandsDiagram();
            }
        }

        if (canViewParDuringAuction) {
            if (toggleWrap) toggleWrap.style.display = 'flex';
            if (toggleBtn) {
                toggleBtn.disabled = !ddTableHtml;
                toggleBtn.textContent = ddTableHtml
                    ? (showParDuringAuction ? '🎴 Voir les enchères' : '📊 Voir le PAR')
                    : '⏳ PAR en calcul…';
            }
            if (!ddTableHtml) showParDuringAuction = false;
            setAuctionVisualMode(
                (ddTableHtml && showParDuringAuction) ? 'par' : 'bidding',
                { parCapable: true, ddTableHtml }
            );
        } else {
            showParDuringAuction = false;
            if (toggleWrap) toggleWrap.style.display = 'none';
            if (toggleBtn) toggleBtn.disabled = false;
            setAuctionVisualMode('bidding', { parCapable: false });
        }
        return;
    }

    showParDuringAuction = false;
    const toggleWrap = document.getElementById('parBiddingToggleWrap');
    if (toggleWrap) toggleWrap.style.display = 'none';

    const contract = determineContract(auctionHistory);
    // Voir échange avec Guillaume (session du 8 août — ""Export PBN" devrait être en
    // haut à droite dans le carré du PAR, à droite de la ligne contrat final") : calculé
    // ICI (avant de construire la ligne d'en-tête), pour savoir dès le départ si le
    // bouton doit y apparaître — auparavant calculé après coup, forçant le bouton dans
    // une rangée séparée sous le tableau entier.
    // Mémorise ce qui était déjà présent AVANT de reconstruire le résultat. Cela permet
    // de distinguer une vraie arrivée tardive du DD/PBN d'un simple rerender du même état.
    const hadDDTable = !!resultEl.querySelector('.dd-table');
    const hadExportButton = !!resultEl.querySelector('#dealExportBtn');
    const ddTableHtml = renderDDTable(currentDeal().ddTable, currentDeal().vulnerable);
    // Ne joue l'animation de révélation (voir .contract-reveal dans styles.css) qu'au
    // moment précis où le contrat apparaît, pas à chaque re-rendu (renderBoard tourne
    // pour bien d'autres raisons — reconnexion d'un joueur, etc. — tant que la donne
    // reste sur cet écran) : on la déclenche seulement s'il était masqué juste avant.
    const wasHidden = lastAuctionVisualMode !== 'final' || !resultEl.querySelector('.contract-final-header');
    // Si le contrat était déjà affiché SANS DD, puis que le calcul arrive plus tard,
    // n'anime que les nouveaux éléments. La ligne "Contrat final" reste parfaitement fixe.
    const ddArrivedLate = !wasHidden && !!ddTableHtml && !hadDDTable;
    // Voir échange avec Guillaume ("le bouton export PBN doit être disponible également
    // pour les invités") : canControlBoard() plutôt que myRole==='host' — voir le même
    // commentaire détaillé sur uiExportDealPBN plus haut. Affiché seulement une fois le
    // double mort disponible.
    const exportBtnHtml = (canControlBoard() && ddTableHtml) ? `
        <span class="dd-export-row">
            <button type="button" class="btn btn-secondary btn-small" id="dealExportBtn" data-ui-click="export-deal-pbn">📤 Export PBN</button>
            <span id="dealExportStatus" class="dd-export-status"></span>
        </span>
    ` : '';
    const exportArrivedLate = !wasHidden && !!exportBtnHtml && !hadExportButton;
    if (!contract) {
        resultEl.innerHTML = `<div class="contract-final-header"><span class="contract-final-text">↩️ Donne passée — personne n'a annoncé.</span>${exportBtnHtml}</div>`;
    } else {
        const strainCls = SUIT_CLASSES[contract.strain] || 'notrump';
        const strainLabel = formatStrainLabel(contract.strain);
        const contractHtml = `<span class="call-suit ${strainCls}">${contract.level}${strainLabel}${escapeHtml(contract.doubled)}</span>`;
        resultEl.innerHTML = `<div class="contract-final-header"><span class="contract-final-text">Contrat final : <strong>${contractHtml}</strong> par <strong>${seatFullName(contract.declarer)}</strong></span>${exportBtnHtml}</div>`;
    }
    if (wasHidden) {
        // Retire puis relit offsetWidth avant de rajouter la classe : sans ce "force
        // reflow", le navigateur ne rejouerait pas l'animation si la classe était déjà
        // présente d'un affichage précédent (peu probable ici vu qu'on ne la retire
        // jamais ailleurs, mais le filet de sécurité ne coûte rien).
        resultEl.classList.remove('contract-reveal');
        void resultEl.offsetWidth;
        resultEl.classList.add('contract-reveal');
    }

    if (ddTableHtml) {
        resultEl.innerHTML += ddTableHtml;
    }

    if (ddArrivedLate || exportArrivedLate) {
        const lateTargets = [];
        if (ddArrivedLate) {
            lateTargets.push(
                resultEl.querySelector('.dd-table-title'),
                resultEl.querySelector('.dd-table')
            );
        }
        if (exportArrivedLate) {
            lateTargets.push(resultEl.querySelector('.dd-export-row'));
        }
        replayQuickFadeGroup(lateTargets);
    }

    // Voir échange avec Guillaume ("une fois la donne finie, les 4 mains doivent
    // apparaître pour l'hôte, que l'option soit ON ou OFF") : inconditionnel pour tout le
    // monde une fois l'enchère terminée, y compris l'hôte — la bascule
    // hostSeeAllHands/isTrueOriginalHost ne joue un rôle QUE pendant l'enchère (voir plus
    // haut, if (!auctionOver)), jamais après. Un essai précédent avait rendu ceci
    // conditionnel pour l'hôte, ce qui n'était pas ce qui était demandé — revenu à
    // l'affichage inconditionnel d'origine.
    const finalHandsWereHidden = getComputedStyle(diagramEl).display === 'none';
    renderAllHandsDiagram();
    diagramEl.style.display = 'grid';
    if (finalHandsWereHidden) replayQuickFade(diagramEl);
    {
        const myHandsEl = document.getElementById('myHandsContainer');
        if (myHandsEl) myHandsEl.style.display = 'none';
    }

    const isLastBoard = boardIndex >= deals.length - 1;
    // R14 — même règle que les flèches et le fast-forward : en live, seul l'hôte
    // déplace la table ; en différé, chaque joueur ASSIS navigue localement. Un kibbitz
    // reste exclu. gotoBoard() n'émet aucun goto-board en différé, donc ce bouton ne peut
    // jamais déplacer la vue du partenaire.
    const iCanNavigate = canNavigateBoards();

    if (isLastBoard) {
        resultEl.innerHTML += '<div class="info-text">Dernière donne du fichier chargé.</div>';
    } else if (!iCanNavigate) {
        resultEl.innerHTML += '<div class="info-text">En attente que l\'hôte passe à la donne suivante.</div>';
    } else {
        // Voir échange avec Guillaume ("je t'avais pas demandé à ce que ce bouton soit
        // dans la zone des PARs ?") : DANS resultEl (la case du PAR elle-même), comme
        // demandé à l'origine — pas un nœud DOM séparé positionné par-dessus (l'ancienne
        // approche en position:absolute ne s'ancrait en réalité jamais correctement, voir
        // git blame). Une simple chaîne HTML ajoutée ici survit sans problème à la
        // reconstruction complète de resultEl.innerHTML à chaque rendu, puisqu'elle en
        // fait justement partie.
        resultEl.innerHTML += '<div class="next-board-panel"><button type="button" class="btn btn-secondary btn-small" data-ui-click="next-board">Donne suivante →</button></div>';
    }

    setAuctionVisualMode('final', { parCapable: true, ddTableHtml });

    // Mobile uniquement : les tailles réelles restent inchangées, on maintient simplement
    // le même point de vue quand les 4 mains apparaissent à la fin de l'enchère.
    restoreMobileAuctionEndViewportAnchor(mobileAuctionEndAnchor);
}

// ===== Demande d'annulation (undo) =====
//
// Un joueur actif peut demander l'annulation de la dernière annonce (utile en cas de
// mauvais clic). Cette annonce a pu déjà donner une information au camp adverse : on ne
// l'annule donc jamais tout seul dans son coin, il faut l'accord d'un adversaire humain.
// S'il n'y a personne à convaincre en face (siège robot, ou la même personne joue les
// deux camps), l'annulation s'applique immédiatement.
//
// Protocole (voir aussi peer-connection.js) :
//   'undo-request' (→ hôte)      le demandeur sollicite une annulation
//   'undo-ask'     (hôte →)      l'hôte demande l'accord à un adversaire humain
//   'undo-answer'  (→ hôte)      la réponse de cet adversaire (accepté/refusé)
//   'undo-apply'   (hôte →)      l'annulation est actée, tout le monde retire la dernière annonce
//   'undo-rejected'(hôte →)      informe le demandeur que ça ne s'est pas fait, et pourquoi
//
// L'hôte est toujours l'arbitre (hostPendingUndo) : c'est le seul point de passage
// obligé entre deux invités (topologie en étoile). Quand l'hôte est lui-même demandeur ou
// répondeur, ces messages sont traités directement en local (voir deliverToParticipant),
// sans aller-retour réseau inutile.

function clearUndoUiState() {
    undoRequestPending = false;
    pendingUndoAsk = null;
    clearTimeout(undoRequestTimeoutId);
    undoRequestTimeoutId = null;
    renderUndoControls();
    renderUndoAskBanner();
}

// Le statut Undo vit dans l'en-tête, donc il peut déplacer tout ce qui suit avant même
// que la boîte d'enchères soit visible (cas fréquent en haut de page mobile). On ancre le
// premier bloc réellement visible SOUS l'en-tête ; si l'utilisateur regarde plus bas,
// aucun élément invisible ne prend le contrôle de son scroll.
function captureUndoStatusViewportAnchor() {
    if (window.innerWidth > 760 || !deals) return null;
    const candidates = [
        document.querySelector('.hand-display-options'),
        document.querySelector('.hands-panel'),
        document.querySelector('.auction-panel')
    ];
    for (const candidate of candidates) {
        const anchor = captureVisibleMobileViewportAnchor(candidate);
        if (anchor) return anchor;
    }
    return null;
}

function setUndoStatus(text) {
    const el = document.getElementById('undoStatusText');
    if (!el) return;
    const nextText = text || '';
    if (el.textContent === nextText) return;
    // Contrairement à l'ancien ancrage limité au biddingBox/PAR, celui-ci fonctionne aussi
    // tout en haut de la donne : c'est précisément là que l'apparition du statut ajoutait
    // encore 21 à 36 px visibles sur 320-760 px.
    const mobileViewportAnchor = captureUndoStatusViewportAnchor();
    el.textContent = nextText;
    restoreVisibleMobileViewportAnchor(mobileViewportAnchor);
}

function renderUndoControls() {
    const btn = document.getElementById('requestUndoBtn');
    if (!btn) return;
    const visible = canControlBoard();
    btn.style.display = visible ? '' : 'none';
    // R25 — en mode différé, règle strictement symétrique pour les deux joueurs : chacun
    // peut annuler SA PROPRE dernière annonce tant que son partenaire n'a rien annoncé
    // depuis. Une annonce adverse/robot intercalée ne couvre jamais l'annonce du joueur.
    //
    // Voir ARCHITECTURE-P2P-SERVEUR.md ("l'hôte n'a pas reçu la demande d'undo pendant
    // qu'il était hors ligne, et elle a fini par disparaître") : même règle étendue à un
    // invité EN MODE LIVE mais actuellement déconnecté de l'hôte (voir
    // pushUndoViaServerFallback) — techniquement dans la même situation qu'un participant
    // du mode différé pour cette annonce précise : personne à qui demander l'accord, donc
    // même repli sur la règle locale plutôt que d'attendre une réponse qui n'arrivera
    // jamais.
    // Les annonces adverses/robots intercalées seront retirées avec le suffixe lors de
    // l'annulation, puisque leur décision dépendait de l'annonce corrigée.
    const isDeferredPersonalUndo = deals && deferredRoomMode;
    const isDisconnectedGuest = deals && myRole === 'guest' && (!peerConn || !peerConn.isConnected());
    const appliesImmediately = myRole === 'host' || isDeferredPersonalUndo || isDisconnectedGuest;
    const myUndoTargetIndex = findUndoTargetIndex(myParticipantId, auctionHistory);
    const partnerLastCallIndex = findPartnerLastCallIndex(myParticipantId, auctionHistory);
    const blockedByPartnerSince = (isDeferredPersonalUndo || isDisconnectedGuest)
        && myUndoTargetIndex >= 0 && myUndoTargetIndex <= partnerLastCallIndex;
    // Un invité ne peut demander l'annulation que s'il a réellement produit au moins
    // une annonce sur CETTE donne. Auparavant, la simple présence d'une annonce dans
    // l'historique (hôte/robot/autre joueur) suffisait à activer le bouton, puis la
    // demande était rejetée plus tard avec "rien à annuler". L'hôte conserve son droit
    // historique d'annuler la dernière annonce humaine de la table.
    // En différé, même le créateur suit la règle personnelle : pas d'Undo tant qu'il
    // n'a lui-même rien annoncé sur cette donne. En live, on conserve le privilège
    // historique de l'hôte (dernière annonce humaine de la table).
    const hasRequiredUndoTarget = isDeferredPersonalUndo ? myUndoTargetIndex >= 0 : (myRole !== 'guest' || myUndoTargetIndex >= 0);
    btn.disabled = !visible || !deals || auctionHistory.length === 0 || !hasRequiredUndoTarget
        || undoRequestPending || !!pendingUndoAsk || blockedByPartnerSince;
    // Deux <span> (voir index.html) plutôt qu'un textContent direct : .btn-label-full/
    // .btn-label-short sont affichés en alternance en CSS selon la largeur d'écran
    // (bouton complet sur desktop, abrégé sur mobile où la place manque).
    // Libellé différent selon le cas (voir échange avec Guillaume) : "Faire un undo"
    // s'applique immédiatement, sans validation du camp d'en face — vrai pour l'hôte
    // (voir hostHandleUndoRequest), pour tout participant en mode différé
    // (myRole==='host' localement pour tout le monde là-bas, voir uiResumeFromCloud), ET
    // désormais pour un invité déconnecté en mode live (voir juste au-dessus) — jamais de
    // "Demande envoyée..." qui n'aurait de toute façon personne en ligne pour y répondre
    // dans ces trois cas.
    const fullEl = btn.querySelector('.btn-label-full');
    const shortEl = btn.querySelector('.btn-label-short');
    if (appliesImmediately) {
        if (fullEl) fullEl.textContent = '↩️ Faire un undo';
        if (shortEl) shortEl.textContent = '↩️ Undo';
    } else {
        if (fullEl) fullEl.textContent = undoRequestPending ? '⏳ Demande envoyée...' : "↩️ Demande d'undo";
        // Sur mobile, ne pas réduire le libellé à "Undo" : pour un invité il s'agit
        // bien d'une DEMANDE soumise à l'hôte, pas d'un undo immédiat.
        if (shortEl) shortEl.textContent = undoRequestPending ? '⏳ Envoyée...' : "↩️ Demande d'undo";
    }
}

function renderUndoAskBanner() {
    const banner = document.getElementById('undoAskBanner');
    if (!banner) return;
    const shouldShow = !!pendingUndoAsk;
    const isShown = getComputedStyle(banner).display !== 'none';
    const stateChanges = shouldShow !== isShown;
    const parViewActive = isAuctionParViewActive();
    // La bannière vit dans le flux juste au-dessus de la pile Enchères/PAR. Ancrer la vue
    // réellement regardée, uniquement lorsqu'elle change d'état et si elle est à l'écran.
    const mobileViewportAnchor = !stateChanges ? null : (parViewActive
        ? captureVisibleMobileViewportAnchor(document.getElementById('auctionViewStack'))
        : captureMobileLedgerViewportAnchor());
    if (!shouldShow) {
        banner.style.display = 'none';
        banner.innerHTML = '';
        if (parViewActive) restoreVisibleMobileViewportAnchor(mobileViewportAnchor);
        else scheduleMobileLedgerViewportRestore(mobileViewportAnchor);
        return;
    }
    const name = escapeHtml(participantName(pendingUndoAsk.requesterId));
    banner.style.display = 'flex';
    banner.innerHTML = `
        <span>${name} demande à annuler la dernière annonce.</span>
        <button class="btn btn-success btn-small" data-ui-click="answer-undo" data-approved="true">Accepter</button>
        <button class="btn btn-secondary btn-small" data-ui-click="answer-undo" data-approved="false">Refuser</button>
    `;
    if (parViewActive) restoreVisibleMobileViewportAnchor(mobileViewportAnchor);
    else scheduleMobileLedgerViewportRestore(mobileViewportAnchor);
}

function participantName(pid) {
    if (pid === 'host') return "L'hôte";
    if (pid === SEAT_PENDING) return 'En attente…';
    const p = participants.find(x => x.id === pid);
    return p ? p.name : 'Un joueur';
}

function partnershipSeats(partnership) {
    return SEATS.filter(s => partnershipOf(s) === partnership);
}

function seatsOfParticipant(pid) {
    return SEATS.filter(seat => seatAssignment[seat] === pid);
}

// Détermine quelle entrée de l'historique une demande d'undo doit effectivement annuler :
// la dernière annonce parmi celles produites par UN des sièges que ce participant
// contrôle — pas forcément la toute dernière case du tableau, puisqu'un ou plusieurs
// robots ont pu passer automatiquement juste après (voir maybeRobotBid) si le joueur a
// mis un peu de temps à cliquer sur "undo". On renvoie alors l'index de SA dernière
// annonce ; applyUndoAsHost retirera cette annonce et tout ce qui a suivi (uniquement des
// passes robot, puisqu'aucun autre humain n'a pu jouer avant que ce ne soit à nouveau le
// tour de ce joueur).
// Renvoie -1 si ce participant n'a fait aucune annonce sur cette donne (rien à annuler).
//
// MÊME LOGIQUE pour l'hôte et les invités (voir échange avec Guillaume) : un ancien cas
// spécial pour 'host' renvoyait ici à tort la toute dernière case du tableau quel qu'en
// soit l'auteur — si un robot passait automatiquement juste après l'annonce de l'hôte
// (avant qu'il ait le temps de cliquer "undo"), l'hôte annulait alors CE PASSE ROBOT au
// lieu de sa propre annonce.
// Voir échange avec Guillaume (session du 8 août — "faire un undo par l'hôte devrait
// annuler la dernière enchère produite (si elle a été faite par un humain ; si c'est un
// bot, annuler la dernière enchère produite par un humain)") : distincte de
// findUndoTargetIndex ci-dessus (qui cible SA PROPRE dernière annonce pour une demande
// d'un participant précis) — ici, l'hôte cliquant sur SON bouton d'undo direct vise la
// toute dernière annonce de l'historique, MAIS en sautant les annonces de robots (sièges
// non occupés par un humain au sens de seatAssignment) pour retomber sur la dernière
// vraiment humaine. Renvoie -1 si l'historique entier n'a que des annonces de robots
// (rien d'humain à annuler).
function findHostUndoTargetIndex(history) {
    for (let i = history.length - 1; i >= 0; i--) {
        const occupant = seatAssignment[history[i].seat];
        if (occupant && occupant !== SEAT_PENDING) return i;
    }
    return -1;
}

function findUndoTargetIndex(requesterId, history) {
    const seats = seatsOfParticipant(requesterId);
    for (let i = history.length - 1; i >= 0; i--) {
        if (seats.includes(history[i].seat)) return i;
    }
    return -1;
}

// Voir échange avec Guillaume ("undo en mode différé") : index de la dernière annonce du
// PARTENAIRE de ce participant (même camp, sièges qu'il ne contrôle PAS lui-même) — sert
// uniquement à la règle d'undo du mode différé (voir hostHandleUndoRequest/
// renderUndoControls), pas au mode live qui garde son propre mécanisme d'accord
// d'adversaire. -1 si le partenaire (au sens : le reste de son camp) n'a encore rien
// annoncé, ou si ce participant contrôle déjà tout son camp lui-même (aucun partenaire
// distinct — voir échange avec Guillaume, "je jouais E/O" — dans ce cas l'undo n'est
// jamais bloqué par cette règle, seul un adversaire a pu enchérir depuis, ce qui ne compte
// pas).
function findPartnerLastCallIndex(requesterId, history) {
    const mySeats = seatsOfParticipant(requesterId);
    if (mySeats.length === 0) return -1;
    const myPartnerships = new Set(mySeats.map(partnershipOf));
    const partnerSeats = SEATS.filter(seat => myPartnerships.has(partnershipOf(seat)) && !mySeats.includes(seat));
    for (let i = history.length - 1; i >= 0; i--) {
        if (partnerSeats.includes(history[i].seat)) return i;
    }
    return -1;
}

function guestIndexForParticipant(pid) {
    if (!pid || pid === 'host') return null;
    return Object.prototype.hasOwnProperty.call(guestIndexByToken, pid) ? guestIndexByToken[pid] : null;
}

function undoRejectReasonText(reason) {
    switch (reason) {
        case 'declined': return 'Annulation refusée.';
        case 'timeout': return "Personne n'a répondu à temps.";
        case 'busy': return 'Une autre demande est déjà en cours, réessayez.';
        case 'stale': return 'La situation a changé entre-temps, réessayez.';
        case 'nothing': return "Vous n'avez fait aucune annonce à annuler sur cette donne.";
        case 'partner-since': return 'Votre partenaire a annoncé depuis — impossible d\'annuler cette annonce.';
        default: return "Impossible d'annuler pour le moment.";
    }
}

// Envoie `msg` à un participant donné — sans passer par le réseau si ce participant,
// c'est nous (l'hôte est toujours au centre de l'arbitrage, y compris pour lui-même).
function deliverToParticipant(pid, msg) {
    if (pid === myParticipantId) {
        if (msg.type === 'undo-ask') {
            pendingUndoAsk = msg;
            renderUndoAskBanner();
            renderUndoControls();
        } else if (msg.type === 'undo-rejected') {
            clearUndoUiState();
            setUndoStatus(undoRejectReasonText(msg.reason));
        }
        return;
    }
    const gi = guestIndexForParticipant(pid);
    if (gi != null) peerConn.send(msg, gi);
}

function uiRequestUndo() {
    if (!canControlBoard() || !deals || auctionHistory.length === 0) return;
    if (undoRequestPending || pendingUndoAsk) return;

    // R26 — mémoriser l'annonce EXACTE visée au moment du clic. Si le cloud se met à
    // jour pendant l'attente (robot/adversaire, ACK de notre call, etc.), l'Undo doit
    // toujours viser cette annonce-là, jamais une éventuelle annonce ultérieure du même
    // participant.
    const requestedTargetIndex = findUndoTargetIndex(myParticipantId, auctionHistory);
    const requestedTargetEntry = requestedTargetIndex >= 0 ? auctionHistory[requestedTargetIndex] : null;
    const requestedUndoTarget = requestedTargetEntry ? {
        index: requestedTargetIndex,
        seat: requestedTargetEntry.seat,
        call: String(requestedTargetEntry.call || '').toUpperCase()
    } : null;

    const msg = {
        type: 'undo-request',
        boardIndex,
        requesterId: myParticipantId,
        historyLengthAtRequest: auctionHistory.length
    };

    undoRequestPending = true;
    setUndoStatus('');
    renderUndoControls();

    clearTimeout(undoRequestTimeoutId);
    undoRequestTimeoutId = setTimeout(() => {
        if (undoRequestPending) {
            undoRequestPending = false;
            renderUndoControls();
            setUndoStatus("Personne n'a répondu à temps.");
        }
    }, 20000);

    if (myRole === 'host') {
        hostHandleUndoRequest(msg);
    } else {
        // R28 — en différé, le cloud n'est qu'un REPLI. Tant que l'hôte P2P est réellement
        // joignable, l'Undo suit le même chemin court que les annonces : guest -> hôte.
        // On sérialise néanmoins derrière un éventuel PUT participant de la dernière
        // annonce (R26), sinon ce PUT pourrait encore courir après l'Undo et recréer
        // artificiellement l'annonce supprimée côté serveur.
        dispatchGuestUndoRequest(msg, requestedUndoTarget);
    }
}

async function dispatchGuestUndoRequest(msg, requestedUndoTarget = null) {
    if (deferredRoomMode && participantServerCallInFlight) {
        const cloudCtx = currentRoomCode ? captureCloudSyncContext(currentRoomCode) : null;
        const callSettled = await waitForParticipantServerCallBeforeUndo(cloudCtx);
        if (!callSettled || (cloudCtx && !isCloudSyncContextActive(cloudCtx))) {
            pushDebugLog("Undo : la transaction d\'enchère précédente n\'a pas pu être stabilisée avant la demande.");
            clearUndoUiState();
            return;
        }
    }

    if (peerConn && peerConn.isConnected()) {
        recordSyncTrace('undo.route.peer-host', { boardIndex: msg.boardIndex, requesterId: msg.requesterId });
        try {
            peerConn.send(msg);
            return;
        } catch (e) {
            pushDebugLog('Undo : envoi P2P impossible, bascule vers le relais serveur (' + ((e && e.message) || e) + ').');
        }
    }

    // Hôte réellement absent / P2P indisponible : conserver le chemin autonome R26/R27.
    recordSyncTrace('undo.route.cloud-fallback', { boardIndex: msg.boardIndex, requesterId: msg.requesterId });
    await pushUndoViaServerFallback(msg.boardIndex, requestedUndoTarget);
}

// Voir échange avec Guillaume ("l'hôte n'a pas reçu la demande d'undo pendant qu'il était
// hors ligne") : même principe que pushCallViaServerFallback — relit l'état serveur,
// applique la même règle locale que le mode différé (ma propre dernière annonce, tant que
// mon partenaire n'a rien annoncé depuis), tronque l'historique en conséquence, puis
// repousse avec le verrou de version. Contrairement à une annonce, pas d'affichage
// optimiste préalable : on valide contre l'état serveur AVANT de toucher à quoi que ce
// soit localement — une annulation est plus délicate à défaire proprement qu'une simple
// enchère de trop si jamais elle s'avérait invalide entre-temps.
async function pushUndoViaServerFallback(targetBoardIndex = boardIndex, requestedUndoTarget = null) {
    const done = () => { undoRequestPending = false; renderUndoControls(); };

    if (!currentRoomCode || typeof pullSessionState !== 'function' || typeof pushSessionState !== 'function') {
        pushDebugLog('Undo : impossible de tenter le relais serveur (currentRoomCode ou fonctions cloud manquantes).');
        done();
        return;
    }
    pushDebugLog('Undo : tentative de remontée au serveur (déconnecté de l\'hôte).');
    const cloudCtx = captureCloudSyncContext(currentRoomCode);

    try {
        // R26 — cause racine des Undos invités intermittents : uiMakeCall lance le PUT
        // participant de l'enchère de façon asynchrone. Un clic Undo juste après la
        // réponse robot pouvait donc exécuter ce pull AVANT le commit de notre propre
        // annonce et obtenir un snapshot où elle n'existait pas encore. Attendre la fin
        // du guard rend call -> undo strictement séquentiel côté participant.
        if (deferredRoomMode && myRole === 'guest' && participantServerCallInFlight) {
            const callSettled = await waitForParticipantServerCallBeforeUndo(cloudCtx);
            if (!callSettled || !isCloudSyncContextActive(cloudCtx)) {
                pushDebugLog('Undo : attente de confirmation de l\'enchère interrompue ; resynchronisation nécessaire.');
                done();
                return;
            }
        }

        let pulled;
        try {
            pulled = await pullSessionState(cloudCtx.roomCode);
            if (!isCloudSyncContextActive(cloudCtx)) { done(); return; }
            if (pulled) pulled = validateCloudSnapshot(pulled, cloudCtx.roomCode);
        } catch (e) {
            pushDebugLog('Undo : lecture serveur impossible (' + ((e && e.message) || e) + ').');
            done();
            return;
        }
        if (!pulled) { done(); return; }

        const idx = Number.isInteger(targetBoardIndex) ? targetBoardIndex : boardIndex;
        const initialDeals = pulled.state && pulled.state.deals;
        if (!initialDeals || !initialDeals[idx]) {
            pushDebugLog(`Undo abandonné : donne ${idx} introuvable dans l'état serveur relu.`);
            done();
            return;
        }
        let initialHistory = cloneCloudData(initialDeals[idx].auctionHistory || []);
        let targetIndex = findUndoTargetIndex(myParticipantId, initialHistory);
        let partnerIndex = findPartnerLastCallIndex(myParticipantId, initialHistory);

        const requestedTargetMatches = () => {
            if (!requestedUndoTarget) return targetIndex >= 0;
            if (targetIndex !== requestedUndoTarget.index || targetIndex < 0) return false;
            const entry = initialHistory[targetIndex];
            return !!entry
                && entry.seat === requestedUndoTarget.seat
                && String(entry.call || '').toUpperCase() === requestedUndoTarget.call;
        };

        // R26 — filet de convergence : même après la fin du guard, un fetch/Pusher déjà
        // lancé peut nous remettre une vue très légèrement antérieure. Ne jamais conclure
        // « rien à annuler » au PREMIER pull si l'annonce visée existe encore localement.
        // On effectue au maximum trois relectures courtes ; aucune écriture n'est faite
        // pendant cette attente.
        if (requestedUndoTarget && !requestedTargetMatches()) {
            for (let retry = 0; retry < 3 && isCloudSyncContextActive(cloudCtx); retry++) {
                await new Promise(resolve => setTimeout(resolve, 120 * (retry + 1)));
                let refreshed = null;
                try {
                    refreshed = await pullSessionState(cloudCtx.roomCode);
                    if (refreshed) refreshed = validateCloudSnapshot(refreshed, cloudCtx.roomCode);
                } catch (_) {}
                if (!refreshed) continue;
                pulled = refreshed;
                const refreshedDeals = pulled.state && pulled.state.deals;
                if (!refreshedDeals || !refreshedDeals[idx]) continue;
                initialHistory = cloneCloudData(refreshedDeals[idx].auctionHistory || []);
                targetIndex = findUndoTargetIndex(myParticipantId, initialHistory);
                partnerIndex = findPartnerLastCallIndex(myParticipantId, initialHistory);
                if (requestedTargetMatches()) break;
            }
        }

        if (targetIndex < 0 || targetIndex <= partnerIndex || !requestedTargetMatches()) {
            const reason = targetIndex >= 0 && targetIndex <= partnerIndex ? 'partner-since' : 'nothing';
            pushDebugLog('Undo abandonné : plus valide par rapport à l\'état serveur relu (annonce visée absente, ou partenaire ayant annoncé depuis) — resynchronisation.');
            setUndoStatus(undoRejectReasonText(reason));
            applyCloudUpdate(pulled, { expectedRoomCode: cloudCtx.roomCode });
            done();
            return;
        }
        const desiredHistory = cloneCloudData(initialHistory.slice(0, targetIndex));
        // Identité de l'enchère que l'utilisateur a demandé à annuler. Les conflits CAS
        // pourront ajouter des annonces adverses/robots APRÈS cette entrée, mais ne doivent
        // ni réécrire le préfixe ni faire apparaître une nouvelle annonce du demandeur.
        const targetPrefix = cloneCloudData(initialHistory.slice(0, targetIndex + 1));
        let authoritative = pulled;
        const maxConflictRebases = 3;

        for (let conflictAttempt = 0; conflictAttempt <= maxConflictRebases; conflictAttempt++) {
            const baseState = cloneCloudData(authoritative.state);
            const boardDeals = baseState && baseState.deals;
            if (!boardDeals || !boardDeals[idx]) {
                pushDebugLog(`Undo abandonné : donne ${idx} absente après conflit.`);
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                done();
                return;
            }
            if (!boardDeals[idx].auctionHistory) boardDeals[idx].auctionHistory = [];
            const hist = boardDeals[idx].auctionHistory;

            // Idempotence : si l'undo a déjà été commité (ou qu'un autre undo a raccourci
            // encore davantage le même préfixe), l'objectif est atteint. Ne jamais
            // ressusciter des annonces pour obtenir exactement notre longueur d'origine.
            const currentIsAtLeastAsUndone = hist.length <= desiredHistory.length
                && sameCloudData(desiredHistory.slice(0, hist.length), hist);
            if (currentIsAtLeastAsUndone) {
                lastKnownCloudVersion = authoritative.version;
                cloudLastSyncedState = cloneCloudData(authoritative.state);
                // R26 — un Undo explicite doit primer sur la garde anti-clignotement R15.
                // Sinon la garde de la dernière call optimiste peut conserver localement
                // le suffixe que le serveur vient précisément d'annuler.
                clearDeferredOptimisticAuctionGuard(idx, null, null, 'server-undo-already-committed');
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                recordSyncTrace('undo.cloud-fallback.already-committed', { targetBoardIndex: idx, version: authoritative.version });
                done();
                return;
            }

            // R25 — un conflit sur CETTE donne n'est plus automatiquement stale. On
            // accepte toute extension qui conserve exactement le préfixe jusqu'à MA
            // dernière annonce et dans laquelle mon partenaire n'a toujours pas parlé
            // depuis. Cela couvre précisément une réponse robot/adverse arrivée pendant
            // le PUT. En revanche partenaire, nouvelle annonce du demandeur ou réécriture
            // du préfixe => fail-closed.
            const currentTargetIndex = findUndoTargetIndex(myParticipantId, hist);
            const currentPartnerIndex = findPartnerLastCallIndex(myParticipantId, hist);
            const sameTargetPrefix = hist.length >= targetPrefix.length
                && sameCloudData(hist.slice(0, targetPrefix.length), targetPrefix);
            if (currentTargetIndex !== targetIndex || currentPartnerIndex >= targetIndex || !sameTargetPrefix) {
                const reason = currentTargetIndex >= 0 && currentPartnerIndex >= currentTargetIndex ? 'partner-since' : 'stale';
                recordSyncTrace('undo.cloud-fallback.same-board-conflict', { targetBoardIndex: idx, version: authoritative.version, reason });
                pushDebugLog(`Undo abandonné : la donne ${idx} a changé de façon incompatible (${reason}) — resynchronisation sans réécriture.`);
                if (reason === 'partner-since') setUndoStatus(undoRejectReasonText('partner-since'));
                applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                done();
                return;
            }

            hist.length = targetIndex;
            const stateToPush = { ...baseState, savedAt: Date.now() };
            let conflictCurrent = null;
            const result = await pushSessionState(cloudCtx.roomCode, stateToPush, authoritative.version, {
                participantCredential: participantCredentialForCloudWrite(),
                onConflict: (current) => {
                    if (!isCloudSyncContextActive(cloudCtx)) return;
                    const validCurrent = current && validateCloudSnapshot(current, cloudCtx.roomCode);
                    if (validCurrent) {
                        conflictCurrent = validCurrent;
                        lastKnownCloudVersion = validCurrent.version;
                        cloudLastSyncedState = cloneCloudData(validCurrent.state);
                    }
                    recordSyncTrace('undo.cloud-fallback.conflict', { targetBoardIndex: idx, version: validCurrent && validCurrent.version, attempt: conflictAttempt + 1 });
                }
            });
            if (!isCloudSyncContextActive(cloudCtx)) { done(); return; }

            if (result) {
                lastKnownCloudVersion = result.version;
                cloudLastSyncedState = cloneCloudData(result.state || stateToPush);
                if (result.state) {
                    const restricted = validateCloudSnapshot({ version: result.version, updatedAt: result.updatedAt, state: result.state }, cloudCtx.roomCode);
                    if (restricted) {
                        // R26 — même règle que pour `undo-apply` P2P : une réduction
                        // explicitement demandée ne doit JAMAIS être neutralisée par la
                        // garde optimiste d'une ancienne call.
                        clearDeferredOptimisticAuctionGuard(idx, null, null, 'server-undo-success');
                        applyCloudUpdate(restricted, { expectedRoomCode: cloudCtx.roomCode });
                    }
                } else if (idx === boardIndex) {
                    auctionHistory.length = targetIndex;
                    renderAuctionLedger();
                    renderBiddingBox();
                    renderMyHands();
                    checkAuctionEnd();
                }
                recordSyncTrace('undo.cloud-fallback.success', { targetBoardIndex: idx, version: result.version, conflictRebases: conflictAttempt });
                pushDebugLog(`Undo remonté au serveur avec succès (version ${result.version}).`);
                done();
                return;
            }

            if (conflictCurrent && conflictAttempt < maxConflictRebases) {
                authoritative = conflictCurrent;
                recordSyncTrace('undo.cloud-fallback.rebase', { targetBoardIndex: idx, version: conflictCurrent.version, attempt: conflictAttempt + 1 });
                continue;
            }
            if (conflictCurrent) applyCloudUpdate(conflictCurrent, { expectedRoomCode: cloudCtx.roomCode });
            pushDebugLog('Undo : trop de conflits successifs, resynchronisation sans forcer l\'écriture.');
            done();
            return;
        }
    } catch (e) {
        pushDebugLog('Undo : échec inattendu de la remontée serveur — ' + ((e && (e.message || e.stack)) || e));
    } finally {
        // `done` est idempotent visuellement ; les retours de succès l'appellent déjà pour
        // rendre immédiatement les contrôles, et ce filet couvre toute exception imprévue.
        done();
    }
}

// (Hôte) Reçoit une demande d'annulation — la sienne, ou celle d'un invité relayée par
// handlePeerData — et décide si elle nécessite l'accord d'un adversaire humain.
function hostHandleUndoRequest(msg) {
    if (hostPendingUndo) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'busy' });
        return;
    }

    const targetBoardIndex = Number(msg.boardIndex);
    if (!deals || !Number.isInteger(targetBoardIndex) || targetBoardIndex < 0 || targetBoardIndex >= deals.length || !deals[targetBoardIndex]) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'stale' });
        return;
    }

    // R28 — le mode différé est BOARD-LOCAL. L'hôte peut regarder la donne 7 pendant que
    // Nord travaille sur la donne 3 : la demande porte sur deals[msg.boardIndex] et ne doit
    // jamais être rejetée au seul motif que boardIndex (vue locale hôte) est différent.
    // En live, au contraire, la donne reste partagée et l'ancienne garde est conservée.
    const isDeferredPersonalUndo = deferredRoomMode === true;
    if (!isDeferredPersonalUndo && targetBoardIndex !== boardIndex) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'stale' });
        return;
    }

    const targetDeal = deals[targetBoardIndex];
    if (!Array.isArray(targetDeal.auctionHistory)) targetDeal.auctionHistory = [];
    const targetHistory = isDeferredPersonalUndo ? targetDeal.auctionHistory : auctionHistory;

    // R25 — en différé, la longueur brute de l'historique n'est PAS un critère de
    // validité. Entre le clic du joueur et le traitement de l'Undo, un adversaire/robot
    // peut parfaitement avoir annoncé. La seule règle métier est : ma dernière annonce
    // existe encore et mon partenaire n'a rien annoncé après elle.
    if (!isDeferredPersonalUndo && msg.historyLengthAtRequest !== targetHistory.length) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'stale' });
        return;
    }

    const isHostDirectUndo = msg.requesterId === 'host' || msg.requesterId === roomCreatorToken;
    const targetIndex = isDeferredPersonalUndo
        ? findUndoTargetIndex(msg.requesterId, targetHistory)
        : (isHostDirectUndo ? findHostUndoTargetIndex(targetHistory) : findUndoTargetIndex(msg.requesterId, targetHistory));
    if (targetIndex < 0) {
        deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'nothing' });
        return;
    }

    if (isDeferredPersonalUndo) {
        const partnerIdx = findPartnerLastCallIndex(msg.requesterId, targetHistory);
        if (targetIndex <= partnerIdx) {
            deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'partner-since' });
            return;
        }
        applyUndoAsHost({
            boardIndex: targetBoardIndex,
            requesterId: msg.requesterId,
            historyLengthAtRequest: msg.historyLengthAtRequest,
            targetIndex,
            deferredPersonalUndo: true
        });
        return;
    }

    // Mode live : comportement historique conservé. L'hôte peut annuler directement la
    // dernière annonce humaine ; un autre joueur demande l'arbitrage de l'hôte.
    if (isHostDirectUndo) {
        applyUndoAsHost({ boardIndex: targetBoardIndex, requesterId: msg.requesterId, historyLengthAtRequest: msg.historyLengthAtRequest, targetIndex });
        return;
    }

    // Repli historique NullPeerConnection hors différé : règle personnelle locale.
    if (peerConn instanceof NullPeerConnection) {
        const partnerIdx = findPartnerLastCallIndex(msg.requesterId, targetHistory);
        if (targetIndex <= partnerIdx) {
            deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: msg.boardIndex, requesterId: msg.requesterId, reason: 'partner-since' });
            return;
        }
        applyUndoAsHost({ boardIndex: targetBoardIndex, requesterId: msg.requesterId, historyLengthAtRequest: msg.historyLengthAtRequest, targetIndex });
        return;
    }

    pendingUndoAsk = { requesterId: msg.requesterId, boardIndex: targetBoardIndex, historyLengthAtRequest: msg.historyLengthAtRequest };
    hostPendingUndo = { requesterId: msg.requesterId, boardIndex: targetBoardIndex, historyLengthAtRequest: msg.historyLengthAtRequest, targetIndex };
    renderUndoAskBanner();

    setTimeout(() => {
        if (hostPendingUndo &&
            hostPendingUndo.requesterId === msg.requesterId &&
            hostPendingUndo.boardIndex === targetBoardIndex &&
            hostPendingUndo.historyLengthAtRequest === msg.historyLengthAtRequest) {
            hostPendingUndo = null;
            pendingUndoAsk = null;
            renderUndoAskBanner();
            deliverToParticipant(msg.requesterId, { type: 'undo-rejected', boardIndex: targetBoardIndex, requesterId: msg.requesterId, reason: 'timeout' });
        }
    }, 20000);
}

// (Hôte) Reçoit la réponse (accepté/refusé) d'un adversaire — la sienne, ou celle d'un
// invité relayée par handlePeerData. Seule la première réponse compte.
function hostReceiveUndoAnswer(msg) {
    if (!hostPendingUndo) return;
    if (msg.boardIndex !== hostPendingUndo.boardIndex || msg.historyLengthAtRequest !== hostPendingUndo.historyLengthAtRequest) return;

    const resolved = hostPendingUndo;
    hostPendingUndo = null;

    if (msg.approved) {
        applyUndoAsHost(resolved);
    } else {
        deliverToParticipant(resolved.requesterId, { type: 'undo-rejected', boardIndex: resolved.boardIndex, requesterId: resolved.requesterId, reason: 'declined' });
    }
}

// (Hôte) Applique effectivement l'annulation et la diffuse à tout le monde.
function applyUndoAsHost(pending) {
    const targetBoardIndex = Number(pending.boardIndex);
    if (!deals || !Number.isInteger(targetBoardIndex) || targetBoardIndex < 0 || targetBoardIndex >= deals.length || !deals[targetBoardIndex]) {
        deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: pending.boardIndex, requesterId: pending.requesterId, reason: 'stale' });
        return;
    }

    const isDeferredBoardLocalUndo = pending.deferredPersonalUndo || deferredRoomMode === true;
    if (!isDeferredBoardLocalUndo && targetBoardIndex !== boardIndex) {
        deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: pending.boardIndex, requesterId: pending.requesterId, reason: 'stale' });
        return;
    }

    const targetDeal = deals[targetBoardIndex];
    if (!Array.isArray(targetDeal.auctionHistory)) targetDeal.auctionHistory = [];
    const targetHistory = isDeferredBoardLocalUndo ? targetDeal.auctionHistory : auctionHistory;

    let targetIndex = pending.targetIndex;
    if (isDeferredBoardLocalUndo) {
        // R25 + R28 — revalide au DERNIER moment sur la DONNE CIBLE, pas sur la vue de
        // l'hôte. Un robot/adversaire intercalé reste autorisé ; le partenaire bloque.
        targetIndex = findUndoTargetIndex(pending.requesterId, targetHistory);
        const partnerIdx = findPartnerLastCallIndex(pending.requesterId, targetHistory);
        if (targetIndex < 0) {
            deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: targetBoardIndex, requesterId: pending.requesterId, reason: 'nothing' });
            return;
        }
        if (targetIndex <= partnerIdx) {
            deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: targetBoardIndex, requesterId: pending.requesterId, reason: 'partner-since' });
            return;
        }
    } else if (pending.historyLengthAtRequest !== targetHistory.length) {
        deliverToParticipant(pending.requesterId, { type: 'undo-rejected', boardIndex: targetBoardIndex, requesterId: pending.requesterId, reason: 'stale' });
        return;
    }

    // Retire l'annonce ciblée et TOUT le suffixe qui l'a suivie. En différé ce suffixe
    // peut contenir des annonces adverses/robots : c'est volontaire, puisque l'enchère
    // corrigée change le contexte dans lequel elles avaient été produites.
    targetHistory.length = targetIndex;

    // Ne jamais déplacer/rerendre la donne que l'hôte est en train de regarder. Si l'Undo
    // concerne sa donne courante, la globale auctionHistory reste la même référence et on
    // met l'UI à jour ; sinon seule la donnée hors-écran est modifiée.
    if (targetBoardIndex === boardIndex) {
        auctionHistory = targetHistory;
        renderAuctionLedger();
        renderBiddingBox();
        renderMyHands();
        checkAuctionEnd();
        if (pending.requesterId === myParticipantId || !deferredRoomMode) clearUndoUiState();
        maybeRobotBid();
    } else {
        const overview = document.getElementById('boardOverviewModal');
        if (overview && overview.style.display !== 'none') renderBoardOverview();
    }

    peerConn.send({ type: 'undo-apply', boardIndex: targetBoardIndex, newLength: targetIndex });
    saveHostGameStateToStorage();
}

// Réponse de l'utilisateur au bandeau "on me demande d'annuler".
function uiAnswerUndo(approved) {
    const ask = pendingUndoAsk;
    if (!ask) return;
    pendingUndoAsk = null;
    renderUndoAskBanner();
    renderUndoControls();

    const answerMsg = {
        type: 'undo-answer',
        boardIndex: ask.boardIndex,
        requesterId: ask.requesterId,
        historyLengthAtRequest: ask.historyLengthAtRequest,
        approved
    };

    if (myRole === 'host') {
        hostReceiveUndoAnswer(answerMsg);
    } else {
        peerConn.send(answerMsg);
    }
}

// Réservé au VRAI créateur (le bouton lui-même est déjà masqué pour tout autre rôle, voir
// updateBoardControlVisibility, mais on se protège quand même ici en cas d'appel direct —
// voir échange avec Guillaume, "en mode différé, l'invité ne devrait pas avoir
// recommencer l'enchère").
function uiAllPass() {
    if (!isTrueOriginalHost() || !deals || isAuctionOver(auctionHistory) || allPassInProgress) return;

    allPassInProgress = true;
    showParDuringAuction = false;
    try {
        const deal = currentDeal();
        let safety = 0;
        while (!isAuctionOver(auctionHistory) && safety < 4) {
            const seat = currentTurnSeat(deal.dealer, auctionHistory);
            if (!isCallLegal(auctionHistory, 'PASS', seat)) break;
            auctionHistory.push({ seat, call: 'PASS' });
            if (peerConn) peerConn.send({ type: 'call', boardIndex, seat, call: 'PASS' });
            safety++;
        }
    } finally {
        allPassInProgress = false;
    }

    renderAuctionLedger();
    renderBiddingBox();
    renderMyHands();
    checkAuctionEnd();
    renderUndoControls();
    updateBoardControlVisibility();
    saveHostGameStateToStorage();
}

function uiResetAuction() {
    if (!isTrueOriginalHost() || !canControlBoard()) return;
    showParDuringAuction = false;
    auctionHistory = [];
    deals[boardIndex].auctionHistory = auctionHistory; // reste la référence partagée
    hostPendingUndo = null;
    clearUndoUiState();
    renderAuctionLedger();
    renderBiddingBox();
    renderMyHands();
    checkAuctionEnd();
    peerConn.send({ type: 'reset-auction', boardIndex });
    // Voir échange avec Guillaume ("vérifie s'il n'y a pas des problèmes de même ordre") :
    // même oubli qu'applyUndoAsHost — sans ça, un invité en repli serveur ne voyait
    // jamais qu'une enchère venait d'être recommencée.
    saveHostGameStateToStorage();
    maybeRobotBid(); // sans effet si on n'est pas l'hôte (voir maybeRobotBid) ; utile si le
                      // dealer (ou tout siège en tête d'enchère après reset) est un robot
}

// Change de donne : restaure l'enchère déjà jouée sur cette donne si on y était déjà
// passé (voir échange avec Guillaume — l'historique vit maintenant sur la donne
// elle-même, deals[i].auctionHistory, pas dans une simple variable de travail écrasée à
// chaque navigation), sinon en démarre une neuve. `auctionHistory` devient une RÉFÉRENCE
// vers ce tableau : tout push/pop ultérieur (voir applyCall, l'undo) se répercute
// automatiquement dessus, sans synchronisation supplémentaire à faire. Annule toute
// demande d'undo en cours, et diffuse le nouvel index à tout le monde. Partagé par le
// bouton "Donne suivante →" (réservé à l'hôte, voir échange avec Guillaume — session du 23
// juillet, uniquement une fois l'enchère terminée, voir checkAuctionEnd) et par les
// flèches ◀▶ de navigation libre, également réservées à l'hôte.
function gotoBoard(newIndex) {
    showParDuringAuction = false;

    // Cas rare mais important : l'hôte saute vers une donne future avant que le scheduler
    // de lancement legacy ne l'ait préparée. On ne change pas la sémantique historique :
    // cette seule donne est avancée immédiatement jusqu'au prochain tour humain. Le coût
    // éventuel est localisé à ce saut volontaire, au lieu de bloquer toutes les donnes au
    // lancement. PONS/WASM reste sur son chemin asynchrone habituel.
    if (!window.PonsEngine && deals && deals[newIndex]) {
        advanceRobotBidsOnBoard(newIndex);
    }

    boardIndex = newIndex;
    if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
    auctionHistory = deals[boardIndex].auctionHistory;
    hostPendingUndo = null;
    clearUndoUiState();
    renderBoard();
    // Le boardIndex est une vue LOCALE en différé : deux partenaires peuvent travailler
    // sur des donnes différentes. En live seulement, l'hôte continue de déplacer toute la
    // table par P2P comme historiquement.
    if (!deferredRoomMode && peerConn) {
        peerConn.send({
            type: 'goto-board',
            boardIndex,
            auctionHistory: cloneAuctionHistoryForWire(auctionHistory)
        });
    }
    if (myRole === 'host') saveHostGameStateToStorage();
}

// Navigation depuis le bouton « Donne suivante → » du bloc final/PAR.
//
// Ce bouton est utilisé quand l'utilisateur se trouve naturellement très bas dans une
// donne terminée. La donne suivante est souvent beaucoup plus courte : Safari/Chrome
// conservent alors l'ancien scroll autant que possible et le clampent au nouveau bas de
// page — ce qui peut faire atterrir directement sur le chat.
//
// Les flèches ◀▶ du haut n'ont pas ce problème et restent volontairement inchangées.
// Ici seulement, après le rendu COMPLET de la nouvelle donne, on replace la zone utile
// (options des mains + mains + relevé) juste sous la barre de connexion fixe.
// Double requestAnimationFrame : le premier laisse renderBoard poser la nouvelle
// géométrie, le second intervient après le recalage de scroll natif du navigateur.
function positionNextBoardAfterParNavigation() {
    if (window.innerWidth > 760) return;

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            if (!deals) return;

            const target = document.querySelector('#screen-game .hand-display-options')
                || document.querySelector('#screen-game .game-content-row');
            if (!target || !target.isConnected) return;

            const connectionBar = document.getElementById('connectionBar');
            let desiredTop = 8;
            if (connectionBar && getComputedStyle(connectionBar).display !== 'none') {
                const barRect = connectionBar.getBoundingClientRect();
                desiredTop = Math.max(desiredTop, barRect.bottom + 8);
            }

            const delta = target.getBoundingClientRect().top - desiredTop;
            if (Math.abs(delta) > 0.5) {
                window.scrollBy({ top: delta, left: 0, behavior: 'auto' });
            }
        });
    });
}

function uiNextBoard() {
    if (!canNavigateBoards()) return;
    if (boardIndex >= deals.length - 1) return;
    gotoBoard(boardIndex + 1);
    fadeBoardNavigationTargets();
    positionNextBoardAfterParNavigation();
}

// Navigation libre entre les donnes (avancer ou reculer, y compris en pleine enchère) :
// live = hôte seul ; différé = navigation locale de chaque joueur assis.
function uiHostSkipNextBoard() {
    if (!canNavigateBoards() || !deals) return;
    if (boardIndex >= deals.length - 1) return;
    gotoBoard(boardIndex + 1);
    fadeBoardNavigationTargets();
}

function uiHostSkipPrevBoard() {
    if (!canNavigateBoards() || !deals) return;
    if (boardIndex <= 0) return;
    gotoBoard(boardIndex - 1);
    fadeBoardNavigationTargets();
}

// Voir échange avec Guillaume (session asynchrone à deux — "écran récapitulatif de toutes
// les donnes") : statut de chaque donne en un coup d'œil, sans avoir à les parcourir une
// par une. Accessible à tout le monde en lecture ; la navigation suit canNavigateBoards()
// (live = hôte seul, différé = joueur assis en local).
// Voir échange avec Guillaume (session du 8 août — nouvelle vue d'ensemble) : quel siège
// afficher pour un joueur qui n'occupe qu'UNE place normalement — mais qui peut en
// occuper deux (ex. un robot remplacé temporairement). Dans ce cas, celui qui doit
// effectivement enchérir sur CETTE donne précise prime ; hors de son tour (ou enchère
// terminée), repli sur le premier de ses sièges.
function myEffectiveSeatForDeal(deal) {
    if (!mySeats || mySeats.length === 0) return null;
    if (mySeats.length === 1) return mySeats[0];
    const hist = deal.auctionHistory || [];
    if (!isAuctionOver(hist)) {
        const turnSeat = currentTurnSeat(deal.dealer, hist);
        if (mySeats.includes(turnSeat)) return turnSeat;
    }
    return mySeats[0];
}

// Voir échange avec Guillaume ("l'app calcule le PAR même si le PBN ne le contient
// pas") : dérive le contrat PAR (approximatif — le meilleur contrat réalisable du camp
// qui peut scorer le plus, pas un vrai calcul de PAR tournoi avec sacrifices) à partir
// de la table du double mort déjà calculée pour cette donne (voir kickOffBackgroundDD),
// en réutilisant computeDDScores tel quel plutôt que dupliquer sa logique. Renvoie null
// tant que la table n'est pas encore prête (calcul en tâche de fond, voir missingDD).
function getParContractCell(ddTable, dealVulnerable, preferredStrain) {
    if (!ddTable) return null;
    const { info, sideSummary } = computeDDScores(ddTable, dealVulnerable);
    const nsScore = sideSummary.NS.bestScore;
    const ewScore = sideSummary.EW.bestScore;
    if (nsScore === null && ewScore === null) return null; // aucun camp ne fait le moindre pli au-dessus de 6, rarissime
    const winningSide = (nsScore ?? -Infinity) >= (ewScore ?? -Infinity) ? 'NS' : 'EW';
    const summary = sideSummary[winningSide];
    const sidePositions = winningSide === 'NS' ? ['N', 'S'] : ['E', 'W'];
    // Voir échange avec Guillaume ("il y a 5♠ et 5♥, comme on est arrivé au contrat de
    // 4♥, le PAR affiché devrait être 5♥ plutôt que 5♠") : quand plusieurs couleurs sont
    // À ÉGALITÉ pour le meilleur palier, celle réellement jouée en séquence prime sur
    // l'ordre arbitraire de STRAIN_ORDER — plus parlant pour le joueur qui compare son
    // résultat au PAR. On collecte donc TOUTES les couleurs à égalité avant de choisir,
    // au lieu de s'arrêter à la première trouvée.
    const tiedStrains = [];
    for (const strain of STRAIN_ORDER) {
        const matchingPositions = sidePositions.filter(pos => {
            const cell = info[strain][pos];
            return cell.tier === summary.activeTier && cell.score === summary.bestScore;
        });
        if (matchingPositions.length > 0) tiedStrains.push({ strain, matchingPositions });
    }
    if (tiedStrains.length === 0) return null;
    const chosen = (preferredStrain && tiedStrains.find(t => t.strain === preferredStrain)) || tiedStrains[0];
    const level = ddTable[chosen.strain][chosen.matchingPositions[0]] - 6;
    const declarer = chosen.matchingPositions.length === sidePositions.length ? winningSide : chosen.matchingPositions[0];
    return { strain: chosen.strain, level, declarer };
}

// Petit badge de contrat réutilisable (même classe .call-suit que partout ailleurs dans
// l'appli — relevé d'enchères, contrat final, table du double mort — pour rester
// visuellement cohérent) : palier + couleur colorée, plus le déclarant en toutes
// lettres à côté si fourni.
function contractBadgeHtml(strain, level, declarerSeat, doubled) {
    const strainCls = SUIT_CLASSES[strain] || 'notrump';
    const strainLabel = formatStrainLabel(strain);
    const declarerHtml = declarerSeat ? ` <span class="board-overview-declarer">${declarerSeat}</span>` : '';
    return `<span class="call-suit ${strainCls}">${level}${strainLabel}${doubled || ''}</span>${declarerHtml}`;
}

// Main compacte sur une seule ligne (♠JT6 ♥T6 ♦KT932 ♣K32), pour tenir dans une ligne de
// liste — contrairement à dealPreviewHandCardHtml (carte empilée, trop haute ici).
// Voir échange avec Guillaume ("le nombre de points, légèrement à droite des cartes") :
// badge HCP ajouté après les 4 couleurs, "XXH" en italique — même info que le badge HCP
// des autres vues (renderMyHands/buildAllHandsHtml), format condensé pour tenir sur une
// seule ligne ici plutôt que "XX HCP" comme ailleurs.
function compactHandHtml(hand) {
    if (!hand) return '<span class="board-overview-hand-empty">—</span>';
    return ['S', 'H', 'D', 'C'].map(suit =>
        `<span class="board-overview-hand-suit">${suitIconHtml(suit)}${formatRanksForDisplay(hand[suit]) || '—'}</span>`
    ).join('');
}

function compactHandHcpText(hand) {
    if (!hand) return '—';
    return `${computeHandHcp(hand)}H`;
}

function renderBoardOverview() {
    const listEl = document.getElementById('boardOverviewList');
    if (!listEl || !deals) return;
    listEl.innerHTML = deals.map((deal, idx) => {
        const hist = deal.auctionHistory || [];
        const mySeat = myEffectiveSeatForDeal(deal);
        const hand = mySeat ? deal.hands[mySeat] : null;
        const handHtml = compactHandHtml(hand);
        const handHcpText = compactHandHcpText(hand);
        const auctionOver = isAuctionOver(hist);

        let reachedHtml;
        let titleAttr = '';
        let reachedContract = null;
        if (auctionOver) {
            if (isPassedOut(hist)) {
                reachedHtml = '<span class="board-overview-status is-done">Passé</span>';
            } else {
                reachedContract = determineContract(hist);
                reachedHtml = contractBadgeHtml(reachedContract.strain, reachedContract.level, reachedContract.declarer, reachedContract.doubled);
            }
        } else {
            // Voir échange avec Guillaume ("le point d'interrogation... doit être en
            // rouge si le joueur concerné est celui dont on attend l'enchère pour
            // continuer") : même logique que la donne n'ait pas encore commencé (le
            // donneur doit ouvrir) ou soit déjà en cours — dans les 2 cas, quelqu'un
            // doit agir, et le "?" devient rouge précisément si c'est MOI (un de mes
            // sièges) qu'on attend.
            const turnSeat = currentTurnSeat(deal.dealer, hist);
            const isMyTurnHere = mySeats && mySeats.includes(turnSeat);
            const occupantId = seatAssignment[turnSeat];
            const occupantLabel = !occupantId
                ? 'un robot'
                : (occupantId === SEAT_PENDING ? 'un partenaire pas encore arrivé' : participantName(occupantId));
            reachedHtml = `<span class="board-overview-status ${isMyTurnHere ? 'needs-me' : 'is-waiting'}">?</span>`;
            titleAttr = hist.length === 0
                ? (isMyTurnHere ? 'À vous d\'ouvrir' : `En attente de ${seatFullName(turnSeat)} (${occupantLabel})`)
                : (isMyTurnHere ? 'À vous d\'enchérir' : `En attente de ${seatFullName(turnSeat)} (${occupantLabel})`);
        }

        // Voir échange avec Guillaume ("le PAR ne doit apparaître que si la séquence
        // d'enchère est finie") : masqué tant que l'enchère n'est pas terminée, plutôt
        // que de révéler par avance ce qui serait un bon résultat.
        let parHtml = '<span class="board-overview-status is-pending">—</span>';
        if (auctionOver) {
            const reachedStrainForPar = reachedContract ? (reachedContract.strain === 'NT' ? 'N' : reachedContract.strain) : null;
            const parCell = getParContractCell(deal.ddTable, deal.vulnerable, reachedStrainForPar);
            if (parCell) {
                parHtml = contractBadgeHtml(parCell.strain, parCell.level, parCell.declarer);
            } else if (deal.par && deal.par.contract) {
                // Repli sur le résumé PBN préformaté (voir dealPreviewParText) si la
                // table complète n'est pas dispo mais qu'un PAR direct l'était à l'import.
                parHtml = `<span class="board-overview-status">${escapeHtml(deal.par.contract)}${deal.par.declarer ? ' ' + escapeHtml(deal.par.declarer) : ''}</span>`;
            }
        }

        const activeClass = idx === boardIndex ? ' is-current' : '';
        return `
            <button type="button" class="board-overview-row${activeClass}" data-ui-click="jump-board" data-board-index="${idx}"${titleAttr ? ` title="${escapeHtml(titleAttr)}"` : ''}>
                <span class="board-overview-number">${deal.board != null ? deal.board : idx + 1}</span>
                <span class="board-overview-hand">${handHtml}</span>
                <span class="board-overview-hcp">${handHcpText}</span>
                <span class="board-overview-contract">${reachedHtml}</span>
                <span class="board-overview-par">${parHtml}</span>
            </button>
        `;
    }).join('');

    // Si la modale est déjà ouverte (mise à jour réseau/enchère pendant qu'on la
    // consulte), recalculer le léger ajustement typographique mobile après le rendu.
    const overviewModal = document.getElementById('boardOverviewModal');
    if (overviewModal && overviewModal.style.display !== 'none') {
        requestAnimationFrame(fitBoardOverviewMobileRows);
    }
}

// Vue d'ensemble mobile : les quatre couleurs, le contrat atteint et le PAR doivent
// rester sur UNE seule ligne. Le CSS récupère d'abord un maximum de largeur (marges et
// gaps réduits) ; cette passe ne réduit la police de la main que si une main donnée est
// encore réellement trop large. On ne touche jamais au desktop ni aux colonnes contrat/PAR.
function fitBoardOverviewMobileRows() {
    if (!window.matchMedia || !window.matchMedia('(max-width: 1024px), ((hover: none) and (pointer: coarse) and (max-width: 1366px))').matches) return;
    const modal = document.getElementById('boardOverviewModal');
    if (!modal || modal.style.display === 'none') return;

    const hands = Array.from(modal.querySelectorAll('.board-overview-hand'));
    if (!hands.length) return;

    // Repartir de la taille CSS normale avant chaque mesure (rotation du téléphone,
    // changement de largeur, nouveau rendu de la liste, etc.).
    hands.forEach(hand => { hand.style.fontSize = ''; });

    // La mesure doit se faire après le reset ci-dessus pour ne pas conserver une petite
    // taille calculée pour une orientation précédente.
    hands.forEach(hand => {
        const available = hand.clientWidth;
        const required = hand.scrollWidth;
        if (!available || required <= available + 1) return;

        const basePx = parseFloat(getComputedStyle(hand).fontSize) || 12;
        // Petite marge (0,97) contre les arrondis sub-pixel WebKit. 9px reste lisible et
        // suffit largement pour une main de bridge de 13 cartes sur les iPhone étroits.
        const fittedPx = Math.max(9, basePx * (available / required) * 0.97);
        hand.style.fontSize = `${fittedPx.toFixed(2)}px`;
    });
}

let boardOverviewFitResizeRaf = null;
window.addEventListener('resize', () => {
    const modal = document.getElementById('boardOverviewModal');
    if (!modal || modal.style.display === 'none') return;
    if (boardOverviewFitResizeRaf) cancelAnimationFrame(boardOverviewFitResizeRaf);
    boardOverviewFitResizeRaf = requestAnimationFrame(() => {
        boardOverviewFitResizeRaf = null;
        fitBoardOverviewMobileRows();
    });
});

function uiOpenBoardOverview() {
    if (!deals) return;
    renderBoardOverview();
    const modal = document.getElementById('boardOverviewModal');
    if (!modal) return;
    modal.style.display = 'flex';
    requestAnimationFrame(fitBoardOverviewMobileRows);
    activateAccessibleModal(modal, { closeOnEscape: uiCloseBoardOverview });
}

function uiCloseBoardOverview() {
    const modal = document.getElementById('boardOverviewModal');
    if (!modal) return;
    modal.style.display = 'none';
    deactivateAccessibleModal(modal);
}

function uiCloseBoardOverviewOnBackdrop(evt) {
    if (evt.target.id === 'boardOverviewModal') uiCloseBoardOverview();
}

function uiJumpToBoardFromOverview(idx) {
    uiCloseBoardOverview();
    // Même règle que les flèches ◀▶ existantes : live = hôte seul ; différé = chaque
    // joueur assis navigue localement, sans déplacer le partenaire.
    if (!canNavigateBoards()) return;
    if (idx === boardIndex) return;
    gotoBoard(idx);
}

// Voir échange avec Guillaume (session asynchrone à deux — bouton "avance rapide") :
// saute à la prochaine donne où c'est le tour d'un de MES sièges, en CONTINUANT dans
// l'ordre numérique à partir de la donne actuelle plutôt que de repartir de la donne 1 —
// une donne plus loin dans l'ordre (ex. la 7 après avoir fini la 6) est prioritaire sur
// une donne plus tôt (ex. la 2), qu'on ne retrouve qu'en bouclant si rien de plus proche
// n'attend. Avance les robots au passage (voir advanceRobotBidsOnBoard), au cas où une
// donne n'aurait pas encore été touchée depuis un chargement antérieur à ce correctif.
// Live : hôte seul. Différé : chaque joueur assis peut l'utiliser pour sa vue locale.
async function uiFastForwardToMyTurn() {
    if (!canNavigateBoards() || !deals) return;
    const n = deals.length;
    for (let offset = 1; offset <= n; offset++) {
        const idx = (boardIndex + offset) % n;
        // R12 — le pré-calcul de lancement est volontairement asynchrone. Si l'utilisateur
        // clique très vite sur avance rapide, attendre/terminer le préfixe robot de cette
        // donne avant de décider si elle attend réellement une annonce humaine.
        await ensureRobotPrefixReadyOnBoard(idx);
        const hist = deals[idx].auctionHistory || [];
        if (isAuctionOver(hist)) continue;
        const turnSeat = currentTurnSeat(deals[idx].dealer, hist);
        if (mySeats.includes(turnSeat)) {
            if (idx !== boardIndex) {
                gotoBoard(idx);
                fadeBoardNavigationTargets();
            }
            return;
        }
    }
    // Aucune donne ne m'attend nulle part (tout est déjà fait de mon côté, ou terminé
    // partout) : plutôt qu'un message qui disparaît sans donner de vue d'ensemble, on
    // ouvre directement la vue d'ensemble — elle montre précisément pourquoi (tout
    // terminé, ou en attente d'un partenaire/robot ailleurs).
    pushDebugLog("Avance rapide : aucune donne n'attend une de mes annonces pour l'instant.");
    uiOpenBoardOverview();
}

function renderBoardSkipControls() {
    const prevBtn = document.getElementById('prevBoardBtn');
    const nextBtn = document.getElementById('skipNextBoardBtn');
    const fastForwardBtn = document.getElementById('fastForwardBoardBtn');
    if (!prevBtn || !nextBtn) return;
    const canNavigate = canNavigateBoards();
    // Voir échange avec Guillaume ("Donne #... devrait être à la même place pour l'invité
    // que pour l'hôte, l'invité ne doit juste pas voir les 2 flèches") : visibility (pas
    // display:none) — sans ça, les flèches masquées disparaissaient du flux flex
    // (.board-nav-row), et #boardNumberLabel, leur voisin direct, se retrouvait décalé
    // vers la gauche pour un invité par rapport à l'hôte (même principe déjà utilisé pour
    // rotateBtn/seatReorgBtn, voir updateBoardControlVisibility).
    prevBtn.style.visibility = canNavigate ? '' : 'hidden';
    prevBtn.style.pointerEvents = canNavigate ? '' : 'none';
    nextBtn.style.visibility = canNavigate ? '' : 'hidden';
    nextBtn.style.pointerEvents = canNavigate ? '' : 'none';
    // Voir échange avec Guillaume ("la flèche avance rapide ne doit pas apparaître en cas
    // de jeu non différé") : "avance rapide" saute à la prochaine donne où c'est mon tour
    // AILLEURS — utile seulement en mode différé, où les donnes avancent indépendamment
    // les unes des autres au fil des connexions successives. En live, tout le monde est
    // connecté en même temps sur la même donne : il n'y a jamais rien à "rattraper"
    // ailleurs, le bouton n'a donc pas de sens et ne doit pas apparaître, même pour
    // l'hôte. Même repère que pollCloudForUpdates pour détecter le mode différé
    // (`peerConn instanceof NullPeerConnection`), fixé au lancement de la salle.
    const isDeferredRoom = deferredRoomMode;
    const showFastForward = canNavigate && isDeferredRoom;
    if (fastForwardBtn) {
        fastForwardBtn.style.display = showFastForward ? '' : 'none';
        fastForwardBtn.style.visibility = '';
        fastForwardBtn.style.pointerEvents = showFastForward ? '' : 'none';
    }
    if (!canNavigate || !deals) return;
    prevBtn.disabled = boardIndex <= 0;
    nextBtn.disabled = boardIndex >= deals.length - 1;
}

// ===== PWA : service worker, installation iOS, hors-ligne =====
//
// Voir manifest.json + sw.js pour le reste. Le versioning des fichiers mis en cache
// (anciennement un paramètre `?v=NN` sur chaque <script>/<link> de index.html) est
// désormais géré par CACHE_NAME dans sw.js — à incrémenter là-bas à chaque déploiement
// qui touche un fichier mis en cache.

let pendingSwRegistration = null;

function initServiceWorker() {
    if (!('serviceWorker' in navigator)) return;

    navigator.serviceWorker.register('sw.js').then((registration) => {
        // Une version déjà en attente ou nouvellement installée est mémorisée pour le
        // diagnostic. La page ne lui envoie jamais skipWaiting() elle-même : depuis R2,
        // c'est le Service Worker qui s'active une fois son cache complet, sans forcer de
        // reload de la salle courante.
        if (registration.waiting) {
            pendingSwRegistration = registration;
            tryAutoApplyUpdate();
        }

        registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (!newWorker) return;
            newWorker.addEventListener('statechange', () => {
                // 'installed' + controller actif = nouvelle version prête. Le worker R2+
                // s'active lui-même ; côté page on ne force aucune navigation/reload à chaud.
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    pendingSwRegistration = registration;
                    recordPlayPerfMilestone('service-worker-update-waiting');
                    tryAutoApplyUpdate();
                }
            });
        });

        // Continuer à détecter une nouvelle version sur un onglet laissé ouvert. Le worker
        // peut s'activer en arrière-plan, mais le JavaScript déjà chargé dans cet onglet
        // reste intact jusqu'à une navigation utilisateur.
        setInterval(() => registration.update(), 60000);
    }).catch((err) => {
        pushDebugLog('Service worker : échec d\'enregistrement — ' + (err && err.message));
    });

    // controllerchange peut encore arriver lors d'une navigation/reprise normale du
    // navigateur. Il ne doit JAMAIS provoquer lui-même un reload : on journalise seulement
    // l'événement. La version déjà chargée en mémoire continue jusqu'à la prochaine vraie
    // navigation choisie par l'utilisateur.
    navigator.serviceWorker.addEventListener('controllerchange', () => {
        recordPlayPerfMilestone('service-worker-controller-change');
    });
}

function scheduleServiceWorkerInit() {
    // L'installation d'une nouvelle version force plusieurs fetch(cache:'reload'). La faire
    // au tout premier DOMContentLoaded pouvait concurrencer le clic « Créer » sur mobile.
    // Un ancien SW déjà actif continue naturellement à servir la navigation ; seule la
    // vérification/installation de la prochaine version est reportée à une période calme.
    const run = () => {
        // Ne jamais démarrer une installation SW au milieu d'un Create/Join ou d'une salle
        // active : ces fetch(cache:'reload') sont utiles pour la prochaine visite, pas pour
        // concurrencer la connexion en cours. On réessaie plus tard quand l'accueil est libre.
        if (peerConn || pendingJoinAfterNickname) {
            setTimeout(run, 5000);
            return;
        }
        recordPlayPerfMilestone('service-worker-init');
        initServiceWorker();
    };
    if (window.requestIdleCallback) window.requestIdleCallback(run, { timeout: 5000 });
    else setTimeout(run, 2500);
}

// Politique de mise à jour PWA : pas de reload forcé par la page.
//
// Le worker R2+ peut s'activer immédiatement après construction complète de son cache, mais
// PLAY ne recharge jamais de lui-même une salle en cours. Cette fonction conserve seulement
// l'information "mise à jour détectée" pour le diagnostic ; le nouvel ensemble de fichiers
// sera utilisé à la prochaine vraie navigation/ouverture.
function tryAutoApplyUpdate() {
    if (!pendingSwRegistration || !pendingSwRegistration.waiting) return;
    recordPlayPerfMilestone('service-worker-update-deferred');
}

// iPadOS se fait passer pour un Mac (navigator.platform "MacIntel") depuis la version 13 :
// le distinguer d'un vrai Mac se fait via le support tactile, qu'aucun Mac n'a.
function isIosDevice() {
    return (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream)
        || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

// Voir échange avec Guillaume ("le bouton bug ouvre le partage natif de Windows sur PC,
// c'est pas normal") : navigator.share (utilisé dans uiReportBug pour décider entre
// feuille de partage et copie presse-papiers) existe AUSSI sur desktop — Chrome/Windows le
// relaie vers le panneau "Partager" natif de Windows, comme on vient de le constater en
// pratique. Sa seule présence ne permet donc pas de distinguer mobile de desktop ; détection
// par user-agent à la place, même repli tactile que isIosDevice ci-dessus pour le cas iPad.
function isMobileOrTabletDevice() {
    return /Android|iPhone|iPad|iPod|Mobile|Windows Phone/i.test(navigator.userAgent)
        || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function isStandaloneDisplay() {
    return window.navigator.standalone === true
        || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
}

const IOS_INSTALL_HINT_DISMISSED_KEY = 'bridgeBidIosInstallHintDismissed';

// Safari iOS ne propose aucune invite d'installation automatique (contrairement à Chrome
// Android) : sans ce message, un joueur sur iPhone n'a aucun moyen de découvrir que
// l'appli peut être ajoutée à l'écran d'accueil.
function initIosInstallHint() {
    if (!isIosDevice() || isStandaloneDisplay()) return;
    let dismissed = false;
    try { dismissed = localStorage.getItem(IOS_INSTALL_HINT_DISMISSED_KEY) === 'true'; } catch (e) { /* tant pis */ }
    if (dismissed) return;
    const banner = document.getElementById('iosInstallBanner');
    if (banner) banner.style.display = 'flex';
}

function uiDismissIosInstallHint() {
    document.getElementById('iosInstallBanner').style.display = 'none';
    try { localStorage.setItem(IOS_INSTALL_HINT_DISMISSED_KEY, 'true'); } catch (e) { /* tant pis */ }
}

const IOS_LOCK_WARNING_DISMISSED_KEY = 'bridgeBidIosLockWarningDismissed';

// iOS suspend les connexions WebRTC quand Safari passe en arrière-plan ou que l'écran se
// verrouille — une vraie limitation de la plateforme, pas un bug de l'appli. Affiché une
// fois sur l'écran d'accueil, mémorisé pour ne pas le réafficher à chaque visite.
function initIosLockScreenWarning() {
    if (!isIosDevice()) return;
    let dismissed = false;
    try { dismissed = localStorage.getItem(IOS_LOCK_WARNING_DISMISSED_KEY) === 'true'; } catch (e) { /* tant pis */ }
    if (dismissed) return;
    const note = document.getElementById('iosLockScreenWarning');
    if (note) note.style.display = 'block';
}

function uiDismissIosLockScreenWarning() {
    document.getElementById('iosLockScreenWarning').style.display = 'none';
    try { localStorage.setItem(IOS_LOCK_WARNING_DISMISSED_KEY, 'true'); } catch (e) { /* tant pis */ }
}

// Hors-ligne : la partie de l'appli qui a un sens sans réseau est proche de zéro (tout
// repose sur la connexion pair-à-pair), donc on se contente de désactiver clairement les
// deux points d'entrée plutôt que de laisser l'utilisateur découvrir l'échec au clic.
function updateOfflineUI() {
    const offline = !navigator.onLine;
    const banner = document.getElementById('offlineBanner');
    if (banner) banner.style.display = offline ? 'block' : 'none';
    const createBtn = document.getElementById('createRoomBtn');
    const joinBtn = document.getElementById('joinRoomBtn');
    if (createBtn) createBtn.disabled = offline;
    if (joinBtn) joinBtn.disabled = offline;
}

function initOfflineHandling() {
    updateOfflineUI();
    window.addEventListener('online', updateOfflineUI);
    window.addEventListener('offline', updateOfflineUI);
}

// ===== Initialisation =====

// Voir échange avec Guillaume (session du 23 juillet — "si l'hôte refresh dans le salon,
// ça devrait clôturer la room") : PREMIER essai avec beforeunload (retirer le code de
// l'URL juste avant le rechargement) — ne fonctionnait pas, le navigateur a déjà figé
// quelle URL il va recharger avant que ce code n'ait la moindre chance de s'exécuter,
// donc la modifier à ce moment-là n'a aucun effet sur le rechargement en cours. Reprise
// avec sessionStorage à la place (survit à un rechargement de CET onglet, contrairement
// aux variables JS) : posé tant que l'hôte est dans le salon (avant le lancement, voir
// enterLobbyScreen), retiré dès que la partie démarre (voir uiStartGameAsHost). Au
// chargement de la page, AVANT de tenter quoi que ce soit avec un ?room= dans l'URL, on
// vérifie s'il correspond à une salle qu'on hébergeait nous-même, encore dans le salon,
// juste avant ce rechargement — auquel cas elle est morte de toute façon (rien n'est
// persistant), pas la peine de tenter (et échouer) à la rejoindre.
const HOSTING_PREGAME_KEY = 'bridgeBidHostingPregameRoom';

function markHostingPregame(roomCode) {
    try { sessionStorage.setItem(HOSTING_PREGAME_KEY, roomCode); } catch (e) { /* tant pis */ }
}

function clearHostingPregameMark() {
    try { sessionStorage.removeItem(HOSTING_PREGAME_KEY); } catch (e) { /* tant pis */ }
}

// ===== Reprise de partie après fermeture complète de l'onglet (voir échange avec
// Guillaume, session du 23 juillet) =====
//
// Contrairement à HOSTING_PREGAME_KEY ci-dessus (qui ne fait que nettoyer une URL avant un
// rechargement), ceci sauvegarde l'état COMPLET de la partie EN COURS (donnes, enchère,
// sièges, participants) dans localStorage — qui, contrairement à sessionStorage et aux
// variables JS, survit à la fermeture complète du navigateur, voire à un redémarrage de
// l'appareil. Limite assumée : ne fonctionne que sur le MÊME appareil et le MÊME
// navigateur (localStorage est propre à cette combinaison), pas depuis un autre — pour
// couvrir ce cas-là, voir plutôt le relais serveur par siège (voir
// ARCHITECTURE-P2P-SERVEUR.md), pensé précisément pour "continuer depuis un autre appareil
// sans l'hôte d'origine".
const HOST_GAME_STATE_KEY = 'bridgeBidHostGameStates'; // carte {roomCode: payload}, voir échange avec Guillaume (session du 8 août — "multi room")
const HOST_GAME_STATE_INDEX_KEY = 'bridgeBidHostGameStatesIndexV1'; // métadonnées légères pour l'accueil
// Passé ce délai, une session sauvegardée n'est plus proposée à la reprise — un chiffre
// volontairement généreux (une session de club peut s'étaler sur plusieurs heures avec
// pauses), sans non plus laisser une bannière "reprendre" resurgir des jours après une
// partie oubliée.
const HOST_GAME_STATE_EXPIRY_MS = 6 * 60 * 60 * 1000; // 6h
// Voir échange avec Guillaume (session du 8 août — "multi room") : plafond du nombre de
// salles mémorisées simultanément, pour ne pas laisser localStorage grossir sans limite
// au fil des semaines — au-delà, la plus ancienne (par savedAt) est évincée en priorité,
// avant même de regarder l'expiration.
const MAX_SAVED_HOST_SESSIONS = 8;

// Lit la carte complète {roomCode: payload} depuis localStorage, purgée des entrées
// expirées au passage (jamais écrites telles quelles ailleurs — voir writeAllHostGame
// States, seul point d'écriture). Repli sur un objet vide si absent/corrompu.
function readAllHostGameStates() {
    let map;
    try {
        const raw = localStorage.getItem(HOST_GAME_STATE_KEY);
        map = raw ? JSON.parse(raw) : {};
    } catch (e) {
        map = {};
    }
    if (!map || typeof map !== 'object') map = {};
    let changed = false;
    for (const code of Object.keys(map)) {
        const entry = map[code];
        if (!entry || !entry.roomCode || !entry.deals || !entry.savedAt
                || Date.now() - entry.savedAt > HOST_GAME_STATE_EXPIRY_MS) {
            delete map[code];
            changed = true;
        }
    }
    if (changed) writeAllHostGameStates(map);
    return map;
}

function buildHostGameStateIndex(map) {
    return Object.values(map || {}).filter(Boolean).map(entry => ({
        roomCode: entry.roomCode,
        savedAt: entry.savedAt,
        dealsCount: Array.isArray(entry.deals) ? entry.deals.length : 0
    })).filter(entry => entry.roomCode && entry.savedAt);
}

function writeAllHostGameStates(map) {
    try {
        localStorage.setItem(HOST_GAME_STATE_KEY, JSON.stringify(map));
        localStorage.setItem(HOST_GAME_STATE_INDEX_KEY, JSON.stringify(buildHostGameStateIndex(map)));
    } catch (e) {
        // Quota localStorage dépassé, ou navigation privée stricte qui bloque l'écriture :
        // tant pis, la reprise ne sera simplement pas possible — rien d'autre n'est cassé.
    }
}

function readResumableHostIndexFast() {
    try {
        const raw = localStorage.getItem(HOST_GAME_STATE_INDEX_KEY);
        if (!raw) return null; // installation venant d'une ancienne version : migration idle plus bas
        const list = JSON.parse(raw);
        if (!Array.isArray(list)) return null;
        const now = Date.now();
        return list.filter(entry => entry && entry.roomCode && Number.isFinite(entry.savedAt)
            && now - entry.savedAt <= HOST_GAME_STATE_EXPIRY_MS)
            .sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
    } catch (e) {
        return null;
    }
}

let hostResumeIndexMigrationScheduled = false;
function scheduleHostResumeIndexMigration() {
    if (hostResumeIndexMigrationScheduled || readResumableHostIndexFast() !== null) return;
    hostResumeIndexMigrationScheduled = true;
    const run = () => {
        hostResumeIndexMigrationScheduled = false;
        const map = readAllHostGameStates(); // gros parse, mais hors chemin critique d'accueil
        try { localStorage.setItem(HOST_GAME_STATE_INDEX_KEY, JSON.stringify(buildHostGameStateIndex(map))); } catch (e) { /* ignore */ }
        checkForResumableHostSession();
    };
    if (window.requestIdleCallback) window.requestIdleCallback(run, { timeout: 2500 });
    else setTimeout(run, 700);
}

// Sauvegarde l'état complet — appelée à chaque changement significatif (voir applyCall,
// gotoBoard, broadcastLobbyState) tant qu'on est hôte et que la partie est lancée. Pas de
// débounce/throttle : ces événements sont d'ores et déjà peu fréquents à l'échelle
// humaine (une enchère toutes les quelques secondes au plus), et écrire dans localStorage
// est une opération synchrone rapide.
//
// Voir échange avec Guillaume (session asynchrone à deux) : pousse AUSSI vers le cloud
// (voir pushCloudGameState) à chaque appel — un seul point d'accroche à tenir à jour pour
// les deux formes de sauvegarde (même appareil via localStorage, n'importe quel appareil
// via le cloud), plutôt que de dupliquer l'appel à chacun des call sites existants.
function saveHostGameStateToStorage() {
    if (myRole !== 'host' || !deals || !currentRoomCode) return;
    persistHostGuestReconnectSecrets(currentRoomCode);
    const payload = {
        roomCode: currentRoomCode,
        deals, boardIndex, seatAssignment, participants, autoPassSeats,
        roomCreatorName, roomCreatorToken, deferredRoomMode,
        // Voir échange avec Guillaume (session du 23 juillet — "sauve aussi le chat") :
        // sans ça, la conversation repartait de zéro à chaque reprise, même s'il y
        // avait des messages échangés juste avant la fermeture de l'onglet.
        chatMessages,
        savedAt: Date.now()
    };
    const map = readAllHostGameStates();
    map[currentRoomCode] = payload;
    // Voir échange avec Guillaume (session du 8 août — "multi room") : plafond appliqué
    // ICI, pas seulement à la lecture — sans ça, une salle active depuis longtemps (donc
    // re-sauvegardée sans cesse, jamais expirée) pourrait à elle seule empêcher toute
    // purge naturelle des autres.
    const codes = Object.keys(map);
    if (codes.length > MAX_SAVED_HOST_SESSIONS) {
        codes.sort((a, b) => (map[a].savedAt || 0) - (map[b].savedAt || 0));
        for (let i = 0; i < codes.length - MAX_SAVED_HOST_SESSIONS; i++) delete map[codes[i]];
    }
    writeAllHostGameStates(map);
    pushCloudGameState();
}

// Efface UNE salle précise de la carte des sessions reprenables (celle en cours par
// défaut) — jamais les autres, contrairement à l'ancien comportement mono-salle qui
// effaçait tout indistinctement.
function clearHostGameStateStorage(roomCode) {
    const code = roomCode || currentRoomCode;
    if (!code) return;
    const map = readAllHostGameStates();
    if (map[code]) {
        delete map[code];
        writeAllHostGameStates(map);
    }
}

// Lit UNE session sauvegardée par son code de salle, sans effet de bord au-delà de la
// purge déjà faite par readAllHostGameStates — utilisée à la fois pour l'afficher
// (checkForResumableHostSession) et pour la reprendre (uiResumeHostSession), afin de ne
// jamais dupliquer la logique de validité/expiration entre les deux.
function readResumableHostState(roomCode) {
    const map = readAllHostGameStates();
    return map[roomCode] || null;
}

// Renvoie toutes les sessions reprenables, triées de la plus récente à la plus ancienne.
function readAllResumableHostStates() {
    const fast = readResumableHostIndexFast();
    if (fast !== null) return fast;
    scheduleHostResumeIndexMigration();
    return [];
}

// Affiche (ou masque) la bannière de reprise à l'accueil — une entrée par salle
// reprenable (voir échange avec Guillaume, session du 8 août — "multi room" : auparavant
// une seule salle possible, la plus récemment sauvegardée écrasait systématiquement les
// précédentes). Appelée une fois au chargement de la page (voir DOMContentLoaded plus
// bas), et à chaque fermeture/reprise pour rester à jour.
function checkForResumableHostSession() {
    const banner = document.getElementById('resumeSessionBanner');
    if (!banner) return [];
    const sessions = readAllResumableHostStates();
    if (sessions.length === 0) {
        banner.style.display = 'none';
        return [];
    }
    const list = document.getElementById('resumeSessionList');
    if (list) {
        list.innerHTML = sessions.map(saved => {
            const minutesAgo = Math.max(0, Math.round((Date.now() - saved.savedAt) / 60000));
            const timeLabel = minutesAgo === 0 ? "à l'instant" : `il y a ${minutesAgo} min`;
            const code = escapeHtml(saved.roomCode);
            return `<div class="resume-session-row">
                <div class="resume-session-text">🔄 Salle ${code} <span class="resume-session-details">(${saved.dealsCount != null ? saved.dealsCount : (saved.deals ? saved.deals.length : 0)} donnes, ${timeLabel})</span></div>
                <div class="resume-session-actions">
                    <button type="button" class="btn btn-primary btn-small" data-ui-click="resume-host-session" data-room-code="${escapeHtml(code)}">Reprendre</button>
                    <button type="button" class="btn btn-secondary btn-small" data-ui-click="dismiss-resume-session" data-room-code="${escapeHtml(code)}">Non merci</button>
                </div>
            </div>`;
        }).join('');
    }
    banner.style.display = 'block';
    return sessions;
}

function uiDismissResumeSession(roomCode) {
    // Voir échange avec Guillaume (session du 24 juillet) : clôture définitivement la
    // partie — supprime la sauvegarde elle-même, pas seulement la bannière pour cette
    // visite. Un rechargement ultérieur ne la reproposera plus. Paramétré par salle
    // (session du 8 août — "multi room") : n'affecte que celle-ci, les autres salles
    // reprenables restent proposées normalement.
    clearHostGameStateStorage(roomCode);
    checkForResumableHostSession(); // ré-affiche la liste sans cette entrée (ou masque si c'était la dernière)
}

// Reprend une partie sauvegardée : restaure tout l'état en mémoire à l'identique, puis
// réclame le même code de salle (voir createRoom(cap, forcedRoomCode), déjà construit
// pour la reprise volontaire sous un code forcé — même mécanisme, ici déclenché
// volontairement par l'hôte lui-même plutôt qu'automatiquement par quelqu'un d'autre).
//
// Voir échange avec Guillaume ("les enchères de B n'apparaissent toujours pas") : cette
// sauvegarde LOCALE ne reflète que ce que CET appareil savait au moment de sa fermeture —
// elle ignore tout ce qu'un partenaire a pu enchérir depuis, sur un autre appareil, via le
// cloud (voir pushCloudGameState, qui écrit à chaque action, sur TOUS les appareils qui
// jouent).
//
// Voir échange avec Guillaume ("l'enchère de B n'apparaît toujours pas", répété plusieurs
// fois malgré des correctifs par ailleurs réels) : la VRAIE cause de fond était ici — une
// comparaison d'horodatage entre le cloud et cette sauvegarde locale. Le défaut : cette
// sauvegarde locale se remet à jour TOUTE SEULE à chaque reprise sur cet appareil, y
// compris via ce chemin local lui-même (voir saveHostGameStateToStorage en fin de
// fonction) — dès la première fois où ce chemin se déclenche, pour n'importe quelle
// raison, son horodatage devient "maintenant" et reste alors indéfiniment plus récent que
// n'importe quelle écriture antérieure de B, même authentiquement plus à jour en contenu.
// Un cercle qui se referme sur lui-même, sans jamais pouvoir se rouvrir tout seul.
//
// Plus de comparaison d'horodatage du tout : pour une salle où la persistance cloud
// existe, le cloud est TOUJOURS au moins aussi à jour que cette sauvegarde locale
// (chaque sauvegarde locale part de toute façon aussi vers le cloud en même temps, voir
// pushCloudGameState) — il l'emporte systématiquement dès qu'il est joignable. La
// sauvegarde locale ne sert plus que de filet si le cloud est injoignable (hors-ligne,
// panne passagère) ou n'a jamais rien reçu pour ce code.
async function uiResumeHostSession(roomCode) {
    const saved = readResumableHostState(roomCode);
    if (!saved) {
        checkForResumableHostSession(); // périmée entre-temps : remet la bannière à jour
        return;
    }

    // Voir échange avec Guillaume ("la ligne 'Reprise hôte' n'apparaît pas dans le
    // journal combiné") : posé ICI, le plus tôt possible — pushDebugLog (voir plus haut)
    // n'envoie une ligne vers le journal PARTAGÉ de la salle que si currentRoomCode est
    // déjà renseigné au moment de l'appel. Sans ce réglage précoce, tout ce qui se
    // journalise pendant cette reprise (y compris la ligne de diagnostic juste en
    // dessous) restait local uniquement, invisible pour quiconque irait relire le
    // journal combiné depuis un autre appareil.
    currentRoomCode = saved.roomCode;
    ensureCloudSyncContext(saved.roomCode);
    loadHostGuestReconnectSecrets(saved.roomCode);

    if (typeof pullSessionState === 'function') {
        try {
            let cloudResult = await pullSessionState(saved.roomCode);
            if (cloudResult) {
                cloudResult = prepareCloudResumeCandidate(cloudResult, saved.roomCode);
                if (!cloudResult) throw new Error('snapshot cloud invalide');
                // Voir échange avec Guillaume ("l'enchère de l'invité n'est pas visible
                // à la réouverture de l'hôte") : trace précise de ce qui a été relu ici
                // — la longueur de l'historique d'enchères de la première donne donne
                // un indice immédiat si c'est bien à jour ou visiblement périmé.
                const b0Len = (cloudResult.state && cloudResult.state.deals && cloudResult.state.deals[0]
                    && cloudResult.state.deals[0].auctionHistory) ? cloudResult.state.deals[0].auctionHistory.length : 'n/a';
                pushDebugLog(`Reprise hôte : état cloud relu, version ${cloudResult.version}, historique donne #1 = ${b0Len} annonce(s).`);
                cloudResumeCandidate = cloudResult;
                uiResumeFromCloud();
                return;
            } else {
                pushDebugLog('Reprise hôte : aucun état cloud trouvé pour cette salle (pullSessionState a renvoyé null) — repli sur la sauvegarde locale.');
            }
        } catch (e) {
            pushDebugLog('Reprise hôte : lecture cloud impossible (' + ((e && e.message) || e) + ') — repli sur la sauvegarde locale.');
            // Cloud injoignable (hors-ligne, panne passagère...) : tant pis, on continue
            // avec la sauvegarde locale ci-dessous plutôt que de bloquer la reprise.
        }
    }

    deals = saved.deals;
    const localResumeFallbackBoardIndex = Number.isInteger(saved.boardIndex) && saved.boardIndex >= 0 && saved.boardIndex < deals.length
        ? saved.boardIndex
        : 0;
    boardIndex = localResumeFallbackBoardIndex;
    if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
    auctionHistory = deals[boardIndex].auctionHistory;
    const resumedParticipants = normalizePublicParticipantList(saved.participants || [{ id: 'host', name: savedNickname || 'Hôte' }]);
    const resumedSeatAssignment = normalizePublicSeatAssignment(saved.seatAssignment || { N: null, E: null, S: null, W: null }, resumedParticipants || []);
    if (!resumedParticipants || !resumedSeatAssignment) {
        pushDebugLog('Reprise locale refusée : identité participant/sièges invalides.');
        clearHostGameStateStorage(saved.roomCode);
        showScreen('screen-landing');
        showLandingError('Cette sauvegarde locale contient des identifiants invalides et a été refusée par sécurité.');
        return;
    }
    seatAssignment = resumedSeatAssignment;
    participants = resumedParticipants;
    deferredRoomMode = saved.deferredRoomMode === true || SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
    // Repli sur le participant 'host' actuel pour une sauvegarde antérieure à l'ajout de
    // ce champ (voir échange avec Guillaume) — sans quoi une session déjà en cours au
    // moment de la mise à jour du code perdrait ce nom au premier rechargement.
    roomCreatorName = saved.roomCreatorName || (participants.find(p => p.id === 'host') || {}).name || 'Hôte';
    // Repli sur getReconnectToken() : une reprise via uiResumeHostSession se fait
    // forcément depuis le MÊME appareil que la création (localStorage), donc le créateur
    // d'origine est nécessairement celui qui recharge ici.
    roomCreatorToken = saved.roomCreatorToken || getReconnectToken();
    // Voir échange avec Guillaume (session du 23 juillet — "il apparaît toujours en
    // blanc alors qu'il est déconnecté") : le statut restauré reflète la DERNIÈRE
    // sauvegarde (où tout le monde pouvait très bien être connecté) — mais personne
    // n'est réellement connecté au tout nouveau Peer qu'on vient de recréer, tant qu'ils
    // ne se sont pas reconnectés eux-mêmes (voir onGuestConnected, qui les remettra
    // correctement à disconnected:false à ce moment-là).
    const resumedAt = Date.now();
    if (!deferredRoomMode) {
        // Live : le nouveau Peer hôte n'a encore aucune DataConnection, donc les invités
        // sont réellement non joignables jusqu'à leur reconnexion.
        participants.forEach(p => {
            if (p.id !== 'host') {
                p.disconnected = true;
                p.disconnectedAt = resumedAt;
            }
        });
    } else {
        // Différé : la présence commune vient du cloud. Ne jamais marquer tout le monde
        // rouge simplement parce que CET onglet vient de rouvrir.
        const myTokenForPresence = getReconnectToken();
        const own = participants.find(p => p.id === 'host' || p.id === myTokenForPresence);
        if (own) { own.disconnected = false; own.disconnectedAt = null; }
    }
    autoPassSeats = saved.autoPassSeats || [];
    // Voir échange avec Guillaume (session du 23 juillet — "sauve aussi le chat") :
    // restaure la conversation telle qu'elle était juste avant la fermeture de l'onglet.
    chatMessages = saved.chatMessages || [];
    myRole = 'host';
    advanceRobotBidsOnAllBoards(boardIndex); // R12 : seulement après restauration explicite de l'autorité host
    // Voir échange avec Guillaume ("je réouvre en A, kibbitz") : depuis la séparation
    // live/différé, une salle DIFFÉRÉE n'utilise plus jamais la chaîne littérale 'host'
    // dans seatAssignment (remplacée par mon vrai jeton dès le lancement, voir
    // uiStartGameAsHost) — seule une salle LIVE l'utilise encore. Sans cette
    // distinction, chercher seatAssignment[seat] === 'host' sur une salle différée ne
    // trouvait plus jamais mon siège, me faisant apparaître comme kibbitz.
    const myToken = getReconnectToken();
    const isLegacyHostRoom = SEATS.some(seat => seatAssignment[seat] === 'host') || participants.some(p => p.id === 'host');
    myParticipantId = isLegacyHostRoom ? 'host' : myToken;
    mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
    if (deferredRoomMode) {
        const firstWaitingBoard = findFirstBoardWaitingForSeats(mySeats, deals);
        boardIndex = firstWaitingBoard >= 0 ? firstWaitingBoard : localResumeFallbackBoardIndex;
        if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
        auctionHistory = deals[boardIndex].auctionHistory;
    }
    currentRoomCode = saved.roomCode;
    guestIndexByToken = {};
    hostPendingUndo = null;
    hostTransferInProgress = false;
    // Voir échange avec Guillaume (session du 23 juillet — même genre de bug que les
    // participants marqués à tort "connectés") : ces deux "photos" de l'état précédent
    // servent à détecter des CHANGEMENTS (animation d'arrivée/départ de siège, toast "de
    // retour") — sans reset, elles restent celles d'avant la fermeture de l'onglet, et
    // pourraient déclencher une animation ou un toast à tort dès le premier
    // rafraîchissement après la reprise.
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;

    // Voir ARCHITECTURE-P2P-SERVEUR.md : recrée maintenant une vraie salle P2P (voir
    // juste en dessous) plutôt que d'éviter le réseau — la raison d'origine de cet évitement
    // (ancien risque d'"unavailable-id" lié à une prise automatique du même code) a
    // disparu avec l'élection automatique elle-même.
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 2, révisée après le test de Guillaume —
    // "quand l'hôte revient, l'invité reste marqué déconnecté, et la donne suivante ne le
    // fait pas bouger") : recrée maintenant une vraie salle P2P, comme au tout premier
    // lancement — au lieu de NullPeerConnection. L'ancien choix (voir git blame) était
    // motivé par l'ancien risque d'"unavailable-id" si un autre peer avait pris ce
    // même code ; ce risque n'existe plus (plus d'élection automatique, voir étape 4).
    // Sans un vrai P2P ici, un invité qui tentait de se reconnecter (voir
    // attemptGuestAutoReconnect) ne trouvait plus jamais personne à qui parler — coincé
    // sur le seul relais serveur pour toujours, y compris pour ce qui n'y passe
    // volontairement jamais (changement de donne, voir "Ne touche jamais boardIndex ici"
    // dans applyCloudUpdate).
    if (peerConn) peerConn.destroy();
    const resumeOnOpenExtra = () => {
        renderReconnectButton();
        if (deals) renderBoard(); else renderLobby();
    };
    peerConn = new BridgePeerConnection(buildHostHandlers(resumeOnOpenExtra));
    peerConn.handlers.onError = (err) => {
        // Filet de sécurité seulement — très improbable désormais (plus personne d'autre
        // ne peut légitimement détenir ce code), mais un délai de libération côté serveur
        // de signalisation reste théoriquement possible juste après la fermeture de
        // l'ancien Peer. Une seule retentative après un court délai plutôt que d'abandonner
        // platement ; au-delà, juste journalisé (le bouton "Se reconnecter" reste
        // disponible pour réessayer manuellement).
        if (err && err.type === 'unavailable-id') {
            pushDebugLog('Impossible de recréer la salle hôte (code pas encore libéré côté serveur) — nouvel essai dans un instant.');
            setTimeout(() => {
                if (myRole !== 'host' || (peerConn && peerConn.signalingOpen)) return;
                if (peerConn) peerConn.destroy();
                peerConn = new BridgePeerConnection(buildHostHandlers(resumeOnOpenExtra));
                peerConn.createRoom(6, saved.roomCode);
            }, 1500);
            return;
        }
        pushDebugLog("Échec de la recréation de la salle hôte : " + ((err && (err.message || err.type)) || err));
    };
    peerConn.createRoom(6, saved.roomCode);
    startDeferredPolling();

    hideConnectingOverlay();
    enterGameScreen();
    // Voir échange avec Guillaume (session du 23 juillet — "le DD n'est plus calculé") :
    // le calcul du double mort tourne en arrière-plan via un appel réseau (voir
    // kickOffBackgroundDD) — s'il n'était pas encore terminé au moment de la fermeture de
    // l'onglet, cet appel a été abandonné avec lui, et rien ne le relance tout seul. On
    // relance ici pour toute donne encore sans résultat.
    const missingDD = deals.filter(d => !d.par && !d.ddTable);
    if (missingDD.length > 0) kickOffBackgroundDD(missingDD);
    // À la reprise, rétablit simplement l'état permanent du chat si l'ancien indicateur
    // de compatibilité ne l'a pas encore fait (même chemin que le handler 'resync').
    if (!chatPanelOpen) uiToggleChat(false);
    saveHostGameStateToStorage(); // remet savedAt à jour tout de suite
}

// ===== Reprise "à froid" depuis le cloud (session asynchrone à deux, voir échange avec
// Guillaume) =====
//
// Distinct du relais serveur par siège en cours de partie (voir
// ARCHITECTURE-P2P-SERVEUR.md) : celui-ci suppose une connexion P2P déjà établie qui
// vient de se couper, avec quelqu'un d'autre encore en ligne pour relayer. Ici, personne
// n'était forcément connecté depuis des heures — on repart de l'état sauvegardé dans le
// cloud (voir session-storage.js), jamais de la mémoire locale, et N'IMPORTE QUEL
// participant muni du lien peut reprendre (voir échange avec Guillaume : "n'importe qui
// peut claim") — soit en retrouvant son propre siège (son jeton de reconnexion y figure
// déjà), soit en
// revendiquant le premier siège encore SEAT_PENDING.

let lastKnownCloudVersion = 0; // dernier numéro de version cloud connu, pour le verrou optimiste (voir session-storage.js)
let cloudResumeCandidate = null; // { version, updatedAt, state, _serverState? }, en attente de reprise

// Tout état de synchronisation cloud est désormais lié à UNE salle et à UNE génération.
// Les promesses fetch d'une ancienne salle peuvent continuer à se résoudre après qu'on a
// créé/rejoint une autre salle dans le même onglet ; leur résultat doit alors devenir
// strictement inerte au lieu de polluer lastKnownCloudVersion de la nouvelle salle.
let cloudSyncRoomCode = null;
let cloudSyncGeneration = 0;
let cloudLastSyncedState = null; // clone exact de l'état serveur correspondant à lastKnownCloudVersion

// Voir échange avec Guillaume (test du 27 juillet — "409 (Conflict)" en rafale) : plusieurs
// sauvegardes rapprochées restent sérialisées. Les appels reçus pendant un PUT en cours
// marquent seulement qu'un nouvel état devra repartir ensuite.
let cloudPushInFlight = false;
let cloudPushQueued = false;

const CLOUD_EXIT_RECOVERY_KEY = 'bridgeCloudExitRecoveryV1';
const CLOUD_EXIT_RECOVERY_MAX_AGE_MS = 24 * 60 * 60 * 1000;

function cloneCloudData(value) {
    if (value == null) return value;
    if (typeof structuredClone === 'function') {
        try { return structuredClone(value); } catch (e) { /* repli JSON ci-dessous */ }
    }
    return JSON.parse(JSON.stringify(value));
}

function sameCloudData(a, b) {
    if (a === b) return true;
    try { return JSON.stringify(a) === JSON.stringify(b); }
    catch (e) { return false; }
}

// R20 — empreinte de tout ce qui exige un rendu COMPLET du plateau, hors historique
// d'enchères. Les confirmations cloud changent très souvent seulement `savedAt`, la
// version ou des données d'une AUTRE donne : ces mutations ne doivent pas reconstruire
// les mains/contrôles de la donne actuellement affichée.
function currentBoardNonAuctionRenderSignature() {
    const deal = Array.isArray(deals) && deals[boardIndex] ? deals[boardIndex] : null;
    let dealWithoutAuction = null;
    if (deal) {
        dealWithoutAuction = { ...deal };
        delete dealWithoutAuction.auctionHistory;
    }
    const visibleParticipants = (participants || []).map(p => ({
        id: p.id,
        name: p.name,
        disconnected: !!p.disconnected,
        avatarColor: p.avatarColor || null
    }));
    return JSON.stringify({
        boardIndex: Number.isInteger(boardIndex) ? boardIndex : null,
        deal: dealWithoutAuction,
        seatAssignment: seatAssignment || null,
        participants: visibleParticipants,
        deferredRoomMode: !!deferredRoomMode,
        mySeats: Array.isArray(mySeats) ? mySeats : [],
        autoPassSeats: Array.isArray(autoPassSeats) ? autoPassSeats : [],
        roomCreatorName: roomCreatorName || null
    });
}

function resetCloudSyncContext(roomCode, version = 0, serverState = null) {
    cloudSyncGeneration++;
    cloudSyncRoomCode = roomCode || null;
    lastKnownCloudVersion = Number.isInteger(version) && version >= 0 ? version : 0;
    cloudLastSyncedState = serverState ? cloneCloudData(serverState) : null;
    cloudPushInFlight = false;
    cloudPushQueued = false;
    cloudResumeCandidate = null;
    // R22 — un verrou/watchdog d'une ancienne salle ne doit jamais survivre à un leave,
    // une création ou un join différent. Le token invalide aussi tout finally tardif.
    resetParticipantServerCallGuard();
    resetDeferredOptimisticChatGuards();
    // Une salle quittée ne doit pas continuer à recevoir ses événements/polls dans la
    // nouvelle. stopDeferredPolling() désabonne aussi Pusher.
    if (typeof stopDeferredPolling === 'function') stopDeferredPolling();
}

function ensureCloudSyncContext(roomCode) {
    const normalized = roomCode == null ? null : String(roomCode);
    if (cloudSyncRoomCode !== normalized) resetCloudSyncContext(normalized);
    return { roomCode: normalized, generation: cloudSyncGeneration };
}

function captureCloudSyncContext(roomCode) {
    const ctx = ensureCloudSyncContext(roomCode);
    return { roomCode: ctx.roomCode, generation: ctx.generation };
}

function isCloudSyncContextActive(ctx) {
    return !!ctx && ctx.generation === cloudSyncGeneration
        && ctx.roomCode === cloudSyncRoomCode
        && ctx.roomCode === (currentRoomCode == null ? null : String(currentRoomCode));
}

function validateCloudSnapshot(result, expectedRoomCode) {
    try {
        if (!result || !Number.isInteger(result.version) || result.version < 0 || !result.state || typeof result.state !== 'object') {
            throw new Error('enveloppe/version invalide');
        }
        const st = cloneCloudData(result.state);
        const expected = expectedRoomCode == null ? null : String(expectedRoomCode);
        if (st.roomCode != null && expected != null && String(st.roomCode) !== expected) {
            throw new Error(`code de salle ${st.roomCode} différent de ${expected}`);
        }
        if (!Array.isArray(st.deals) || st.deals.length === 0) throw new Error('liste de donnes absente ou vide');
        for (let i = 0; i < st.deals.length; i++) {
            const deal = st.deals[i];
            if (!deal || typeof deal !== 'object') throw new Error(`donne ${i + 1} absente`);
            if (typeof validateDealSemantics === 'function') validateDealSemantics(deal, `Snapshot cloud, donne ${i + 1}`);
            const cleanHistory = normalizeCloudAuctionHistory(deal, i);
            if (!cleanHistory) throw new Error(`historique donne ${i + 1} illégal ou hors vocabulaire`);
            deal.auctionHistory = cleanHistory;
        }
        if (!Number.isInteger(st.boardIndex) || st.boardIndex < 0 || st.boardIndex >= st.deals.length) {
            throw new Error(`boardIndex invalide (${st.boardIndex})`);
        }
        const cleanParticipants = normalizePublicParticipantList(st.participants || []);
        if (!cleanParticipants) throw new Error('participants invalides');
        const cleanSeatAssignment = normalizePublicSeatAssignment(st.seatAssignment, cleanParticipants);
        if (!cleanSeatAssignment) throw new Error('seatAssignment invalide');
        st.participants = cleanParticipants;
        st.seatAssignment = cleanSeatAssignment;
        const cleanChat = normalizeCloudChatMessages(st.chatMessages, cleanParticipants);
        if (!cleanChat) throw new Error('chatMessages invalides');
        st.chatMessages = cleanChat;
        if (expected != null) st.roomCode = expected;
        return { version: result.version, updatedAt: result.updatedAt, state: st };
    } catch (e) {
        if (typeof pushDebugLog === 'function') pushDebugLog('Snapshot cloud refusé : ' + ((e && e.message) || e));
        return null;
    }
}

function arrayIsPrefix(prefix, full) {
    if (!Array.isArray(prefix) || !Array.isArray(full) || prefix.length > full.length) return false;
    for (let i = 0; i < prefix.length; i++) if (!sameCloudData(prefix[i], full[i])) return false;
    return true;
}

function mergeAuctionHistoryThreeWay(base, local, remote, dealer) {
    base = Array.isArray(base) ? base : [];
    local = Array.isArray(local) ? local : [];
    remote = Array.isArray(remote) ? remote : [];
    if (sameCloudData(local, base)) return cloneCloudData(remote);
    if (sameCloudData(remote, base)) return cloneCloudData(local);
    if (sameCloudData(local, remote)) return cloneCloudData(local);

    // Deux annulations concurrentes sur le même historique : conserver la plus courte
    // (elle satisfait les deux intentions sans ressusciter une annonce annulée).
    // IMPORTANT : ce cas doit être testé AVANT les préfixes local↔remote ci-dessous.
    // Sinon, si l'un a annulé deux annonces et l'autre une seule, le plus court est
    // naturellement préfixe du plus long et l'ancienne priorité réacceptait le plus long.
    if (arrayIsPrefix(local, base) && arrayIsPrefix(remote, base)) {
        return cloneCloudData(local.length <= remote.length ? local : remote);
    }

    // R27 — un raccourcissement SERVEUR par rapport à la baseline connue est un vrai Undo
    // externe, pas un simple snapshot en retard. Il doit gagner contre une extension locale
    // devenue obsolète, sinon l'hôte peut ressusciter l'annonce annulée lors de son prochain
    // PUT. Ce test vient volontairement APRÈS le cas `remote === base` ci-dessus : un simple
    // ACK ancien (cas R19 : base=3, local=4, remote=3) doit toujours conserver l'avancée
    // locale. Il vient aussi APRÈS les deux Undo concurrents : si les deux côtés raccourcissent
    // la même baseline, la plus courte reste gagnante.
    if (remote.length < base.length && arrayIsPrefix(remote, base)) {
        return cloneCloudData(remote);
    }

    if (arrayIsPrefix(local, remote)) return cloneCloudData(remote);
    if (arrayIsPrefix(remote, local)) return cloneCloudData(local);

    // Deux extensions concurrentes du même préfixe : l'état serveur a déjà gagné. On ne
    // rejoue l'extension locale APRÈS lui que si elle reste légalement applicable ; sinon
    // on garde le serveur, ce qui évite d'écraser une annonce valide déjà acceptée.
    if (arrayIsPrefix(base, local) && arrayIsPrefix(base, remote)) {
        const merged = cloneCloudData(remote);
        for (const entry of local.slice(base.length)) {
            const expectedSeat = currentTurnSeat(dealer, merged);
            if (entry.seat !== expectedSeat || !isCallLegal(merged, entry.call, entry.seat)) {
                if (typeof pushDebugLog === 'function') pushDebugLog(`Conflit cloud : annonce locale ${entry.call} (${entry.seat}) non rejouable après l'état serveur — serveur conservé.`);
                continue;
            }
            merged.push(cloneCloudData(entry));
        }
        return merged;
    }

    // Cas ambigu (ex. undo d'un côté, nouvelle annonce de l'autre) : serveur gagnant.
    return cloneCloudData(remote);
}

function mergeSimpleThreeWay(base, local, remote) {
    if (sameCloudData(local, base)) return cloneCloudData(remote);
    if (sameCloudData(remote, base)) return cloneCloudData(local);
    if (sameCloudData(local, remote)) return cloneCloudData(local);
    return cloneCloudData(remote); // conflit réel sur le même champ : serveur gagnant
}

function mergeChatThreeWay(base, local, remote) {
    base = Array.isArray(base) ? base : [];
    local = Array.isArray(local) ? local : [];
    remote = Array.isArray(remote) ? remote : [];
    if (sameCloudData(local, base)) return cloneCloudData(remote);
    if (sameCloudData(remote, base)) return cloneCloudData(local);
    if (sameCloudData(local, remote)) return cloneCloudData(local);
    if (arrayIsPrefix(base, local) && arrayIsPrefix(base, remote)) {
        const out = cloneCloudData(remote);
        for (const msg of local.slice(base.length)) {
            if (!out.some(existing => sameCloudData(existing, msg))) out.push(cloneCloudData(msg));
        }
        return out;
    }
    return cloneCloudData(remote);
}

function mergeDealThreeWay(base, local, remote) {
    if (sameCloudData(local, base)) return cloneCloudData(remote);
    if (sameCloudData(remote, base)) return cloneCloudData(local);
    if (sameCloudData(local, remote)) return cloneCloudData(local);
    if (!local || !remote || typeof local !== 'object' || typeof remote !== 'object') return cloneCloudData(remote);
    const out = {};
    const keys = new Set([...Object.keys(base || {}), ...Object.keys(local || {}), ...Object.keys(remote || {})]);
    for (const key of keys) {
        if (key === 'auctionHistory') {
            out[key] = mergeAuctionHistoryThreeWay(base && base[key], local[key], remote[key], remote.dealer || local.dealer);
        } else {
            out[key] = mergeSimpleThreeWay(base && base[key], local[key], remote[key]);
        }
    }
    return out;
}

function mergeDealsThreeWay(base, local, remote) {
    base = Array.isArray(base) ? base : [];
    local = Array.isArray(local) ? local : [];
    remote = Array.isArray(remote) ? remote : [];
    const count = Math.max(base.length, local.length, remote.length);
    const out = [];
    for (let i = 0; i < count; i++) {
        const b = base[i], l = local[i], r = remote[i];
        if (l == null) { if (r != null) out[i] = cloneCloudData(r); continue; }
        if (r == null) { out[i] = cloneCloudData(l); continue; }
        out[i] = mergeDealThreeWay(b, l, r);
    }
    return out;
}

function mergeCloudStatesThreeWay(baseState, localState, remoteState) {
    const base = baseState || {};
    const local = localState || {};
    const remote = remoteState || {};
    const out = {};
    const keys = new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(remote)]);
    for (const key of keys) {
        if (key === 'deals') out.deals = mergeDealsThreeWay(base.deals, local.deals, remote.deals);
        else if (key === 'chatMessages') out.chatMessages = mergeChatThreeWay(base.chatMessages, local.chatMessages, remote.chatMessages);
        else if (key === 'savedAt') out.savedAt = Date.now();
        else out[key] = mergeSimpleThreeWay(base[key], local[key], remote[key]);
    }
    out.roomCode = currentRoomCode || local.roomCode || remote.roomCode;
    if (out.seatAssignment) out.autoPassSeats = SEATS.filter(seat => !out.seatAssignment[seat]);
    return out;
}

// R19 — un PUT réussi accuse réception de l'état QUI A ÉTÉ ENVOYÉ ; ce n'est pas
// une photographie magique du navigateur au moment où la réponse revient. Si le local a
// avancé pendant l'aller-retour (cas typique : Sud est envoyé, puis Ouest robot est ajouté),
// réappliquer aveuglément la réponse ferait reculer 4→3 et pourrait être relayé comme un
// faux Undo. On fusionne donc la réponse serveur avec les changements locaux POSTÉRIEURS
// au payload envoyé, en prenant précisément ce payload comme base trois-voies.
function reconcileSuccessfulCloudPush(sentState, localNow, serverState) {
    const sent = cloneCloudData(sentState || {});
    const local = cloneCloudData(localNow || sentState || {});
    const server = cloneCloudData(serverState || sentState || {});
    if (sameCloudData(local, sent)) {
        return { exactServerState: server, viewState: server, localAdvanced: false };
    }
    const merged = mergeCloudStatesThreeWay(sent, local, server);
    return {
        exactServerState: server,
        viewState: merged,
        localAdvanced: !sameCloudData(merged, server)
    };
}

function readCloudExitRecoveryMap() {
    try {
        const parsed = JSON.parse(localStorage.getItem(CLOUD_EXIT_RECOVERY_KEY) || '{}');
        return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (e) { return {}; }
}

function writeCloudExitRecoveryMap(map) {
    try { localStorage.setItem(CLOUD_EXIT_RECOVERY_KEY, JSON.stringify(map)); }
    catch (e) { /* la sauvegarde locale normale reste le filet principal */ }
}

function rememberCloudExitRecovery(roomCode, localState) {
    if (!roomCode || !localState) return;
    const map = readCloudExitRecoveryMap();
    map[roomCode] = {
        savedAt: Date.now(),
        version: lastKnownCloudVersion,
        baseState: cloneCloudData(cloudLastSyncedState),
        localState: cloneCloudData(localState)
    };
    // Un seul onglet peut raisonnablement avoir quelques fermetures non réconciliées ;
    // limite stricte pour ne pas doubler indéfiniment le poids des snapshots localStorage.
    const codes = Object.keys(map).sort((a, b) => (map[b].savedAt || 0) - (map[a].savedAt || 0));
    for (const code of codes.slice(2)) delete map[code];
    writeCloudExitRecoveryMap(map);
}

function clearCloudExitRecovery(roomCode) {
    if (!roomCode) return;
    const map = readCloudExitRecoveryMap();
    if (map[roomCode]) { delete map[roomCode]; writeCloudExitRecoveryMap(map); }
}

function prepareCloudResumeCandidate(result, roomCode) {
    const validated = validateCloudSnapshot(result, roomCode);
    if (!validated) return null;
    const map = readCloudExitRecoveryMap();
    const pending = map[roomCode];
    if (!pending || !pending.localState || Date.now() - (pending.savedAt || 0) > CLOUD_EXIT_RECOVERY_MAX_AGE_MS) {
        if (pending) clearCloudExitRecovery(roomCode);
        return { ...validated, _serverState: cloneCloudData(validated.state) };
    }
    const localValidated = validateCloudSnapshot({ version: pending.version || 0, state: pending.localState }, roomCode);
    if (!localValidated) {
        clearCloudExitRecovery(roomCode);
        return { ...validated, _serverState: cloneCloudData(validated.state) };
    }
    const merged = mergeCloudStatesThreeWay(pending.baseState, localValidated.state, validated.state);
    if (sameCloudData(merged, validated.state)) {
        clearCloudExitRecovery(roomCode);
        return { ...validated, _serverState: cloneCloudData(validated.state) };
    }
    if (typeof pushDebugLog === 'function') pushDebugLog('Reprise cloud : modifications locales de fermeture réconciliées avec la version serveur avant reprise.');
    return { ...validated, state: merged, _serverState: cloneCloudData(validated.state), _needsPush: true };
}

// Pousse l'état courant vers le cloud — voir l'unique point d'accroche dans
// saveHostGameStateToStorage(), qui appelle ceci à chaque sauvegarde locale. En tâche de
// fond (fire-and-forget) : un échec réseau ici ne doit jamais empêcher de continuer à
// jouer localement (voir pushSessionState, qui gère déjà ses propres tentatives).
function buildCloudStatePayload() {
    return {
        roomCode: currentRoomCode,
        // R21 — sérialisation canonique : aucun marqueur UI local ne doit entrer dans
        // Redis/Pusher ni influencer les comparaisons de synchro.
        deals: cloneDealsForCloudPayload(deals), boardIndex, seatAssignment, participants, autoPassSeats, chatMessages,
        roomCreatorName, deferredRoomMode,
        // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : roomCreatorToken n'est jamais
        // renseigné localement côté invité (variable réservée à l'hôte) — l'utiliser
        // tel quel écraserait la bonne valeur en cloud avec null si un invité pousse
        // (voir le nouveau site d'appel dans uiMakeCall). currentHostReconnectToken,
        // lui, EST tenu à jour côté invité aussi (voir 'start-game'/'resync'), donc
        // fiable dans les deux cas — repli dessus si roomCreatorToken est vide ici.
        roomCreatorToken: roomCreatorToken || currentHostReconnectToken,
        // Même raisonnement : getReconnectToken() renvoie MON PROPRE jeton, pas
        // forcément celui de l'hôte — correct seulement si je suis moi-même l'hôte.
        hostReconnectToken: myRole === 'host' ? getReconnectToken() : (currentHostReconnectToken || getReconnectToken()),
        savedAt: Date.now()
    };
}

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : n'était utilisable QUE par l'hôte
// jusqu'ici — élargi à n'importe quel rôle, puisque cette fonction ne fait que pousser
// l'état LOCAL de qui l'appelle, quel qu'il soit (voir buildCloudStatePayload, qui ne
// lit que des variables déjà tenues à jour côté client, pas une info réservée à l'hôte).
// Nouveau site d'appel : un invité déconnecté de l'hôte en P2P, qui pousse directement
// sa propre annonce (voir uiMakeCall) — même filet de sécurité par verrou optimiste
// (expectedVersion/409) que pour tout le monde, aucun traitement de faveur ici.
function pushCloudGameState() {
    if (!deals || !currentRoomCode) return;
    if (typeof pushSessionState !== 'function') return;

    const ctx = captureCloudSyncContext(currentRoomCode);
    if (cloudPushInFlight) {
        cloudPushQueued = true;
        return;
    }

    const payload = buildCloudStatePayload();
    const expectedVersion = lastKnownCloudVersion;
    const baseStateAtStart = cloneCloudData(cloudLastSyncedState);
    const participantCredential = currentClientParticipantCredentialForCloudWrite();
    const hasHostWriteAuthority = currentClientHasHostCloudWriteAuthority();
    if (!hasHostWriteAuthority && !participantCredential) {
        pushDebugLog('Push cloud refusé localement : aucune autorité d’écriture host ni preuve participant disponible.');
        return;
    }
    cloudPushInFlight = true;

    pushSessionState(ctx.roomCode, payload, expectedVersion, {
        participantCredential,
        onConflict: (current) => {
            if (!isCloudSyncContextActive(ctx)) return;
            const validatedCurrent = validateCloudSnapshot(current, ctx.roomCode);
            if (!validatedCurrent) {
                pushDebugLog('Conflit cloud : état serveur invalide, aucune réécriture automatique effectuée.');
                return;
            }

            // Trois voies : base connue au départ / état local ACTUEL / gagnant serveur.
            // Les champs indépendants sont combinés ; si les deux côtés modifient le même
            // champ de façon incompatible, le serveur gagne. Une annonce locale n'est
            // rejouée après le serveur que si elle reste légalement jouable.
            const localNow = buildCloudStatePayload();
            const merged = mergeCloudStatesThreeWay(baseStateAtStart, localNow, validatedCurrent.state);
            lastKnownCloudVersion = validatedCurrent.version;
            cloudLastSyncedState = cloneCloudData(validatedCurrent.state);

            if (!sameCloudData(merged, validatedCurrent.state)) {
                applyCloudUpdate(
                    { version: validatedCurrent.version, updatedAt: validatedCurrent.updatedAt, state: merged },
                    { serverState: validatedCurrent.state, expectedRoomCode: ctx.roomCode }
                );
                cloudPushQueued = true;
                pushDebugLog(`Conflit cloud v${validatedCurrent.version} : état serveur fusionné, réécriture sûre planifiée.`);
            } else {
                applyCloudUpdate(validatedCurrent, { expectedRoomCode: ctx.roomCode });
                pushDebugLog(`Conflit cloud v${validatedCurrent.version} : aucune modification locale rejouable, serveur conservé.`);
            }
        }
    }).then(result => {
        if (!isCloudSyncContextActive(ctx)) return;
        if (result && Number.isInteger(result.version)) {
            // Une réponse d'un PUT plus ancien peut arriver APRÈS qu'un poll/Pusher ait
            // déjà installé une version supérieure. Un ACK n'a jamais le droit de faire
            // redescendre le numéro de version ni la baseline serveur.
            if (result.version < lastKnownCloudVersion) {
                cloudPushQueued = true;
                recordSyncTrace('cloud.push.stale-success-ignored', {
                    ackVersion: result.version,
                    currentVersion: lastKnownCloudVersion
                });
                pushDebugLog(`ACK cloud v${result.version} ignoré : le client connaît déjà v${lastKnownCloudVersion}.`);
                return;
            }

            if (result.state) {
                const restricted = validateCloudSnapshot({ version: result.version, updatedAt: result.updatedAt, state: result.state }, ctx.roomCode);
                if (restricted) {
                    const localNow = buildCloudStatePayload();
                    const reconciled = reconcileSuccessfulCloudPush(payload, localNow, restricted.state);
                    lastKnownCloudVersion = result.version;
                    cloudLastSyncedState = cloneCloudData(reconciled.exactServerState);

                    if (reconciled.localAdvanced) {
                        // Le local a avancé pendant le PUT : conserver cette vue et pousser
                        // immédiatement ensuite contre la nouvelle version serveur. Surtout
                        // ne jamais appliquer `restricted` seul, qui créerait le faux 4→3.
                        applyCloudUpdate(
                            { version: result.version, updatedAt: result.updatedAt, state: reconciled.viewState },
                            { serverState: reconciled.exactServerState, expectedRoomCode: ctx.roomCode }
                        );
                        cloudPushQueued = true;
                        recordSyncTrace('cloud.push.success-rebased-local', { version: result.version });
                        pushDebugLog(`ACK cloud v${result.version} reçu sur un état déjà dépassé localement : local conservé, push suivant planifié.`);
                    } else {
                        applyCloudUpdate(restricted, { expectedRoomCode: ctx.roomCode });
                    }
                }
            } else {
                lastKnownCloudVersion = result.version;
                cloudLastSyncedState = cloneCloudData(payload);
                // Sans état renvoyé, le payload est seulement acquitté ; s'il a été dépassé
                // localement, la sauvegarde déjà mise en file doit partir ensuite.
                if (!sameCloudData(buildCloudStatePayload(), payload)) cloudPushQueued = true;
            }
            clearCloudExitRecovery(ctx.roomCode);
        }
    }).catch(err => {
        if (isCloudSyncContextActive(ctx)) pushDebugLog('Push cloud échoué : ' + ((err && err.message) || err));
    }).finally(() => {
        if (!isCloudSyncContextActive(ctx)) return;
        cloudPushInFlight = false;
        if (cloudPushQueued) {
            cloudPushQueued = false;
            pushCloudGameState();
        }
    });
}

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : chemin de repli pour un invité dont la
// connexion P2P à l'hôte est coupée au moment de vouloir annoncer (voir uiMakeCall). Ne
// réutilise PAS buildCloudStatePayload/pushCloudGameState directement sur l'état local :
// celui-ci peut être en avance (mon propre affichage optimiste) ou en retard (si je n'ai
// pas suivi les derniers changements pendant ma coupure) par rapport à ce que le serveur
// connaît vraiment — on relit donc le serveur d'abord, on rejoue CETTE annonce sur SA
// version de l'historique, et on revalide avant de pousser. Si elle n'est plus légale
// (quelqu'un/quelque chose a changé la situation ailleurs entre-temps), on abandonne et on
// resynchronise sur le vrai état serveur plutôt que de laisser mon affichage optimiste
// erroné en place (voir applyCloudUpdate, réutilisé tel quel pour ce cas).
async function nudgeDeferredRobotContinuationViaServer(authoritative, targetBoardIndex, cloudCtx) {
    if (!deferredRoomMode || !authoritative || !authoritative.state) return false;
    const state = authoritative.state;
    const idx = Number(targetBoardIndex);
    if (!Number.isInteger(idx) || !state.deals || !state.deals[idx]) return false;
    const deal = state.deals[idx];
    const hist = Array.isArray(deal.auctionHistory) ? deal.auctionHistory : [];
    if (isAuctionOver(hist)) return false;
    const expectedSeat = currentTurnSeat(deal.dealer, hist);
    // Dans PLAY, un robot est précisément un siège sans participant assigné (null/undefined).
    // SEAT_PENDING est une chaîne non vide et ne doit donc jamais être pris pour un robot.
    if (!expectedSeat || (state.seatAssignment && state.seatAssignment[expectedSeat])) return false;

    // Le serveur R7 utilise `proposed.boardIndex` comme HINT en mode différé, sans recopier
    // cette navigation dans l'état partagé. Un participant assis peut donc demander à PONS
    // d'avancer cette donne sans prendre aucune autorité sur la valeur de l'annonce robot.
    const hintedState = cloneCloudData(state);
    hintedState.boardIndex = idx;
    hintedState.savedAt = Date.now();
    let conflictCurrent = null;
    const result = await pushSessionState(cloudCtx.roomCode, hintedState, authoritative.version, {
        participantCredential: ensureDeferredGuestCloudWriteCredential(),
        onConflict: (current) => {
            if (!isCloudSyncContextActive(cloudCtx)) return;
            const validCurrent = current && validateCloudSnapshot(current, cloudCtx.roomCode);
            if (validCurrent) conflictCurrent = validCurrent;
        }
    });
    if (!isCloudSyncContextActive(cloudCtx)) return false;
    if (!result) {
        if (conflictCurrent) {
            lastKnownCloudVersion = conflictCurrent.version;
            cloudLastSyncedState = cloneCloudData(conflictCurrent.state);
            applyCloudUpdate(conflictCurrent, { expectedRoomCode: cloudCtx.roomCode });
        }
        return false;
    }

    lastKnownCloudVersion = result.version;
    if (result.state) {
        const restricted = validateCloudSnapshot({
            version: result.version,
            updatedAt: result.updatedAt,
            state: result.state
        }, cloudCtx.roomCode);
        if (restricted) {
            cloudLastSyncedState = cloneCloudData(restricted.state);
            applyCloudUpdate(restricted, { expectedRoomCode: cloudCtx.roomCode });
        }
    }
    recordSyncTrace('call.cloud-fallback.robot-nudge', { targetBoardIndex: idx, version: result.version });
    pushDebugLog(`Continuation robot donne ${idx + 1} déclenchée côté serveur (version ${result.version}).`);
    return true;
}

async function pushCallViaServerFallback(targetBoardIndex, seat, call, explanation) {
    if (!currentRoomCode || typeof pullSessionState !== 'function' || typeof pushSessionState !== 'function') {
        pushDebugLog(`Annonce ${call} (${seat}) : impossible de tenter le relais serveur (currentRoomCode ou fonctions cloud manquantes).`);
        return;
    }
    pushDebugLog(`Annonce ${call} (${seat}) : tentative de remontée au serveur (déconnecté de l'hôte).`);
    recordSyncTrace('call.cloud-fallback.begin', { targetBoardIndex, seat, call });
    const cloudCtx = captureCloudSyncContext(currentRoomCode);
    if (deferredRoomMode && myRole === 'guest' && !ensureDeferredGuestCloudWriteCredential()) {
        recordSyncTrace('call.cloud-fallback.no-participant-credential', {
            targetBoardIndex, seat, call, participantId: myParticipantId || null
        });
        pushDebugLog(`Annonce ${call} (${seat}) : credential participant différée indisponible.`);
        return;
    }
    try {
        let pulled;
        let normalPullError = null;
        try {
            pulled = await pullSessionState(cloudCtx.roomCode);
            if (!isCloudSyncContextActive(cloudCtx)) return;
            if (pulled) pulled = validateCloudSnapshot(pulled, cloudCtx.roomCode);
        } catch (e) {
            normalPullError = e;
        }

        // R9 : le `resync` P2P peut précéder de très peu le message `session-access`.
        // En différé, cela ne doit JAMAIS faire perdre la première annonce : le code à
        // 4 chiffres est précisément la capacité de lecture prévue par le produit.
        // On prime donc la credential locale puis on tente la lecture code-seul. Ce
        // repli ne s'exécute jamais en live et ne change pas les droits d'écriture : le
        // serveur exige toujours la preuve participant pré-enregistrée.
        if (!pulled && deferredRoomMode && typeof pullDeferredSessionStateByCode === 'function') {
            primeDeferredGuestCloudAccess();
            try {
                pulled = await pullDeferredSessionStateByCode(cloudCtx.roomCode);
                if (!isCloudSyncContextActive(cloudCtx)) return;
                if (pulled) pulled = validateCloudSnapshot(pulled, cloudCtx.roomCode);
            } catch (e) {
                // pullDeferredSessionStateByCode est normalement fail-soft ; garder le
                // dernier diagnostic seulement si cette implémentation remonte une erreur.
                if (!normalPullError) normalPullError = e;
            }
        }
        if (!pulled) {
            pushDebugLog('Remontée serveur de l\'annonce impossible (lecture) : ' + ((normalPullError && normalPullError.message) || normalPullError || 'session différée inaccessible'));
            return;
        }

        const idx = Number.isInteger(targetBoardIndex) ? targetBoardIndex : boardIndex;
        const initialState = pulled ? pulled.state : buildCloudStatePayload();
        const initialDeals = initialState && initialState.deals;
        if (!initialDeals || !initialDeals[idx]) {
            pushDebugLog(`Annonce ${call} (${seat}) abandonnée : état serveur relu inattendu (donne ${idx} introuvable).`);
            return;
        }
        const initialServerHistory = cloneCloudData(initialDeals[idx].auctionHistory || []);
        let authoritative = pulled;
        const maxConflictRebases = 3;

        for (let conflictAttempt = 0; conflictAttempt <= maxConflictRebases; conflictAttempt++) {
            const baseState = authoritative ? cloneCloudData(authoritative.state) : cloneCloudData(initialState);
            const expectedVersion = authoritative ? authoritative.version : 0;
            const boardDeals = baseState && baseState.deals;
            if (!boardDeals || !boardDeals[idx]) {
                pushDebugLog(`Annonce ${call} (${seat}) abandonnée : donne ${idx} absente après conflit.`);
                if (authoritative) applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                return;
            }
            if (!boardDeals[idx].auctionHistory) boardDeals[idx].auctionHistory = [];
            const hist = boardDeals[idx].auctionHistory;

            // R12 — course R11 : le miroir P2P peut permettre à l'hôte de committer
            // l'annonce AVANT le PUT participant. Si ce snapshot hôte laisse maintenant
            // un robot au tour, ne pas abandonner simplement parce que l'annonce humaine
            // est déjà là : envoyer un PUT participant identique avec `boardIndex` en hint
            // afin que l'autorité PONS serveur fasse immédiatement jouer ce robot.
            const serverTurnSeat = currentTurnSeat(boardDeals[idx].dealer, hist);
            const serverTurnIsRobot = !!serverTurnSeat
                && (!baseState.seatAssignment || !baseState.seatAssignment[serverTurnSeat]);
            if (deferredRoomMode && serverTurnIsRobot) {
                const nudged = await nudgeDeferredRobotContinuationViaServer(
                    { version: expectedVersion, state: baseState }, idx, cloudCtx
                );
                if (nudged) return;
                if (!isCloudSyncContextActive(cloudCtx)) return;
            }

            // Idempotence : un timeout réseau peut avoir laissé croire que le PUT a échoué
            // alors que le serveur l'a commité puis a déjà ajouté un ou plusieurs appels
            // PONS. Si le préfixe serveur initial est intact et que NOTRE appel se trouve
            // exactement à la position attendue, il est déjà acquis : ne jamais le doubler.
            const sameInitialPrefix = hist.length >= initialServerHistory.length
                && sameCloudData(hist.slice(0, initialServerHistory.length), initialServerHistory);
            const committedEntry = sameInitialPrefix ? hist[initialServerHistory.length] : null;
            const callAlreadyCommitted = !!committedEntry
                && committedEntry.seat === seat
                && String(committedEntry.call || '').toUpperCase() === String(call || '').toUpperCase();
            if (callAlreadyCommitted) {
                if (authoritative) {
                    lastKnownCloudVersion = authoritative.version;
                    cloudLastSyncedState = cloneCloudData(authoritative.state);
                    applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                }
                recordSyncTrace('call.cloud-fallback.already-committed', { targetBoardIndex: idx, seat, call, version: authoritative && authoritative.version });
                pushDebugLog(`Annonce ${call} (${seat}) déjà présente sur le serveur après conflit ; aucune duplication.`);
                return;
            }

            // On ne rebase automatiquement que si CETTE donne n'a pas changé depuis notre
            // lecture initiale. Un conflit causé par une autre donne/chat/présence peut donc
            // être rejoué sans perdre l'action utilisateur. En revanche, si la même donne a
            // changé, la décision métier n'est plus forcément valable : fail-closed + resync.
            if (!sameCloudData(hist, initialServerHistory)) {
                clearDeferredOptimisticAuctionGuard(idx, seat, call, 'same-board-conflict');
                recordSyncTrace('call.cloud-fallback.same-board-conflict', { targetBoardIndex: idx, seat, call, currentVersion: authoritative && authoritative.version });
                pushDebugLog(`Annonce ${call} (${seat}) abandonnée : la donne ${idx} a changé pendant le conflit — resynchronisation sans réécriture.`);
                if (authoritative) applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                return;
            }

            const expectedSeat = currentTurnSeat(boardDeals[idx].dealer, hist);
            if (seat !== expectedSeat || !isCallLegal(hist, call, seat)) {
                clearDeferredOptimisticAuctionGuard(idx, seat, call, 'server-rejected-call');
                pushDebugLog(`Annonce ${call} (${seat}) abandonnée : plus valide par rapport à l'état serveur relu (tour attendu : ${expectedSeat}) — resynchronisation.`);
                if (authoritative) applyCloudUpdate(authoritative, { expectedRoomCode: cloudCtx.roomCode });
                return;
            }

            hist.push(explanation ? { seat, call, explanation } : { seat, call });
            const stateToPush = { ...baseState, savedAt: Date.now() };
            let conflictCurrent = null;
            const result = await pushSessionState(cloudCtx.roomCode, stateToPush, expectedVersion, {
                participantCredential: ensureDeferredGuestCloudWriteCredential(),
                onConflict: (current) => {
                    if (!isCloudSyncContextActive(cloudCtx)) return;
                    const validCurrent = current && validateCloudSnapshot(current, cloudCtx.roomCode);
                    if (validCurrent) {
                        conflictCurrent = validCurrent;
                        lastKnownCloudVersion = validCurrent.version;
                        cloudLastSyncedState = cloneCloudData(validCurrent.state);
                    }
                    recordSyncTrace('call.cloud-fallback.conflict', {
                        targetBoardIndex: idx, seat, call,
                        currentVersion: validCurrent && validCurrent.version,
                        attempt: conflictAttempt + 1
                    });
                }
            });
            if (!isCloudSyncContextActive(cloudCtx)) return;

            if (result) {
                lastKnownCloudVersion = result.version;
                if (result.state) {
                    // Une écriture participant peut contenir PLUS que mon annonce : le
                    // serveur fait immédiatement jouer PONS tant que le tour reste robot.
                    const restricted = validateCloudSnapshot({
                        version: result.version,
                        updatedAt: result.updatedAt,
                        state: result.state
                    }, cloudCtx.roomCode);
                    if (restricted) {
                        cloudLastSyncedState = cloneCloudData(restricted.state);
                        applyCloudUpdate(restricted, { expectedRoomCode: cloudCtx.roomCode });
                    } else {
                        cloudLastSyncedState = cloneCloudData(stateToPush);
                    }
                } else {
                    cloudLastSyncedState = cloneCloudData(stateToPush);
                }
                recordSyncTrace('call.cloud-fallback.success', { targetBoardIndex: idx, seat, call, version: result.version, conflictRebases: conflictAttempt });
                pushDebugLog(`Annonce ${call} (${seat}) remontée au serveur avec succès (version ${result.version}).`);
                return;
            }

            if (conflictCurrent && conflictAttempt < maxConflictRebases) {
                authoritative = conflictCurrent;
                recordSyncTrace('call.cloud-fallback.rebase', { targetBoardIndex: idx, seat, call, version: conflictCurrent.version, attempt: conflictAttempt + 1 });
                continue;
            }

            if (conflictCurrent) {
                clearDeferredOptimisticAuctionGuard(idx, seat, call, 'too-many-conflicts');
                pushDebugLog(`Annonce ${call} (${seat}) : trop de conflits successifs ; resynchronisation sans forcer l'écriture.`);
                applyCloudUpdate(conflictCurrent, { expectedRoomCode: cloudCtx.roomCode });
            } else {
                pushDebugLog(`Annonce ${call} (${seat}) : pushSessionState n'a renvoyé aucun résultat exploitable — à surveiller.`);
            }
            return;
        }
    } catch (e) {
        recordSyncTrace('call.cloud-fallback.error', { targetBoardIndex, seat, call, message: (e && e.message) || String(e) });
        pushDebugLog(`Annonce ${call} (${seat}) : échec inattendu de la remontée serveur — ` + ((e && (e.message || e.stack)) || e));
    }
}

// ===== Synchronisation cloud (voir ARCHITECTURE-P2P-SERVEUR.md, étape 3) =====
//
// Anciennement "sondage périodique du cloud (mode différé uniquement)" — élargi : ne
// sert plus seulement au mode différé pur, mais aussi de filet de secours en mode live
// dès qu'AU MOINS UN siège occupé n'est plus joignable en P2P (voir pollCloudForUpdates,
// dont le garde-fou a changé en conséquence). Tant que tout le monde reste en P2P, ce
// mécanisme ne fait strictement rien (aucun coût réseau ajouté) — voir le principe "le
// serveur est un chemin normal pour un siège donné, jamais un repli permanent" dans le
// document de conception.
//
// Voir échange avec Guillaume ("B est dans la partie, mais n'apparaît pas chez A tant
// qu'on ne rafraîchit pas") : conséquence directe et attendue de l'absence de P2P en mode
// différé — rien ne prévient A en direct quand B agit, puisqu'il n'y a plus de canal live
// du tout. Si A garde son onglet ouvert PENDANT que B agit ailleurs (les deux en même
// temps, comme en plein test), il fallait recharger la page pour s'en apercevoir. Ce
// sondage périodique relit le cloud toutes les quelques secondes et applique s'il y a du
// nouveau, sans jamais avoir besoin d'un F5.
// Voir échange avec Guillaume ("j'aimerais que ce soit quasi instantané") : le vrai temps
// réel vient maintenant de Pusher (voir subscribeToSessionUpdates dans
// realtime-updates.js), déclenché par le serveur à chaque écriture réussie. Ce sondage
// redevient un simple FILET DE SECOURS (au cas où un événement Pusher se perdrait —
// coupure passagère, etc.), d'où un intervalle bien plus large que quand il portait toute
// la réactivité à lui seul.
const DEFERRED_POLL_INTERVAL_MS = 20000;
let deferredPollIntervalId = null;

// Démarre le sondage — sans effet s'il tourne déjà (évite d'empiler plusieurs minuteurs
// si appelé plusieurs fois, ex. depuis uiStartGameAsHost ET uiResumeFromCloud dans la
// même session). Voir stopDeferredPolling pour l'arrêt (mode live, ou changement de rôle).
function startDeferredPolling() {
    if (typeof subscribeToSessionUpdates === 'function' && currentRoomCode) {
        subscribeToSessionUpdates(currentRoomCode, onCloudPusherEvent);
    }
    if (deferredPollIntervalId) return;
    recordSyncTrace('cloud.consume.start', { intervalMs: DEFERRED_POLL_INTERVAL_MS });
    deferredPollIntervalId = setInterval(pollCloudForUpdates, DEFERRED_POLL_INTERVAL_MS);
    // Sondage immédiat dès que l'onglet redevient actif — pas la peine d'attendre le
    // prochain sondage si on vient de revenir dessus après être allé voir ailleurs (autre
    // onglet, autre appli). Toujours utile même avec Pusher : un onglet en arrière-plan
    // peut voir sa connexion WebSocket suspendue par le navigateur.
    document.addEventListener('visibilitychange', onVisibilityChangeForDeferredPolling);
}

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 5) : appelé avec le contenu de l'événement
// Pusher lui-même, plutôt que de systématiquement relire via GET (voir l'ancien
// comportement, où subscribeToSessionUpdates appelait directement pollCloudForUpdates
// sans rien lui passer). Deux formes possibles, décidées côté serveur selon la taille
// (voir api/session.js, PUSHER_EVENT_MAX_BYTES) :
//   - {version, updatedAt, state} : état déjà là, appliqué directement (aucun aller-
//     retour supplémentaire — c'est le vrai gain de latence).
//   - {version, updatedAt} seul : repli, on relit via GET comme avant (pollCloudForUpdates).
// Même garde-fou que pollCloudForUpdates : ne fait rien tant qu'on est pleinement en P2P.
function shouldConsumeCloudUpdates() {
    if (!currentRoomCode || !deals) return false;
    if (myRole === 'host') {
        return deferredRoomMode || (peerConn instanceof NullPeerConnection) || hasDisconnectedOccupiedSeat();
    }
    if (myRole === 'guest') {
        // En différé, le cloud reste la source de convergence entre donnes même quand le
        // P2P fonctionne. En live il ne prend le relais que pendant une coupure P2P.
        return deferredRoomMode || !peerConn || !peerConn.isConnected();
    }
    return false;
}

function onCloudPusherEvent(data) {
    if (!shouldConsumeCloudUpdates()) return;
    recordSyncTrace('cloud.pusher.event', { version: data && data.version, stateIncluded: !!(data && data.state) });
    if (!data || typeof data.version !== 'number' || data.version <= lastKnownCloudVersion) return;
    if (cloudPushInFlight || cloudPushQueued) return; // pas la peine de relire ce qu'on vient tout juste d'envoyer

    if (data.state) {
        applyCloudUpdate(data, { expectedRoomCode: currentRoomCode });
    } else {
        pollCloudForUpdates(); // état pas embarqué (payload trop gros) : repli sur l'ancien chemin
    }
}

function onVisibilityChangeForDeferredPolling() {
    if (document.visibilityState === 'visible') pollCloudForUpdates();
}

// Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : condition de déclenchement du relais
// serveur en mode live — vrai dès qu'un siège RÉELLEMENT OCCUPÉ (pas un robot, pas
// SEAT_PENDING) appartient à un participant actuellement marqué déconnecté. `p.disconnected`
// est déjà tenu à jour côté hôte à chaque connexion/déconnexion P2P (voir
// onGuestConnected et onPeerDisconnected/onSignalingDisconnected côté... hôte, pour les
// invités qui SE déconnectent de lui) — rien de neuf à faire tourner ici, juste une
// lecture de ce qui existe déjà.
function hasDisconnectedOccupiedSeat() {
    return SEATS.some(seat => {
        const occupant = seatAssignment[seat];
        if (!occupant || occupant === SEAT_PENDING) return false;
        const p = participants.find(x => x.id === occupant);
        return !!(p && p.disconnected);
    });
}

function stopDeferredPolling() {
    if (typeof unsubscribeFromSessionUpdates === 'function') unsubscribeFromSessionUpdates();
    if (deferredPollIntervalId) {
        clearInterval(deferredPollIntervalId);
        deferredPollIntervalId = null;
    }
    document.removeEventListener('visibilitychange', onVisibilityChangeForDeferredPolling);
}

async function pollCloudForUpdates() {
    if (!shouldConsumeCloudUpdates()) return;
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : sonde toujours en mode différé pur
    // (NullPeerConnection, inchangé), et DÉSORMAIS AUSSI en mode live dès qu'au moins un
    // siège occupé n'est plus joignable en P2P (voir hasDisconnectedOccupiedSeat) — c'est
    // par ce chemin qu'une annonce poussée en repli serveur par un invité déconnecté
    // (voir pushCallViaServerFallback) est récupérée puis relayée en P2P à qui reste
    // connecté (voir applyCloudUpdate). Tant que tout le monde est en P2P, cette
    // condition est fausse et rien ne se passe ici — aucun coût réseau ajouté au cas
    // normal.
    // La décision de consommer le cloud est centralisée dans shouldConsumeCloudUpdates().
    // Ne sonde pas pendant qu'on est nous-mêmes en train d'écrire (voir pushCloudGameState)
    // — pas la peine de relire ce qu'on vient tout juste d'envoyer.
    if (cloudPushInFlight || cloudPushQueued) return;
    if (typeof pullSessionState !== 'function') return;

    const cloudCtx = captureCloudSyncContext(currentRoomCode);
    try {
        let result = await pullSessionState(cloudCtx.roomCode);
        if (!isCloudSyncContextActive(cloudCtx)) return;
        if (!result || result.version <= lastKnownCloudVersion) return; // rien de neuf
        result = validateCloudSnapshot(result, cloudCtx.roomCode);
        if (!result) return;
        recordSyncTrace('cloud.poll.update', { fromVersion: lastKnownCloudVersion, toVersion: result.version });
        applyCloudUpdate(result, { expectedRoomCode: cloudCtx.roomCode });
    } catch (e) {
        recordSyncTrace('cloud.poll.error', { message: (e && e.message) || String(e) });
        // Panne réseau passagère : tant pis, on retentera au prochain sondage.
    }
}

// Applique un état plus récent trouvé par le sondage, SANS repartir de zéro comme le fait
// uiResumeFromCloud (on est déjà en jeu, pas besoin de revendiquer un siège ni de
// recalculer l'identité — seulement d'absorber ce qui a changé ailleurs).
function applyCloudUpdate(result, options = {}) {
    const expectedRoomCode = options.expectedRoomCode || currentRoomCode;
    const validated = validateCloudSnapshot(result, expectedRoomCode);
    if (!validated) return false;
    const st = validated.state;
    const tracePreviousVersion = lastKnownCloudVersion;
    const traceLocalBoard = boardIndex;
    recordSyncTrace('cloud.apply.begin', { fromVersion: tracePreviousVersion, toVersion: validated.version, localBoard: traceLocalBoard, serverBoard: st.boardIndex });
    const exactServerState = options.serverState ? cloneCloudData(options.serverState) : cloneCloudData(st);
    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : capturé AVANT tout remplacement, pour
    // pouvoir relayer en P2P (plus bas) uniquement ce qui est réellement NOUVEAU apporté
    // par cette mise à jour cloud — jamais question de rejouer tout depuis le début à
    // chaque fois, seulement ce qui manquait.
    const oldBoardIndexForRelay = boardIndex;
    const oldAuctionForRelay = (deals && deals[oldBoardIndexForRelay] && deals[oldBoardIndexForRelay].auctionHistory)
        ? deals[oldBoardIndexForRelay].auctionHistory
        : [];
    const oldAuctionLengthForRelay = oldAuctionForRelay.length;
    // Voir échange avec Guillaume ("chat/sièges via le relais serveur") : même principe,
    // étendu au-delà des seules annonces.
    const oldChatLengthForRelay = chatMessages ? chatMessages.length : 0;
    const oldSeatAssignmentJsonForRelay = JSON.stringify(seatAssignment);
    // R17 — contrairement à l'ancien relais qui ne regardait que `boardIndex`, mémoriser
    // l'historique de TOUTES les donnes avant le remplacement cloud. Un robot serveur peut
    // avancer une donne que l'hôte ne regarde pas ; ses invités doivent tout de même recevoir
    // immédiatement ce suffixe en P2P.
    const oldAuctionHistoriesForDeferredRelay = Array.isArray(deals)
        ? deals.map(deal => cloneAuctionHistoryForWire((deal && deal.auctionHistory) || []))
        : [];
    // R20 — distinguer une vraie mutation visible d'une simple confirmation réseau.
    // On capture AVANT le remplacement cloud l'enchère courante, la structure visible
    // hors enchères, et le chat. Cela permet de choisir ensuite entre zéro rendu,
    // rendu léger d'enchère, ou rendu complet.
    const oldCurrentAuctionForRender = cloneAuctionHistoryForWire(oldAuctionForRelay);
    const oldNonAuctionRenderSignature = currentBoardNonAuctionRenderSignature();
    const oldChatForRender = cloneCloudData(chatMessages || []);

    // R16 — ne jamais laisser un snapshot cloud seulement EN RETARD sur une annonce
    // fraîche locale/P2P raccourcir visuellement la séquence. exactServerState ci-dessus
    // reste, lui, byte-for-byte l'état autoritaire utilisé comme base de CAS/merge.
    st.deals = stabilizeDeferredOptimisticAuctionHistories(st.deals);
    deals = st.deals;
    seatAssignment = st.seatAssignment || seatAssignment;
    participants = st.participants || participants;
    deferredRoomMode = st.deferredRoomMode === true || deferredRoomMode || SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
    autoPassSeats = SEATS.filter(seat => !seatAssignment[seat]);
    st.chatMessages = stabilizeDeferredOptimisticChatMessages(st.chatMessages || []);
    chatMessages = st.chatMessages || [];
    // Voir échange avec Guillaume : la sauvegarde qu'on vient de lire reflète le point de
    // vue de la dernière personne à avoir écrit — elle nous marque, NOUS, comme
    // déconnectés de son point de vue. On corrige immédiatement pour ne pas s'afficher
    // soi-même comme "déconnecté".
    let myEntry = participants.find(p => p.id === myParticipantId);
    if (!myEntry && myRole === 'guest' && isModernGuestParticipantId(myParticipantId)) {
        const recoveredName = guestRoomDisplayName(currentRoomCode, myParticipantId) || savedNickname || defaultParticipantName(myParticipantId);
        myEntry = { id: myParticipantId, name: recoveredName, disconnected: false, disconnectedAt: null };
        participants.push(myEntry);
        st.participants = participants;
        rememberGuestRoomDisplayName(currentRoomCode, myParticipantId, recoveredName);
        recordSyncTrace('cloud.apply.guest-profile-recovered', { participantId: myParticipantId, name: recoveredName });
    }
    if (myEntry) {
        myEntry.disconnected = false;
        myEntry.disconnectedAt = null;
        if (myRole === 'guest' && isModernGuestParticipantId(myParticipantId)) {
            rememberGuestRoomDisplayName(currentRoomCode, myParticipantId, myEntry.name);
        }
    }
    // L'état serveur ne peut pas deviner instantanément qu'un hôte P2P vient de disparaître.
    // Tant que CET invité n'a réellement aucune DataConnection vers l'hôte, son affichage
    // local garde donc l'hôte en rouge ; au succès P2P, onGuestConnected le remet à false.
    if (myRole === 'guest' && (!peerConn || !peerConn.isConnected())) {
        const hostEntry = participants.find(p => p.id === 'host');
        if (hostEntry) {
            hostEntry.disconnected = true;
            if (!hostEntry.disconnectedAt) hostEntry.disconnectedAt = selfDisconnectedAt || Date.now();
        }
    }
    mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);
    lastKnownCloudVersion = validated.version;
    cloudLastSyncedState = exactServerState;

    // Ne touche jamais boardIndex ici : on ne fait pas sauter A d'une donne à l'autre
    // sous ses pieds pendant qu'il regarde — seul un geste explicite de sa part (flèches,
    // vue d'ensemble, avance rapide) doit déplacer la donne affichée.
    if (!deals[boardIndex]) boardIndex = 0;
    if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
    auctionHistory = deals[boardIndex].auctionHistory;

    // Voir ARCHITECTURE-P2P-SERVEUR.md (étape 3) : relais P2P de ce qui vient d'être
    // appris via le cloud — sans ça, un invité resté connecté en P2P ne verrait JAMAIS
    // l'annonce/le message/le changement de siège d'un participant passé par le relais
    // serveur avant que ce dernier ne se reconnecte lui-même (ce qui peut arriver bien
    // après, voire jamais si la partie se termine avant). Seulement si on est encore
    // hôte, avec une vraie connexion P2P (pas NullPeerConnection — rien à relayer en pur
    // mode différé).
    const canRelay = myRole === 'host' && peerConn && !(peerConn instanceof NullPeerConnection);

    // R17 — source de convergence différée : republier en snapshot monotone CHAQUE donne
    // que ce nouvel état cloud vient d'étendre. Cela couvre notamment un robot calculé par
    // api/session.js après une annonce participant, même si le petit événement `call` P2P
    // correspondant n'est jamais celui qui fait évoluer l'écran du guest.
    if (canRelay && deferredRoomMode) {
        const relayedBoards = broadcastDeferredExtendedBoardSnapshots(oldAuctionHistoriesForDeferredRelay);
        if (relayedBoards > 0) pushDebugLog(`${relayedBoards} donne(s) étendue(s) via le cloud, republiée(s) en snapshot P2P différé.`);
    }

    // Annonces : seulement si on est resté sur la MÊME donne (jamais question de relayer
    // un changement de donne par ce canal, seulement des annonces).
    if (canRelay && boardIndex === oldBoardIndexForRelay && auctionHistory.length > oldAuctionLengthForRelay) {
        for (let i = oldAuctionLengthForRelay; i < auctionHistory.length; i++) {
            const entry = auctionHistory[i];
            peerConn.send({ type: 'call', boardIndex, seat: entry.seat, call: entry.call, explanation: entry.explanation });
        }
        pushDebugLog(`${auctionHistory.length - oldAuctionLengthForRelay} annonce(s) apprise(s) via le cloud, relayée(s) en P2P.`);
    }

    // Voir échange avec Guillaume ("vérifie s'il n'y a pas des problèmes de même ordre") :
    // le cas INVERSE ci-dessus (l'historique RACCOURCIT) manquait entièrement — c'est
    // exactement ce qui se produit quand un participant en repli serveur fait son propre
    // undo (voir pushUndoViaServerFallback) : sans ce relais, un invité resté connecté en
    // P2P ne voyait jamais qu'une annulation avait eu lieu ailleurs, tant qu'il ne se
    // reconnectait pas lui-même.
    if (canRelay && boardIndex === oldBoardIndexForRelay && auctionHistory.length < oldAuctionLengthForRelay) {
        peerConn.send({ type: 'undo-apply', boardIndex, newLength: auctionHistory.length });
        pushDebugLog(`Annulation apprise via le cloud (historique ramené à ${auctionHistory.length} annonce(s)), relayée en P2P.`);
    }

    // Messages de chat : en LIVE seulement, un message appris via le cloud peut être
    // relayé vers les pairs qui ne consomment pas nécessairement le cloud. En DIFFÉRÉ,
    // tous les clients consomment déjà le cloud en permanence ; un relais P2P supplémentaire
    // ferait notamment revenir au sender son propre message déjà affiché localement et
    // créerait un doublon. R14 garde donc une seule voie de convergence pour le chat différé.
    if (canRelay && !deferredRoomMode && chatMessages.length > oldChatLengthForRelay) {
        for (let i = oldChatLengthForRelay; i < chatMessages.length; i++) {
            peerConn.send(chatMessages[i]);
        }
        pushDebugLog(`${chatMessages.length - oldChatLengthForRelay} message(s) de chat appris via le cloud, relayé(s) en P2P.`);
    }

    // Changement de sièges (voir échange avec Guillaume) : diffuse l'état complet des
    // sièges plutôt qu'un delta (contrairement aux deux ci-dessus) — broadcastLobbyState
    // envoie déjà tout ce qu'il faut (participants, seatAssignment, autoPassSeats), pas
    // la peine de reconstruire un message dédié pour ça.
    if (canRelay && JSON.stringify(seatAssignment) !== oldSeatAssignmentJsonForRelay) {
        broadcastLobbyState();
        pushDebugLog('Changement de sièges appris via le cloud, relayé en P2P.');
    }

    // R20 — ne plus reconstruire systématiquement tout le plateau à chaque ACK/poll.
    // 1) changement structurel visible (sièges, présence, DD/PAR, donne...) => rendu complet ;
    // 2) simple extension monotone de l'enchère => même rendu léger qu'un `call` normal ;
    // 3) confirmation réseau sans changement visible => aucun rendu du plateau.
    const newNonAuctionRenderSignature = currentBoardNonAuctionRenderSignature();
    const currentAuctionChanged = !sameCloudData(oldCurrentAuctionForRender, auctionHistory);
    const currentAuctionExtended = currentAuctionChanged
        && oldCurrentAuctionForRender.length < auctionHistory.length
        && auctionCallsArePrefixForDeferredSnapshot(oldCurrentAuctionForRender, auctionHistory);
    const nonAuctionVisibleChanged = oldNonAuctionRenderSignature !== newNonAuctionRenderSignature;
    const chatVisibleChanged = !sameCloudData(oldChatForRender, chatMessages || []);

    if (nonAuctionVisibleChanged || (currentAuctionChanged && !currentAuctionExtended)) {
        renderBoard();
        recordSyncTrace('cloud.apply.render-full', { version: lastKnownCloudVersion, auctionChanged: currentAuctionChanged, structuralChanged: nonAuctionVisibleChanged });
    } else if (currentAuctionExtended) {
        renderAfterNormalCall();
        recordSyncTrace('cloud.apply.render-auction-only', { version: lastKnownCloudVersion, fromLength: oldCurrentAuctionForRender.length, toLength: auctionHistory.length });
    } else {
        recordSyncTrace('cloud.apply.render-skipped-identical', { version: lastKnownCloudVersion, auctionLength: auctionHistory.length });
    }

    // Si renderBoard() a été exécuté, il a déjà rafraîchi chat/roomBoard lorsque le
    // panneau est ouvert. Sinon, un changement de chat seul doit tout de même apparaître.
    if (chatPanelOpen && chatVisibleChanged && !nonAuctionVisibleChanged && !(currentAuctionChanged && !currentAuctionExtended)) {
        renderRoomBoard();
        renderChat();
    }

    // La vue d'ensemble peut être ouverte pendant qu'une AUTRE donne progresse. Le rendu
    // principal reste alors intact, mais la miniature/liste doit suivre cette progression.
    const overview = document.getElementById('boardOverviewModal');
    if (overview && overview.style.display !== 'none') {
        const newAuctionHistoriesForOverview = Array.isArray(deals)
            ? deals.map(deal => cloneAuctionHistoryForWire((deal && deal.auctionHistory) || []))
            : [];
        if (!sameCloudData(oldAuctionHistoriesForDeferredRelay, newAuctionHistoriesForOverview)) renderBoardOverview();
    }
    recordSyncTrace('cloud.apply.end', { version: lastKnownCloudVersion, localBoard: boardIndex, preservedBoard: boardIndex === traceLocalBoard });
    return true;
}

// Voir échange avec Guillaume ("les enchères de B n'apparaissent toujours pas") : le
// `keepalive` ajouté précédemment protège une requête déjà EN COURS, mais pas une requête
// qui n'a encore jamais été émise — or c'est exactement ce qui peut arriver avec la file
// d'attente ci-dessus (cloudPushQueued) : si l'onglet se ferme pendant qu'un envoi attend
// simplement son tour, ce tour peut ne jamais venir, la page étant coupée avant même que
// ce code n'ait la moindre chance de s'exécuter. Ce filet de sécurité est indépendant de
// cette file : déclenché explicitement à la fermeture/mise en arrière-plan de l'onglet
// (voir 'pagehide' plus bas), il relit l'état à cet instant précis et l'envoie une
// dernière fois, sans jamais attendre son tour derrière un envoi en cours.
function preserveLatestCloudStateBeforeSuspend(allowDirectKeepalive = true) {
    if (myRole !== 'host' || !deals || !currentRoomCode) return;
    const ctx = captureCloudSyncContext(currentRoomCode);
    const payload = buildCloudStatePayload();
    // Toujours conserver localement le dernier snapshot + sa base serveur. Si la page est
    // détruite pendant qu'un PUT plus ancien est encore en vol, on ne peut pas connaître
    // sa future version sans aide serveur ; ce marqueur permet une vraie réconciliation
    // trois voies à la prochaine reprise au lieu de perdre silencieusement la dernière action.
    rememberCloudExitRecovery(ctx.roomCode, payload);
    if (typeof pushSessionState !== 'function') return;

    // S'il n'y a AUCUN PUT en cours, le keepalive existant reste le meilleur chemin : la
    // requête est déjà émise avant destruction de la page. S'il y en a un, surtout ne pas
    // envoyer un second snapshot avec le même expectedVersion (409 garanti) ni deviner
    // expectedVersion+1 (qui pourrait écraser une écriture concurrente distante).
    if (allowDirectKeepalive && !cloudPushInFlight) {
        const participantCredential = currentClientParticipantCredentialForCloudWrite();
        if (currentClientHasHostCloudWriteAuthority() || participantCredential) {
            pushSessionState(ctx.roomCode, payload, lastKnownCloudVersion, { participantCredential });
        }
    }
}

// R23 — fermeture volontaire d'un client invité : prévenir l'hôte pendant que
// la DataChannel est encore vivante. `pagehide.persisted` (BFCache) n'est PAS une vraie
// sortie et ne doit pas faire clignoter la présence. Une perte réseau brutale reste couverte
// par `onPeerDisconnected` côté hôte.
function notifyHostGuestLeavingBeforePageHide(event) {
    if (event && event.persisted) return false;
    if (myRole !== 'guest' || !peerConn || typeof peerConn.isConnected !== 'function' || !peerConn.isConnected()) return false;
    try {
        peerConn.send({ type: 'presence-leaving' });
        recordSyncTrace('presence.guest.pagehide-sent');
        return true;
    } catch (e) {
        recordSyncTrace('presence.guest.pagehide-send-failed', { message: (e && e.message) || String(e) });
        return false;
    }
}

// visibilitychange arrive généralement avant pagehide : déclencher la file normale ici
// donne au PUT sérialisé une chance de finir pendant que le document existe encore.
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
        preserveLatestCloudStateBeforeSuspend(false);
        if (!cloudPushInFlight) pushCloudGameState();
        else cloudPushQueued = true;
        return;
    }
    if (document.visibilityState === 'visible' && myRole === 'host' && deals) {
        const me = participants.find(p => p.id === myParticipantId);
        if (me && me.disconnected) {
            me.disconnected = false;
            me.disconnectedAt = null;
        }
        pushCloudGameState();
    }
});
window.addEventListener('pagehide', (event) => {
    notifyHostGuestLeavingBeforePageHide(event);
    preserveLatestCloudStateBeforeSuspend(true);
});

// Interroge le cloud pour ce code de salon et, si un état y est trouvé, reprend
// directement la partie (voir échange avec Guillaume : "reprendre automatiquement, sans
// demander" — plus de bannière de confirmation intermédiaire). Renvoie true si une reprise
// a effectivement été lancée (pour que l'appelant sache s'il doit encore afficher son
// propre message d'erreur "Aucune partie trouvée" ou non).
async function offerCloudResume(code) {
    if (typeof pullSessionState !== 'function') return false;
    // Voir échange avec Guillaume ("la ligne 'Reprise hôte' n'apparaît pas dans le
    // journal combiné") : même correctif que uiResumeHostSession — posé tôt pour que les
    // lignes journalisées ici remontent bien vers le journal partagé de la salle.
    currentRoomCode = code;
    const cloudCtx = captureCloudSyncContext(code);
    let result = null;
    let normalPullError = null;

    // 1) Chemin normal : capacité déjà mémorisée sur cet appareil (live ou différé).
    try {
        result = await pullSessionState(code);
        if (!isCloudSyncContextActive(cloudCtx)) return false;
    } catch (e) {
        normalPullError = e;
    }

    // 2) Nouveau chemin "code seul" : si cet appareil ne connaît encore aucun secret,
    // essayer la capacité déterministe réservée aux salles DIFFÉRÉES. Une salle live
    // conserve sa clé aléatoire : cette tentative y échoue simplement avec 401/403.
    if (!result && typeof pullDeferredSessionStateByCode === 'function') {
        try {
            result = await pullDeferredSessionStateByCode(code);
            if (!isCloudSyncContextActive(cloudCtx)) return false;
            if (result && typeof deferredCodeOnlyParticipantCredential === 'function') {
                const credential = deferredCodeOnlyParticipantCredential(code);
                if (credential) rememberGuestRoomCredential(code, credential);
            }
        } catch (e) {
            // Même sémantique que l'ancien chemin : l'échec cloud ne doit pas produire un
            // écran différent tant qu'on ne sait pas qu'une session existe réellement.
        }
    }

    if (!result) {
        if (normalPullError) {
            pushDebugLog('Reprise cloud : aucune session accessible pour ce code (' + ((normalPullError && normalPullError.message) || normalPullError) + ').');
        }
        return false;
    }

    result = prepareCloudResumeCandidate(result, code);
    if (!result) return false;

    cloudResumeCandidate = result;
    showConnectingOverlay('Reprise de la partie…');
    uiResumeFromCloud();
    return true;
}

// Reprend effectivement la partie depuis l'état cloud trouvé par offerCloudResume — voir
// le long commentaire en tête de section pour la logique de revendication de siège.
function uiResumeFromCloud() {
    if (!cloudResumeCandidate) return;
    const candidate = cloudResumeCandidate;
    const st = cloneCloudData(candidate.state);
    const codeToReclaim = st.roomCode || currentRoomCode;
    const hostToken = getReconnectToken();
    const creatorToken = st.roomCreatorToken || st.hostReconnectToken || null;
    const isCreatorResume = !!creatorToken && hostToken === creatorToken;

    const guestCredential = isCreatorResume ? null : getGuestRoomCredential(codeToReclaim, true);
    const myToken = isCreatorResume ? hostToken : (guestCredential ? guestCredential.participantId : null);
    if (!myToken || !isSafeParticipantId(myToken)) {
        hideConnectingOverlay();
        showLandingError('Impossible de restaurer une identité locale sécurisée pour cette salle.');
        return;
    }

    if (!Array.isArray(st.participants)) st.participants = [];
    if (!st.seatAssignment || typeof st.seatAssignment !== 'object') {
        hideConnectingOverlay();
        showLandingError('État de salle invalide : assignation des sièges absente.');
        return;
    }

    if (isCreatorResume) {
        // Le créateur reprend la vraie identité réseau `host`. Les snapshots différés
        // récents peuvent avoir mémorisé sa place sous son token persistant : normaliser
        // les deux formes avant de recréer la salle P2P.
        SEATS.forEach(seat => {
            if (st.seatAssignment[seat] === myToken || st.seatAssignment[seat] === 'host') {
                st.seatAssignment[seat] = 'host';
            }
        });
        const tokenEntry = st.participants.find(p => p && p.id === myToken);
        const hostEntry = st.participants.find(p => p && p.id === 'host');
        if (tokenEntry && hostEntry && tokenEntry !== hostEntry) {
            Object.assign(hostEntry, tokenEntry, { id: 'host' });
            st.participants = st.participants.filter(p => p !== tokenEntry);
        } else if (tokenEntry) {
            tokenEntry.id = 'host';
        } else if (!hostEntry) {
            st.participants.push({ id: 'host', name: savedNickname || st.roomCreatorName || 'Hôte' });
        }
    } else {
        // Un participant reprend TOUJOURS son vrai rôle invité. C'était la grosse
        // régression : la reprise cloud le promouvait en `host` + NullPeerConnection,
        // coupant définitivement sa reconnexion P2P et mélangeant ses écritures avec les
        // snapshots d'autorité hôte.
        let claimedSeat = SEATS.find(seat => st.seatAssignment[seat] === myToken);
        if (!claimedSeat) {
            claimedSeat = SEATS.find(seat => st.seatAssignment[seat] === SEAT_PENDING);
            if (claimedSeat) st.seatAssignment[claimedSeat] = myToken;
        }
        const resumedGuestEntry = st.participants.find(p => p && p.id === myToken);
        if (!resumedGuestEntry) {
            const recoveredName = guestRoomDisplayName(codeToReclaim, myToken) || savedNickname || defaultParticipantName(myToken);
            st.participants.push({
                id: myToken,
                name: recoveredName,
                ...(normalizeAvatarColor(savedAvatarColor) ? { avatarColor: normalizeAvatarColor(savedAvatarColor) } : {})
            });
            rememberGuestRoomDisplayName(codeToReclaim, myToken, recoveredName);
            recordSyncTrace('resume.cloud.guest-profile-recovered', { participantId: myToken, name: recoveredName });
        } else {
            rememberGuestRoomDisplayName(codeToReclaim, myToken, resumedGuestEntry.name);
        }
    }

    deals = st.deals;
    if (!Array.isArray(deals) || deals.length === 0) {
        hideConnectingOverlay();
        showLandingError('Cette session ne contient aucune donne exploitable.');
        return;
    }
    seatAssignment = st.seatAssignment;
    participants = st.participants;
    deferredRoomMode = st.deferredRoomMode === true || SEATS.some(seat => seatAssignment[seat] === SEAT_PENDING);
    // Fallback seulement. En différé, la vraie donne d'arrivée est choisie un peu plus bas,
    // APRÈS restauration de mon identité et de mes sièges : première donne 1→N qui attend
    // effectivement une de mes annonces. En live, le créateur conserve sa dernière donne.
    const resumeFallbackBoardIndex = isCreatorResume && Number.isInteger(st.boardIndex) && st.boardIndex >= 0 && st.boardIndex < deals.length
        ? st.boardIndex
        : 0;
    boardIndex = resumeFallbackBoardIndex;
    if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
    auctionHistory = deals[boardIndex].auctionHistory;
    autoPassSeats = SEATS.filter(seat => !seatAssignment[seat]);
    chatMessages = st.chatMessages || [];
    roomCreatorName = st.roomCreatorName || (participants.find(p => p.id === 'host') || {}).name || 'Hôte';
    roomCreatorToken = creatorToken || null;
    currentHostReconnectToken = st.hostReconnectToken || creatorToken || null;
    currentRoomCode = codeToReclaim;
    ensureCloudSyncContext(codeToReclaim);

    // IMPORTANT : préserver l'état de présence partagé des AUTRES joueurs. Une reprise
    // locale n'est pas une preuve qu'ils sont hors ligne. Seule ma propre entrée est
    // réactivée ; les événements P2P et les mutations participant serveur feront évoluer
    // le reste. L'ancien code marquait systématiquement "tout le monde sauf moi" rouge,
    // puis republiait cette opinion comme vérité commune.
    myRole = isCreatorResume ? 'host' : 'guest';
    myParticipantId = isCreatorResume ? 'host' : myToken;
    if (myRole === 'host') advanceRobotBidsOnAllBoards(boardIndex);
    recordSyncTrace('resume.cloud.role-resolved', { creatorResume: isCreatorResume, version: candidate.version, participantId: myParticipantId });
    const me = participants.find(p => p && p.id === myParticipantId);
    if (me) { me.disconnected = false; me.disconnectedAt = null; }
    mySeats = SEATS.filter(seat => seatAssignment[seat] === myParticipantId);

    // R24 — une fermeture/réouverture n'est pas une navigation volontaire : en différé,
    // remettre le joueur directement sur son premier travail restant, dans l'ordre des
    // donnes. Si aucune donne ne l'attend actuellement, conserver le fallback historique
    // (dernière donne du créateur, donne 1 du partenaire) plutôt que d'inventer un saut.
    if (deferredRoomMode) {
        const firstWaitingBoard = findFirstBoardWaitingForSeats(mySeats, deals);
        if (firstWaitingBoard >= 0) boardIndex = firstWaitingBoard;
        else boardIndex = resumeFallbackBoardIndex;
        if (!deals[boardIndex].auctionHistory) deals[boardIndex].auctionHistory = [];
        auctionHistory = deals[boardIndex].auctionHistory;
    }

    if (isCreatorResume) loadHostGuestReconnectSecrets(codeToReclaim);
    else guestReconnectSecretsByParticipantId = {};

    // Installer la base de version AVANT toute écriture de présence/claim : le premier PUT
    // participant doit partir du snapshot effectivement lu, pas d'une version 0 héritée
    // d'un ancien contexte.
    lastKnownCloudVersion = candidate.version;
    cloudLastSyncedState = cloneCloudData(candidate._serverState || candidate.state);
    cloudSyncRoomCode = String(codeToReclaim);
    cloudResumeCandidate = null;

    guestIndexByToken = {};
    hostPendingUndo = null;
    hostTransferInProgress = false;
    prevSeatAssignmentSnapshot = null;
    prevParticipantsDisconnectedSnapshot = null;

    if (peerConn) peerConn.destroy();
    if (isCreatorResume) {
        const resumeOnOpenExtra = () => {
            renderReconnectButton();
            if (deals) renderBoard(); else renderLobby();
        };
        peerConn = new BridgePeerConnection(buildHostHandlers(resumeOnOpenExtra));
        peerConn.handlers.onError = (err) => {
            if (err && err.type === 'unavailable-id') {
                pushDebugLog('Impossible de recréer la salle hôte (code pas encore libéré côté serveur) — nouvel essai dans un instant.');
                setTimeout(() => {
                    if (myRole !== 'host' || (peerConn && peerConn.signalingOpen)) return;
                    if (peerConn) peerConn.destroy();
                    peerConn = new BridgePeerConnection(buildHostHandlers(resumeOnOpenExtra));
                    peerConn.createRoom(6, codeToReclaim);
                }, 1500);
                return;
            }
            pushDebugLog("Échec de la recréation de la salle hôte : " + ((err && (err.message || err.type)) || err));
        };
        peerConn.createRoom(6, codeToReclaim);
    } else {
        // La partie est déjà active via le cloud : empêcher les callbacks d'une ancienne
        // tentative de join de reprendre la main, puis reconstruire immédiatement une vraie
        // connexion invitée en arrière-plan avec LA MÊME credential.
        guestJoinAttemptToken++;
        everConnectedAsGuest = true;
        selfDisconnectedAt = selfDisconnectedAt || Date.now();
        markGuestActiveRoom(codeToReclaim);
        peerConn = null;
    }

    startDeferredPolling();
    hideConnectingOverlay();
    enterGameScreen();

    if (isCreatorResume) {
        saveHostGameStateToStorage();
    } else {
        // Ce PUT participant fait deux choses atomiquement côté serveur : revendique la
        // place PENDING si nécessaire et remet MA présence à connected. Il n'a jamais le
        // droit de réécrire la présence des autres participants.
        pushCloudGameState();
        attemptGuestAutoReconnect();
    }

    if (deals.every(d => isAuctionOver(d.auctionHistory || []))) uiOpenBoardOverview();
    const missingDD = deals.filter(d => !d.par && !d.ddTable);
    if (missingDD.length > 0) kickOffBackgroundDD(missingDD);
    if (!chatPanelOpen) uiToggleChat(false);
}



// ===== Gestes tactiles mobile =====
// Le swipe horizontal entre donnes et le bounce vertical simulé ont été retirés.
// Sur mobile, le défilement vertical revient au comportement inertiel natif du navigateur
// (notamment le rubber-band iOS), plus naturel et moins coûteux sur les anciens iPhone.

window.addEventListener('DOMContentLoaded', () => {
    recordPlayPerfMilestone('dom-content-loaded');
    scheduleServiceWorkerInit();
    initIosInstallHint();
    initIosLockScreenWarning();
    initMobileRoomCodeKeypad();
    initOfflineHandling();
    initChatVisibilityTracking();

    // Le bouton de reconnexion reste réévalué en continu plutôt que de compter sur CHAQUE
    // scénario de rétablissement pour appeler explicitement renderReconnectButton() au
    // bon moment (une reconnexion ICE peut notamment se rétablir sans passer par tous nos
    // gestionnaires). L'ancienne bannière persistante est désormais un no-op et n'a plus
    // besoin de son propre timer périodique.
    setInterval(renderReconnectButton, 1000);

    const params = new URLSearchParams(window.location.search);
    // Compatibilité avec les liens sécurisés des builds précédents : si un ancien
    // ?room=XXXX#access=<capacité> est ouvert, on mémorise encore la capacité avant toute
    // tentative P2P/cloud puis on l'efface de l'URL. Les NOUVEAUX liens copiés sont courts
    // et ne contiennent plus cette capacité (voir buildRoomShareUrl).
    rememberRoomAccessFromUrl(params);
    const room = params.get('room');
    // Voir échange avec Guillaume (session du 23 juillet — reprise via localStorage) :
    // vérifiée AVANT le traitement du paramètre ?room= ci-dessous — si ce paramètre
    // correspond justement à la salle qu'on peut reprendre, la bannière de reprise prend
    // le pas : tenter de la rejoindre comme invité échouerait ou n'importe pas puisqu'on
    // est en réalité toujours son hôte légitime. Si le code diffère (lien d'un tiers), le
    // traitement normal du paramètre reste inchangé — la bannière de reprise s'affiche
    // simplement EN PLUS, comme une option indépendante.
    const resumableSessions = checkForResumableHostSession();
    let matchingResumable = room && resumableSessions.find(s => s.roomCode === room.toUpperCase());
    // Migration d'une installation antérieure : pour un lien direct vers UNE salle précise,
    // on accepte exceptionnellement le gros parse afin de ne jamais rater une reprise hôte.
    // L'accueil normal, lui, reste non bloquant et migre l'index en idle.
    if (room && !matchingResumable && readResumableHostIndexFast() === null) {
        matchingResumable = readResumableHostState(room.toUpperCase());
    }

    // Voir échange avec Guillaume (session du 23 juillet) — voir HOSTING_PREGAME_KEY plus
    // haut : si ce code correspond à une salle qu'on hébergeait nous-même, encore dans le
    // salon, juste avant ce rechargement, elle est morte de toute façon (rien n'est
    // persistant côté hôte avant le lancement) — pas la peine de tenter (et échouer) à la
    // rejoindre comme invité. On nettoie l'URL et le marqueur, puis on atterrit sur un
    // accueil propre, sans code préempli ni tentative de connexion.
    let wasHostingThisPregame = false;
    try { wasHostingThisPregame = room && sessionStorage.getItem(HOSTING_PREGAME_KEY) === room; } catch (e) { /* tant pis */ }
    if (wasHostingThisPregame) {
        clearHostingPregameMark();
        const url = new URL(window.location.href);
        url.searchParams.delete('room');
        window.history.replaceState(null, '', url.toString());
    } else if (matchingResumable) {
        // Voir échange avec Guillaume ("je devrais être versé directement dedans") : le
        // lien pointe explicitement vers CETTE salle, sur l'appareil qui en est bien
        // l'hôte légitime — aucune ambiguïté à lever, contrairement à un code tapé à la
        // main sans certitude d'être le bon. On masque la bannière (elle ferait
        // doublon) et on reprend directement, via uiResumeHostSession(roomCode) —
        // désormais consciente du cloud (voir plus bas), donc jamais périmée même si un
        // partenaire a enchéri depuis un autre appareil entre-temps.
        const banner = document.getElementById('resumeSessionBanner');
        if (banner) banner.style.display = 'none';
        uiResumeHostSession(matchingResumable.roomCode);
    } else if (room && navigator.onLine) {
        document.getElementById('joinCodeInput').value = room.toUpperCase();
        uiJoinRoom();
    } else if (room) {
        // Lien de partage ouvert hors-ligne : on préremplit le code, mais on ne tente pas
        // la connexion (updateOfflineUI, appelé juste au-dessus par initOfflineHandling,
        // a déjà désactivé le bouton "Rejoindre" — la personne devra réessayer une fois
        // reconnectée).
        document.getElementById('joinCodeInput').value = room.toUpperCase();
    }

    const dealFileInput = document.getElementById('dealFileInput');
    if (dealFileInput) {
        dealFileInput.addEventListener('change', uiHandleDealFileChosen);
    }
});
